package com.akila.incentive.notifications;

import java.math.BigDecimal;

/**
 * @author 
 *
 */
public class NotificationValues {

	private BigDecimal values;
	
	private BigDecimal points;

	public NotificationValues(BigDecimal values, BigDecimal points) {
		super();
		this.values = values;
		this.points = points;
	}

	public BigDecimal getValues() {
		return values;
	}

	public void setValues(BigDecimal values) {
		this.values = values;
	}

	public BigDecimal getPoints() {
		return points;
	}

	public void setPoints(BigDecimal points) {
		this.points = points;
	}

	@Override
	public String toString() {
		return "NotificationValues [values=" + values + ", points=" + points + "]";
	}
	
}
