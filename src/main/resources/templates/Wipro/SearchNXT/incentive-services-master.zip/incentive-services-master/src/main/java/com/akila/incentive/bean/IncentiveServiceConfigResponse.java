package com.akila.incentive.bean;

import com.akila.AkilaResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties
public class IncentiveServiceConfigResponse extends AkilaResponse {

	private String refCodeId;

	private String serviceMnemonic;

	private String endPoint;

	private String methodType;

	private String queryParam;

	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public String getServiceMnemonic() {
		return serviceMnemonic;
	}

	public void setServiceMnemonic(String serviceMnemonic) {
		this.serviceMnemonic = serviceMnemonic;
	}

	public String getEndPoint() {
		return endPoint;
	}

	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}

	public String getMethodType() {
		return methodType;
	}

	public void setMethodType(String methodType) {
		this.methodType = methodType;
	}

	public String getQueryParam() {
		return queryParam;
	}

	public void setQueryParam(String queryParam) {
		this.queryParam = queryParam;
	}

	@Override
	public String toString() {
		return "IncentiveServiceConfigResponse [refCodeId=" + refCodeId + ", serviceMnemonic=" + serviceMnemonic
				+ ", endPoint=" + endPoint + ", methodType=" + methodType + ", queryParam=" + queryParam + "]";
	}

}
