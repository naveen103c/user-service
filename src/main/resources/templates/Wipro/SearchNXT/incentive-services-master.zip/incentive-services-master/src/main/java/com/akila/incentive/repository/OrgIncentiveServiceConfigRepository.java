package com.akila.incentive.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgIncentiveServiceConfigRepository extends JpaRepository<com.akila.incentive.entity.OrgIncentiveServiceConfig, String> {

}
