package com.akila.incentive.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.incentive.entity.OrgUserIncentiveMetric;
import com.akila.incentive.entity.OrgUserIncentiveMetricPK;
import com.akila.incentive.metric.bean.IncentiveUserMetric;
import com.akila.incentive.metric.bean.IncentiveUserMetricResponse;

@Repository
public interface OrgUserIncentiveMetricRepository extends JpaRepository<OrgUserIncentiveMetric, OrgUserIncentiveMetricPK>,PagingAndSortingRepository<OrgUserIncentiveMetric, OrgUserIncentiveMetricPK> {

	List<OrgUserIncentiveMetric> findByIdRefCodeIdInAndIdUserIdInAndIdMetricPeriodCd(List<String> ids,List<String> userIds, Integer periodCd);

	List<OrgUserIncentiveMetric> findByIdRefCodeIdInAndIdUserIdInAndIdMetricPeriodCdAndIdMetricPeriodDt(List<String> ids,List<String> userIds, Integer periodCd,
			Date date);

	List<OrgUserIncentiveMetric> findByIdRefCodeIdInAndIdUserIdInAndIdMetricPeriodCdAndIdMetricPeriodDtGreaterThanEqualAndIdMetricPeriodDtLessThan(
			List<String> ids,List<String> iuserIds, Integer periodCd, Date startDate, Date endDate);
	
	
	// For Fetching Metric Data
	@Query(value = "SELECT new com.akila.incentive.metric.bean.IncentiveUserMetricResponse( "
			+ "(o.id.userId) ,(SUM(o.count)),(SUM(o.point))) "
			+ "FROM OrgUserIncentiveMetric o where o.id.metricPeriodCd = (:metricPeriodCd) "
			+ "and date_part('year', metric_period_dt) = (:year)  " 
			+ "and date_part('month', metric_period_dt)  = (:month) "
			+ "group by o.id.userId order by SUM(o.point) desc")
	List<IncentiveUserMetricResponse> getUserIncentiveMetricListForMetricPeriodCd(@Param("metricPeriodCd") Integer metricPeriodCd,Pageable paging, @Param("month") Integer month, @Param("year") Integer year);
	
	@Query(value = "SELECT new com.akila.incentive.metric.bean.IncentiveUserMetric((o.id.userId),"
			+ "(o.id.refCodeId) ,(SUM(o.count)),(SUM(o.point))) "
			+ "FROM OrgUserIncentiveMetric o where o.id.metricPeriodCd = (:metricPeriodCd) "
			+ "and date_part('year', metric_period_dt) = (:year) " 
			+ "and date_part('month', metric_period_dt)  = (:month) and o.id.userId in (:ids) "
			+ "group by o.id.userId,o.id.refCodeId")
	List<IncentiveUserMetric> getUserIncentiveMetricListForMetric(@Param("metricPeriodCd") Integer metricPeriodCd, @Param("ids") List<String> ids,@Param("month") Integer month, @Param("year") Integer year);

}
