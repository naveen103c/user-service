package com.akila.incentive.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.incentive.entity.OrgIncentiveQueue;

@Repository
public interface OrgIncentiveQueueRepository extends JpaRepository<OrgIncentiveQueue, String> {

	public List<OrgIncentiveQueue> findByStatus(int status);

}
