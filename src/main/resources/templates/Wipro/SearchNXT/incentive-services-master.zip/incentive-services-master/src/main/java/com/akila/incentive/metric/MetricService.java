package com.akila.incentive.metric;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.incentive.metric.bean.IncentiveUserMetric;
import com.akila.incentive.metric.bean.IncentiveUserMetricResponse;
import com.akila.incentive.repository.OrgUserIncentiveMetricRepository;

@Service
public class MetricService extends AkilaService {

@Autowired
OrgUserIncentiveMetricRepository orgUserIncentiveMetricRepository;
	
	public List<IncentiveUserMetricResponse> getTopUserMetric(Integer periodCd,
			Integer count , Integer month, Integer year) {
		List<IncentiveUserMetricResponse> incentiveUserMetricResponseList = new ArrayList<IncentiveUserMetricResponse>();
		Pageable paging = PageRequest.of(0, count, Sort.by("id.userId").descending());
		incentiveUserMetricResponseList = orgUserIncentiveMetricRepository.getUserIncentiveMetricListForMetricPeriodCd(periodCd,paging , month,year);
		
		List<String> ids = new ArrayList<String>();
		
		//Set User Position and get user_id list
		int position = 0;
		for (IncentiveUserMetricResponse incentiveUserMetricResponse : incentiveUserMetricResponseList) {
			incentiveUserMetricResponse.setPosition(++position);
			ids.add(incentiveUserMetricResponse.getUserId());
		}
		
		List<IncentiveUserMetric>  incentiveUserMatricList = orgUserIncentiveMetricRepository.getUserIncentiveMetricListForMetric(periodCd,ids,month,year);
		
		for (IncentiveUserMetric incentiveUserMatric : incentiveUserMatricList) {
			for (IncentiveUserMetricResponse incentiveUserMetricResponse : incentiveUserMetricResponseList) {
				if(incentiveUserMetricResponse.getUserId().equalsIgnoreCase(incentiveUserMatric.getUserId())) {
					incentiveUserMetricResponse.getUserMetric().add(incentiveUserMatric);
				}
			}
		}
		return incentiveUserMetricResponseList;
	}

}
