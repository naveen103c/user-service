package com.akila.incentive.config;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.incentive.config.bean.ConfigMapper;
import com.akila.incentive.config.bean.ConfigRequest;
import com.akila.incentive.config.bean.ConfigResponse;
import com.akila.incentive.entity.OrgConfig;
import com.akila.incentive.repository.OrgConfigRepository;
import com.akila.response.ResponseId;

@Service
public class ConfigService extends AkilaService {

	@Autowired
	private OrgConfigRepository orgConfigRepository;


	@Autowired
	private ConfigMapper configMapper;

	public List<ConfigResponse> getAllConfig() {
		return this.orgconfgListToConfigResponseList(orgConfigRepository.findAll());
	}
	
	public ResponseId updateConfig(ConfigRequest configRequest) {
			OrgConfig orgConfig = configMapper.configRequestToOrgConfig(configRequest);
			OrgConfig oldOrgRating = orgConfigRepository.findById(configRequest.getRefCodeId()).orElse(null);
			orgConfig.setCrtBy(oldOrgRating.getCrtBy());
			orgConfig.setCrtTs(oldOrgRating.getCrtTs());
			orgConfig.setModBy(super.getUserId());
			orgConfig.setModTs(new Timestamp(System.currentTimeMillis()));
			orgConfigRepository.save(orgConfig);
			return new ResponseId(configRequest.getRefCodeId());
	}
	
	public List<ConfigResponse> orgconfgListToConfigResponseList(List<OrgConfig> orgRatingList) {
		List<ConfigResponse> response = new ArrayList<ConfigResponse>();
		for (OrgConfig orgConfig : orgRatingList) {
			ConfigResponse configResponse = configMapper.orgconfgToConfigResponse(orgConfig);
			configResponse.setRefCodeDescription(orgConfig.getOrgRefCode().getRefCodeDescription());
			configResponse.setRefCodeDisplayVal(orgConfig.getOrgRefCode().getRefCodeDisplayVal());
			configResponse.setRefCodeStoreVal(orgConfig.getOrgRefCode().getRefCodeStoreVal());
			response.add(configResponse);
		}
		return response;
	}

}
