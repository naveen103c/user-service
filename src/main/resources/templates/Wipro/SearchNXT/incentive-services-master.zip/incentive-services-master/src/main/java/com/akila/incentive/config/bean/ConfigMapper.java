package com.akila.incentive.config.bean;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;
import com.akila.incentive.entity.OrgConfig;

@Mapper(componentModel = "spring")
public interface ConfigMapper {
	ConfigMapper INSTANCE = Mappers.getMapper(ConfigMapper.class);;


	List<ConfigResponse> orgconfgListToConfigResponseList(List<OrgConfig> orgConfigList);
	  

	ConfigResponse orgconfgToConfigResponse(OrgConfig orgConfig);

	@Mappings({})
	OrgConfig configRequestToOrgConfig(ConfigRequest configRequest);


}
