package com.akila.incentive.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.akila.AkilaEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * The persistent class for the org_incentive_config database table.
 * 
 */
@Entity
@Table(name = "org_incentive_config")
@NamedQuery(name = "OrgConfig.findAll", query = "SELECT o FROM OrgConfig o")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class OrgConfig extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ref_code_id")
	private String refCodeId;

	@Column(name = "positive_points")
	private Integer positivePoints;

	@Column(name = "negative_points")
	private Integer negativePoints;

	@Column(name = "max_actions")
	private Integer maxActions;

	@Column(name = "is_active")
	private Boolean isActive;
	
    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ref_code_id")
    private OrgRefCode orgRefCode;
	
	public Integer getPositivePoints() {
		return positivePoints;
	}

	public void setPositivePoints(Integer positivePoints) {
		this.positivePoints = positivePoints;
	}

	public Integer getNegativePoints() {
		return negativePoints;
	}

	public void setNegativePoints(Integer negativePoints) {
		this.negativePoints = negativePoints;
	}

	public Integer getMaxActions() {
		return maxActions;
	}

	public void setMaxActions(Integer maxActions) {
		this.maxActions = maxActions;
	}

	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public OrgRefCode getOrgRefCode() {
		return orgRefCode;
	}

	public void setOrgRefCode(OrgRefCode orgRefCode) {
		this.orgRefCode = orgRefCode;
	}

	
}