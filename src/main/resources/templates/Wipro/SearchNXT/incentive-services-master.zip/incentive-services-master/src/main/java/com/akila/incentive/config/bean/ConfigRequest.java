package com.akila.incentive.config.bean;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.akila.AkilaRequest;

public class ConfigRequest extends AkilaRequest {
	
	@NotEmpty(message = "{INCENTIVE.CONFIG.REFCODEID.MANDATORY}")
	private String refCodeId;

	@NotNull(message = "{INCENTIVE.CONFIG.POSITIVE.MANDATORY}")
	private Integer positivePoints;

	@NotNull(message = "{INCENTIVE.CONFIG.NEGATIVE.MANDATORY}")
	private Integer negativePoints;

	@NotNull(message = "{INCENTIVE.CONFIG.MAX.MANDATORY}")
	private Integer maxActions;

	@NotNull(message = "{INCENTIVE.CONFIG.ISACTIVE.MANDATORY}")
	private Boolean isActive;

	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public Integer getPositivePoints() {
		return positivePoints;
	}

	public void setPositivePoints(Integer positivePoints) {
		this.positivePoints = positivePoints;
	}

	public Integer getNegativePoints() {
		return negativePoints;
	}

	public void setNegativePoints(Integer negativePoints) {
		this.negativePoints = negativePoints;
	}

	public Integer getMaxActions() {
		return maxActions;
	}

	public void setMaxActions(Integer maxActions) {
		this.maxActions = maxActions;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
}
