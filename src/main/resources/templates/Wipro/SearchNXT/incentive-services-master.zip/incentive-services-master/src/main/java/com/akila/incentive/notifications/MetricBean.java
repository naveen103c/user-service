package com.akila.incentive.notifications;

import java.math.BigDecimal;

public class MetricBean {

	String refCodeId;

	String eventName;

	String userId;

	String tenant;

	BigDecimal value;

	BigDecimal point;

	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTenant() {
		return tenant;
	}

	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

	public BigDecimal getValue() {
		return value == null ? new BigDecimal(1) : this.value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

	public BigDecimal getPoint() {
		return point == null ? new BigDecimal(0)  : this.point;
	}

	public void setPoint(BigDecimal point) {
		this.point = point;
	}

	@Override
	public String toString() {
		return "Notification [refCodeId=" + refCodeId + ", eventName=" + eventName + ", userId=" + userId + ", tenant="
				+ tenant + ", value=" + value + ", point=" + point + "]";
	}

}
