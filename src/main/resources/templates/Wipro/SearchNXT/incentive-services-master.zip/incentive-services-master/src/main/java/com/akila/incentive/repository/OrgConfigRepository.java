package com.akila.incentive.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.incentive.entity.OrgConfig;

@Repository
public interface OrgConfigRepository extends JpaRepository<OrgConfig, String> {
}
