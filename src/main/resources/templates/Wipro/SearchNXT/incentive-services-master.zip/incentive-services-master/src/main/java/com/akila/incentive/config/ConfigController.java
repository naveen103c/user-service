package com.akila.incentive.config;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.incentive.config.bean.ConfigRequest;
import com.akila.incentive.config.bean.ConfigResponse;
import com.akila.response.ResponseId;

@RestController
public class ConfigController extends AkilaController {
	@Autowired
	private ConfigService configService;

	@GetMapping(path = "/incentive/config")
	public List<ConfigResponse> getAllConfig() {
		return configService.getAllConfig();
	}

	@PutMapping(path = "/incentive/config")
	public ResponseId updateConfig(@Valid @RequestBody ConfigRequest configRequest) {

		return configService.updateConfig(configRequest);
		
	}
}
