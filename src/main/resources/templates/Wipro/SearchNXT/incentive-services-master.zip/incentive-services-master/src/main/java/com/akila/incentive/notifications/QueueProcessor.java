package com.akila.incentive.notifications;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.collections4.ListUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.JDBCException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.akila.incentive.bean.ConfigResponse;
import com.akila.incentive.bean.IncentiveServiceConfigResponse;
import com.akila.incentive.entity.OrgConfig;
import com.akila.incentive.entity.OrgIncentiveQueue;
import com.akila.incentive.entity.OrgIncentiveServiceConfig;
import com.akila.incentive.entity.OrgUserIncentiveMetric;
import com.akila.incentive.entity.OrgUserIncentiveMetricPK;
import com.akila.incentive.repository.OrgConfigRepository;
import com.akila.incentive.repository.OrgIncentiveQueueRepository;
import com.akila.incentive.repository.OrgIncentiveServiceConfigRepository;
import com.akilacommons.tenant.DataSourceProperties;
import com.akilacommons.tenant.TenantContext;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.Message;
import com.azure.core.exception.AzureException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueMessage;

@Configuration
@EnableScheduling
public class QueueProcessor {
	private static final Logger logger = LogManager.getLogger(QueueProcessor.class);

	@Autowired
	IncentiveService incentiveService;
	@Autowired
	OrgIncentiveQueueRepository orgIncentiveQueueRepository;

	@Value("${incentive-sqs-url}")
	private String sqsUrl;

	@Value("${queue.processing.batch.size}")
	private int queueProcessingBatchSize;
	@Value("${incentive.queue.impl}")
	private String incentiveQueueImpl;

	@Value("${azure.blob.connection-string:connectionString}")
	String connectionString;
	@Value("${azure.incentive.queue.name}")
	private String azureQueueName;

	AmazonSQS sqs = null;

	@Autowired
	DataSourceProperties dataSourceProperties;

	List<IncentiveServiceConfigResponse> incentiveServiceConfigResponses;
	Map<String, List<ConfigResponse>> configResponsMap = new HashMap<String, List<ConfigResponse>>();
	@Autowired
	private OrgConfigRepository orgConfigRepository;

	@Autowired
	private OrgIncentiveServiceConfigRepository orgIncentiveServiceConfigRepository;

	public AmazonSQS getSqsClient() {
		if (sqs == null) {

			sqs = AmazonSQSClientBuilder.standard().withCredentials(new InstanceProfileCredentialsProvider(false))
					.build();

		}
		return sqs;
	}

	//@Scheduled(cron = "${incentive.queue.process.cron}")
	public void processQueue() {
		if (incentiveQueueImpl.equalsIgnoreCase("db")) {
			getDataFromDatabase();
		} else if (incentiveQueueImpl.equalsIgnoreCase("azure")) {
			getDataFromAzure();
		} else {
			getDataFromSQS();
		}

		configResponsMap = new HashMap<String, List<ConfigResponse>>();
	}

	private void getDataFromAzure() {
		try {
			CloudStorageAccount storageAccount = CloudStorageAccount.parse(connectionString);
			CloudQueue queue = storageAccount.createCloudQueueClient().getQueueReference(azureQueueName);
			queue.downloadAttributes();
			int count = (int) queue.getApproximateMessageCount();
			if (count > 0) {
				int loop = (count / 32) + 1;
				Map<String, String> servicesMap = incentiveService.getAllIncentiveMetric();
				ObjectMapper mapper = new ObjectMapper();
				for (int i = 1; i <= loop; i++) {
					Iterable<CloudQueueMessage> msg = queue.retrieveMessages(32 * i);
					Map<String, Map<String, NotificationValues>> serviceCountMap = new HashMap<String, Map<String, NotificationValues>>();
					for (CloudQueueMessage cloudQueueMessage : msg) {
						logger.info("QueueProcessor.processQueue, Message : "
								+ cloudQueueMessage.getMessageContentAsString());
						try {
							Notification notification = mapper.readValue(cloudQueueMessage.getMessageContentAsString(),
									Notification.class);
							MetricBean metricBean = getMetricBean(notification);
							getServiceCountMap(servicesMap, serviceCountMap, metricBean);
						}  catch (NullPointerException e) {
							logger.error("QueueProcessor.processQueue - error while parsing message, Message : "
									+ cloudQueueMessage.getMessageContentAsString(), e);
						}catch (Exception e) {
							logger.error("QueueProcessor.processQueue - error while parsing message, Message : "
									+ cloudQueueMessage.getMessageContentAsString(), e);
						}
					}

					for (Map.Entry<String, Map<String, NotificationValues>> map : serviceCountMap.entrySet()) {
						TenantContext.setCurrentTenant(map.getKey());
						saveMetric(map.getValue());
					}

					logger.info("QueueProcessor.processQueue, Deleting messages.... : ");
					for (CloudQueueMessage cloudQueueMessage : msg) {
						queue.deleteMessage(cloudQueueMessage, null, null);
					}
					logger.info("QueueProcessor.processQueue, Deleted messages : ");
				}
			}
		} catch (AzureException e) {
			logger.error("QueueProcessor.getDataFromAzure, Error : " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("QueueProcessor.getDataFromAzure, Error : " + e.getMessage(), e);
		}
	}

	private void getDataFromSQS() {
		List<Message> messages = getSqsClient().receiveMessage(sqsUrl).getMessages();
		if (messages != null && messages.size() > 0) {

			logger.info("QueueProcessor.processQueue, Total Messages in SQS : " + messages.size());
			List<List<Message>> subList = ListUtils.partition(messages, queueProcessingBatchSize);
			Map<String, String> servicesMap = incentiveService.getAllIncentiveMetric();
			ObjectMapper mapper = new ObjectMapper();
			for (List<Message> list : subList) {
				Map<String, Map<String, NotificationValues>> serviceCountMap = new HashMap<String, Map<String, NotificationValues>>();
				for (Message message : list) {
					logger.info("QueueProcessor.processQueue, Message : " + message.getBody());
					try {
						Notification notification = mapper.readValue(message.getBody(), Notification.class);
						MetricBean metricBean = getMetricBean(notification);
						getServiceCountMap(servicesMap, serviceCountMap, metricBean);
					} catch (NullPointerException e) {
						logger.error("QueueProcessor.processQueue - error while parsing message, Message : "
								+ message.getBody(), e);
					} catch (Exception e) {
						logger.error("QueueProcessor.processQueue - error while parsing message, Message : "
								+ message.getBody(), e);
					}
				}

				for (Map.Entry<String, Map<String, NotificationValues>> map : serviceCountMap.entrySet()) {
					TenantContext.setCurrentTenant(map.getKey());
					saveMetric(map.getValue());
				}

				logger.info("QueueProcessor.processQueue, Deleting messages.... : " + list);
				for (Message message : list) {
					sqs.deleteMessage(sqsUrl, message.getReceiptHandle());
				}
				logger.info("QueueProcessor.processQueue, Deleted messages : " + list);
			}
		}
	}

//	
	private void getDataFromDatabase() {

		Map<Object, Object> datasources = dataSourceProperties.getDatasources();

		for (Map.Entry<Object, Object> datasource : datasources.entrySet()) {
			if (String.valueOf(datasource.getKey()).equalsIgnoreCase("base")
					|| String.valueOf(datasource.getKey()).equalsIgnoreCase("wiga-dev")) {
				continue;
			}
			TenantContext.setCurrentTenant(String.valueOf(datasource.getKey()));

			List<OrgIncentiveQueue> messages = getMessagesFromDB();
			if (messages != null && messages.size() > 0) {
				logger.info(
						"Incentive QueueProcessor.processQueue Database, Total Messages in SQS : " + messages.size());
				List<List<OrgIncentiveQueue>> subList = ListUtils.partition(messages, queueProcessingBatchSize);
				Map<String, String> configMap = incentiveService.getAllIncentiveMetric();
				ObjectMapper mapper = new ObjectMapper();
				for (List<OrgIncentiveQueue> list : subList) {
					Map<String, Map<String, NotificationValues>> serviceCountMap = new HashMap<String, Map<String, NotificationValues>>();
					for (OrgIncentiveQueue message : list) {
						logger.info("Incentive QueueProcessor.processQueue, Message : " + message.getQueueJson());
						try {
							Notification notification = mapper.readValue(message.getQueueJson(), Notification.class);
							MetricBean metricBean = getMetricBean(notification);
							getServiceCountMap(configMap, serviceCountMap, metricBean);
						} catch (NullPointerException e) {
							logger.error(
									"Incentive QueueProcessor.processQueue - error while parsing message, Message : "
											+ message.getQueueJson(),
									e);
						} catch (Exception e) {
							logger.error(
									"Incentive QueueProcessor.processQueue - error while parsing message, Message : "
											+ message.getQueueJson(),
									e);
						}

					}
					for (Map.Entry<String, Map<String, NotificationValues>> map : serviceCountMap.entrySet()) {
						// TenantContext.setCurrentTenant(map.getKey());
						saveMetric(map.getValue());
					}

					logger.info("QueueProcessor.processQueue, Deleting messages.... : " + list);

					orgIncentiveQueueRepository.deleteInBatch(list);

					logger.info("QueueProcessor.processQueue, Deleted messages : " + list);
				}
			}
		}
	}

	private List<String> saveMetric(Map<String, NotificationValues> serviceCountMap) {
		List<String> serviceIdList = new ArrayList<String>(serviceCountMap.keySet());

		List<OrgUserIncentiveMetric> updatedList = getMetricsForAllPeriods(serviceCountMap, serviceIdList);

		logger.info("QueueProcessor.processQueue, update metric....");
		incentiveService.saveServiceMetrics(updatedList);
		logger.info("QueueProcessor.processQueue, updated metric. ");
		return serviceIdList;
	}

	private void getServiceCountMap(Map<String, String> servicesMap,
			Map<String, Map<String, NotificationValues>> serviceCountMap, MetricBean metricBean) {
		if (metricBean != null) {
			if (servicesMap.containsKey(metricBean.getRefCodeId())) {
				Map<String, NotificationValues> notificationMap = serviceCountMap.get(metricBean.getTenant());
				if (notificationMap == null) {
					notificationMap = new HashMap<String, NotificationValues>();
					serviceCountMap.put(metricBean.getTenant(), notificationMap);
				}
				String key = metricBean.getRefCodeId() + "#" + metricBean.getUserId();
				if (notificationMap.containsKey(key)) {
					NotificationValues notificationValues = notificationMap.get(key);
					notificationValues.setValues(notificationValues.getValues().add(metricBean.getValue()));
					notificationValues.setPoints(notificationValues.getPoints().add(metricBean.getPoint()));
					notificationMap.put(key, notificationValues);
				} else {
					notificationMap.put(key, new NotificationValues(metricBean.getValue(), metricBean.getPoint()));
				}
			} else {
				logger.error("QueueProcessor.processQueue - Config Name is incorrect, Config Name  : "
						+ metricBean.getEventName());
			}
		}
	}

	private List<OrgUserIncentiveMetric> getMetricsForAllPeriods(Map<String, NotificationValues> serviceCountMap,
			List<String> eventIdList) {

		List<Integer> periodCdList = getPeriodCd();
		List<OrgUserIncentiveMetric> list = null;

		List<String> ids = new ArrayList<String>();
		List<String> userIds = new ArrayList<String>();

		for (String service : eventIdList) {
			ids.add(service.split("#")[0]);
			userIds.add(service.split("#")[1]);
		}

		List<OrgUserIncentiveMetric> updatedList = new ArrayList<OrgUserIncentiveMetric>();
		Date date = new Date();

		for (Integer cd : periodCdList) {
			if (cd == 1) {
				list = incentiveService.getEventMetricsCount(ids, userIds, cd, date);
			} else if (cd == 2) {
				list = incentiveService.getEventMetricsCount(ids, userIds, cd, Utils.getWeekStartDate(date),
						Utils.getWeekEndDate(date));
			} else if (cd == 3) {
				list = incentiveService.getEventMetricsCount(ids, userIds, cd, Utils.getMonthStartDate(date),
						Utils.getMonthEndDate(date));
			} else if (cd == 4) {
				list = incentiveService.getEventMetricsCount(ids, userIds, cd, Utils.getQuarterStartDate(date),
						Utils.getQuarterEndDate(date));
			} else if (cd == 5) {
				list = incentiveService.getEventMetricsCount(ids, userIds, cd, Utils.getYearStartDate(date),
						Utils.getYearEndDate(date));
			} else if (cd == 6) {
				list = incentiveService.getEventMetricsCount(ids, userIds, cd);
			}

			if (list != null && list.size() > 0) {
				for (Map.Entry<String, NotificationValues> entry : serviceCountMap.entrySet()) {
					boolean isFound = false;
					for (OrgUserIncentiveMetric eventMetric : list) {
						if (entry.getKey()
								.equals(eventMetric.getId().getRefCodeId() + "#" + eventMetric.getId().getUserId())) {
							BigDecimal totalCount = eventMetric.getCount().add(entry.getValue().getValues());
							BigDecimal totalPoint = eventMetric.getPoint().add(entry.getValue().getPoints());
							if (totalCount.longValue() < 0) {
								totalCount = new BigDecimal(0);
							}
							eventMetric.setCount(totalCount);
							eventMetric.setPoint(totalPoint);
							updatedList.add(eventMetric);
							isFound = true;
							break;
						}
					}

					if (!isFound) {
						getMetricObj(updatedList, date, cd, entry);
					}
				}
			} else {
				for (Map.Entry<String, NotificationValues> entry : serviceCountMap.entrySet()) {
					getMetricObj(updatedList, date, cd, entry);
				}
			}
		}
		return updatedList;
	}

	private void getMetricObj(List<OrgUserIncentiveMetric> updatedList, Date date, Integer cd,
			Map.Entry<String, NotificationValues> entry) {
		OrgUserIncentiveMetric orgServiceMetric = new OrgUserIncentiveMetric();
		OrgUserIncentiveMetricPK OrgUserIncentiveMetricPK = new OrgUserIncentiveMetricPK();
		OrgUserIncentiveMetricPK.setMetricPeriodCd(cd);
		OrgUserIncentiveMetricPK.setMetricPeriodDt(date);
		OrgUserIncentiveMetricPK.setRefCodeId(entry.getKey().split("#")[0]);
		OrgUserIncentiveMetricPK.setUserId(entry.getKey().split("#")[1]);
		orgServiceMetric.setId(OrgUserIncentiveMetricPK);
		orgServiceMetric.setCount(entry.getValue().getValues());
		orgServiceMetric.setPoint(entry.getValue().getPoints());
		updatedList.add(orgServiceMetric);
	}

	private List<Integer> getPeriodCd() {
		List<Integer> periodCdList = new ArrayList<Integer>();
		periodCdList.add(1);
		periodCdList.add(2);
		periodCdList.add(3);
		periodCdList.add(4);
		periodCdList.add(5);
		periodCdList.add(6);
		return periodCdList;
	}

	private List<OrgIncentiveQueue> getMessagesFromDB() {
		List<OrgIncentiveQueue> list = orgIncentiveQueueRepository.findByStatus(0);
		for (OrgIncentiveQueue orgMetricQueue : list) {
			orgMetricQueue.setStatus(1);
		}
		orgIncentiveQueueRepository.saveAll(list);

		return list;
	}

	private MetricBean getMetricBean(Notification notification) {
		return updateIncentive(notification);
	}

	private MetricBean updateIncentive(Notification notification) {
		try {

			List<ConfigResponse> configResponses = getConfigResponse(notification.getTenant());

			for (IncentiveServiceConfigResponse incentiveServiceConfigResponse : incentiveServiceConfigResponses) {

				String[] lastEndPoint = incentiveServiceConfigResponse.getEndPoint().split("/");

				String lp = lastEndPoint[lastEndPoint.length - 1];

				boolean param = false;
				String[] queryParam;
				String qp = "";
				if (notification.getQueryString()!= null) {
					notification.setRequestUri(notification.getRequestUri()+"?"+notification.getQueryString()); 
					queryParam = notification.getRequestUri().split("\\?");
					qp = queryParam[queryParam.length - 1];
					if (!incentiveServiceConfigResponse.getQueryParam().isEmpty()) {
						param = qp.equals(incentiveServiceConfigResponse.getQueryParam());
					} else if (incentiveServiceConfigResponse.getQueryParam().isEmpty()) {
						String[] s_ = notification.getRequestUri().split("/");
						String query_prm = s_[s_.length - 1].split("\\?")[0];

						param = query_prm.equals(lp);

					}
					if (param) {

						lp = "";
					}
				}
				String serviceName = notification.getRequestUri().split("/")[1];
				String[] s1 = notification.getRequestUri().split("/");
				String uri = s1[s1.length - 1];
				if (incentiveServiceConfigResponse.getServiceMnemonic().replace("/", "").equals(serviceName)
						&& incentiveServiceConfigResponse.getMethodType().equals(notification.getHttpMethod())
						&& containsRefCodeId(configResponses, incentiveServiceConfigResponse.getRefCodeId())
						&& (uri.equals(lp) || param)) {
					MetricBean metricBean = null;
					for (ConfigResponse conf : configResponses) {

						if (incentiveServiceConfigResponse.getRefCodeId().equals(conf.getRefCodeId())) {
							metricBean = new MetricBean();

							metricBean.setRefCodeId(conf.getRefCodeId());
							metricBean.setTenant(notification.getTenant());
							metricBean.setUserId(notification.getUserId());
							if (conf.getPositivePoints() == 0) {
								metricBean.setPoint(BigDecimal.valueOf(conf.getNegativePoints()));
							} else if (conf.getNegativePoints() == 0) {
								metricBean.setPoint(BigDecimal.valueOf(conf.getPositivePoints()));
							} else {
								metricBean.setPoint(BigDecimal.valueOf(0));
							}
							metricBean.setValue(BigDecimal.valueOf(1));
							metricBean.setEventName(conf.getRefCodeDisplayVal());

							break;
						}

					}
					return metricBean;
				}

			}
		} catch (Exception e) {
			logger.error("Update Incentive Method " + e.getStackTrace());
		}

		return null;
	}

	private List<ConfigResponse> getConfigResponse(String tenant) {

		if (configResponsMap.containsKey((tenant))) {

			return configResponsMap.get(tenant);

		} else {

			TenantContext.setCurrentTenant(tenant);

			List<OrgConfig> orgRatingList = orgConfigRepository.findAll();

			List<ConfigResponse> response = new ArrayList<ConfigResponse>();

			try {

				orgRatingList.forEach(orgConfig -> {

					ConfigResponse configResponse = new ConfigResponse();
					configResponse.setRefCodeId(orgConfig.getRefCodeId());
					configResponse.setRefCodeDescription(orgConfig.getOrgRefCode().getRefCodeDescription());
					configResponse.setRefCodeDisplayVal(orgConfig.getOrgRefCode().getRefCodeDisplayVal());
					configResponse.setRefCodeStoreVal(orgConfig.getOrgRefCode().getRefCodeStoreVal());
					configResponse.setPositivePoints(orgConfig.getPositivePoints());
					configResponse.setNegativePoints(orgConfig.getNegativePoints());
					configResponse.setMaxActions(orgConfig.getMaxActions());
					configResponse.setIsActive(orgConfig.getIsActive());
					response.add(configResponse);

				});
			} catch (JDBCException  | NullPointerException  e) {
				logger.error("orgconfgListToConfigResponseList() " + e.getStackTrace());
			} catch (Exception e) {
				logger.error("orgconfgListToConfigResponseList() " + e.getStackTrace());
			}

			configResponsMap.put(String.valueOf(tenant), response);

			return response;

		}
	}

	//@Scheduled(cron = "0 0 */1 * * *")
	public void scheduleFixedRateTask() {
		loadBaseConfig();
	}

	private void loadBaseConfig() {
		try {
			List<OrgIncentiveServiceConfig> incentiveServiceConfigs = orgIncentiveServiceConfigRepository.findAll();
			incentiveServiceConfigResponses = new ArrayList<IncentiveServiceConfigResponse>();
			try {
				incentiveServiceConfigs.forEach(incentiveServiceConfig -> {

					IncentiveServiceConfigResponse incentiveServiceConfigResponse = new IncentiveServiceConfigResponse();
					incentiveServiceConfigResponse.setRefCodeId(incentiveServiceConfig.getRefCodeId());
					incentiveServiceConfigResponse.setServiceMnemonic(incentiveServiceConfig.getServiceMnemonic());
					incentiveServiceConfigResponse.setEndPoint(incentiveServiceConfig.getEndPoint());
					incentiveServiceConfigResponse.setMethodType(incentiveServiceConfig.getMethodType());
					incentiveServiceConfigResponse.setQueryParam(incentiveServiceConfig.getQueryParam());
					incentiveServiceConfigResponses.add(incentiveServiceConfigResponse);

				});
			} catch (JDBCException e) {
				logger.error("Org Incentive Service Config Method " + e.getStackTrace());
			} catch (Exception e) {
				logger.error("Org Incentive Service Config Method " + e.getStackTrace());
			}
		}catch (JDBCException e) {
			logger.error("Error While updating Service Config" + e.getMessage() + e);
		} catch (Exception e) {
			logger.error("Error While updating Service Config" + e.getMessage() + e);
		}

	}

	@PostConstruct
	public void init() {

		loadBaseConfig();

	}

	public boolean containsRefCodeId(final List<ConfigResponse> list, final String refCodeId) {
		return list.stream().anyMatch(o -> o.getRefCodeId().equals(refCodeId));
	}

	public boolean containsServiceName(final List<IncentiveServiceConfigResponse> list, final String serviceName,
			final String methodType) {
		return list.stream().anyMatch(o -> o.getServiceMnemonic().replace("/", "").equals(serviceName)
				&& o.getMethodType().equals(methodType));
	}
}
