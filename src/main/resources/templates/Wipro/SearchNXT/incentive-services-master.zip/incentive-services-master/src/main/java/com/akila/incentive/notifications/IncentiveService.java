package com.akila.incentive.notifications;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaService;
import com.akila.incentive.entity.BaseIncentiveConfig;
import com.akila.incentive.entity.OrgConfig;
import com.akila.incentive.entity.OrgUserIncentiveMetric;
import com.akila.incentive.repository.BaseIncentiveConfigRepository;
import com.akila.incentive.repository.OrgConfigRepository;
import com.akila.incentive.repository.OrgUserIncentiveMetricRepository;

@Service
public class IncentiveService extends AkilaService {

	@Autowired
	protected OrgUserIncentiveMetricRepository orgUserIncentiveMetricRepository;

	@Autowired
	private OrgConfigRepository orgConfigRepository;
	
	@Autowired
	private BaseIncentiveConfigRepository baseIncentiveConfigRepository;
	
	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate restTemplate;


	public Map<String, String> getAllIncentiveMetric() {
		List<BaseIncentiveConfig> baseIncentiveConfigList = baseIncentiveConfigRepository.findAll();
		Map<String, String> data = new HashMap<String, String>();
		for (BaseIncentiveConfig config : baseIncentiveConfigList) {
			data.put(config.getRefCodeId(),config.getOrgRefCode().getRefCodeDisplayVal());
		}
		return data;
	}
	
	public Map<String, String> getAllOrgIncentiveMetric() {
		List<OrgConfig> orgConfigList = orgConfigRepository.findAll();
		Map<String, String> data = new HashMap<String, String>();
		for (OrgConfig orgConfig : orgConfigList) {
			data.put(orgConfig.getRefCodeId(),orgConfig.getOrgRefCode().getRefCodeDisplayVal());
		}
		return data;
	}

	
	public List<OrgUserIncentiveMetric> getEventMetricsCount(List<String> ids,List<String> userIds, Integer periodCd,Date startDate, Date endDate) {
		// weekly, monthly, Quarterly, yearly
		return	orgUserIncentiveMetricRepository.findByIdRefCodeIdInAndIdUserIdInAndIdMetricPeriodCdAndIdMetricPeriodDtGreaterThanEqualAndIdMetricPeriodDtLessThan
				(ids,userIds,periodCd,startDate,endDate);
	}
////	------------------------------
	public List<OrgUserIncentiveMetric> getEventMetricsCount(List<String> ids,List<String> userIds, Integer periodCd, Date date) {
		// daily
		return	orgUserIncentiveMetricRepository.findByIdRefCodeIdInAndIdUserIdInAndIdMetricPeriodCdAndIdMetricPeriodDt(ids,userIds,periodCd,date);
	}
	
	public List<OrgUserIncentiveMetric> getEventMetricsCount(List<String> ids,List<String> userIds, Integer periodCd) {
		// till date
		return	orgUserIncentiveMetricRepository.findByIdRefCodeIdInAndIdUserIdInAndIdMetricPeriodCd(ids ,userIds ,periodCd);
	}
	
	public void saveServiceMetrics(OrgUserIncentiveMetric orgUserIncentiveMetric){
		orgUserIncentiveMetricRepository.save(orgUserIncentiveMetric);
	}

	public void saveServiceMetrics(List<OrgUserIncentiveMetric> orgUserIncentiveMetricList){
		orgUserIncentiveMetricRepository.saveAll(orgUserIncentiveMetricList);
	}

	public static String convertNumber(long count) {
	    if (count < 1000) return "" + count;
	    int exp = (int) (Math.log(count) / Math.log(1000));
	    return String.format("%.1f%c",
	                         count / Math.pow(1000, exp),
	                         "kMGTPE".charAt(exp-1));
	}

}
