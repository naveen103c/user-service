package com.akila.incentive.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;

/**
 * The persistent class for the org_ref_codes database table.
 * 
 */
@Entity
@Table(name = "org_ref_codes")
@NamedQuery(name = "OrgRefCode.findAll", query = "SELECT o FROM OrgRefCode o")
public class OrgRefCode extends AkilaEntity  implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ref_code_id")
	private String refCodeId;

	@Column(name = "ref_code_description")
	private String refCodeDescription;

	@Column(name = "ref_code_display_val")
	private String refCodeDisplayVal;

	@Column(name = "ref_code_store_val")
	private Integer refCodeStoreVal;

	public OrgRefCode() {
	}

	public String getRefCodeId() {
		return this.refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public String getRefCodeDescription() {
		return this.refCodeDescription;
	}

	public void setRefCodeDescription(String refCodeDescription) {
		this.refCodeDescription = refCodeDescription;
	}

	public String getRefCodeDisplayVal() {
		return this.refCodeDisplayVal;
	}

	public void setRefCodeDisplayVal(String refCodeDisplayVal) {
		this.refCodeDisplayVal = refCodeDisplayVal;
	}

	public Integer getRefCodeStoreVal() {
		return this.refCodeStoreVal;
	}

	public void setRefCodeStoreVal(Integer refCodeStoreVal) {
		this.refCodeStoreVal = refCodeStoreVal;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Timestamp getModTs() {
		return modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

}