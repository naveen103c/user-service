package com.akila.incentive.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "org_incentive_service_config", schema = "base")
@NamedQuery(name = "OrgIncentiveServiceConfig.findAll", query = "SELECT o FROM OrgIncentiveServiceConfig o")
public class OrgIncentiveServiceConfig implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ref_code_id")
	private String refCodeId;

	@Column(name = "service_mnemonic")
	private String serviceMnemonic;

	@Column(name = "end_point")
	private String endPoint;

	@Column(name = "method_type")
	private String methodType;

	@Column(name = "query_param")
	private String queryParam;

	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public String getServiceMnemonic() {
		return serviceMnemonic;
	}

	public void setServiceMnemonic(String serviceMnemonic) {
		this.serviceMnemonic = serviceMnemonic;
	}

	public String getEndPoint() {
		return endPoint;
	}

	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}

	public String getMethodType() {
		return methodType;
	}

	public void setMethodType(String methodType) {
		this.methodType = methodType;
	}

	public String getQueryParam() {
		return queryParam;
	}

	public void setQueryParam(String queryParam) {
		this.queryParam = queryParam;
	}

}

