package com.akila.incentive.bean;

import com.akila.AkilaRequest;

public class ConfigRequest extends AkilaRequest {
	
	private String refCodeId;

	private Integer positivePoints;

	private Integer negativePoints;

	private Integer maxActions;

	private Boolean isActive;

	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public Integer getPositivePoints() {
		return positivePoints;
	}

	public void setPositivePoints(Integer positivePoints) {
		this.positivePoints = positivePoints;
	}

	public Integer getNegativePoints() {
		return negativePoints;
	}

	public void setNegativePoints(Integer negativePoints) {
		this.negativePoints = negativePoints;
	}

	public Integer getMaxActions() {
		return maxActions;
	}

	public void setMaxActions(Integer maxActions) {
		this.maxActions = maxActions;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
}
