package com.akila.incentive.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the org_incentive_queue database table.
 * 
 */
@Entity
@Table(name="org_user_incentive_metric")
@NamedQuery(name="OrgUserIncentiveMetric.findAll", query="SELECT o FROM OrgUserIncentiveMetric o")
public class OrgUserIncentiveMetric implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgUserIncentiveMetricPK id;

	@Column(name="count")
	private BigDecimal count;
	
	@Column(name="point")
	private BigDecimal point;

	public OrgUserIncentiveMetric() {
	}

	public OrgUserIncentiveMetricPK getId() {
		return this.id;
	}

	public void setId(OrgUserIncentiveMetricPK id) {
		this.id = id;
	}

	public BigDecimal getCount() {
		return count;
	}

	public void setCount(BigDecimal count) {
		this.count = count;
	}

	public BigDecimal getPoint() {
		return point;
	}

	public void setPoint(BigDecimal point) {
		this.point = point;
	}

}