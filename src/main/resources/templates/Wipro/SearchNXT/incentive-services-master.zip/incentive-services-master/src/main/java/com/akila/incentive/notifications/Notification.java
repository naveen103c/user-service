package com.akila.incentive.notifications;

import java.math.BigDecimal;

import javax.validation.constraints.NotEmpty;

public class Notification {

	@NotEmpty(message = "{NOTIFICATION.USERID.MANDATORY}")
	String userId;
	
	@NotEmpty(message = "{NOTIFICATION.TENANT.MANDATORY}")
	String tenant;
	
	@NotEmpty(message = "{NOTIFICATION.URL.MANDATORY}")
	String requestUri;
	
	//@NotEmpty(message = "{NOTIFICATION.QUERYSTRING.MANDATORY}")
	private String queryString;
	
	@NotEmpty(message = "{NOTIFICATION.HTTPMETHOD.MANDATORY}")
	String httpMethod;
	
	String orgId;
	String serviceName;
	String metricName;
	BigDecimal value;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTenant() {
		return tenant;
	}

	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

	public String getRequestUri() {
		return requestUri;
	}

	public void setRequestUri(String requestUri) {
		this.requestUri = requestUri;
	}

	public String getQueryString() {
		return queryString == null ? "" : queryString;
	}

	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getMetricName() {
		return metricName;
	}

	public void setMetricName(String metricName) {
		this.metricName = metricName;
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

}
