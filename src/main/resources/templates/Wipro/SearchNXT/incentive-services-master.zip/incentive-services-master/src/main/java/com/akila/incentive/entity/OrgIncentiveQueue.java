package com.akila.incentive.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="org_incentive_queue")
public class OrgIncentiveQueue implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="queue_id")
	String queueId;
	
	@Column(name="event_nm")
	String eventNm;
	
	@Column(name="queue_json")
	String queueJson;
	
	@Column(name="crt_ts")
	Timestamp crtTs;
	
	@Column(name="status")
	int status = 0;

	public String getQueueId() {
		return queueId;
	}

	public void setQueueId(String queueId) {
		this.queueId = queueId;
	}

	public String getEventNm() {
		return eventNm;
	}

	public void setEventNm(String eventNm) {
		this.eventNm = eventNm;
	}

	public String getQueueJson() {
		return queueJson;
	}

	public void setQueueJson(String queueJson) {
		this.queueJson = queueJson;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
