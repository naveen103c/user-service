package com.akila.incentive.config.bean;

import com.akila.AkilaResponse;

public class ConfigResponse extends AkilaResponse {
	
	private String refCodeId;

	private Integer positivePoints;

	private Integer negativePoints;

	private Integer maxActions;

	private Boolean isActive;
	
	private String refCodeDisplayVal;
	
	private String refCodeDescription;
	
	private Integer refCodeStoreVal;

	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public Integer getPositivePoints() {
		return positivePoints;
	}

	public void setPositivePoints(Integer positivePoints) {
		this.positivePoints = positivePoints;
	}

	public Integer getNegativePoints() {
		return negativePoints;
	}

	public void setNegativePoints(Integer negativePoints) {
		this.negativePoints = negativePoints;
	}

	public Integer getMaxActions() {
		return maxActions;
	}

	public void setMaxActions(Integer maxActions) {
		this.maxActions = maxActions;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getRefCodeDisplayVal() {
		return refCodeDisplayVal;
	}

	public void setRefCodeDisplayVal(String refCodeDisplayVal) {
		this.refCodeDisplayVal = refCodeDisplayVal;
	}

	public String getRefCodeDescription() {
		return refCodeDescription;
	}

	public void setRefCodeDescription(String refCodeDescription) {
		this.refCodeDescription = refCodeDescription;
	}

	public Integer getRefCodeStoreVal() {
		return refCodeStoreVal;
	}

	public void setRefCodeStoreVal(Integer refCodeStoreVal) {
		this.refCodeStoreVal = refCodeStoreVal;
	}

}
