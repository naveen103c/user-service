package com.akila.incentive.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the org_service_metric database table.
 * 
 */
@Embeddable
public class OrgUserIncentiveMetricPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="user_id")
	private String userId;
	
	@Column(name="ref_code_id")
	private String refCodeId;

	@Column(name="metric_period_cd")
	private Integer metricPeriodCd;

	@Temporal(TemporalType.DATE)
	@Column(name="metric_period_dt")
	private java.util.Date metricPeriodDt;

	public OrgUserIncentiveMetricPK() {
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public Integer getMetricPeriodCd() {
		return metricPeriodCd;
	}

	public void setMetricPeriodCd(Integer metricPeriodCd) {
		this.metricPeriodCd = metricPeriodCd;
	}

	public java.util.Date getMetricPeriodDt() {
		return metricPeriodDt;
	}

	public void setMetricPeriodDt(java.util.Date metricPeriodDt) {
		this.metricPeriodDt = metricPeriodDt;
	}
	
}