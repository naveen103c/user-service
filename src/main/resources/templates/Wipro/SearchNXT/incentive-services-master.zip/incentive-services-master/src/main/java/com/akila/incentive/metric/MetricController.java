package com.akila.incentive.metric;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.incentive.metric.bean.IncentiveUserMetricResponse;

@RestController
public class MetricController extends AkilaController {
	@Autowired
	private MetricService metricService;

	@GetMapping(path = "/incentive/metric/topusers")
	public List<IncentiveUserMetricResponse> getTopUserMetric(@RequestParam Integer periodCd,
			@RequestParam Integer count, @RequestParam Integer month, @RequestParam Integer year) {
		return metricService.getTopUserMetric(periodCd,count,month,year);
	}

}