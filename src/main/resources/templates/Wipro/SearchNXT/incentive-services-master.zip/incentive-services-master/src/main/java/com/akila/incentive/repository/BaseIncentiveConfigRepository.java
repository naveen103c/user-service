package com.akila.incentive.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.incentive.entity.BaseIncentiveConfig;

@Repository
public interface BaseIncentiveConfigRepository extends JpaRepository<BaseIncentiveConfig, String> {
}
