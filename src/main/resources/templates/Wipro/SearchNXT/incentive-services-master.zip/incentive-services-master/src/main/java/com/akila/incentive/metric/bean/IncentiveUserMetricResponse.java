package com.akila.incentive.metric.bean;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * @author
 *
 */
public class IncentiveUserMetricResponse {

	private Integer position;
	
	private String userId;

	private BigDecimal totalCount;

	private BigDecimal totalPoint;

	List<IncentiveUserMetric>  userMetric = new ArrayList<IncentiveUserMetric>();
	
	public IncentiveUserMetricResponse() {
		
	}

	public IncentiveUserMetricResponse(String userId, BigDecimal totalCount, BigDecimal totalPoint) {
		super();
		this.userId = userId;
		this.totalCount = totalCount;
		this.totalPoint = totalPoint;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public BigDecimal getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(BigDecimal totalCount) {
		this.totalCount = totalCount;
	}

	public BigDecimal getTotalPoint() {
		return totalPoint;
	}

	public void setTotalPoint(BigDecimal totalPoint) {
		this.totalPoint = totalPoint;
	}

	public List<IncentiveUserMetric> getUserMetric() {
		return userMetric;
	}

	public void setUserMetric(List<IncentiveUserMetric> userMetric) {
		this.userMetric = userMetric;
	}

	@Override
	public String toString() {
		return "IncentiveUserMetricResponse [position=" + position + ", userId=" + userId + ", totalCount="
				+ totalCount + ", totalPoint=" + totalPoint + ", userMetric=" + userMetric + "]";
	}
	
}
