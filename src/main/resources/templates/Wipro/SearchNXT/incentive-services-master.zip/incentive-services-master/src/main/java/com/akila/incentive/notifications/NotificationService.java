package com.akila.incentive.notifications;

import java.sql.Timestamp;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.incentive.entity.OrgIncentiveQueue;
import com.akila.incentive.repository.OrgIncentiveQueueRepository;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueMessage;

@Service
public class NotificationService extends AkilaService{
	private static final Logger logger = LogManager.getLogger(NotificationService.class);
	
	@Value("${incentive-sqs-url}")
	private String sqsUrl;
	
	AmazonSQS sqs = null;

	@Value("${incentive.queue.impl}")
	private String incentiveQueueImpl;
	
	@Value("${azure.blob.connection-string:connectionString}")
	String connectionString;
	@Value("${azure.incentive.queue.name}")
	private String azureQueueName;

	@Autowired
	OrgIncentiveQueueRepository orgIncentiveQueueRepository;
		
	public AmazonSQS getSqsClient(){
		if(sqs == null) {
			
			sqs = AmazonSQSClientBuilder.standard()
		              .withCredentials(new InstanceProfileCredentialsProvider(false))
		              .build();
		}
		return sqs;
	}
	
	
	public void addMessageInQueue(Notification notification) {
		
		ObjectMapper mapper = new ObjectMapper();
		try {
			String message = mapper.writeValueAsString(notification);
			if(incentiveQueueImpl.equalsIgnoreCase("db")) {
				OrgIncentiveQueue queue = new OrgIncentiveQueue();
				queue.setQueueId(UUID.randomUUID().toString());
				queue.setEventNm("");
				queue.setQueueJson(message);
				queue.setStatus(0);
				queue.setCrtTs(new Timestamp(System.currentTimeMillis()));
				orgIncentiveQueueRepository.save(queue);
			}else if(incentiveQueueImpl.equalsIgnoreCase("azure")) {
				CloudStorageAccount storageAccount = CloudStorageAccount.parse(connectionString);
				CloudQueue queue = storageAccount.createCloudQueueClient().getQueueReference(azureQueueName);
				CloudQueueMessage msg = new CloudQueueMessage(message);
				queue.addMessage(msg);
			} else {
				SendMessageRequest send_msg_request = new SendMessageRequest()
				        .withQueueUrl(sqsUrl)
				        .withDelaySeconds(1);
				send_msg_request.setMessageBody(message);
				getSqsClient().sendMessage(send_msg_request);
			}
	        
		} catch (NullPointerException e) {
			logger.error("Incentive SeNotificationService:addMessageInQueue : "+e.getMessage(),e);
			e.printStackTrace();
		} catch (Exception e) {
			logger.error("Incentive SeNotificationService:addMessageInQueue : "+e.getMessage(),e);
			e.printStackTrace();
		}
	}

}
