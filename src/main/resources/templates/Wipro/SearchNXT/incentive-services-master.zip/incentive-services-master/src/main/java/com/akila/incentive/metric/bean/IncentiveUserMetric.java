package com.akila.incentive.metric.bean;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author
 *
 */
public class IncentiveUserMetric {

	@JsonIgnore
	private String userId;
	
	private String refCodeId;
	
	private BigDecimal count;
	
	private BigDecimal point;

	public IncentiveUserMetric() {
	}

	public IncentiveUserMetric(String userId, String refCodeId, BigDecimal count, BigDecimal point) {
		super();
		this.userId = userId;
		this.refCodeId = refCodeId;
		this.count = count;
		this.point = point;
	}


	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public BigDecimal getCount() {
		return count;
	}

	public void setCount(BigDecimal count) {
		this.count = count;
	}

	public BigDecimal getPoint() {
		return point;
	}

	public void setPoint(BigDecimal point) {
		this.point = point;
	}

	@Override
	public String toString() {
		return "IncentiveUserMatric [userId=" + userId + ", refCodeId=" + refCodeId + ", count=" + count + ", point="
				+ point + "]";
	}

}
