package com.akila.orgservices.refcodetype;

import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.orgservices.entity.OrgRefCode;
import com.akila.orgservices.refcodetype.bean.RefCodeTypeRequest;
import com.akila.orgservices.refcodetype.bean.RefCodeTypeResponse;
import com.akila.orgservices.skill.bean.ResponseStatus;
import com.akila.response.ResponseId;

@RestController
public class RefcodetypeController extends AkilaController {
	@Autowired
	private RefcodetypeService refcodetypeService;
	private int STATUS_FAILED = 0;
	private int STATUS_PASS = 1;

	private static final Logger logger = LogManager.getLogger(RefcodetypeController.class);

	@GetMapping(path = "/ref-code-types")
	public List<RefCodeTypeResponse> getAllCodeTypes() {
		return refcodetypeService.getAllCodeTypes();
	}

	@PostMapping(path = "/ref-code-types")
	public ResponseEntity<ResponseStatus> saveRefCodeType(@Valid @RequestBody RefCodeTypeRequest refCodeTypeRequest) {

		try {

			if (refCodeTypeRequest.getRefCodeDisplayVal() != null
					&& refCodeTypeRequest.getRefCodeDisplayVal().trim().length() > 0
					&& refCodeTypeRequest.getRefCodeDescription() != null
					&& refCodeTypeRequest.getRefCodeDescription().trim().length() > 0) {

				List<OrgRefCode> orgRefCodes = refcodetypeService
						.getByRefCodeDisplayValue(refCodeTypeRequest.getRefCodeDisplayVal().trim());

				if (orgRefCodes.size() > 0) {

					ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
							("Ref Code  '" + refCodeTypeRequest.getRefCodeDisplayVal() + "' Already Exist"), 102);
					return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
				}

			} else {
				ResponseStatus status = getResponseStatus(STATUS_FAILED, "", ("Ref Code can't be null or blank"), 101);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
		} catch (NullPointerException e) {
			logger.error("OrgServices:  ref-code-types -> Save" + e.getMessage(),e);
		}
		catch (Exception e) {
			logger.error("OrgServices:  ref-code-types -> Save" + e.getMessage(), e);
		}

		ResponseId id = refcodetypeService.saveRefCodeType(refCodeTypeRequest);
		ResponseStatus status = getResponseStatus(STATUS_PASS, id.getId(), "Ref Code Type successfully created", 0);

		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	}

	@PutMapping(path = "/ref-code-types")
	public ResponseEntity<ResponseStatus> updateRefCodeType(@Valid @RequestBody RefCodeTypeRequest refCodeTypeRequest) {

		try {
			if (refCodeTypeRequest.getRefCodeDisplayVal() != null
					&& refCodeTypeRequest.getRefCodeDisplayVal().trim().length() > 0
					&& refCodeTypeRequest.getRefCodeDescription() != null
					&& refCodeTypeRequest.getRefCodeDescription().trim().length() > 0) {

				List<OrgRefCode> mnemonicList = refcodetypeService.getByRefCodeDisplayValueAndId(
						refCodeTypeRequest.getRefCodeDisplayVal().trim(),
						refCodeTypeRequest.getRefCodeDescription().trim(), refCodeTypeRequest.getRefCodeId());
				if (mnemonicList.size() > 0) {
					ResponseStatus status = getResponseStatus(STATUS_FAILED, "", ("Ref Code Display Value '"
							+ refCodeTypeRequest.getRefCodeDisplayVal() + "' Already Exist"), 102);
					return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
				}

			} else {
				ResponseStatus status = getResponseStatus(STATUS_FAILED, "", ("Ref Code can't be null or blank"), 101);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}

		}
		catch (NullPointerException e) {

			logger.error("OrgServices:  ref-code-types -> Update" + e.getMessage(), e);
		} catch (Exception e) {

			logger.error("OrgServices:  ref-code-types -> Update" + e.getMessage(), e);
		}

		ResponseId id = refcodetypeService.updateRefCodeType(refCodeTypeRequest);
		ResponseStatus status = getResponseStatus(STATUS_PASS, id.getId(), "Ref Code Type successfully updated", 0);

		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	}

	/*
	 * Kindly Check all references for deleting ref code before uncomment code
	 * 
	 * @DeleteMapping(path = "/ref-code-types/{id}") public void
	 * deleteRefCodeType(@PathVariable String id) {
	 * refcodetypeService.deleteRefCode(id); }
	 */

	private ResponseStatus getResponseStatus(int statusCd, String id, String message, int errorCode) {
		ResponseStatus status = new ResponseStatus();
		status.setStatusCode(statusCd);
		status.setId(id);
		status.setMessage(message);
		status.setErrorCode(errorCode);
		return status;
	}
}
