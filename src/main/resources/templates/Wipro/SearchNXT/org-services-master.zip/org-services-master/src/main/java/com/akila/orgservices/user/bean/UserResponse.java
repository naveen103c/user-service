package com.akila.orgservices.user.bean;

import java.util.ArrayList;
import java.util.List;

import com.akila.AkilaResponse;

public class UserResponse extends AkilaResponse 
{
	protected String userId;
	private String userFirstNm;

	private String userLastNm;

	private String userMidNm;

	private String usrEmail;
	
	private String usrSecondaryEmail;
	
    protected Boolean enabled;
    
    protected List<String> roles = new ArrayList<>();
    
    protected List<String> groups = new ArrayList<>();

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserFirstNm() {
		return userFirstNm;
	}

	public void setUserFirstNm(String userFirstNm) {
		this.userFirstNm = userFirstNm;
	}

	public String getUserLastNm() {
		return userLastNm;
	}

	public void setUserLastNm(String userLastNm) {
		this.userLastNm = userLastNm;
	}

	public String getUserMidNm() {
		return userMidNm;
	}

	public void setUserMidNm(String userMidNm) {
		this.userMidNm = userMidNm;
	}

	public String getUsrEmail() {
		return usrEmail;
	}

	public void setUsrEmail(String usrEmail) {
		this.usrEmail = usrEmail;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<String> getGroups() {
		return groups;
	}

	public void setGroups(List<String> groups) {
		this.groups = groups;
	}
	
	public String getUsrSecondaryEmail() {
		return usrSecondaryEmail == null ? "" : usrSecondaryEmail;
	}

	public void setUsrSecondaryEmail(String usrSecondaryEmail) {
		this.usrSecondaryEmail = usrSecondaryEmail;
	}

	@Override
	public String toString() {
		return "UserResponse [userId=" + userId + ", userFirstNm=" + userFirstNm + ", userLastNm=" + userLastNm
				+ ", userMidNm=" + userMidNm + ", usrEmail=" + usrEmail + ", enabled=" + enabled + ", roles=" + roles
				+ ", groups=" + groups + "]";
	}

}
