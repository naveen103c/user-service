package com.akila.orgservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.orgservices.community.bean.UserDetail;
import com.akila.orgservices.entity.OrgCommunity;

@Repository
public interface OrgCommunityRepository extends JpaRepository<OrgCommunity, String> {

	@Query("select o from OrgCommunity o where o.communityOwner = (:userId)")
	public List<OrgCommunity> findByOwnerId(String userId);
	
	@Query("select distinct new com.akila.orgservices.community.bean.UserDetail(ou.userId, ou.usrEmail, ou.userFirstNm, ou.userLastNm, ou.isActive) "
			+ "from OrgUserGroupToUsersLink ougtul inner join OrgCommunityUserGroup ocug " 
			+ "on ougtul.id.userGroupId = ocug.id.userGroupId " 
			+ "inner join OrgUser ou on ou.userId  = ougtul.id.userId " 
			+ "where ocug.id.communityId = :communityId")
	public List<UserDetail> getAllUsersMappedWithCommunityUserGroup(@Param("communityId") String communityId);
}
