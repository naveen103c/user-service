package com.akila.orgservices.user;

import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.akila.AkilaController;
import com.akila.orgservices.entity.OrgBulkUser;
import com.akila.orgservices.entity.OrgUser;
import com.akila.orgservices.skill.bean.ResponseStatus;
import com.akila.orgservices.user.bean.CreateUserResponse;
import com.akila.orgservices.user.bean.UserCommunityResponse;
import com.akila.orgservices.user.bean.UserRequest;
import com.akila.orgservices.user.bean.UserResponse;
import com.akila.response.ResponseId;

@CrossOrigin(origins = "*")
@RestController
public class UserController extends AkilaController {
	@Autowired
	private UserService userService;


	private int STATUS_FAILED = 0;
	private int STATUS_PASS = 1;

	@PostMapping(path = "/users")
	public ResponseEntity<ResponseStatus> createUser(@Valid @RequestBody UserRequest userRequest, @RequestParam(required = false) Boolean activeStatus) {
		
		if(!validateInputData(userRequest)) {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "", ("Input data not valid"), 104);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		if ((userRequest.getUserFirstNm() != null && userRequest.getUserFirstNm().trim().length() > 0)
				|| userRequest.getUsrEmail() != null && userRequest.getUsrEmail().trim().length() > 0) {
			 List<OrgUser> userList = userService.getUserByEmail(userRequest.getUsrEmail()); 
			 if (userList.size() > 0) { 
				  ResponseStatus status = getResponseStatus(STATUS_FAILED, "",("User Email '" + userRequest.getUsrEmail() + "' Already Exist"), 102);
				  return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST); 
			 }
		} else {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "", ("User details can't be null or blank"), 101);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		
		if(userService.isUserLimitAllow()) {
			CreateUserResponse createUserResponse = userService.createUser(userRequest, activeStatus);
			ResponseStatus status = getResponseStatus(STATUS_PASS, createUserResponse.getUserId(),
					"User successfully created", 0);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
		} else {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "", ("User limit exceed"), 103);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
	
	}

	@PostMapping(path = "/users/copy")
	public ResponseEntity<ResponseStatus> copyUser(@Valid @RequestBody UserRequest userRequest) {

		if ((userRequest.getUserFirstNm() != null && userRequest.getUserFirstNm().trim().length() > 0)
				&& (userRequest.getUsrEmail() != null && userRequest.getUsrEmail().trim().length() > 0)) {
			List<OrgUser> userList = userService.getUserByEmail(userRequest.getUsrEmail());
			if (userList.size() > 0) {
				ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
						("User Email '" + userRequest.getUsrEmail() + "' Already Exist"), 102);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
		} else {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "", ("User details can't be null or blank"), 101);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		CreateUserResponse createUserResponse = userService.copyUser(userRequest);
		ResponseStatus status = getResponseStatus(STATUS_PASS, createUserResponse.getUserId(),
				"User successfully created", 0);

		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);

	}

	@GetMapping(path = "/users")
	public List<OrgUser> getAllUsers(@RequestParam(required = false) String role) {
		return userService.getAllUsers(role);
	}

	@GetMapping(path = "/users/{id}")
	public UserResponse getUser(@PathVariable String id) {
		return userService.getUser(id);
	}

	@PutMapping(path = "/users/{id}")
	public ResponseId updateUser(@PathVariable String id,@Valid @RequestBody UserRequest userRequest) {
		return userService.updateUser(id, userRequest);
	}

	@PutMapping(path = "/users/{id}/suspend")
	public void suspendUser(@PathVariable String id) {
		userService.suspendUser(id);
	}

	@PutMapping(path = "/users/{id}/activate")
	public void activateUser(@PathVariable String id) {
		userService.activateUser(id);
	}

	@PutMapping(path = "/users/{id}/assign-user-groups")
	public void assignUserGroupsToUser(@PathVariable String id, @RequestBody List<String> groups) {
		userService.assignUserGroupsToUser(id, groups);
	}

	@PutMapping(path = "/users/{id}/remove-user-groups")
	public void removeUserGroupsToUser(@PathVariable String id, @RequestBody List<String> groups) {
		userService.removeUserGroupsToUser(id, groups);
	}

	@PutMapping(path = "/users/{id}/assign-roles")
	public void assignRolesToUser(@PathVariable String id, @RequestBody List<String> roles) {
		userService.assignRolesToUser(id, roles);
	}

	@PutMapping(path = "/users/{id}/remove-roles")
	public void removeRolesFromUser(@PathVariable String id, @RequestBody List<String> roles) {
		userService.unAssignRolesToUser(id, roles);
	}

	@GetMapping(path = "/user/community-owner")
	public UserCommunityResponse getCommunityForUserOwner() {
		return userService.getCommunityForUserOwner();
	}

	@GetMapping(path = "/users/{id}/login")
	public void loginUser(@PathVariable String id) {
		userService.loginUser(id);
	}

	@GetMapping(path = "/user/groups/{userId}")
	public List<String> getUserGroup(@PathVariable String userId) {
		return userService.getUserGroup(userId);
	}

	
	@GetMapping(path = "/users/bulk-config")
	public List<OrgBulkUser> getBulkUserConfig() {
		return userService.getBulkUserConfig();
	}
	
	@GetMapping(path = "/users/bulk-config/{id}")
	public OrgBulkUser getBulkUserConfig(@PathVariable UUID id) {
		return userService.getBulkUserConfig(id);
	}
	
	@GetMapping(path = "/users/bulk-config/file/{id}")
	public ResponseEntity<Resource> getBulkUserFile(@PathVariable UUID id) {
	    String filename = "user_details.xlsx";
	    InputStreamResource file = new InputStreamResource(userService.getBulkUserFile(id));

	    return ResponseEntity.ok()
	        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
	        .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
	        .body(file);
	}
	
	@GetMapping(path = "/users/bulk-config/sample")
	public ResponseEntity<Resource> getBulkUserSampleFile() {
		String filename = "user_sample.xlsx";
		InputStreamResource file = new InputStreamResource(userService.getBulkUserSampleFile());

		return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
				.contentType(MediaType.parseMediaType("application/vnd.ms-excel")).body(file);
	}
	
	@PostMapping(path = "/users/bulk-config")
	public ResponseEntity<ResponseStatus> createBulkUser(
			@RequestParam("file") MultipartFile file,@RequestParam("configName") String configName) throws Exception {
		
		userService.uploadBulkUser(file,configName);
		ResponseStatus status = new ResponseStatus(1, file.getOriginalFilename(), "File uploaded Successfuly", 0);
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	}

	
	private ResponseStatus getResponseStatus(int statusCd, String id, String message, int errorCode) {
		ResponseStatus status = new ResponseStatus();
		status.setStatusCode(statusCd);
		status.setId(id);
		status.setMessage(message);
		status.setErrorCode(errorCode);
		return status;
	}
	
	private boolean validateInputData( UserRequest userRequest) {
		boolean ok = true;
		String namePattern = "[a-zA-Z]+";
		String EMAIL_REGEX = "^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$";
		if(Pattern.matches(namePattern, userRequest.getUserFirstNm())) {
			if(Pattern.matches(namePattern, userRequest.getUserLastNm())) {
				Pattern emailPattern = Pattern.compile(EMAIL_REGEX, Pattern.CASE_INSENSITIVE);
				if(!emailPattern.matcher(userRequest.getUsrEmail()).matches()) {
					ok = false;
				} 
			} else {
				ok = false;
			}
		} else {
			ok = false;
		}
		
		return ok;
	}
}
