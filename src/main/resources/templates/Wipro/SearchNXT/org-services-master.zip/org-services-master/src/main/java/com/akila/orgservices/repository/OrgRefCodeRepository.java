package com.akila.orgservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.orgservices.entity.OrgRefCode;

@Repository
public interface OrgRefCodeRepository extends JpaRepository<OrgRefCode, String> {

	public List<OrgRefCode> findByRefCodeDisplayValIgnoreCase(String refCodeDisplayVal);

	public List<OrgRefCode> findByRefCodeDisplayValIgnoreCaseAndRefCodeDescriptionIgnoreCaseAndRefCodeId(
			String refCodeDisplayVal, String refCodeDescription, String refCodeId);
}
