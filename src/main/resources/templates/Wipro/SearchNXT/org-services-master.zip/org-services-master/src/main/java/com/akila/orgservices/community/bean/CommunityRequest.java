package com.akila.orgservices.community.bean;

import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.akila.AkilaRequest;

public class CommunityRequest extends AkilaRequest 
{
	private String communityId;

	@NotEmpty(message = "{COMMUNITY.NAME.MANDATORY}")
	@Pattern(regexp="[a-zA-Z][a-zA-Z0-9 ]*",message = "{COMMUNITY.NAME.FORMAT}")
	@Size(min = 2, max = 50,message = "{COMMUNITY.NAME.LENGTH}")
	private String communityNm;

	@NotEmpty(message = "{COMMUNITY.OWNER.MANDATORY}")
	private String communityOwner;

	@NotNull(message = "{COMMUNITY.PARENT.NOTNULL}")
	private String parentCommunityNm;
	
	@NotEmpty(message = "{COMMUNITY.TAGS.MANDATORY}")
	private List<String> orgCommunityTags;
	
	@NotEmpty(message = "{COMMUNITY.ADMINS.MANDATORY}")
	private List<String> orgCommunityAdmins;
	
	@NotEmpty(message = "{COMMUNITY.USERGROUPS.MANDATORY}")
	private List<String> orgCommunityUserGroups;
	
	public String getCommunityId() {
		return this.communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public String getCommunityNm() {
		if(this.communityNm != null){
			this.communityNm = this.communityNm.trim();
		}
		return this.communityNm;
	}

	public void setCommunityNm(String communityNm) {
		this.communityNm = communityNm;
	}

	public String getCommunityOwner() {
		return this.communityOwner;
	}

	public void setCommunityOwner(String communityOwner) {
		this.communityOwner = communityOwner;
	}

	public String getParentCommunityNm() {
		return this.parentCommunityNm;
	}

	public void setParentCommunityNm(String parentCommunityNm) {
		this.parentCommunityNm = parentCommunityNm;
	}

	public List<String> getOrgCommunityTags() {
		return orgCommunityTags;
	}

	public void setOrgCommunityTags(List<String> orgCommunityTags) {
		this.orgCommunityTags = orgCommunityTags;
	}

	public List<String> getOrgCommunityAdmins() {
		return orgCommunityAdmins;
	}

	public void setOrgCommunityAdmins(List<String> orgCommunityAdmins) {
		this.orgCommunityAdmins = orgCommunityAdmins;
	}

	public List<String> getOrgCommunityUserGroups() {
		return orgCommunityUserGroups;
	}

	public void setOrgCommunityUserGroups(List<String> orgCommunityUserGroups) {
		this.orgCommunityUserGroups = orgCommunityUserGroups;
	}
	
}
