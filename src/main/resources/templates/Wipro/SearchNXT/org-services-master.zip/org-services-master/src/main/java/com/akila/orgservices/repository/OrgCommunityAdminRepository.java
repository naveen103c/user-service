package com.akila.orgservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.orgservices.entity.OrgCommunityAdmin;
import com.akila.orgservices.entity.OrgCommunityAdminPK;

@Repository
public interface OrgCommunityAdminRepository extends JpaRepository<OrgCommunityAdmin, OrgCommunityAdminPK> {

	List<OrgCommunityAdmin> findByIdUserId(String userId);
	
}
