package com.akila.orgservices.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the org_bulk_user_upload database table.
 * 
 */
@Entity
@Table(name="org_bulk_user_upload")
@NamedQuery(name="OrgBulkUser.findAll", query="SELECT o FROM OrgBulkUser o")
public class OrgBulkUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="upload_id")
	private UUID uploadId;

	@Column(name="upload_config_nm")
	protected String uploadConfigNm;
	
	@Column(name="file_nm")
	protected String fileNm;

	@Column(name="total_records")
	private Integer totalRecords;

	@Column(name="success_records")
	private Integer successRecords;

	@Column(name="failure_records")
	private Integer failureRecords;
	
	@Column(name="status")
	private Integer status;

	@Column(name="crt_by")
	protected String crtBy;

	@Column(name="crt_ts")
	protected Timestamp crtTs;
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "upload_id", insertable = false, updatable = false)
    private Set<OrgBulkUserDetails> details;
	
	public OrgBulkUser() {
	}

	public UUID getUploadId() {
		return uploadId;
	}

	public void setUploadId(UUID uploadId) {
		this.uploadId = uploadId;
	}

	public String getUploadConfigNm() {
		return uploadConfigNm;
	}

	public void setUploadConfigNm(String uploadConfigNm) {
		this.uploadConfigNm = uploadConfigNm;
	}

	public String getFileNm() {
		return fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public Integer getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(Integer totalRecords) {
		this.totalRecords = totalRecords;
	}

	public Integer getSuccessRecords() {
		return successRecords;
	}

	public void setSuccessRecords(Integer successRecords) {
		this.successRecords = successRecords;
	}

	public Integer getFailureRecords() {
		return failureRecords;
	}

	public void setFailureRecords(Integer failureRecords) {
		this.failureRecords = failureRecords;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public Set<OrgBulkUserDetails> getDetails() {
		return details;
	}

	public void setDetails(Set<OrgBulkUserDetails> details) {
		this.details = details;
	}

	@Override
	public String toString() {
		return "OrgBulkUser [uploadId=" + uploadId + ", uploadConfigNm=" + uploadConfigNm + ", fileNm=" + fileNm
				+ ", totalRecords=" + totalRecords + ", successRecords=" + successRecords + ", failureRecords="
				+ failureRecords + ", status=" + status + ", crtBy=" + crtBy + ", crtTs=" + crtTs + ", details="
				+ details + "]";
	}

}

