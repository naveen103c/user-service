package com.akila.orgservices.skill.bean;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.akila.AkilaRequest;

public class SkillRequest extends AkilaRequest {
	
  @NotEmpty(message = "{DESC.MANDATORY}")
  @Pattern(regexp = "[a-zA-Z][a-zA-Z0-9 ]*", message = "{DESC.FORMAT}")
  @Size(min = 2, message = "{DESC.LENGTH.MIN}")	
  @Size(max = 100, message = "{DESC.LENGTH.MAX}")	
  private String description;

  @NotEmpty(message = "{SKILL.NAME.MANDATORY}")
  @Pattern(regexp = "[a-zA-Z][a-zA-Z0-9 ]*", message = "{SKILL.NAME.FORMAT}")
  @Size(min = 2, message = "{SKILL.NAME.LENGTH.MIN}")	
  @Size(max = 20, message = "{SKILL.NAME.LENGTH.MAX}")	
  private String skillMnemonic;

  public void setDescription(String description) {
    this.description = description;
  }

  public void setSkillMnemonic(String skillMnemonic) {
    this.skillMnemonic = skillMnemonic;
  }

  public String getDescription() {
    return description;
  }

  public String getSkillMnemonic() {
    return skillMnemonic;
  }
}
