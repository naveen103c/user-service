package com.akila.orgservices.refcodetype.bean;

import com.akila.orgservices.entity.OrgRefCode;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface RefCodeTypeMapper {
  RefCodeTypeMapper INSTANCE = Mappers.getMapper(RefCodeTypeMapper.class);
  ;

  @Mappings({})
  RefCodeTypeResponse orgRefCodeToRefcodetypeResponse(OrgRefCode orgRefCode);

  @Mappings({})
  List<RefCodeTypeResponse> orgRefCodeToRefcodetypeResponseList(List<OrgRefCode> orgRefCode);

  @Mappings({})
  OrgRefCode refcodetypeRequestToOrgRefCode(RefCodeTypeRequest refcodetypeRequest);
}
