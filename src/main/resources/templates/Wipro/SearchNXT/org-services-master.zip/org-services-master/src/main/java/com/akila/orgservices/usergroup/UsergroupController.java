package com.akila.orgservices.usergroup;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.orgservices.entity.OrgUserGroup;
import com.akila.orgservices.entity.OrgUserGroupToUsersLink;
import com.akila.orgservices.skill.bean.ResponseStatus;
import com.akila.orgservices.usergroup.bean.UserGroupGetAllResponse;
import com.akila.orgservices.usergroup.bean.UserGroupRequest;
import com.akila.response.ResponseId;

@RestController
public class UsergroupController extends AkilaController {
  @Autowired
  private UsergroupService usergroupService;

  private int STATUS_FAILED = 0;
  private int STATUS_PASS = 1;
  
  @PostMapping(
      path = "/user-groups"
  )
  public ResponseEntity<ResponseStatus> createUserGroups(@Valid @RequestBody UserGroupRequest usergroupRequest) {
	  if(usergroupService.isGroupLimitAllow()) {
		  ResponseId id = usergroupService.createUserGroups(usergroupRequest);
		  if(id.getId() == null ) {
			  ResponseStatus status = getResponseStatus(STATUS_FAILED, "", "User Group Already Exist", 102);
			  return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		  }else {
			  ResponseStatus status = getResponseStatus(STATUS_PASS, id.getId(), "User Group successfully created", 0);
			  return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
		  }
	  }else {
		  ResponseStatus status = getResponseStatus(STATUS_FAILED, "", "User Group limit exceed", 103);
		  return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
	  }
  }
  
  @DeleteMapping(
      path = "/user-groups/{id}"
  )
  public void deleteUserGroups(@PathVariable String id) {
      usergroupService.deleteUserGroups(id);
  }

	@PutMapping(path = "/user-groups/{id}")
	public ResponseEntity<ResponseStatus> updateUserGroup(@PathVariable String id,@Valid  @RequestBody UserGroupRequest usergroupRequest) {
		
		  ResponseId responseId = usergroupService.updateUserGroups(id, usergroupRequest);
		  if(responseId.getId() == null ) {
			  ResponseStatus status = getResponseStatus(STATUS_FAILED, id, "User Group Already Exist", 102);
			  return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		  }else {
			  ResponseStatus status = getResponseStatus(STATUS_PASS, responseId.getId(), "User Group successfully updated", 0);
			  return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
		  }
	}
  
  @GetMapping(
      path = "/user-groups/{id}"
  )
  public OrgUserGroup getUserGroup(@PathVariable String id) {
    return usergroupService.getUserGroup(id);
  }

  @GetMapping(
      path = "/user-groups"
  )
  public List<UserGroupGetAllResponse> getAllUserGroups() {
    return usergroupService.getAllUserGroups();
  }

  @GetMapping(
      path = "/user/{id}/user-groups"
  )
  public List<OrgUserGroupToUsersLink> getAllUserGroupsForUser(@PathVariable String id) {
    return usergroupService.getAllUserGroupsForUser(id);
  }

  @PutMapping(
      path = "/user-groups/{id}/add-users"
  )
  public void addUsersToUserGroup(@PathVariable String id,
      @RequestBody List<String> users) {
    usergroupService.addUsersToUserGroup(id, users);
  }
  
  @PutMapping(
	      path = "/user-groups/{id}/remove-users"
	  )
	  public void removeUsersToUserGroup(@PathVariable String id,
	      @RequestBody List<String> users) {
	    usergroupService.removeUsersToUserGroup(id, users);
	  }
  
  private ResponseStatus getResponseStatus(int statusCd, String id, String message, int errorCode) {
		ResponseStatus status = new ResponseStatus();
		status.setStatusCode(statusCd);
		status.setId(id);
		status.setMessage(message);
		status.setErrorCode(errorCode);
		return status;
	}
  
}
