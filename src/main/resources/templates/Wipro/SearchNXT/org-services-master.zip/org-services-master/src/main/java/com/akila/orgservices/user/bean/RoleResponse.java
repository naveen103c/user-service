package com.akila.orgservices.user.bean;

import com.akila.AkilaResponse;
import java.lang.String;
import java.sql.Timestamp;

public class RoleResponse extends AkilaResponse {
  private String roleId;

  private String crtBy;

  private Timestamp crtTs;

  private String modBy;

  private Timestamp modTs;

  private String roleDescription;

  private String roleNm;

  public void setRoleId(String roleId) {
    this.roleId = roleId;
  }

  public void setCrtBy(String crtBy) {
    this.crtBy = crtBy;
  }

  public void setCrtTs(Timestamp crtTs) {
    this.crtTs = crtTs;
  }

  public void setModBy(String modBy) {
    this.modBy = modBy;
  }

  public void setModTs(Timestamp modTs) {
    this.modTs = modTs;
  }

  public void setRoleDescription(String roleDescription) {
    this.roleDescription = roleDescription;
  }

  public void setRoleNm(String roleNm) {
    this.roleNm = roleNm;
  }

  public String getRoleId() {
    return roleId;
  }

  public String getCrtBy() {
    return crtBy;
  }

  public Timestamp getCrtTs() {
    return crtTs;
  }

  public String getModBy() {
    return modBy;
  }

  public Timestamp getModTs() {
    return modTs;
  }

  public String getRoleDescription() {
    return roleDescription;
  }

  public String getRoleNm() {
    return roleNm;
  }
}
