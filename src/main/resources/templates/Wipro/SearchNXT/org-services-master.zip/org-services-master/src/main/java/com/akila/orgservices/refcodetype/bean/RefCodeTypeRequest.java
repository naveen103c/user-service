package com.akila.orgservices.refcodetype.bean;

import com.akila.AkilaRequest;

import java.lang.String;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class RefCodeTypeRequest extends AkilaRequest {
	
	private String refCodeId;

	private String refCodeTypeId;

	@NotEmpty(message = "{DESC.MANDATORY}")
	@Pattern(regexp = "[a-zA-Z][a-zA-Z ]*", message = "{DESC.FORMAT}")
	@Size(min = 2, message = "{DESC.LENGTH.MIN}") 
	@Size(max = 100, message = "{DESC.LENGTH.MAX}") 
	private String refCodeDescription;

	@NotEmpty(message = "{REFCODETYPE.DISPLAY.MANDATORY}")
	@Pattern(regexp = "[a-zA-Z][a-zA-Z ]*", message = "{REFCODETYPE.DISPLAY.FORMAT}")
	@Size(min = 2, message = "{REFCODETYPE.NAME.LENGTH.MIN}") 
	@Size(max = 50, message = "{REFCODETYPE.NAME.LENGTH.MAX}") 	
	private String refCodeDisplayVal;

	@NotNull()
	@Min(1)
	private String refCodeStoreVal;

	public String getRefCodeTypeId() {
		return refCodeTypeId;
	}

	public void setRefCodeTypeId(String refCodeTypeId) {
		this.refCodeTypeId = refCodeTypeId;
	}

	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public String getRefCodeStoreVal() {
		return refCodeStoreVal;
	}

	public void setRefCodeStoreVal(String refCodeStoreVal) {
		this.refCodeStoreVal = refCodeStoreVal;
	}

	public void setRefCodeDescription(String refCodeDescription) {
		this.refCodeDescription = refCodeDescription;
	}

	public void setRefCodeDisplayVal(String refCodeDisplayVal) {
		this.refCodeDisplayVal = refCodeDisplayVal;
	}

	public String getRefCodeDescription() {
		return refCodeDescription;
	}

	public String getRefCodeDisplayVal() {
		return refCodeDisplayVal;
	}
}
