package com.akila.orgservices.community;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.orgservices.entity.OrgCommunitySme;
import com.akila.orgservices.entity.OrgCommunitySmePK;
import com.akila.orgservices.repository.OrgCommunitySmeRepository;

@Service
public class CommunitySmeService extends AkilaService
{
	@Autowired
	private OrgCommunitySmeRepository orgCommunitySmeRepository;
	
	public void deleteSme(String communityId, String userId)
	{
		OrgCommunitySme orgCommunityTag = new OrgCommunitySme();
		orgCommunityTag.setId(getOrgCommunitySmePK(communityId,userId));
		orgCommunitySmeRepository.delete(orgCommunityTag);
	}
	
	public void createSme(String communityId, String userId)
	{
		OrgCommunitySme orgCommunityTag = new OrgCommunitySme();
		orgCommunityTag.setId(getOrgCommunitySmePK(communityId,userId));
		orgCommunityTag.setCrtBy(getUserId());
		orgCommunityTag.setModBy(getUserId());
		orgCommunityTag.setCrtTs(new Timestamp(new Date().getTime()));
		orgCommunityTag.setModTs(new Timestamp(new Date().getTime()));
		orgCommunitySmeRepository.save(orgCommunityTag);
	}
	
	public OrgCommunitySmePK getOrgCommunitySmePK(String communityId,String userId) {
		OrgCommunitySmePK orgCommunitySmePK = new OrgCommunitySmePK();
		orgCommunitySmePK.setUserId(userId);
		orgCommunitySmePK.setCommunityId(communityId);
		return orgCommunitySmePK;
	}

}
