package com.akila.orgservices.user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.orgservices.OrgServicesApplication;
import com.akila.orgservices.user.bean.UserRequest;

@SpringBootTest(classes = OrgServicesApplication.class)
public class UserControllerTest 
{
	
	@Test
	public void getAllUsers()
	{
		//controller.getAllUsers("");
	}
	
	@Test
	public void createUser()
	{
		UserRequest request = new UserRequest();
		request.setUserFirstNm("first name");
		request.setUserLastNm("last name");
		request.setUsrEmail("ak1127@test.com");
		//controller.createUser(request);
	}
	
	@Test
	public void deactivateUser()
	{
	//	controller.activateUser("fc2a4418-e2f4-4b4f-bcd8-6afc932a1ef4");
	}

}
