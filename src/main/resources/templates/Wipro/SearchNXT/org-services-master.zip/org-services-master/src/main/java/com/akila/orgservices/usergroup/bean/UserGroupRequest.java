package com.akila.orgservices.usergroup.bean;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.akila.AkilaRequest;

public class UserGroupRequest extends AkilaRequest {

	@NotEmpty(message = "{USERGROUP.NAME.MANDATORY}")
	@Pattern(regexp = "[a-zA-Z][a-zA-Z0-9 ]*", message = "{USERGROUP.NAME.FORMAT}")
	@Size(min = 2, message = "{USERGROUP.NAME.LENGTH.MIN}") 
	@Size(max = 50, message = "{USERGROUP.NAME.LENGTH.MAX}") 
	private String userGroupNm;
	
	@NotEmpty(message = "{DESC.MANDATORY}")
	@Pattern(regexp = "[a-zA-Z][a-zA-Z0-9 ]*", message = "{DESC.FORMAT}")
	@Size(min = 2, message = "{DESC.LENGTH.MIN}") 
	@Size(max = 200, message = "{DESC.LENGTH.MAX}") 
	private String userGroupDesc;

	public void setUserGroupNm(String userGroupNm) {
		this.userGroupNm = userGroupNm;
	}

	public String getUserGroupNm() {
		return userGroupNm;
	}

	public String getUserGroupDesc() {
		return userGroupDesc;
	}

	public void setUserGroupDesc(String userGroupDesc) {
		this.userGroupDesc = userGroupDesc;
	}

}
