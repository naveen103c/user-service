package com.akila.orgservices.usergroup.bean;

import com.akila.AkilaResponse;
import com.akila.orgservices.entity.OrgUserGroupToUsersLink;

import java.lang.String;
import java.sql.Timestamp;
import java.util.List;

public class UserGroupResponse extends AkilaResponse {
  private String crtBy;

  private Timestamp crtTs;

  private String modBy;

  private Timestamp modTs;

  private String userGroupNm;
  
  private List<OrgUserGroupToUsersLink> users;

  public void setCrtBy(String crtBy) {
    this.crtBy = crtBy;
  }

  public void setCrtTs(Timestamp crtTs) {
    this.crtTs = crtTs;
  }

  public void setModBy(String modBy) {
    this.modBy = modBy;
  }

  public void setModTs(Timestamp modTs) {
    this.modTs = modTs;
  }

  public void setUserGroupNm(String userGroupNm) {
    this.userGroupNm = userGroupNm;
  }

  public String getCrtBy() {
    return crtBy;
  }

  public Timestamp getCrtTs() {
    return crtTs;
  }

  public String getModBy() {
    return modBy;
  }

  public Timestamp getModTs() {
    return modTs;
  }

  public String getUserGroupNm() {
    return userGroupNm;
  }

	public List<OrgUserGroupToUsersLink> getUsers() {
		return users;
	}

	public void setUsers(List<OrgUserGroupToUsersLink> users) {
		this.users = users;
	}
  
}
