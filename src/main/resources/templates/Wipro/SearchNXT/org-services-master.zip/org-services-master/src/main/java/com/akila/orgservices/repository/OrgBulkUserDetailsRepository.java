package com.akila.orgservices.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.orgservices.entity.OrgBulkUserDetails;

@Repository
public interface OrgBulkUserDetailsRepository extends JpaRepository<OrgBulkUserDetails, UUID> 
{
	List<OrgBulkUserDetails> findByUploadId(UUID uploadId);
	
	List<OrgBulkUserDetails> findByUploadIdAndStatus(UUID uploadId,Integer status);
}
