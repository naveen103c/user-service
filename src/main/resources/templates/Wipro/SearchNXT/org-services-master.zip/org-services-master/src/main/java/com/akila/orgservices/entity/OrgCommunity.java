package com.akila.orgservices.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.akila.AkilaEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The persistent class for the org_communities database table.
 * 
 */
@Entity
@Table(name="org_communities")
@NamedQuery(name="OrgCommunity.findAll", query="SELECT o FROM OrgCommunity o")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class OrgCommunity extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="community_id")
	private String communityId;

	@Column(name="community_nm")
	private String communityNm;

	@Column(name="community_owner")
	private String communityOwner;

	@Column(name="parent_community_nm")
	private String parentCommunityNm;

	@Column(name="config_id")
	private String configId;

	//bi-directional many-to-one association to OrgCommunitySme
	@OneToMany(mappedBy="orgCommunity",orphanRemoval=true , cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	private List<OrgCommunitySme> orgCommunitySmes;

	//bi-directional many-to-one association to OrgCommunityTag
	@OneToMany(mappedBy="orgCommunity",orphanRemoval=true , cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	private List<OrgCommunityTag> orgCommunityTags;
	
	//bi-directional many-to-one association to OrgCommunityAdmin
	@OneToMany(mappedBy="orgCommunity",orphanRemoval=true , cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	private List<OrgCommunityAdmin> orgCommunityAdmins;
	
	@OneToMany(mappedBy="orgCommunity",orphanRemoval=true , cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	private List<OrgCommunityUserGroup> orgCommunityUserGroups;


	public OrgCommunity() {
	}

	public String getCommunityId() {
		return this.communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public String getCommunityNm() {
		return this.communityNm;
	}

	public void setCommunityNm(String communityNm) {
		this.communityNm = communityNm;
	}

	public String getCommunityOwner() {
		return this.communityOwner;
	}

	public void setCommunityOwner(String communityOwner) {
		this.communityOwner = communityOwner;
	}

	public String getParentCommunityNm() {
		return this.parentCommunityNm;
	}

	public void setParentCommunityNm(String parentCommunityNm) {
		this.parentCommunityNm = parentCommunityNm;
	}

	public List<OrgCommunitySme> getOrgCommunitySmes() {
		return this.orgCommunitySmes;
	}

	public void setOrgCommunitySmes(List<OrgCommunitySme> orgCommunitySmes) {
		this.orgCommunitySmes = orgCommunitySmes;
	}

	public OrgCommunitySme addOrgCommunitySme(OrgCommunitySme orgCommunitySme) {
		getOrgCommunitySmes().add(orgCommunitySme);
		orgCommunitySme.setOrgCommunity(this);

		return orgCommunitySme;
	}

	public OrgCommunitySme removeOrgCommunitySme(OrgCommunitySme orgCommunitySme) {
		getOrgCommunitySmes().remove(orgCommunitySme);
		orgCommunitySme.setOrgCommunity(null);

		return orgCommunitySme;
	}

	public List<OrgCommunityTag> getOrgCommunityTags() {
		return this.orgCommunityTags;
	}

	public void setOrgCommunityTags(List<OrgCommunityTag> orgCommunityTags) {
		this.orgCommunityTags = orgCommunityTags;
	}

	public OrgCommunityTag addOrgCommunityTag(OrgCommunityTag orgCommunityTag) {
		getOrgCommunityTags().add(orgCommunityTag);
		orgCommunityTag.setOrgCommunity(this);

		return orgCommunityTag;
	}

	public OrgCommunityTag removeOrgCommunityTag(OrgCommunityTag orgCommunityTag) {
		getOrgCommunityTags().remove(orgCommunityTag);
		orgCommunityTag.setOrgCommunity(null);

		return orgCommunityTag;
	}

	
	public OrgCommunityAdmin addOrgCommunityAdmin(OrgCommunityAdmin orgCommunityAdmin) {
		this.getOrgCommunityAdmins().add(orgCommunityAdmin);
		orgCommunityAdmin.setOrgCommunity(this);
		return orgCommunityAdmin;
	}

	public OrgCommunityAdmin removeOrgCommunityAdmin(OrgCommunityAdmin orgCommunityAdmin) {
		this.getOrgCommunityAdmins().remove(orgCommunityAdmin);
		orgCommunityAdmin.setOrgCommunity(null);

		return orgCommunityAdmin;
	}
	
	public List<OrgCommunityAdmin> getOrgCommunityAdmins() {
		return orgCommunityAdmins;
	}

	public void setOrgCommunityAdmins(List<OrgCommunityAdmin> orgCommunityAdmins) {
		this.orgCommunityAdmins = orgCommunityAdmins;
	}

	public List<OrgCommunityUserGroup> getOrgCommunityUserGroups() {
		return orgCommunityUserGroups;
	}

	public void setOrgCommunityUserGroups(List<OrgCommunityUserGroup> orgCommunityUserGroups) {
		this.orgCommunityUserGroups = orgCommunityUserGroups;
	}
	
	public OrgCommunityUserGroup addOrgCommunityUserGroup(OrgCommunityUserGroup orgCommunityUserGroup) {
		this.getOrgCommunityUserGroups().add(orgCommunityUserGroup);
		orgCommunityUserGroup.setOrgCommunity(this);
		return orgCommunityUserGroup;
	}

	public OrgCommunityUserGroup removeOrgCommunityUserGroup(OrgCommunityUserGroup orgCommunityUserGroup) {
		this.getOrgCommunityUserGroups().remove(orgCommunityUserGroup);
		orgCommunityUserGroup.setOrgCommunity(null);
		return orgCommunityUserGroup;
	}

	public String getConfigId() {
		return configId;
	}

	public void setConfigId(String configId) {
		this.configId = configId;
	}

}