package com.akila.orgservices.refcode.bean;

import com.akila.orgservices.entity.OrgRefCode;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface RefCodeMapper {
  RefCodeMapper INSTANCE = Mappers.getMapper(RefCodeMapper.class);
  ;

  @Mappings({})
  RefCodeResponse orgRefCodeToRefcodeResponse(OrgRefCode orgRefCode);

  @Mappings({})
  List<RefCodeResponse> orgRefCodeToRefcodeResponseList(List<OrgRefCode> orgRefCode);

  @Mappings({})
  OrgRefCode refcodeRequestToOrgRefCode(RefCodeRequest refcodeRequest);
}
