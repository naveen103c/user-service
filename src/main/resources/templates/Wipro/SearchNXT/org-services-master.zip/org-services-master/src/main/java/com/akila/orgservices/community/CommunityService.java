package com.akila.orgservices.community;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.orgservices.community.bean.CommunityMapper;
import com.akila.orgservices.community.bean.CommunityRequest;
import com.akila.orgservices.community.bean.CommunityResponse;
import com.akila.orgservices.community.bean.ConfFilter;
import com.akila.orgservices.community.bean.ConfRequest;
import com.akila.orgservices.community.bean.Schedule;
import com.akila.orgservices.community.bean.SourceTypeField;
import com.akila.orgservices.community.bean.UserDetail;
import com.akila.orgservices.entity.OrgCommunity;
import com.akila.orgservices.entity.OrgCommunityAdmin;
import com.akila.orgservices.entity.OrgCommunityAdminPK;
import com.akila.orgservices.entity.OrgCommunitySmePK;
import com.akila.orgservices.entity.OrgCommunityTag;
import com.akila.orgservices.entity.OrgCommunityTagPK;
import com.akila.orgservices.entity.OrgCommunityUserGroup;
import com.akila.orgservices.entity.OrgCommunityUserGroupPK;
import com.akila.orgservices.repository.OrgCommunityRepository;
import com.akila.response.ResponseId;

@Service
public class CommunityService extends AkilaService {

	
	@Autowired
	private OrgCommunityRepository orgCommunityRepository;

	@Autowired
	private CommunityMapper communityMapper;
	
	@Value("${ask.attachment.source.type}")
	private int attachmentSourceType;
	
	@Value("${attachment.conf.postfix}")
	private String attachmentConfPostfix;
	
	@Value("${batchjob.service.url}")
	private String batchjobServiceUrl;
	
	@Autowired
	AkilaRestTemplate akilaRestTemplate;
	
	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate loadBalancedRestTemplate;

	@Transactional
	public ResponseId createCommunity(CommunityRequest communityRequest) {
		
		String confId = createCommunityConfig(communityRequest);
		
		OrgCommunity orgCommunity = communityMapper.communityRequestToOrgCommunity(communityRequest);
		orgCommunity.setCommunityId(UUID.randomUUID().toString());
		//orgCommunity.setCommunityOwner(super.getUserId());
		orgCommunity.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgCommunity.setModTs(new Timestamp(System.currentTimeMillis()));
		orgCommunity.setOrgCommunityAdmins(new ArrayList<OrgCommunityAdmin>());
		orgCommunity.setOrgCommunityTags(new ArrayList<OrgCommunityTag>());
		orgCommunity.setOrgCommunityUserGroups(new ArrayList<OrgCommunityUserGroup>());
		orgCommunity.setConfigId(confId);
		for(String tag : communityRequest.getOrgCommunityTags())
		{
			OrgCommunityTag orgCommunityTag = new OrgCommunityTag();
			orgCommunityTag.setId(getOrgCommunityTagPK(orgCommunity.getCommunityId(), tag));
			orgCommunityTag.setCrtBy(getUserId());
			orgCommunityTag.setModBy(getUserId());
			orgCommunityTag.setCrtTs(new Timestamp(new Date().getTime()));
			orgCommunityTag.setModTs(new Timestamp(new Date().getTime()));
			
			orgCommunity.addOrgCommunityTag(orgCommunityTag);
		}
		
		for(String admin : communityRequest.getOrgCommunityAdmins())
		{
			OrgCommunityAdmin orgCommunityAdmin = new OrgCommunityAdmin();
			orgCommunityAdmin.setId(getOrgCommunityAdminPK(orgCommunity.getCommunityId(), admin));
			orgCommunityAdmin.setCrtBy(getUserId());
			orgCommunityAdmin.setModBy(getUserId());
			orgCommunityAdmin.setCrtTs(new Timestamp(new Date().getTime()));
			orgCommunityAdmin.setModTs(new Timestamp(new Date().getTime()));
			orgCommunity.addOrgCommunityAdmin(orgCommunityAdmin);
		}
		
		for(String userGroup : communityRequest.getOrgCommunityUserGroups())
		{
			OrgCommunityUserGroup orgCommunityUserGroup = new OrgCommunityUserGroup();
			orgCommunityUserGroup.setId(getOrgCommunityUserGroupPK(orgCommunity.getCommunityId(), userGroup));
			orgCommunityUserGroup.setCrtBy(getUserId());
			orgCommunityUserGroup.setModBy(getUserId());
			orgCommunityUserGroup.setCrtTs(new Timestamp(new Date().getTime()));
			orgCommunityUserGroup.setModTs(new Timestamp(new Date().getTime()));
			orgCommunity.addOrgCommunityUserGroup(orgCommunityUserGroup);
		}	
		
		orgCommunity = orgCommunityRepository.save(orgCommunity);
		
		// Create Metric-Community Event
		this.createEvent("Metric-Community");
		return new ResponseId(orgCommunity.getCommunityId());
		
	}

	@Transactional
	public ResponseId updateCommunity(String id, CommunityRequest communityRequest) {
		OrgCommunity orgCommunity = orgCommunityRepository.findById(id).orElse(null);
		
		if(orgCommunity.getConfigId() == null) {
			String confId = createCommunityConfig(communityRequest);
			orgCommunity.setConfigId(confId);
		}else {
			updateCommunityConfigUserGroups(communityRequest, orgCommunity.getConfigId());
		} 
		if (orgCommunity != null) {
			orgCommunity.setCommunityNm(communityRequest.getCommunityNm());
			orgCommunity.setCommunityOwner(communityRequest.getCommunityOwner());
			orgCommunity.setParentCommunityNm(communityRequest.getParentCommunityNm());
			orgCommunity.setModTs(new Timestamp(System.currentTimeMillis()));
			orgCommunity.setModBy(super.getUserId());
			
			List<String> availableTags = new ArrayList<String>();
			List<OrgCommunityTag> deletedTags = new ArrayList<OrgCommunityTag>();
			for (OrgCommunityTag tag : orgCommunity.getOrgCommunityTags()) {
				if(!communityRequest.getOrgCommunityTags().contains(tag.getId().getTagId())) {
					deletedTags.add(tag);
				}
				else {
					availableTags.add(tag.getId().getTagId());
				}
			}
			// Remove All Deleted Tags 
			orgCommunity.getOrgCommunityTags().removeAll(deletedTags);
			// Add All New Added Tags
			for (String tag : communityRequest.getOrgCommunityTags()) {
				if (!availableTags.contains(tag)) {
					OrgCommunityTag orgCommunityTag = new OrgCommunityTag();
					orgCommunityTag.setId(getOrgCommunityTagPK(orgCommunity.getCommunityId(), tag));
					orgCommunityTag.setCrtBy(getUserId());
					orgCommunityTag.setModBy(getUserId());
					orgCommunityTag.setCrtTs(new Timestamp(new Date().getTime()));
					orgCommunityTag.setModTs(new Timestamp(new Date().getTime()));
					orgCommunity.addOrgCommunityTag(orgCommunityTag);
				}
			}	
			
			List<String> availableAdmins = new ArrayList<String>();
			List<OrgCommunityAdmin> deletedAdmins = new ArrayList<OrgCommunityAdmin>();
			for (OrgCommunityAdmin admin : orgCommunity.getOrgCommunityAdmins()) {
				if(!communityRequest.getOrgCommunityAdmins().contains(admin.getId().getUserId())) {
					deletedAdmins.add(admin);
				}
				else {
					availableAdmins.add(admin.getId().getUserId());
				}
			}
			// Remove All Deleted Admins 
			orgCommunity.getOrgCommunityAdmins().removeAll(deletedAdmins);
			// Add All New Added Admins
			for (String admin : communityRequest.getOrgCommunityAdmins()) {
				if (!availableAdmins.contains(admin)) {
					OrgCommunityAdmin orgCommunityAdmin = new OrgCommunityAdmin();
					orgCommunityAdmin.setId(getOrgCommunityAdminPK(orgCommunity.getCommunityId(), admin));
					orgCommunityAdmin.setCrtBy(getUserId());
					orgCommunityAdmin.setModBy(getUserId());
					orgCommunityAdmin.setCrtTs(new Timestamp(new Date().getTime()));
					orgCommunityAdmin.setModTs(new Timestamp(new Date().getTime()));
					orgCommunity.addOrgCommunityAdmin(orgCommunityAdmin);
				}
			}
			
			List<String> availableGroups = new ArrayList<String>();
			List<OrgCommunityUserGroup> deletedGroups = new ArrayList<OrgCommunityUserGroup>();
			for (OrgCommunityUserGroup group : orgCommunity.getOrgCommunityUserGroups()) {
				if(!communityRequest.getOrgCommunityUserGroups().contains(group.getId().getUserGroupId())) {
					deletedGroups.add(group);
				}
				else {
					availableGroups.add(group.getId().getUserGroupId());
				}
			}
			
			// Remove All Deleted User Groups 
			orgCommunity.getOrgCommunityUserGroups().removeAll(deletedGroups);
			
			for(String userGroup : communityRequest.getOrgCommunityUserGroups())
			{
				if (!availableGroups.contains(userGroup)) {
					OrgCommunityUserGroup orgCommunityUserGroup = new OrgCommunityUserGroup();
					orgCommunityUserGroup.setId(getOrgCommunityUserGroupPK(orgCommunity.getCommunityId(), userGroup));
					orgCommunityUserGroup.setCrtBy(getUserId());
					orgCommunityUserGroup.setModBy(getUserId());
					orgCommunityUserGroup.setCrtTs(new Timestamp(new Date().getTime()));
					orgCommunityUserGroup.setModTs(new Timestamp(new Date().getTime()));
					orgCommunity.addOrgCommunityUserGroup(orgCommunityUserGroup);
				}
			}
			
			orgCommunity = orgCommunityRepository.save(orgCommunity);
			return new ResponseId(orgCommunity.getCommunityId());
		} else {
			return null;
		}

	}

	public OrgCommunity getCommunity(String id) {
		OrgCommunity orgCommunity = orgCommunityRepository.findById(id).orElse(null);
		if(orgCommunity != null) {
			orgCommunity.getOrgCommunitySmes().removeIf(sme -> sme.getUser().getIsActive() == false);
			return orgCommunity;
		}
		return orgCommunity;
	}

	public List<CommunityResponse> getAllCommunities() {
		List<OrgCommunity> orgCommunityList = orgCommunityRepository.findAll();
		return communityMapper.orgCommunityListToCommunityResponseList(orgCommunityList);
	}

	public void deleteCommunity(String id) 
	{
		orgCommunityRepository.deleteById(id);
	}

	public OrgCommunitySmePK getOrgCommunitySmePK(String communityId) {
		OrgCommunitySmePK orgCommunitySmePK = new OrgCommunitySmePK();
		orgCommunitySmePK.setUserId(super.getUserId());
		orgCommunitySmePK.setCommunityId(communityId);
		return orgCommunitySmePK;
	}
	
	public OrgCommunityAdminPK getOrgCommunityAdminPK(String communityId,String userId) {
		OrgCommunityAdminPK orgCommunityAdminPK = new OrgCommunityAdminPK();
		orgCommunityAdminPK.setUserId(userId);
		orgCommunityAdminPK.setCommunityId(communityId);
		return orgCommunityAdminPK;
	}

	public OrgCommunityTagPK getOrgCommunityTagPK(String communityId, String tagId) {
		OrgCommunityTagPK orgCommunityTagPK = new OrgCommunityTagPK();
		orgCommunityTagPK.setCommunityId(communityId);
		orgCommunityTagPK.setTagId(tagId);
		return orgCommunityTagPK;
	}
	
	public OrgCommunityUserGroupPK getOrgCommunityUserGroupPK(String communityId, String userGroupId) {
		OrgCommunityUserGroupPK orgCommunityUserGroupPK = new OrgCommunityUserGroupPK();
		orgCommunityUserGroupPK.setCommunityId(communityId);
		orgCommunityUserGroupPK.setUserGroupId(userGroupId);
		return orgCommunityUserGroupPK;
	}
	
	public List<String> getAllCommunitiesName(String id) {
		 List<String> name = new  ArrayList<String>();
		List<OrgCommunity> orgCommunityList = orgCommunityRepository.findAll();
		for (OrgCommunity orgCommunity : orgCommunityList) {
			if(id == null || !id.equalsIgnoreCase(orgCommunity.getCommunityId())) {
				name.add(orgCommunity.getCommunityNm().trim().toLowerCase());
			}
		}
		return name;
	}

	
	public String createCommunityConfig(CommunityRequest communityRequest) {
		
		ConfRequest confRequest = new ConfRequest();
		confRequest.setConfName(communityRequest.getCommunityNm()+attachmentConfPostfix);
		confRequest.setSourceExtractionTypeCd(2);
		confRequest.setSourceTypeCd(attachmentSourceType);
		confRequest.setSourceAllowedUserGroupList(communityRequest.getOrgCommunityUserGroups());
		confRequest.setSourceDescription(communityRequest.getCommunityNm()+attachmentConfPostfix);
		
		confRequest.setSourceTypeFields(new ArrayList<SourceTypeField>());
		confRequest.setSourceTagIdList(new ArrayList<>());
		confRequest.setSourceScheduleJson(new Schedule());
		confRequest.setFilter(new ArrayList<ConfFilter>());
		
		HttpHeaders headers = super.getRequestHeader();
		HttpEntity<ConfRequest> entity = new HttpEntity<ConfRequest>(confRequest, headers);
		ResponseEntity<ResponseId> response = akilaRestTemplate.postForEntity(loadBalancedRestTemplate, batchjobServiceUrl + "/confs", entity,
				ResponseId.class);
		return response.getBody().getId();
	}
	
	public String updateCommunityConfigUserGroups(CommunityRequest communityRequest,String confId) {
		
		HttpHeaders headers = super.getRequestHeader();
		HttpEntity<List<String>> entity = new HttpEntity<List<String>>(communityRequest.getOrgCommunityUserGroups(), headers);
		ResponseEntity<ResponseId> response = akilaRestTemplate.exchange(loadBalancedRestTemplate, batchjobServiceUrl + "/confs/user-groups/"+confId,HttpMethod.PUT,entity,
				ResponseId.class);
		return response.getBody().getId();
	}

	public List<UserDetail> getCommunityGroupUsers(String id) {
		List<UserDetail> orgUsers = orgCommunityRepository.getAllUsersMappedWithCommunityUserGroup(id);
        if(orgUsers !=null && orgUsers.size() > 0) {
        	orgUsers.removeIf(user -> user.isActive() == false);
        }
        else {
        	orgUsers = new ArrayList<>();
        }
		return orgUsers;
	}
}
