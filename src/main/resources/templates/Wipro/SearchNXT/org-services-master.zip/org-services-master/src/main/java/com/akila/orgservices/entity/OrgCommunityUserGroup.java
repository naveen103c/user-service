package com.akila.orgservices.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the org_community_user_groups database table.
 * 
 */
@Entity
@Table(name="org_community_user_groups")
@NamedQuery(name="OrgCommunityUserGroup.findAll", query="SELECT o FROM OrgCommunityUserGroup o")
public class OrgCommunityUserGroup extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgCommunityUserGroupPK id;

	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="community_id",  insertable=false, updatable=false)
	private OrgCommunity orgCommunity;

	public OrgCommunityUserGroup() {
	}

	public OrgCommunityUserGroupPK getId() {
		return this.id;
	}

	public void setId(OrgCommunityUserGroupPK id) {
		this.id = id;
	}

	public OrgCommunity getOrgCommunity() {
		return this.orgCommunity;
	}

	public void setOrgCommunity(OrgCommunity orgCommunity) {
		this.orgCommunity = orgCommunity;
	}

}