package com.akila.orgservices.refcode.bean;

import com.akila.AkilaRequest;
import java.lang.String;

public class RefCodeRequest extends AkilaRequest {
  private String refCodeDescription;

  private String refCodeDisplayVal;

  public void setRefCodeDescription(String refCodeDescription) {
    this.refCodeDescription = refCodeDescription;
  }

  public void setRefCodeDisplayVal(String refCodeDisplayVal) {
    this.refCodeDisplayVal = refCodeDisplayVal;
  }

  public String getRefCodeDescription() {
    return refCodeDescription;
  }

  public String getRefCodeDisplayVal() {
    return refCodeDisplayVal;
  }
}
