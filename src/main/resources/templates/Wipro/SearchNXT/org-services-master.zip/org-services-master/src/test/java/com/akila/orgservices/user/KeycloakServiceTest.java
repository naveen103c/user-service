package com.akila.orgservices.user;

import org.junit.jupiter.api.Test;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.orgservices.OrgServicesApplication;

@SpringBootTest(classes = OrgServicesApplication.class)
public class KeycloakServiceTest 
{
	@Test
	public void createUser()
	{
		//KeycloakService service = new KeycloakService("wiga-dev", "9444dfc4-b65e-428a-a6f8-47b75c58dad6", "akk", "akk","http://ec2-3-15-27-179.us-east-2.compute.amazonaws.com:8080/auth/");
		UserRepresentation user = new UserRepresentation();
        user.setEnabled(true);
        user.setUsername("a1k@test.com");
        user.setFirstName("First");
        user.setLastName("Last");
        user.setEmail("a1k@test.com");
		//service.createUser(user);
	}

}
