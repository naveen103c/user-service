package com.akila.orgservices.tag;

import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.orgservices.entity.OrgTag;
import com.akila.orgservices.repository.OrgTagRepository;
import com.akila.orgservices.tag.bean.TagMapper;
import com.akila.orgservices.tag.bean.TagRequest;
import com.akila.orgservices.tag.bean.TagResponse;
import com.akila.response.ResponseId;

@Service
public class TagService extends AkilaService {
	@Autowired
	private OrgTagRepository orgTagRepository;

	@Autowired
	private TagMapper tagMapper;

	public ResponseId createTag(TagRequest tagRequest) {
		OrgTag orgTag = tagMapper.tagRequestToOrgTag(tagRequest);
		orgTag.setTagId(UUID.randomUUID().toString());
		orgTag.setCrtBy(super.getUserId());
		orgTag.setModBy(super.getUserId());
		orgTag.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgTag.setModTs(new Timestamp(System.currentTimeMillis()));
		orgTag = orgTagRepository.save(orgTag);
		return new ResponseId(orgTag.getTagId());
	}

	public ResponseId updateTag(String id, TagRequest tagRequest) {
		
		if (orgTagRepository.existsById(id)) {
			OrgTag orgTag = tagMapper.tagRequestToOrgTag(tagRequest);
			OrgTag orgTagOld = orgTagRepository.getOne(id);
			
			orgTagOld.setTagMnemonic(orgTag.getTagMnemonic());
			orgTagOld.setTagTypeCd(orgTag.getTagTypeCd());
			orgTagOld.setDescription(orgTag.getDescription());
			orgTagOld.setCrtTs(new Timestamp(System.currentTimeMillis()));
			orgTagOld.setModTs(new Timestamp(System.currentTimeMillis()));
			orgTagOld = orgTagRepository.save(orgTagOld);
			
			return new ResponseId(orgTagOld.getTagId().toString());
		} else {
			return null;// todo: replace the null value with the Resource not found exception
		}
	}

	public TagResponse getTag(String id) {
		OrgTag orgTag=orgTagRepository.getOne(id);
		return tagMapper.orgTagToTagResponse(orgTag);
	}

	public List<TagResponse> getAllTags(Integer tagTypeCd) {
		List<OrgTag> orgTagList=null;
		if(tagTypeCd !=null) {
		orgTagList = orgTagRepository.findAllOrgTagsByTagTypeCode(tagTypeCd);
		}
		else {
			orgTagList = orgTagRepository.findAll();
		}
		return tagMapper.orgTagToTagResponseList(orgTagList);
	}
	
	public List<OrgTag> getByTagMnemonicByName(String tagMnemonic) {
		return orgTagRepository.findByTagMnemonicIgnoreCase(tagMnemonic);
	}
	
	public List<OrgTag> getByTagMnemonicAndId(String tagMnemonic, String tagId) {
		return orgTagRepository.findByTagMnemonicIgnoreCaseAndTagIdNot(tagMnemonic, tagId);
	}

	public ResponseId deleteTag(String id) {
		OrgTag orgTag=orgTagRepository.getOne(id);
		orgTagRepository.delete(orgTag);
		return new ResponseId(orgTag.getTagTypeCd().toString());
	}

}
