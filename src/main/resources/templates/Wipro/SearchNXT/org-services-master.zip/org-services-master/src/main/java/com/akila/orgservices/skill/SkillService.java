package com.akila.orgservices.skill;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.orgservices.entity.OrgSkill;
import com.akila.orgservices.repository.OrgSkillRepository;
import com.akila.orgservices.skill.bean.SkillMapper;
import com.akila.orgservices.skill.bean.SkillRequest;
import com.akila.orgservices.skill.bean.SkillResponse;
import com.akila.response.ResponseId;

@Service
public class SkillService extends AkilaService {
  @Autowired
  private OrgSkillRepository orgSkillRepository;

  @Autowired
  private SkillMapper skillMapper;

	public ResponseId createSkill(SkillRequest skillRequest) {
		OrgSkill orgSkill = skillMapper.skillRequestToOrgSkill(skillRequest);
		orgSkill.setSkillId(UUID.randomUUID().toString());
		orgSkill.setCrtBy(super.getUserId());
		orgSkill.setModBy(super.getUserId());
		orgSkill.setModTs(new Timestamp(System.currentTimeMillis()));
		orgSkill.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgSkill = orgSkillRepository.save(orgSkill);
		return new ResponseId(orgSkill.getSkillId());
	}

  public ResponseId updateSkill(String id, SkillRequest skillRequest) {
		OrgSkill orgSkill = orgSkillRepository.getOne(id);
		if(orgSkill != null) {
			orgSkill.setSkillMnemonic(skillRequest.getSkillMnemonic());
			orgSkill.setDescription(skillRequest.getDescription());
			orgSkill.setModBy(super.getUserId());
			orgSkill.setModTs(new Timestamp(System.currentTimeMillis()));
			orgSkill = orgSkillRepository.save(orgSkill);
		}
		return new ResponseId(id);
  }

  public SkillResponse getSkills(String id) {
    OrgSkill orgSkill = orgSkillRepository.getOne(id);
        return skillMapper.orgSkillToSkillResponse(orgSkill);
  }

  public List<SkillResponse> getAllSkills() {
	    List<OrgSkill> orgSkills = orgSkillRepository.findAll();
        return skillMapper.orgSkillToSkillResponseList(orgSkills);
  }

  public void deleteSkill(String id) {
    orgSkillRepository.deleteById(id);
  }
  
  public List<String> getAllExisitngSkillMnemonic(String id){
	  List<String> name = new ArrayList<String>();
	  List<OrgSkill> orgSkills = orgSkillRepository.findAll();
	  for (OrgSkill orgSkill : orgSkills) {
		  if(id == null || !id.equalsIgnoreCase(orgSkill.getSkillId())){
			  name.add(orgSkill.getSkillMnemonic().toLowerCase());
		  }
	}
	  return name;
  }
}
