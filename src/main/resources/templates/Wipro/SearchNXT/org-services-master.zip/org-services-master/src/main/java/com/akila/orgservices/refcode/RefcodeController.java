package com.akila.orgservices.refcode;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.orgservices.entity.BaseRefCodeType;

@RestController
public class RefcodeController extends AkilaController {
  @Autowired
  private RefcodeService refcodeService;

  @GetMapping(
      path = "/ref-codes"
  )
  public List<BaseRefCodeType> getAllRefCodes() {
    return refcodeService.getAllRefCodes();
  }

	@GetMapping(path = "/ref-codes/type/{codeType}")
	public BaseRefCodeType getAllRefCodesByType(@PathVariable String codeType) {
		return refcodeService.getAllRefCodesByType(codeType);
	}
}
