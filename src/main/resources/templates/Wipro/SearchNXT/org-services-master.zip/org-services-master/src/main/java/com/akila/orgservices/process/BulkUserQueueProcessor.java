package com.akila.orgservices.process;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.transaction.Transactional;

import org.apache.commons.collections4.ListUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.akila.commons.AkilaRestTemplate;
import com.akila.orgservices.entity.OrgBulkUser;
import com.akila.orgservices.entity.OrgBulkUserDetails;
import com.akila.orgservices.entity.OrgUser;
import com.akila.orgservices.entity.OrgUserFavlist;
import com.akila.orgservices.entity.OrgUserFavlistPK;
import com.akila.orgservices.entity.OrgUserGroupToUsersLink;
import com.akila.orgservices.entity.OrgUserGroupToUsersLinkPK;
import com.akila.orgservices.entity.OrgUserToRolesLink;
import com.akila.orgservices.entity.OrgUserToRolesLinkPK;
import com.akila.orgservices.repository.OrgBulkUserDetailsRepository;
import com.akila.orgservices.repository.OrgBulkUserRepository;
import com.akila.orgservices.repository.OrgUserFavlistRepository;
import com.akila.orgservices.repository.OrgUserGroupToUsersLinkRepository;
import com.akila.orgservices.repository.OrgUserRepository;
import com.akila.orgservices.repository.OrgUserToRolesLinkRepository;
import com.akila.orgservices.user.KeycloakService;
import com.akila.orgservices.user.SecrateProperties;
import com.akila.orgservices.user.UserService;
import com.akila.orgservices.user.bean.Constant;
import com.akila.orgservices.user.bean.CreateUserResponse;
import com.akila.orgservices.user.bean.RoleResponse;
import com.akila.orgservices.usergroup.UsergroupService;
import com.akila.orgservices.usergroup.bean.UserGroupGetAllResponse;
import com.akilacommons.tenant.DataSourceProperties;
import com.akilacommons.tenant.TenantContext;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
@EnableScheduling
public class BulkUserQueueProcessor {
	private static final Logger logger = LogManager.getLogger(BulkUserQueueProcessor.class);

	@Value("${user.queue.processing.batch.size}")
	private int queueProcessingBatchSize;

	@Autowired
	DataSourceProperties dataSourceProperties;

	@Autowired
	OrgBulkUserRepository orgBulkUserRepository;

	@Autowired
	OrgBulkUserDetailsRepository orgBulkUserDetailsRepository;

	@Autowired
	UserService userService;

	@Autowired
	private UsergroupService usergroupService;

	@Value("${keyclock.username}")
	private String keyClockUserName;

	@Value("${keyclock.password}")
	private String keyClockPassword;

	@Value("${keyclock.url}")
	private String keyClockURL;
	
	@Value("${metric-services.event.url}")
	private String metricServicesEventUrl;
	
	@Value("${platform-services.role.url}")
	private String platformServicesRolesUrl;
	
	public static final String TENANT_HEADER = "tenant";

	@Autowired
	SecrateProperties secrateProperties;

	@Autowired
	private OrgUserRepository orgUserRepository;

	@Autowired
	OrgUserFavlistRepository orgUserFavlistRepository;

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate loadBalancedRestTemplate;

	Map<String, String> roleMap = null;

	@Autowired
	private OrgUserGroupToUsersLinkRepository orgUserGroupToUsersLinkRepository;

	@Autowired
	OrgUserToRolesLinkRepository orgUserToRolesLinkRepository;

	@Autowired
	private AkilaRestTemplate akilaRestTemplate;
	
	//@Scheduled(cron = "${user.queue.process.cron}")
	public void processQueue() {
		System.out.println("Running Job-------------------------------------");
		getDataFromDatabase();
	}

	private void getDataFromDatabase() {

		Map<Object, Object> datasources = dataSourceProperties.getDatasources();

		for (Map.Entry<Object, Object> datasource : datasources.entrySet()) {
			if (String.valueOf(datasource.getKey()).equalsIgnoreCase("base")
					|| String.valueOf(datasource.getKey()).equalsIgnoreCase("wiga-dev")) {
				continue;
			}
			String tenantName = String.valueOf(datasource.getKey());
			TenantContext.setCurrentTenant(tenantName);
			roleMap = this.getRoleMap();
			//System.out.println("Tenant Name--" + tenantName);

			// Fetch List From Database
			List<OrgBulkUser> orgBulkUserList = this.getBulkUserConfigs();
			for (OrgBulkUser orgBulkUser : orgBulkUserList) {

				int updatedCount = orgBulkUserRepository.updateConfigStatus(orgBulkUser.getUploadId(),
						Constant.BULK_USER_PROCESSING, Constant.BULK_USER_NOT_STARTED);

				if (updatedCount > 0) {
					List<OrgBulkUserDetails> queue = getMessagesFromDB(orgBulkUser.getUploadId());
					if (queue != null && queue.size() > 0) {
						logger.info(
								"BulkUserQueueProcessor.processQueue Database, Total Records in DB : " + queue.size());

						Map<String, String> groupMap = new HashMap<String, String>();

						List<UserGroupGetAllResponse> userGroup = usergroupService.getAllUserGroups();
						for (UserGroupGetAllResponse userGroupElement : userGroup) {
							groupMap.put(userGroupElement.getUserGroupNm().toLowerCase(),
									userGroupElement.getUserGroupId());
						}

						List<List<OrgBulkUserDetails>> subList = ListUtils.partition(queue, queueProcessingBatchSize);
						for (List<OrgBulkUserDetails> list : subList) {
							// Create keycloak service object
							KeycloakService keycloakService = new KeycloakService(
									secrateProperties.getRealm().get(tenantName),
									secrateProperties.getSecret().get(tenantName), keyClockUserName, keyClockPassword,
									keyClockURL);

							for (OrgBulkUserDetails userDetails : list) {

								logger.info("BulkUserQueueProcessor.processQueue, Record : " + userDetails.toString());
								try {

									if (validateRow(userDetails, groupMap, roleMap)) {
										CreateUserResponse createUserResponse = this.createUser(userDetails, groupMap, keycloakService, orgBulkUser,
												tenantName);
										if(createUserResponse.getResponseCode() == 201) {
											userDetails.setStatus(Constant.BULK_USER_COMPLETED);
										}
										else if(createUserResponse.getResponseCode() == 409) {
											userDetails.setStatus(Constant.BULK_USER_USER_ALREADY_EXIST);
										}
										else {
											userDetails.setStatus(Constant.BULK_USER_SOMETHING_WENT_WRONG);
										}
									}
								} catch (NullPointerException e) {
									userDetails.setStatus(Constant.BULK_USER_SOMETHING_WENT_WRONG);
									logger.error(
											"NullPointerException BulkUserQueueProcessor.processQueue - error while parsing message, Message : "
													+ userDetails.toString(),
											e);
								} catch (Exception e) {
									userDetails.setStatus(Constant.BULK_USER_SOMETHING_WENT_WRONG);
									logger.error(
											"Exception BulkUserQueueProcessor.processQueue - error while parsing message, Message : "
													+ userDetails.toString(),
											e);
								}
								// Update Total Success failure count
								if (userDetails.getStatus() == Constant.BULK_USER_COMPLETED) {
									orgBulkUser.setSuccessRecords(orgBulkUser.getSuccessRecords() + 1);
								} else {
									orgBulkUser.setFailureRecords(orgBulkUser.getFailureRecords() + 1);
								}
							}

							logger.info("BulkUserQueueProcessor.processQueue, Updating User.... : " + list);

							orgBulkUserDetailsRepository.saveAll(list);

						}
					}
				}
				// Update Complete status for config
				orgBulkUser.setStatus(Constant.BULK_USER_COMPLETED);
				orgBulkUserRepository.save(orgBulkUser);
			}
		}
	}

	// Get Upload Configuration From Database
	@Transactional
	private List<OrgBulkUser> getBulkUserConfigs() {
		List<OrgBulkUser> orgBulkUserList = orgBulkUserRepository.findAllByStatusOrderByStatusAsc(1);
		return orgBulkUserList;
	}

	// Get Upload Configuration pending records From Database
	private List<OrgBulkUserDetails> getMessagesFromDB(UUID configId) {
		return orgBulkUserDetailsRepository.findByUploadIdAndStatus(configId, 1);
	}

	private Boolean validateRow(OrgBulkUserDetails orgBulkUserDetails, Map<String, String> groupMap,
			Map<String, String> roleMap) {

		Pattern FIRST_NAME_REGEX = Pattern.compile("^[A-Za-z\\\\s]+$", Pattern.CASE_INSENSITIVE);
		Pattern LAST_NAME_REGEX = Pattern.compile("^[A-Za-z\\\\s]+$|", Pattern.CASE_INSENSITIVE);
		Pattern EMAIL_REGEX = Pattern.compile("^(.+)@(.+)$", Pattern.CASE_INSENSITIVE);

		if (orgBulkUserDetails.getUsrGroups() == null || orgBulkUserDetails.getUsrGroups().equals("")) {
			orgBulkUserDetails.setStatus(Constant.BULK_USER_GROUP_MISSING);
			return false;
		} else if (orgBulkUserDetails.getUsrRoles() == null || orgBulkUserDetails.getUsrRoles().equals("")) {
			orgBulkUserDetails.setStatus(Constant.BULK_USER_ROLE_MISSING);
			return false;
		} else if (orgBulkUserDetails.getUsrEmail() == null || orgBulkUserDetails.getUsrEmail().equals("")) {
			orgBulkUserDetails.setStatus(Constant.BULK_USER_EMAIL_MISSING);
			return false;
		} else if (orgBulkUserDetails.getUsrFirstNm() == null || orgBulkUserDetails.getUsrFirstNm().equals("")) {
			orgBulkUserDetails.setStatus(Constant.BULK_USER_FIRST_NAME_MISSING);
			return false;
		} else if (!EMAIL_REGEX.matcher(orgBulkUserDetails.getUsrEmail()).matches()) {
			orgBulkUserDetails.setStatus(Constant.BULK_USER_INVALID_EMAIL);
			return false;
		} else if (!FIRST_NAME_REGEX.matcher(orgBulkUserDetails.getUsrFirstNm()).matches()) {
			orgBulkUserDetails.setStatus(Constant.BULK_USER_INVALID_FIRST_NAME);
			return false;
		} else if (!LAST_NAME_REGEX.matcher(orgBulkUserDetails.getUsrLastNm()).matches()) {
			orgBulkUserDetails.setStatus(Constant.BULK_USER_INVALID_LAST_NAME);
			return false;
		}

		String[] userRoles = orgBulkUserDetails.getUsrRoles().split("\\|");
		for (String role : userRoles) {
			if (!roleMap.containsKey(role.toLowerCase())) {
				orgBulkUserDetails.setStatus(Constant.BULK_USER_ROLE_NOT_EXIST);
				return false;
			}
		}
		String[] userGroups = orgBulkUserDetails.getUsrGroups().split("\\|");
		for (String group : userGroups) {
			if (!groupMap.containsKey(group.toLowerCase())) {
				orgBulkUserDetails.setStatus(Constant.BULK_USER_GROUP_NOT_EXIST);
				return false;
			}
		}
		return true;
	}

	public CreateUserResponse createUser(OrgBulkUserDetails userRequest, Map<String, String> groupMap,
			KeycloakService keycloakService, OrgBulkUser orgBulkUser, String tenant) {
		UserRepresentation user = new UserRepresentation();
		user.setEnabled(true);
		user.setUsername(userRequest.getUsrEmail());
		user.setFirstName(userRequest.getUsrFirstNm());
		user.setLastName(userRequest.getUsrLastNm());
		user.setEmail(userRequest.getUsrEmail());

		CreateUserResponse response = keycloakService.createUser(user);
		if (response.getResponseCode() == 201) {
			OrgUser orgUser = new OrgUser();
			orgUser.setUserId(response.getUserId());
			orgUser.setIsActive(Boolean.TRUE);
			orgUser.setUserFirstNm(userRequest.getUsrFirstNm());
			orgUser.setUserMidNm(userRequest.getUsrLastNm());
			orgUser.setUserLastNm(userRequest.getUsrLastNm());
			orgUser.setUsrEmail(userRequest.getUsrEmail());
			orgUser.setCrtBy(orgBulkUser.getCrtBy());
			orgUser.setModBy(orgBulkUser.getCrtBy());
			orgUser.setCrtTs(new Timestamp(new Date().getTime()));
			orgUser.setModTs(new Timestamp(new Date().getTime()));
			orgUserRepository.save(orgUser);

			// create user default Fav list
			this.createUserDefaultFavList(orgUser.getUserFirstNm(), orgUser.getUserId(), orgBulkUser.getCrtBy());

			// Assign Groups to User
			this.assignUserGroupsToUser(response.getUserId(), userRequest.getUsrGroups(), orgBulkUser.getCrtBy(),
					groupMap);

			List<String> roles = getUserRoles(userRequest.getUsrRoles());
			keycloakService.addRoleToUser(response.getUserId(), roles);

			List<OrgUserToRolesLink> roleList = new ArrayList<OrgUserToRolesLink>();
			for (String role : roles) {
				OrgUserToRolesLink rl = new OrgUserToRolesLink();
				OrgUserToRolesLinkPK pk = new OrgUserToRolesLinkPK();
				pk.setUserId(response.getUserId());
				if (getRoleMap().containsKey(role.toLowerCase())) {
					pk.setRoleId(getRoleMap().get(role.toLowerCase()));
					rl.setId(pk);
					rl.setCrtBy(orgBulkUser.getCrtBy());
					rl.setCrtTs(new Timestamp(new Date().getTime()));
					rl.setModBy(orgBulkUser.getCrtBy());
					rl.setModTs(new Timestamp(new Date().getTime()));
					roleList.add(rl);
				}
			}
			orgUserToRolesLinkRepository.saveAll(roleList);
			try {
				HttpHeaders headers = new HttpHeaders();
				headers.add("tenant", tenant);
				headers.add("userid", orgBulkUser.getCrtBy());

				HttpEntity<String> entity = new HttpEntity<String>("Metric-Users", headers);
				akilaRestTemplate.postForEntity(loadBalancedRestTemplate, metricServicesEventUrl+"?serviceName=Metric-Users",
						entity, Void.class);
			} catch (HttpStatusCodeException e) {
				logger.error("HttpStatusCodeException UserService.createUser : Error while updating metrics", e);
			} catch (Exception e) {
				logger.error("Exception UserService.createUser : Error while updating metrics", e);
			}
		}

		return response;
	}

	public void createUserDefaultFavList(String userFirstName, String userId, String crtBy) {
		OrgUserFavlist orgUserFavlist = new OrgUserFavlist();

		orgUserFavlist.setDescription("Default auto generated list");
		orgUserFavlist.setIsShared(Boolean.FALSE);
		orgUserFavlist.setFavlistNm(userFirstName + "\'s" + " list");

		orgUserFavlist.setId(getOrgUserFavlistPK(UUID.randomUUID().toString(), userId));
		orgUserFavlist.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgUserFavlist.setModTs(new Timestamp(System.currentTimeMillis()));
		orgUserFavlist.setCrtBy(crtBy);
		orgUserFavlist.setModBy(crtBy);
		orgUserFavlist.setIsDefault(Boolean.TRUE);
		orgUserFavlistRepository.save(orgUserFavlist);
	}

	public OrgUserFavlistPK getOrgUserFavlistPK(String favlistId, String userId) {
		OrgUserFavlistPK orgUserFavlistPK = new OrgUserFavlistPK();
		orgUserFavlistPK.setUserId(userId);
		orgUserFavlistPK.setFavlistId(favlistId);
		return orgUserFavlistPK;
	}

	public List<String> getUserRoles(String userRole) {
		List<String> roles = new ArrayList<String>();

		// Added Assigned Roles
		String[] rolesArray = userRole.split("\\|");
		for (String string : rolesArray) {
			roles.add(string.trim());
		}
		return roles;
	}

	public Map<String, String> getRoleMap() {

		if (roleMap == null) {
			roleMap = new HashMap<String, String>();
			try {
				HttpHeaders headers = new HttpHeaders();
				headers.add("tenant", "base");
				HttpEntity<String> entity = new HttpEntity<String>("org-services", headers);
				ResponseEntity<String> response = akilaRestTemplate.exchange(loadBalancedRestTemplate, platformServicesRolesUrl,
						HttpMethod.GET, entity, String.class);
				String responseBody = response.getBody();
				ObjectMapper objectMapper = new ObjectMapper();
				RoleResponse[] role = objectMapper.readValue(responseBody, RoleResponse[].class);
				for (int i = 0; i < role.length; i++) {
					roleMap.put(role[i].getRoleNm(), role[i].getRoleId());
				}
			} catch (HttpStatusCodeException e) {
				logger.error("HttpStatusCodeException getRoleMap : " + e.getMessage(), e);
			} catch (Exception e) {
				logger.error("Exception getRoleMap : " + e.getMessage(), e);
			}
		}
		return roleMap;
	}

	// Assign Groups to User
	public void assignUserGroupsToUser(String userId, String groups, String crtBy, Map<String, String> groupMap) {

		String[] groupList = groups.split("\\|");
		List<OrgUserGroupToUsersLink> OrgUserGroupToUsersLinkList = new ArrayList<OrgUserGroupToUsersLink>();
		for (String group : groupList) {
			OrgUserGroupToUsersLink link = new OrgUserGroupToUsersLink();
			link.setId(getOrgUserGroupToUsersLinkPK(userId, groupMap.get(group.toLowerCase())));
			link.setCrtBy(crtBy);
			link.setModBy(crtBy);
			link.setCrtTs(new Timestamp(new Date().getTime()));
			link.setModTs(new Timestamp(new Date().getTime()));
			OrgUserGroupToUsersLinkList.add(link);
		}
		orgUserGroupToUsersLinkRepository.saveAll(OrgUserGroupToUsersLinkList);

	}

	public OrgUserGroupToUsersLinkPK getOrgUserGroupToUsersLinkPK(String userId, String userGroupId) {
		OrgUserGroupToUsersLinkPK orgUserGroupToUsersLinkPK = new OrgUserGroupToUsersLinkPK();
		orgUserGroupToUsersLinkPK.setUserId(userId);
		orgUserGroupToUsersLinkPK.setUserGroupId(userGroupId);
		return orgUserGroupToUsersLinkPK;
	}

}
