package com.akila.orgservices.refcodetype;

import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.JDBCException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.orgservices.entity.BaseRefCodeType;
import com.akila.orgservices.entity.BaseUserPref;
import com.akila.orgservices.entity.OrgRefCode;
import com.akila.orgservices.refcodetype.bean.RefCodeTypeMapper;
import com.akila.orgservices.refcodetype.bean.RefCodeTypeRequest;
import com.akila.orgservices.refcodetype.bean.RefCodeTypeResponse;
import com.akila.orgservices.repository.BaseRefCodeTypeRepository;
import com.akila.orgservices.repository.BaseUserPrefRepository;
import com.akila.orgservices.repository.OrgRefCodeRepository;
import com.akila.orgservices.user.bean.Constant;
import com.akila.response.ResponseId;

@Service
public class RefcodetypeService extends AkilaService {

	private static final Logger logger = LogManager.getLogger(RefcodetypeService.class);

	@Autowired
	private OrgRefCodeRepository orgRefCodeRepository;

	@Autowired
	private BaseRefCodeTypeRepository baseRefCodeTypeRepository;

	@Autowired
	private RefCodeTypeMapper refcodetypeMapper;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Value("${python.ip}")
	private String pythonIp;

	@Value("${python.create.tag.type.api.url}")
	private String pythonCreateTagTypeApiURL;
	
	@Autowired
	private AkilaRestTemplate akilaRestTemplate;
	
	@Autowired
	private BaseUserPrefRepository baseUserPrefRepository;
	
	@Cacheable(value = "thirty_minute_cache", key = "{'RefcodetypeService_getAllCodeTypes'}")
	public List<RefCodeTypeResponse> getAllCodeTypes() {
		List<OrgRefCode> OrgRefCodeList = orgRefCodeRepository.findAll();
		return refcodetypeMapper.orgRefCodeToRefcodetypeResponseList(OrgRefCodeList);
	}

	@CacheEvict(value = "thirty_minute_cache", key = "{'RefcodeService_getAllRefCodes'}")
	public ResponseId saveRefCodeType(RefCodeTypeRequest refCodeTypeRequest) {

		OrgRefCode orgRefCode = refcodetypeMapper.refcodetypeRequestToOrgRefCode(refCodeTypeRequest);
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<String, String>();
		try {

			BaseRefCodeType baseRefCodeType = baseRefCodeTypeRepository.findById(refCodeTypeRequest.getRefCodeTypeId())
					.orElse(null);

			orgRefCode.setBaseRefCodeType(baseRefCodeType);

			orgRefCode.setRefCodeDescription(refCodeTypeRequest.getRefCodeDescription().trim());

			orgRefCode.setRefCodeDisplayVal(refCodeTypeRequest.getRefCodeDisplayVal().trim());

			orgRefCode.setRefCodeStoreVal(Integer.parseInt(refCodeTypeRequest.getRefCodeStoreVal()));

			orgRefCode.setRefCodeId(UUID.randomUUID().toString());

			orgRefCode.setCrtBy(super.getUserId());

			orgRefCode.setModBy(super.getUserId());

			orgRefCode.setModTs(new Timestamp(System.currentTimeMillis()));

			orgRefCode.setCrtTs(new Timestamp(System.currentTimeMillis()));

			orgRefCode = orgRefCodeRepository.save(orgRefCode);
            if(baseRefCodeType.getRefCodeType().equalsIgnoreCase(Constant.REF_CODE_TYPE)) {
            BaseUserPref baseUserPref = baseUserPrefRepository.findByPrefTypeCdAndPrefNm(Constant.PREF_TYPE_CD, Constant.PREF_NAME);
            if(baseUserPref != null) {
        	baseUserPref.setPrefOptions(baseUserPref.getPrefOptions().concat("," + refCodeTypeRequest.getRefCodeDisplayVal().trim()));
        	baseUserPrefRepository.save(baseUserPref);	
            }
			logger.info("RefcodetypeService.saveRefCodeType Passing tag to python for indexing ");
			multiValueMap.add("org_id", getOrgId());
			multiValueMap.add("tag", orgRefCode.getRefCodeDisplayVal().replaceAll(" ", "_").toLowerCase());
			HttpEntity<MultiValueMap<String, String>> apiRequest = new HttpEntity<MultiValueMap<String, String>>(
					multiValueMap, headers);
		    long pythonStartTime = System.currentTimeMillis();
		    logger.info("RefcodetypeService.saveFefCodeType Python Api request for tag creation "+ apiRequest.toString() + " Python IP "+pythonIp);
		    ResponseEntity<String> apiResponse = akilaRestTemplate.postForEntity(restTemplate, pythonCreateTagTypeApiURL, apiRequest, String.class);
		    String responseString = apiResponse.getBody();
			long pythonEndTime = System.currentTimeMillis();
		    logger.info("RefcodetypeService.saveRefCodeType : Response from Python Service for Add tag : "+responseString);
		    logger.info("RefcodetypeService.saveRefCodeType : Total time taken by Python Service for Add tag (ms) : "+(pythonEndTime - pythonStartTime));
            }
		    
		} catch (JDBCException e) {
			logger.error("OrgServices:  ref-code-types-service -> Save" + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("OrgServices:  ref-code-types-service -> Save" + e.getMessage(), e);
		}

		return new ResponseId(orgRefCode.getRefCodeId());
	}

	public ResponseId updateRefCodeType(RefCodeTypeRequest refCodeTypeRequest) {

		OrgRefCode orgRefCode = orgRefCodeRepository.findById(refCodeTypeRequest.getRefCodeId()).orElse(null);

		try {

			if (orgRefCode != null) {
				BaseRefCodeType baseRefCodeType = baseRefCodeTypeRepository
						.findById(refCodeTypeRequest.getRefCodeTypeId()).orElse(null);

				orgRefCode.setBaseRefCodeType(baseRefCodeType);

				orgRefCode.setCrtBy(super.getUserId());

				orgRefCode.setModBy(super.getUserId());

				orgRefCode.setModTs(new Timestamp(System.currentTimeMillis()));

				orgRefCode.setCrtTs(new Timestamp(System.currentTimeMillis()));

				orgRefCode.setRefCodeDisplayVal(refCodeTypeRequest.getRefCodeDisplayVal().trim());

				orgRefCode.setRefCodeDescription(refCodeTypeRequest.getRefCodeDescription().trim());

				orgRefCode = orgRefCodeRepository.save(orgRefCode);

			}
		} catch (JDBCException e) {
			logger.error("OrgServices:  ref-code-types-service -> Update" + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("OrgServices:  ref-code-types-service -> Update" + e.getMessage(), e);
		}

		return new ResponseId(orgRefCode.getRefCodeId());

	}

	public void deleteRefCode(String id) {
		try {
			orgRefCodeRepository.deleteById(id);
		} catch (JDBCException e) {
			logger.error("OrgServices:  ref-code-types-service -> Delete" + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("OrgServices:  ref-code-types-service -> Delete" + e.getMessage(), e);

		}
	}

	@Cacheable(value = "thirty_minute_cache", key = "{'RefcodetypeService_getByRefCodeDisplayValue_',#refCodeDisplayValue}")
	public List<OrgRefCode> getByRefCodeDisplayValue(String refCodeDisplayValue) {
		return orgRefCodeRepository.findByRefCodeDisplayValIgnoreCase(refCodeDisplayValue);
	}

	@Cacheable(value = "thirty_minute_cache", key = "{'RefcodetypeService_getByRefCodeDisplayValue_',#refCodeDisplayValue,#refCodeDescription,#refCodeId}")
	public List<OrgRefCode> getByRefCodeDisplayValueAndId(String refCodeDisplayValue, String refCodeDescription,String refCodeId) {
		return orgRefCodeRepository.findByRefCodeDisplayValIgnoreCaseAndRefCodeDescriptionIgnoreCaseAndRefCodeId(refCodeDisplayValue, refCodeDescription, refCodeId);
	}

}
