package com.akila.orgservices.refcode.bean;

import com.akila.AkilaResponse;
import java.lang.String;

public class RefCodeResponse extends AkilaResponse {
  private String refCodeDescription;

  private String refCodeDisplayVal;

  public void setRefCodeDescription(String refCodeDescription) {
    this.refCodeDescription = refCodeDescription;
  }

  public void setRefCodeDisplayVal(String refCodeDisplayVal) {
    this.refCodeDisplayVal = refCodeDisplayVal;
  }

  public String getRefCodeDescription() {
    return refCodeDescription;
  }

  public String getRefCodeDisplayVal() {
    return refCodeDisplayVal;
  }
}
