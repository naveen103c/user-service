package com.akila.orgservices.repository;

import com.akila.orgservices.entity.OrgCommunityTag;
import com.akila.orgservices.entity.OrgCommunityTagPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgCommunityTagRepository extends JpaRepository<OrgCommunityTag, OrgCommunityTagPK> {
}
