package com.akila.orgservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.orgservices.entity.BaseUserPref;

@Repository
public interface BaseUserPrefRepository extends JpaRepository<BaseUserPref, String> {
	
	BaseUserPref findByPrefTypeCdAndPrefNm(Integer prefTypeId, String prefName);
	
}
