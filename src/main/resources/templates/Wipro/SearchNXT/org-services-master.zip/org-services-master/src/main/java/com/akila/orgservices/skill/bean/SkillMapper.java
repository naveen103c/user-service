package com.akila.orgservices.skill.bean;

import com.akila.orgservices.entity.OrgSkill;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface SkillMapper {
  SkillMapper INSTANCE = Mappers.getMapper(SkillMapper.class);
  ;

  @Mappings({})
  SkillResponse orgSkillToSkillResponse(OrgSkill orgSkill);

  @Mappings({})
  List<SkillResponse> orgSkillToSkillResponseList(List<OrgSkill> orgSkill);

  @Mappings({})
  OrgSkill skillRequestToOrgSkill(SkillRequest skillRequest);
}
