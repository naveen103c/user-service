package com.akila.orgservices.entity;

import com.akila.AkilaEntity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the org_user_favlist database table.
 * 
 */
@Entity
@Table(name="org_user_favlist")
@NamedQuery(name="OrgUserFavlist.findAll", query="SELECT o FROM OrgUserFavlist o")
public class OrgUserFavlist extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgUserFavlistPK id;

	@Column(name="crt_ts")
	private Timestamp crtTs;

	private String description;

	@Column(name="favlist_nm")
	private String favlistNm;

	@Column(name="is_default")
	private Boolean isDefault;

	@Column(name="is_shared")
	private Boolean isShared;

	@Column(name="mod_ts")
	private Timestamp modTs;

	public OrgUserFavlist() {
	}

	public OrgUserFavlistPK getId() {
		return this.id;
	}

	public void setId(OrgUserFavlistPK id) {
		this.id = id;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFavlistNm() {
		return this.favlistNm;
	}

	public void setFavlistNm(String favlistNm) {
		this.favlistNm = favlistNm;
	}

	public Boolean getIsDefault() {
		return this.isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}

	public Boolean getIsShared() {
		return this.isShared;
	}

	public void setIsShared(Boolean isShared) {
		this.isShared = isShared;
	}

	public Timestamp getModTs() {
		return this.modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

}