package com.akila.orgservices.community;

import java.sql.Timestamp;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.orgservices.entity.OrgCommunityTag;
import com.akila.orgservices.entity.OrgCommunityTagPK;
import com.akila.orgservices.repository.OrgCommunityTagRepository;

@Service
public class CommunityTagService extends AkilaService
{
	@Autowired
	private OrgCommunityTagRepository orgCommunityTagRepository;
	
	public void deleteTag(String communityId, String tagId)
	{
		OrgCommunityTag orgCommunityTag = new OrgCommunityTag();
		orgCommunityTag.setId(getOrgCommunityTagPK(communityId, tagId));
		orgCommunityTagRepository.delete(orgCommunityTag);
	}
	
	public void createTag(String communityId, String tagId)
	{
		OrgCommunityTag orgCommunityTag = new OrgCommunityTag();
		orgCommunityTag.setId(getOrgCommunityTagPK(communityId, tagId));
		orgCommunityTag.setCrtBy(getUserId());
		orgCommunityTag.setModBy(getUserId());
		orgCommunityTag.setCrtTs(new Timestamp(new Date().getTime()));
		orgCommunityTag.setModTs(new Timestamp(new Date().getTime()));
		orgCommunityTagRepository.save(orgCommunityTag);
	}
	
	public OrgCommunityTagPK getOrgCommunityTagPK(String communityId, String tagId) {
		OrgCommunityTagPK orgCommunityTagPK = new OrgCommunityTagPK();
		orgCommunityTagPK.setCommunityId(communityId);
		orgCommunityTagPK.setTagId(tagId);
		return orgCommunityTagPK;
	}

}
