package com.akila.orgservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.orgservices.entity.OrgCommunityUserGroup;
import com.akila.orgservices.entity.OrgCommunityUserGroupPK;

@Repository
public interface OrgCommunityUserGroupRepository extends JpaRepository<OrgCommunityUserGroup, OrgCommunityUserGroupPK> {

}
