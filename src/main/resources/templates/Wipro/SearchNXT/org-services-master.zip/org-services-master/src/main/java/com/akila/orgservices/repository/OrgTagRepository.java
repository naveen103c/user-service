package com.akila.orgservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.orgservices.entity.OrgTag;

@Repository
public interface OrgTagRepository extends JpaRepository<OrgTag, String> 
{
	@Query("select o from OrgTag o where o.tagTypeCd = (:tagTypeCd)")
	public List<OrgTag> findAllOrgTagsByTagTypeCode(Integer tagTypeCd);
	
	public List<OrgTag> findByTagMnemonicIgnoreCaseAndTagIdNot(String tagMnemonic,String tagId);
	
	public List<OrgTag> findByTagMnemonicIgnoreCase(String tagMnemonic);

}
