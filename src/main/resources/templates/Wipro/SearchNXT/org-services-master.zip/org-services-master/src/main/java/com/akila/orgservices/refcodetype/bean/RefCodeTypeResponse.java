package com.akila.orgservices.refcodetype.bean;

import com.akila.AkilaResponse;
import java.lang.String;

public class RefCodeTypeResponse extends AkilaResponse {

	private String refCodeId;

	private String refCodeDescription;

	private String refCodeDisplayVal;

	public void setRefCodeDescription(String refCodeDescription) {
		this.refCodeDescription = refCodeDescription;
	}

	public void setRefCodeDisplayVal(String refCodeDisplayVal) {
		this.refCodeDisplayVal = refCodeDisplayVal;
	}

	public String getRefCodeDescription() {
		return refCodeDescription;
	}

	public String getRefCodeDisplayVal() {
		return refCodeDisplayVal;
	}

	public String getRefCodeId() {
		return refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	@Override
	public String toString() {
		return "RefCodeTypeResponse [refCodeId=" + refCodeId + ", refCodeDescription=" + refCodeDescription
				+ ", refCodeDisplayVal=" + refCodeDisplayVal + "]";
	}

}
