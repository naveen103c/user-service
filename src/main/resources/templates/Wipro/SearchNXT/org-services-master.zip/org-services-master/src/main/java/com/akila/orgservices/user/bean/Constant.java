package com.akila.orgservices.user.bean;

public final class Constant {

	public static final int BULK_USER_VALIDATION_SUCCESS = 1;
	public static final int BULK_USER_NOT_STARTED = 1;
	public static final int BULK_USER_PROCESSING = 2;
	public static final int BULK_USER_COMPLETED = 3;
	public static final int BULK_USER_USER_ALREADY_EXIST = 4;
	public static final int BULK_USER_SOMETHING_WENT_WRONG = 5;
	public static final int BULK_USER_ROLE_MISSING = 6;
	public static final int BULK_USER_GROUP_MISSING = 7;
	public static final int BULK_USER_EMAIL_MISSING = 8;
	public static final int BULK_USER_FIRST_NAME_MISSING = 9;
	public static final int BULK_USER_INVALID_EMAIL = 10;
	public static final int BULK_USER_ROLE_NOT_EXIST = 11;
	public static final int BULK_USER_GROUP_NOT_EXIST = 12;
	public static final int BULK_USER_INVALID_FIRST_NAME = 13;
	public static final int BULK_USER_INVALID_LAST_NAME = 14;
	public static final String REF_CODE_TYPE = "TAG_TYPE_CD";
	public static final String PREF_NAME = "Tags";
	public static final int PREF_TYPE_CD = 5;
}

