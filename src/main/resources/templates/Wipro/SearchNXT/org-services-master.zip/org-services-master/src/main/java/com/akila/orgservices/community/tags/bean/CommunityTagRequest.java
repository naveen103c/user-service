package com.akila.orgservices.community.tags.bean;

import com.akila.AkilaRequest;
import com.akila.orgservices.entity.OrgCommunityTagPK;

import java.lang.String;
import java.sql.Timestamp;

public class CommunityTagRequest extends AkilaRequest {

	private String crtBy;

	private Timestamp crtTs;

	private String modBy;

	private Timestamp modTs;

	private OrgCommunityTagPK id;

	public OrgCommunityTagPK getId() {
		return this.id;
	}

	public void setId(OrgCommunityTagPK id) {
		this.id = id;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public String getModBy() {
		return modBy;
	}

	public Timestamp getModTs() {
		return modTs;
	}
}
