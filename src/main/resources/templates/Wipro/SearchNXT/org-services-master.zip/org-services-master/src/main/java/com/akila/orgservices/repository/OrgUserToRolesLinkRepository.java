package com.akila.orgservices.repository;

import com.akila.orgservices.entity.OrgUserToRolesLink;
import com.akila.orgservices.entity.OrgUserToRolesLinkPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgUserToRolesLinkRepository extends JpaRepository<OrgUserToRolesLink, OrgUserToRolesLinkPK> {
}
