package com.akila.orgservices.refcodetype;

import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.orgservices.OrgServicesApplication;
import com.akila.orgservices.refcodetype.bean.RefCodeTypeResponse;

@SpringBootTest(classes = OrgServicesApplication.class)

public class RefCodeTypeControllerTest {

	@Autowired
	private RefcodetypeController refcodeTypeController;

	@Test
	public void getAllRefCodesTest() {
		List<RefCodeTypeResponse> refCodeTypeResponseList = refcodeTypeController.getAllCodeTypes();
		RefCodeTypeResponse refCodeTypeResponse = new RefCodeTypeResponse();
		Iterator<RefCodeTypeResponse> itr = refCodeTypeResponseList.iterator();
		while (itr.hasNext()) {
			refCodeTypeResponse = itr.next();
		}
	}

}