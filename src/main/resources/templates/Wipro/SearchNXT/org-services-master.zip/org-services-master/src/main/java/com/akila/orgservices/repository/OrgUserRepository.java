package com.akila.orgservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.orgservices.entity.OrgUser;

@Repository
public interface OrgUserRepository extends JpaRepository<OrgUser, String> {
	
	//public List<OrgUser> findByOrgUserToRolesLink_RoleId(String roleId);
	
	public List<OrgUser> findByUsrEmailIgnoreCase(String usrEmail);
	
	@Query("select count(e) from OrgUser e where e.isActive = true")
	public int activeUserCount();
}
