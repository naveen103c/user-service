package com.akila.orgservices.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.akila.AkilaEntity;


/**
 * The persistent class for the base_ref_code_types database table.
 * 
 */
@Entity
@Table(name="base_ref_code_types")
@NamedQuery(name="BaseRefCodeType.findAll", query="SELECT b FROM BaseRefCodeType b")
public class BaseRefCodeType extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ref_code_type_id")
	private String refCodeTypeId;

	@Column(name="is_crud_enabled")
	private Boolean isCrudEnabled;

	@Column(name="is_display_editable")
	private Boolean isDisplayEditable;

	@Column(name="ref_code_type")
	private String refCodeType;

	//bi-directional many-to-one association to OrgRefCode
	@OneToMany(mappedBy="baseRefCodeType")
	private List<OrgRefCode> orgRefCodes;

	public BaseRefCodeType() {
	}

	public String getRefCodeTypeId() {
		return this.refCodeTypeId;
	}

	public void setRefCodeTypeId(String refCodeTypeId) {
		this.refCodeTypeId = refCodeTypeId;
	}

	public Boolean getIsCrudEnabled() {
		return this.isCrudEnabled;
	}

	public void setIsCrudEnabled(Boolean isCrudEnabled) {
		this.isCrudEnabled = isCrudEnabled;
	}

	public Boolean getIsDisplayEditable() {
		return this.isDisplayEditable;
	}

	public void setIsDisplayEditable(Boolean isDisplayEditable) {
		this.isDisplayEditable = isDisplayEditable;
	}

	public String getRefCodeType() {
		return this.refCodeType;
	}

	public void setRefCodeType(String refCodeType) {
		this.refCodeType = refCodeType;
	}

	public List<OrgRefCode> getOrgRefCodes() {
		return this.orgRefCodes;
	}

	public void setOrgRefCodes(List<OrgRefCode> orgRefCodes) {
		this.orgRefCodes = orgRefCodes;
	}

	public OrgRefCode addOrgRefCode(OrgRefCode orgRefCode) {
		getOrgRefCodes().add(orgRefCode);
		orgRefCode.setBaseRefCodeType(this);

		return orgRefCode;
	}

	public OrgRefCode removeOrgRefCode(OrgRefCode orgRefCode) {
		getOrgRefCodes().remove(orgRefCode);
		orgRefCode.setBaseRefCodeType(null);

		return orgRefCode;
	}

}