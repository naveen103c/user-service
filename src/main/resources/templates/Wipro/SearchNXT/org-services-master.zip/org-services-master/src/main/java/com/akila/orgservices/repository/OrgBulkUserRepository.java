package com.akila.orgservices.repository;

import java.util.List;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.orgservices.entity.OrgBulkUser;

@Repository
public interface OrgBulkUserRepository extends JpaRepository<OrgBulkUser, UUID> 
{
	List<OrgBulkUser> findAllByOrderByCrtTsDesc();
	
	List<OrgBulkUser>  findAllByStatusOrderByStatusAsc(Integer status);
	
	@Transactional
	@Modifying  
	@Query("UPDATE OrgBulkUser d SET d.status =:newStatus WHERE d.uploadId=:uploadId and d.status =:oldStatus")
	int  updateConfigStatus(@Param("uploadId") UUID uploadId ,@Param("newStatus") int newStatus,@Param("oldStatus") int oldStatus);
}

