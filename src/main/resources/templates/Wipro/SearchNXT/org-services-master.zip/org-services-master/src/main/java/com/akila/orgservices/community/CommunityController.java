package com.akila.orgservices.community;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.orgservices.community.bean.CommunityRequest;
import com.akila.orgservices.community.bean.CommunityResponse;
import com.akila.orgservices.community.bean.UserDetail;
import com.akila.orgservices.entity.OrgCommunity;
import com.akila.orgservices.skill.bean.ResponseStatus;
import com.akila.response.ResponseId;

@RestController
public class CommunityController extends AkilaController {
  @Autowired
  private CommunityService communityService;
  
  @Autowired
  private CommunityTagService communityTagService;
  
  @Autowired
  private CommunitySmeService communitySmeService;
  private int STATUS_FAILED = 0;
  private int STATUS_PASS = 1;

  @PostMapping(
      path = "/communities"
  )
  public ResponseEntity<ResponseStatus> createCommunity(@Valid @RequestBody CommunityRequest communityRequest) {
	  
	  if(communityRequest.getCommunityNm() != null && communityRequest.getCommunityNm().trim().length() > 0){
			List<String> mnemonicList =  communityService.getAllCommunitiesName(null);
			if(mnemonicList.contains(communityRequest.getCommunityNm().trim().toLowerCase())){
				ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
						("Community Name '" + communityRequest.getCommunityNm() + "' Already Exist"), 102);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
		}else {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
					("Community Name can't be null or blank"), 101);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
	  
		ResponseId id = communityService.createCommunity(communityRequest);
		ResponseStatus status = getResponseStatus(STATUS_PASS, id.getId(), "Community successfully created", 0);
		
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
		
  }

  @PutMapping(
      path = "/communities/{id}"
  )
  public  ResponseEntity<ResponseStatus> updateCommunity(@PathVariable String id,
		  @Valid @RequestBody CommunityRequest communityRequest) {
	  
	  if(communityRequest.getCommunityNm() != null && communityRequest.getCommunityNm().trim().length() > 0){
			List<String> mnemonicList =  communityService.getAllCommunitiesName(id);
			if(mnemonicList.contains(communityRequest.getCommunityNm().trim().toLowerCase())){
				ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
						("Community Name '" + communityRequest.getCommunityNm() + "' Already Exist"), 102);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
		}else {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
					("Community Name can't be null or blank"), 101);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
	  ResponseId id1 = communityService.updateCommunity(id, communityRequest);
		ResponseStatus status = getResponseStatus(STATUS_PASS, id1.getId(), "Community successfully created", 0);
		
	  return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
   
  }

  @GetMapping(
      path = "/communities/{id}"
  )
  public OrgCommunity getCommunity(@PathVariable String id) {
	  return communityService.getCommunity(id);
  }

  @GetMapping(
      path = "/communities"
  )
  public List<CommunityResponse> getAllCommunities() {
    return communityService.getAllCommunities();
  }

  @DeleteMapping(
      path = "/communities/{id}"
  )
  public void deleteCommunity(@PathVariable String id) {
    	 communityService.deleteCommunity(id);
  }
  
  @PostMapping("communities/{id}/tags")
  public void createTag(@PathVariable String id, @RequestBody String tagId) 
  {
	  communityTagService.createTag(id, tagId);
  }
  
  @DeleteMapping("communities/{communityId}/tags/{tagId}")
  public void deleteTag(@PathVariable String communityId, @PathVariable String tagId) 
  {
	  communityTagService.deleteTag(communityId, tagId);
  }
  
  @PostMapping("communities/{id}/sme")
  public void createSme(@PathVariable String id, @RequestBody String userId) 
  {
	  communitySmeService.createSme(id, userId);
  }
  
  @DeleteMapping("communities/{communityId}/sme/{smeId}")
  public void deleteSme(@PathVariable String communityId, @PathVariable String smeId) 
  {
	  communitySmeService.deleteSme(communityId, smeId);
  }
  
  @GetMapping(
	      path = "/communities/{id}/users"
	  )
	  public List<UserDetail> getCommunityGroupUsers(@PathVariable String id) {
		  return communityService.getCommunityGroupUsers(id);
	  }

  private ResponseStatus getResponseStatus(int statusCd, String id, String message, int errorCode) {
		ResponseStatus status = new ResponseStatus();
		status.setStatusCode(statusCd);
		status.setId(id);
		status.setMessage(message);
		status.setErrorCode(errorCode);
		return status;
	}
}
