package com.akila.orgservices.repository;

import com.akila.orgservices.entity.OrgUserGroupToUsersLink;
import com.akila.orgservices.entity.OrgUserGroupToUsersLinkPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgUserGroupToUsersLinkRepository extends JpaRepository<OrgUserGroupToUsersLink, OrgUserGroupToUsersLinkPK> 
{
	
}
