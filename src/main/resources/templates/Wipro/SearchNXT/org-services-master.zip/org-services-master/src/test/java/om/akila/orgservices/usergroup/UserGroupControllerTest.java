package om.akila.orgservices.usergroup;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.orgservices.OrgServicesApplication;

@SpringBootTest(classes = OrgServicesApplication.class)
public class UserGroupControllerTest 
{
	
	@Test
	public void getUserGroup()
	{
		List<String> users = new ArrayList<String>();
		users.add("baa02e3d-5507-4639-97bc-dd4ae32d5fbe");
		users.add("e76db102-fa48-44e9-8393-5be64761f7da");
		
		//controller.removeUsersToUserGroup("39578d2b-df48-4799-b1f3-a4e0f98b81d2", users);
	}
	
	@Test
	public void getAllUserGroupsForUser()
	{
		//List<OrgUserGroup> data = controller.getAllUserGroupsForUser("934e39ab-fd79-4fe9-ab10-a9980a4dd2b3");
		//System.out.println(data.size());
	}
	
	@Test
	public void getUserGroupData()
	{
		//OrgUserGroup data = controller.getUserGroup("0049b4f2-e7ee-4eb7-93b0-3770cfdef7d7");
		//System.out.println(data.getUserGroupNm());
	}

}
