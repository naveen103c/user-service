package com.akila.orgservices.skill.bean;

import com.akila.AkilaResponse;

public class SkillResponse extends AkilaResponse {
  private String skillId;

  private String description;

  private String skillMnemonic;

  public void setSkillId(String skillId) {
    this.skillId = skillId;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setSkillMnemonic(String skillMnemonic) {
    this.skillMnemonic = skillMnemonic;
  }

  public String getSkillId() {
    return skillId;
  }

  public String getDescription() {
    return description;
  }

  public String getSkillMnemonic() {
    return skillMnemonic;
  }
}
