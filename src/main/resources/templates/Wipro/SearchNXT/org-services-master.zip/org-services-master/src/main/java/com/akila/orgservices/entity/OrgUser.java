package com.akila.orgservices.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.akila.AkilaEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the org_users database table.
 * 
 */
@Entity
@Table(name="org_users")
@NamedQuery(name="OrgUser.findAll", query="SELECT o FROM OrgUser o")
public class OrgUser extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="user_id")
	private String userId;

	@Column(name="user_first_nm")
	private String userFirstNm;

	@Column(name="user_last_nm")
	private String userLastNm;

	@Column(name="user_mid_nm")
	private String userMidNm;

	@Column(name="usr_email")
	private String usrEmail;
	
	@Column(name="usr_secondary_email")
	private String usrSecondaryEmail;
	
	@Column(name="is_active")
	private Boolean isActive;
	
	@Column(name="user_last_login_time")
	private Timestamp userLastLoginTime;
	
//	@JsonIgnore
//	@OneToMany
//	@JoinColumn(name = "user_id", insertable = false, updatable = false)
//	List<OrgUserToRolesLink> orgUserToRolesLink;

	public OrgUser() {
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getUserFirstNm() {
		return this.userFirstNm;
	}

	public void setUserFirstNm(String userFirstNm) {
		this.userFirstNm = userFirstNm;
	}

	public String getUserLastNm() {
		return this.userLastNm;
	}

	public void setUserLastNm(String userLastNm) {
		this.userLastNm = userLastNm;
	}

	public String getUserMidNm() {
		return this.userMidNm;
	}

	public void setUserMidNm(String userMidNm) {
		this.userMidNm = userMidNm;
	}

	public String getUsrEmail() {
		return this.usrEmail;
	}

	public void setUsrEmail(String usrEmail) {
		this.usrEmail = usrEmail;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

//	public List<OrgUserToRolesLink> getOrgUserToRolesLink() {
//		return orgUserToRolesLink;
//	}
//
//	public void setOrgUserToRolesLink(List<OrgUserToRolesLink> orgUserToRolesLink) {
//		this.orgUserToRolesLink = orgUserToRolesLink;
//	}

	public Timestamp getUserLastLoginTime() {
		return userLastLoginTime;
	}

	public void setUserLastLoginTime(Timestamp userLastLoginTime) {
		this.userLastLoginTime = userLastLoginTime;
	}

	public String getUsrSecondaryEmail() {
		return usrSecondaryEmail;
	}

	public void setUsrSecondaryEmail(String usrSecondaryEmail) {
		this.usrSecondaryEmail = usrSecondaryEmail;
	}

}