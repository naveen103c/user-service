package com.akila.orgservices.community.sme.bean;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface CommunitySmeMapper {
  CommunitySmeMapper INSTANCE = Mappers.getMapper(CommunitySmeMapper.class);
  ;

}
