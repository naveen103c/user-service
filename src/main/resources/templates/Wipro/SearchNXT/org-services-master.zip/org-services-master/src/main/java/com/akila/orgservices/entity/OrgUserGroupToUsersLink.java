package com.akila.orgservices.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the org_user_group_to_users_link database table.
 * 
 */
@Entity
@Table(name="org_user_group_to_users_link")
@NamedQuery(name="OrgUserGroupToUsersLink.findAll", query="SELECT o FROM OrgUserGroupToUsersLink o")
public class OrgUserGroupToUsersLink extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgUserGroupToUsersLinkPK id;

	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="user_group_id", referencedColumnName = "user_group_id",  insertable=false, updatable=false)
	private OrgUserGroup orgUserGroup;
	
	public OrgUserGroupToUsersLink() {
	}

	public OrgUserGroupToUsersLinkPK getId() {
		return this.id;
	}

	public void setId(OrgUserGroupToUsersLinkPK id) {
		this.id = id;
	}

}