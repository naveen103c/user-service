package com.akila.orgservices.user.bean;

import java.util.List;

import com.akila.AkilaResponse;

public class UserCommunityResponse extends AkilaResponse {
	protected String userId;

	protected Boolean isCommunityOwner;

	protected Boolean isSME;

	protected Boolean isCommunityAdmin;

	protected List<String> orgCommunityOwnerIdList;

	protected List<String> orgCommunityAdminIdList;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Boolean getIsCommunityOwner() {
		return isCommunityOwner == null ? Boolean.FALSE : isCommunityOwner;
	}

	public void setIsCommunityOwner(Boolean isCommunityOwner) {
		this.isCommunityOwner = isCommunityOwner;
	}

	public Boolean getIsSME() {
		return isSME == null ? Boolean.FALSE : isSME;
	}

	public void setIsSME(Boolean isSME) {
		this.isSME = isSME;
	}

	public Boolean getIsCommunityAdmin() {
		return isCommunityAdmin == null ? Boolean.FALSE : isCommunityAdmin;
	}

	public void setIsCommunityAdmin(Boolean isCommunityAdmin) {
		this.isCommunityAdmin = isCommunityAdmin;
	}

	public List<String> getOrgCommunityOwnerIdList() {
		return orgCommunityOwnerIdList;
	}

	public void setOrgCommunityOwnerIdList(List<String> orgCommunityOwnerIdList) {
		this.orgCommunityOwnerIdList = orgCommunityOwnerIdList;
	}

	public List<String> getOrgCommunityAdminIdList() {
		return orgCommunityAdminIdList;
	}

	public void setOrgCommunityAdminIdList(List<String> orgCommunityAdminIdList) {
		this.orgCommunityAdminIdList = orgCommunityAdminIdList;
	}

	
}
