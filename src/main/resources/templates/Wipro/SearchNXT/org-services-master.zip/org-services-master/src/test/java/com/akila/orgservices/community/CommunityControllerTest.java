package com.akila.orgservices.community;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.orgservices.OrgServicesApplication;

@SpringBootTest(classes = OrgServicesApplication.class)

public class CommunityControllerTest {

	
	@Test
	public void getCommunityTest() {
//		OrgCommunity communityResponse = communityController.getCommunity("4fadab2f-83c1-4ef2-9c3f-706cb0f7ca38");
//		System.out.println("tagResponse.getTagMnemonic() = "+ communityResponse.getCommunityNm() );
	}

	@Test
	public void getAllCommunitiesTest() {
		/*
		List<CommunityResponse> communityResponseList = communityController.getAllCommunities();
		System.out.println("communityResponseList.size() = " + communityResponseList.size());
		CommunityResponse communityResponse = new CommunityResponse();
		Iterator<CommunityResponse> itr = communityResponseList.iterator();
		while (itr.hasNext()) {
			communityResponse = itr.next();
			System.out.println("tagResponse.getTagMnemonic() = " + communityResponse.getCommunityNm());
		}*/
	}

	@Test
	public void createTag() 
	{
		//communityController.deleteSme("d86bb492-5eb4-4d7c-b8ca-37f6be28b6ea", "7e7c0448-43de-46cb-9f78-c2476e1dffbe");
		
	}

	@Test
	public void updateCommunity() {
		
	}
	
	@Test
	public void removeCommunity() {
		
	}

}