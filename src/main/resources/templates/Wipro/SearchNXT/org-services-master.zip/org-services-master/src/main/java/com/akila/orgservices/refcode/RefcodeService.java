package com.akila.orgservices.refcode;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.orgservices.entity.BaseRefCodeType;
import com.akila.orgservices.repository.BaseRefCodeTypeRepository;

@Service
public class RefcodeService extends AkilaService {
  @Autowired
  private BaseRefCodeTypeRepository baseRefCodeTypeRepository;

  @Cacheable(value = "thirty_minute_cache", key = "{'RefcodeService_getAllRefCodes'}")
  public List<BaseRefCodeType> getAllRefCodes() {
		 List<BaseRefCodeType> orgRefCodeList = baseRefCodeTypeRepository.findAll();
		 return orgRefCodeList;
	  }
  
  public BaseRefCodeType getAllRefCodesByType(String codeType) {
		 BaseRefCodeType orgRefCode = baseRefCodeTypeRepository.findByRefCodeType(codeType);
		 return orgRefCode;
	  }

}
