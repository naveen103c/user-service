package com.akila.orgservices.skill;

import com.akila.AkilaController;
import com.akila.orgservices.skill.bean.ResponseStatus;
import com.akila.orgservices.skill.bean.SkillRequest;
import com.akila.orgservices.skill.bean.SkillResponse;
import com.akila.response.ResponseId;
import java.lang.String;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SkillController extends AkilaController {
  @Autowired
  private SkillService skillService;
  private int STATUS_FAILED = 0;
  private int STATUS_PASS = 1;

  @PostMapping(
      path = "/skills"
  )
  public ResponseEntity<ResponseStatus> createSkill(@Valid @RequestBody SkillRequest skillRequest) {
	if(skillRequest.getSkillMnemonic() != null && skillRequest.getSkillMnemonic().trim().length() > 0){
		List<String> mnemonicList =  skillService.getAllExisitngSkillMnemonic(null);
		if(mnemonicList.contains(skillRequest.getSkillMnemonic().trim().toLowerCase())){
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
					("Skill Mnemonic '" + skillRequest.getSkillMnemonic() + "' Already Exist"), 102);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
	}else {
		ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
				("Skill Mnemonic can't be null or blank"), 101);
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
	}
	ResponseId id = skillService.createSkill(skillRequest);
	ResponseStatus status = getResponseStatus(STATUS_PASS, id.getId(), "Skill successfully created", 0);
	
	return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
 }

  @PutMapping(
      path = "/skills/{id}"
  )
  public ResponseEntity<ResponseStatus> updateSkill(@PathVariable String id,@Valid  @RequestBody SkillRequest skillRequest) {
	  if(skillRequest.getSkillMnemonic() != null && skillRequest.getSkillMnemonic().trim().length() > 0){
			List<String> mnemonicList =  skillService.getAllExisitngSkillMnemonic(id);
			if(mnemonicList.contains(skillRequest.getSkillMnemonic().trim().toLowerCase())){
				ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
						("Skill Mnemonic '" + skillRequest.getSkillMnemonic() + "' Already Exist"), 102);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
		}else {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
					("Skill Mnemonic can't be null or blank"), 101);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		ResponseId responseId = skillService.updateSkill(id, skillRequest);
		
		ResponseStatus status = getResponseStatus(STATUS_PASS, responseId.getId(), "Skill Successfully Updated", 0);
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
  }

  @GetMapping(
      path = "/skills/{id}"
  )
  public SkillResponse getSkills(@PathVariable String id) {
    return skillService.getSkills(id);
  }

  @GetMapping(
      path = "/skills"
  )
  public List<SkillResponse> getAllSkills() {
    return skillService.getAllSkills();
  }

  @DeleteMapping(
      path = "/skills/{id}"
  )
  public void deleteSkill(@PathVariable String id) {
     skillService.deleteSkill(id);
  }
  
  private ResponseStatus getResponseStatus(int statusCd, String id, String message, int errorCode) {
		ResponseStatus status = new ResponseStatus();
		status.setStatusCode(statusCd);
		status.setId(id);
		status.setMessage(message);
		status.setErrorCode(errorCode);
		return status;
	}
}
