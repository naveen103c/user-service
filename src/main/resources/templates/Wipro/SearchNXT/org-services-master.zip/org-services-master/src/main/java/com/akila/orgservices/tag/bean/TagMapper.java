package com.akila.orgservices.tag.bean;

import com.akila.orgservices.entity.OrgTag;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface TagMapper {
  TagMapper INSTANCE = Mappers.getMapper(TagMapper.class);
  ;

  @Mappings({})
  TagResponse orgTagToTagResponse(OrgTag orgTag);

  @Mappings({})
  List<TagResponse> orgTagToTagResponseList(List<OrgTag> orgTag);

  @Mappings({})
  OrgTag tagRequestToOrgTag(TagRequest tagRequest);
}
