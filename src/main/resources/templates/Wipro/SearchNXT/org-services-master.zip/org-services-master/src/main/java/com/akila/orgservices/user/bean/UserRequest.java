package com.akila.orgservices.user.bean;

import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.akila.AkilaRequest;

public class UserRequest extends AkilaRequest 
{
  
  @NotEmpty(message = "{USER.NAME.MANDATORY}")
  @Size(min = 2, max = 50,message = "{USER.NAME.LENGTH}")
  @Pattern(regexp="^[A-Za-z\\\\s]+$",message = "{USER.NAME.FORMAT}")  
  private String userFirstNm;

  @Size(max = 50,message = "{USER.NAME.LENGTH}")
  @Size(min = 0,message = "{USER.NAME.LENGTH}")
  @Pattern(regexp="[a-zA-Z][a-zA-Z]+[a-zA-Z]$",message = "{USER.NAME.FORMAT}")
  private String userLastNm;

  @Size(max = 50,message = "{USER.NAME.LENGTH}")
  @Pattern(regexp="[a-zA-Z][a-zA-Z]+[a-zA-Z]$|",message = "{USER.NAME.FORMAT}")
  private String userMidNm;

  @Email(message = "{USER.EMAIL.FORMAT}")
  @NotEmpty(message = "{USER.EMAIL.MANDATORY}")
  @Size(min = 4, max = 100,message = "{USER.EMAIL.LENGTH}")   
  private String usrEmail;
  
  private String usrSecondaryEmail;
  
  private List<String> roles;
  
  private List<String> groups;

 

  public void setUserFirstNm(String userFirstNm) {
    this.userFirstNm = userFirstNm;
  }

  public void setUserLastNm(String userLastNm) {
    this.userLastNm = userLastNm;
  }

  public void setUserMidNm(String userMidNm) {
    this.userMidNm = userMidNm;
  }

  public void setUsrEmail(String usrEmail) {
    this.usrEmail = usrEmail;
  }

  public String getUserFirstNm() {
	return userFirstNm == null ? userFirstNm : userFirstNm.trim();
  }

  public String getUserLastNm() {
    return userLastNm;
  }

  public String getUserMidNm() {
    return userMidNm;
  }

  public String getUsrEmail() {
    return usrEmail == null ? usrEmail : usrEmail.trim();
  }

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<String> getGroups() {
		return groups;
	}

	public void setGroups(List<String> groups) {
		this.groups = groups;
	}

	public String getUsrSecondaryEmail() {
		return usrSecondaryEmail == null ? "" : usrSecondaryEmail;
	}

	public void setUsrSecondaryEmail(String usrSecondaryEmail) {
		this.usrSecondaryEmail = usrSecondaryEmail;
	}
	
}
