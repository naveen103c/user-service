package com.akila.orgservices.user;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.keycloak.OAuth2Constants;
import org.keycloak.admin.client.CreatedResponseUtil;
import org.keycloak.admin.client.Keycloak;
import org.keycloak.admin.client.KeycloakBuilder;
import org.keycloak.admin.client.resource.RealmResource;
import org.keycloak.admin.client.resource.UserResource;
import org.keycloak.admin.client.resource.UsersResource;
import org.keycloak.representations.idm.RoleRepresentation;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Value;

import com.akila.AkilaService;
import com.akila.orgservices.user.bean.CreateUserResponse;
import com.akila.orgservices.user.bean.UserRequest;
import com.akila.orgservices.user.bean.UserResponse;

public class KeycloakService 
{
	private Keycloak keycloak;
	private String realm;
	private static final Logger log = LogManager.getLogger(AkilaService.class);
	
	@Value("${keycloak.users.resource.search.offset}")
	Integer offset;
	
	@Value("${keycloak.users.resource.search.limit}")
	Integer limit;
	
	public KeycloakService(String orgNm, String clientSecret, String userName, String password,String url)
	{
		realm = orgNm;
		//log.info("KeycloakService  "+ orgNm +"--Secrate Id--"+clientSecret);
		log.info("KeycloakService  "+ orgNm +"----");
		keycloak = KeycloakBuilder.builder() 
                .serverUrl(url) 
                .realm("master") 
                .grantType(OAuth2Constants.PASSWORD)
                .clientId(orgNm + "-realm")
                .clientSecret(clientSecret)
                .username(userName)
                .password(password)
                .build();
	}
	
	public CreateUserResponse createUser(UserRepresentation user)
	{
		 RealmResource realmResource = keycloak.realm(realm);
	     UsersResource usersRessource = realmResource.users();
	     Response response = usersRessource.create(user);
	     CreateUserResponse keycloakUserResponse = new CreateUserResponse();
	     keycloakUserResponse.setResponseCode(response.getStatus());
	     if(response.getStatus() != 201)
	     {
	    	 String res = response.readEntity(String.class);
	    	 keycloakUserResponse.setMessage(res);
	    	 return keycloakUserResponse;
	     }
	     String userId = CreatedResponseUtil.getCreatedId(response);
	     keycloakUserResponse.setUserId(userId);
	     UserResource userResource = usersRessource.get(userId);
	     RoleRepresentation testerRealmRole = realmResource.roles().get("user").toRepresentation();
	     userResource.roles().realmLevel().add(Arrays.asList(testerRealmRole));
	     return keycloakUserResponse;
	}
	
	public UserResponse getUser(String userId)
	{
		RealmResource realmResource = keycloak.realm(realm);
	    UsersResource usersRessource = realmResource.users();
	    UserResource userResource = usersRessource.get(userId);
	    UserRepresentation user = userResource.toRepresentation();
	    UserResponse response = new UserResponse();
	    response.setUserId(user.getId());
	    response.setUserFirstNm(user.getFirstName());
	    response.setUserLastNm(user.getLastName());
	    response.setUserMidNm(user.getLastName());
	    response.setUsrEmail(user.getEmail());
	    response.setEnabled(user.isEnabled());
	    List<RoleRepresentation> rolesList = userResource.roles().realmLevel().listAll();
	    for(RoleRepresentation role : rolesList)
	    {
	    	response.getRoles().add(role.getName());
	    }
	    response.setGroups(new ArrayList<String>());
	    return response;
	}
	
	public CreateUserResponse updateUser(UserRepresentation user)
	{
		 CreateUserResponse keycloakUserResponse = new CreateUserResponse();
		 return keycloakUserResponse;
	}
	
	public void suspendUser(String userId)
	{
		updateStatus(userId, false);
	}
	
	public void addRoleToUser(String userId, List<String> roles)
	{
		RealmResource realmResource = keycloak.realm(realm);
	    UsersResource usersRessource = realmResource.users();
	    UserResource userResource = usersRessource.get(userId);
	    List<RoleRepresentation> testerRealmRoles = new ArrayList<>();
	    for(String role : roles)
	    {
	    	RoleRepresentation testerRealmRole = realmResource.roles().get(role).toRepresentation();
	    	testerRealmRoles.add(testerRealmRole);
	    }
	    userResource.roles().realmLevel().add(testerRealmRoles);
	}
	
	public void unAssignRolesToUser(String userId, List<String> roles)
	{
		RealmResource realmResource = keycloak.realm(realm);
	    UsersResource usersRessource = realmResource.users();
	    UserResource userResource = usersRessource.get(userId);
	    List<RoleRepresentation> testerRealmRoles = new ArrayList<>();
	    for(String role : roles)
	    {
	    	RoleRepresentation testerRealmRole = realmResource.roles().get(role).toRepresentation();
	    	testerRealmRoles.add(testerRealmRole);
	    }
	    userResource.roles().realmLevel().remove(testerRealmRoles);
	}
	
	public void activateUser(String userId)
	{
		updateStatus(userId, true);
	}
	
	public void updateStatus(String userId, boolean status)
	{
		RealmResource realmResource = keycloak.realm(realm);
	    UsersResource usersRessource = realmResource.users();
	    UserResource userResource = usersRessource.get(userId);
	    UserRepresentation user = userResource.toRepresentation();
	    user.setEnabled(status);
	    userResource.update(user);
	}

	public void updateUser(String userId, UserRequest userRequest)
	{
		RealmResource realmResource = keycloak.realm(realm);
	    UsersResource usersRessource = realmResource.users();
	    UserResource userResource = usersRessource.get(userId);
	    UserRepresentation user = userResource.toRepresentation();
	    user.setFirstName(userRequest.getUserFirstNm());
	    user.setLastName(userRequest.getUserLastNm());
	    userResource.update(user);
	    
	}
	
	public void deleteUser(String email) {
		RealmResource realmResource = keycloak.realm(realm);
		UsersResource usersRessource = realmResource.users();
		List<UserRepresentation> userRepresentations = usersRessource.search("", "", "", email, offset, limit);
		userRepresentations.forEach(user -> {
			if (user.getEmail().equalsIgnoreCase(email)) {
				usersRessource.delete(user.getId());
			}
		});
	}
}
