package com.akila.orgservices.community.sme.bean;

import com.akila.AkilaRequest;
import java.lang.String;
import java.sql.Timestamp;

public class CommunitySmeRequest extends AkilaRequest {
	private String crtBy;

	private Timestamp crtTs;

	private String modBy;

	private Timestamp modTs;

	private String communityId;

	private String communityNm;

	private String communityOwner;

	private String parentCommunityNm;

	public String getCommunityId() {
		return this.communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public String getCommunityNm() {
		return this.communityNm;
	}

	public void setCommunityNm(String communityNm) {
		this.communityNm = communityNm;
	}

	public String getCommunityOwner() {
		return this.communityOwner;
	}

	public void setCommunityOwner(String communityOwner) {
		this.communityOwner = communityOwner;
	}

	public String getParentCommunityNm() {
		return this.parentCommunityNm;
	}

	public void setParentCommunityNm(String parentCommunityNm) {
		this.parentCommunityNm = parentCommunityNm;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public String getModBy() {
		return modBy;
	}

	public Timestamp getModTs() {
		return modTs;
	}
}
