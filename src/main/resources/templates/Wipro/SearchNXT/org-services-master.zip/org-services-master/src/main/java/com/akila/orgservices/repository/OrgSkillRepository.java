package com.akila.orgservices.repository;

import com.akila.orgservices.entity.OrgSkill;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgSkillRepository extends JpaRepository<OrgSkill, String> {
}
