package com.akila.orgservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.orgservices.entity.BaseRefCodeType;

@Repository
public interface BaseRefCodeTypeRepository extends JpaRepository<BaseRefCodeType, String> {
	
	BaseRefCodeType findByRefCodeType(String codeType);
}
