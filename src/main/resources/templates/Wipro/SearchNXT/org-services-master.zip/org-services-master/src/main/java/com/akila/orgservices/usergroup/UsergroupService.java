package com.akila.orgservices.usergroup;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.orgservices.entity.OrgUserGroup;
import com.akila.orgservices.entity.OrgUserGroupToUsersLink;
import com.akila.orgservices.entity.OrgUserGroupToUsersLinkPK;
import com.akila.orgservices.repository.OrgUserGroupRepository;
import com.akila.orgservices.repository.OrgUserGroupToUsersLinkRepository;
import com.akila.orgservices.usergroup.bean.UserGroupGetAllResponse;
import com.akila.orgservices.usergroup.bean.UserGroupMapper;
import com.akila.orgservices.usergroup.bean.UserGroupRequest;
import com.akila.response.ResponseId;

@Service
public class UsergroupService extends AkilaService {
  private static Logger log = LogManager.getLogger(UsergroupService.class);
  
  @Autowired
  private OrgUserGroupRepository orgUserGroupRepository;

  @Autowired
  private OrgUserGroupToUsersLinkRepository orgUserGroupToUsersLinkRepository;

  @Autowired
  private UserGroupMapper usergroupMapper;
  
  @Autowired
  EntityManager em;
  
  @Value("${total.user.group.limit}")
	private int totalUserGroupLimit;

  public ResponseId createUserGroups(UserGroupRequest usergroupRequest) {
	  
	  List<OrgUserGroup> olduserGroupList = orgUserGroupRepository.findByUserGroupNmIgnoreCase(usergroupRequest.getUserGroupNm().trim());
	  
	  if(olduserGroupList.size() == 0 ) {
		  OrgUserGroup userGroup = usergroupMapper.usergroupRequestToOrgUserGroup(usergroupRequest);
		  userGroup.setUserGroupId(UUID.randomUUID().toString());
		  userGroup.setCrtBy(super.getUserId());
		  userGroup.setModBy(super.getUserId());
		  userGroup.setCrtTs(new Timestamp(System.currentTimeMillis()));
		  userGroup.setModTs(new Timestamp(System.currentTimeMillis()));
		  userGroup.setIsDefault(false);
		  userGroup = orgUserGroupRepository.save(userGroup);
		  // Create Metric Event
		  this.createEvent("Metric-User-Group");
		  return new ResponseId(userGroup.getUserGroupId());
	  }
	  else {
		  return new ResponseId();
	  }
	  
  }
  
	public void deleteUserGroups(String id) {
		orgUserGroupRepository.deleteById(id);
	}
	
	public ResponseId updateUserGroups(String id, UserGroupRequest usergroupRequest) {

		List<OrgUserGroup> olduserGroupList = orgUserGroupRepository.findByUserGroupNmIgnoreCaseAndUserGroupId(usergroupRequest.getUserGroupNm().trim(),
				id);
		if (olduserGroupList.size() == 0) {
			OrgUserGroup olduserGroup = orgUserGroupRepository.findById(id).orElse(null);
			if (olduserGroup != null) {
				OrgUserGroup userGroup = usergroupMapper.usergroupRequestToOrgUserGroup(usergroupRequest);
				userGroup.setUserGroupId(id);
				userGroup.setModBy(super.getUserId());
				userGroup.setModTs(new Timestamp(System.currentTimeMillis()));
				userGroup.setIsDefault(false);
				userGroup.setCrtBy(olduserGroup.getCrtBy());
				userGroup.setCrtTs(olduserGroup.getCrtTs());
				orgUserGroupRepository.save(userGroup);
			}
			return new ResponseId(id);
		} else {
			return new ResponseId();
		}
	}

  public OrgUserGroup getUserGroup(String id) 
  {
	  return orgUserGroupRepository.findById(id).orElse(null);
  }
  
  public OrgUserGroup getUserDetaultUserGroup() 
  {
	  return orgUserGroupRepository.findByIsDefault(Boolean.TRUE).get(0);
  }

  public List<UserGroupGetAllResponse> getAllUserGroups() {
    List<OrgUserGroup> orgUserGroup = orgUserGroupRepository.findAll();
    return usergroupMapper.orgUserGroupToUsergroupResponseList(orgUserGroup);
  }

  public List<OrgUserGroupToUsersLink> getAllUserGroupsForUser(String userId) 
  {
	  Query query = em.createQuery("select gl from OrgUserGroup g join OrgUserGroupToUsersLink gl on g.userGroupId = gl.id.userGroupId  where gl.id.userId = :userId");
	  query.setParameter("userId", userId);
	  List<OrgUserGroupToUsersLink> list = query.getResultList();
      return list;
  }

  public void addUsersToUserGroup(String userGroupId, List<String> users) 
  {
	  for(String user : users)
	  {
		  OrgUserGroupToUsersLink link = new OrgUserGroupToUsersLink();
		  link.setId(getOrgUserGroupToUsersLinkPK(userGroupId, user));
		  link.setCrtBy(getUserId());
		  link.setModBy(getUserId());
		  link.setCrtTs(new Timestamp(new Date().getTime()));
		  link.setModTs(new Timestamp(new Date().getTime()));
		  orgUserGroupToUsersLinkRepository.save(link);
	  }
  }
  
  public void removeUsersToUserGroup(String userGroupId, List<String> users) 
  {
	  for(String user : users)
	  {
		  OrgUserGroupToUsersLink link = new OrgUserGroupToUsersLink();
		  link.setId(getOrgUserGroupToUsersLinkPK(userGroupId, user));
		  orgUserGroupToUsersLinkRepository.delete(link);
	  }
  }

 

  public OrgUserGroupToUsersLinkPK getOrgUserGroupToUsersLinkPK(String userGroupId, String user) {
    OrgUserGroupToUsersLinkPK orgUserGroupToUsersLinkPK = new OrgUserGroupToUsersLinkPK();
        orgUserGroupToUsersLinkPK.setUserId(user);
        orgUserGroupToUsersLinkPK.setUserGroupId(userGroupId);
        return orgUserGroupToUsersLinkPK;
  }
  
  public boolean isGroupLimitAllow() {
		boolean limit = false;
		int groupLimit =  getUserGroupLimit();
		int groupCount =  getGroupCount();
		log.info("isGroupLimitAllow >> groupLimit : " + groupLimit+", groupCount : "+groupCount);
		if(groupCount < groupLimit) {
			limit = true;
		}
		
		return limit;
		
	}

	private int getGroupCount() {
		return (int) orgUserGroupRepository.count();
	}

	private int getUserGroupLimit() {
		return totalUserGroupLimit;
	}
}
