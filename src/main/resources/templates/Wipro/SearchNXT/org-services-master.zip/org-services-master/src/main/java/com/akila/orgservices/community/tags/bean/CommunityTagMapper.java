package com.akila.orgservices.community.tags.bean;

import com.akila.orgservices.entity.OrgCommunity;
import com.akila.orgservices.entity.OrgCommunitySme;
import com.akila.orgservices.entity.OrgCommunityTag;

import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface CommunityTagMapper {
  CommunityTagMapper INSTANCE = Mappers.getMapper(CommunityTagMapper.class);
  ;

  @Mappings({})
  CommunityTagResponse orgCommunityTagToCommunityTagResponse(OrgCommunityTag orgCommunityTag);

  @Mappings({})
  List<CommunityTagResponse> orgCommunitySmeToCommunityResponseList(
      List<OrgCommunityTag> orgCommunityTagList);
  
  @Mappings({})
  List<CommunityTagResponse> orgCommunityTagListToCommunityTagResponseList(List<OrgCommunityTag> orgCommunityTagList);
  
  @Mappings({})
  OrgCommunityTag communityTagRequestToOrgCommunityTag(CommunityTagRequest communityTagRequest);
}
