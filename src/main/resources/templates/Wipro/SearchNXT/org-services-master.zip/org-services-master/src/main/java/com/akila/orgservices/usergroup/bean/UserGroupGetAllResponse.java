package com.akila.orgservices.usergroup.bean;

import java.sql.Timestamp;

import com.akila.AkilaResponse;

public class UserGroupGetAllResponse extends AkilaResponse {
	
  private String userGroupId;
  
  private String crtBy;

  private Timestamp crtTs;

  private String modBy;

  private Timestamp modTs;

  private String userGroupNm;
  
  private String userGroupDesc;
  
  public void setCrtBy(String crtBy) {
    this.crtBy = crtBy;
  }

  public void setCrtTs(Timestamp crtTs) {
    this.crtTs = crtTs;
  }

  public String getUserGroupDesc() {
	return userGroupDesc;
}

public void setUserGroupDesc(String userGroupDesc) {
	this.userGroupDesc = userGroupDesc;
}

public void setModBy(String modBy) {
    this.modBy = modBy;
  }

  public void setModTs(Timestamp modTs) {
    this.modTs = modTs;
  }

  public void setUserGroupNm(String userGroupNm) {
    this.userGroupNm = userGroupNm;
  }

  public String getCrtBy() {
    return crtBy;
  }

  public Timestamp getCrtTs() {
    return crtTs;
  }

  public String getModBy() {
    return modBy;
  }

  public Timestamp getModTs() {
    return modTs;
  }

  public String getUserGroupNm() {
    return userGroupNm;
  }

	public String getUserGroupId() {
		return userGroupId;
	}

	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}
}
