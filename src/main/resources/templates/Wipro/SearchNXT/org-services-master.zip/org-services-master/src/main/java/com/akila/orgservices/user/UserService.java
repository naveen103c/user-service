package com.akila.orgservices.user;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.JDBCException;
import org.keycloak.representations.idm.UserRepresentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.orgservices.entity.BaseRefCodeType;
import com.akila.orgservices.entity.OrgBulkUser;
import com.akila.orgservices.entity.OrgBulkUserDetails;
import com.akila.orgservices.entity.OrgCommunity;
import com.akila.orgservices.entity.OrgCommunityAdmin;
import com.akila.orgservices.entity.OrgCommunitySme;
import com.akila.orgservices.entity.OrgRefCode;
import com.akila.orgservices.entity.OrgUser;
import com.akila.orgservices.entity.OrgUserFavlist;
import com.akila.orgservices.entity.OrgUserFavlistPK;
import com.akila.orgservices.entity.OrgUserGroup;
import com.akila.orgservices.entity.OrgUserGroupToUsersLink;
import com.akila.orgservices.entity.OrgUserGroupToUsersLinkPK;
import com.akila.orgservices.entity.OrgUserToRolesLink;
import com.akila.orgservices.entity.OrgUserToRolesLinkPK;
import com.akila.orgservices.refcode.RefcodeService;
import com.akila.orgservices.repository.OrgBulkUserDetailsRepository;
import com.akila.orgservices.repository.OrgBulkUserRepository;
import com.akila.orgservices.repository.OrgCommunityAdminRepository;
import com.akila.orgservices.repository.OrgCommunityRepository;
import com.akila.orgservices.repository.OrgCommunitySmeRepository;
import com.akila.orgservices.repository.OrgUserFavlistRepository;
import com.akila.orgservices.repository.OrgUserGroupRepository;
import com.akila.orgservices.repository.OrgUserGroupToUsersLinkRepository;
import com.akila.orgservices.repository.OrgUserRepository;
import com.akila.orgservices.repository.OrgUserToRolesLinkRepository;
import com.akila.orgservices.user.bean.CreateUserResponse;
import com.akila.orgservices.user.bean.RoleResponse;
import com.akila.orgservices.user.bean.UserCommunityResponse;
import com.akila.orgservices.user.bean.UserMapper;
import com.akila.orgservices.user.bean.UserRequest;
import com.akila.orgservices.user.bean.UserResponse;
import com.akila.orgservices.usergroup.UsergroupService;
import com.akila.response.ResponseId;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class UserService extends AkilaService {
	private static Logger log = LogManager.getLogger(UserService.class);
	
	public static final String TENANT_HEADER = "tenant";
	
	@Autowired
	private OrgUserRepository orgUserRepository;

	@Autowired
	private OrgUserGroupToUsersLinkRepository orgUserGroupToUsersLinkRepository;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private UsergroupService usergroupService;

	@Autowired
	private OrgCommunityRepository orgCommunityRepository;

	@Autowired
	OrgUserToRolesLinkRepository orgUserToRolesLinkRepository;

	@Autowired
	private OrgCommunitySmeRepository orgCommunitySmeRepository;

	@Autowired
	private OrgCommunityAdminRepository orgCommunityAdminRepository;

	@Autowired
	OrgUserFavlistRepository orgUserFavlistRepository;
	
	@Autowired
	OrgBulkUserRepository orgBulkUserRepository;
	
	@Autowired
	OrgBulkUserDetailsRepository orgBulkUserDetailsRepository;

	@Autowired
	RefcodeService refcodeService;

	@Value("${keyclock.username}")
	private String keyClockUserName;

	@Value("${keyclock.password}")
	private String keyClockPassword;

	@Value("${keyclock.url}")
	private String keyClockURL;
	
	@Value("${default.users.limit:20}")
	private int totalUserLimit;

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate loadBalancedRestTemplate;

	Map<String, String> roleMap = null;
	
	@Autowired
	SecrateProperties secrateProperties;
	
	@Value("${metric.service.url}")
	private String metricServiceURL;
	
	@Value("${platform.service.url}")
	private String platformServiceURL;
	
	@Autowired
	private AkilaRestTemplate akilaRestTemplate;
	

	public CreateUserResponse createUser(UserRequest userRequest, Boolean activeStatus) {
		UserRepresentation user = new UserRepresentation();
		// Creating user from SharePoint inactive status
		if (activeStatus == null) {
			user.setEnabled(true);
		} else {
			user.setEnabled(activeStatus);
		}
		user.setUsername(userRequest.getUsrEmail());
		user.setFirstName(userRequest.getUserFirstNm());
		user.setLastName(userRequest.getUserLastNm());
		user.setEmail(userRequest.getUsrEmail());
		log.info("Keycloak URL -------->>>>"+keyClockURL);
		KeycloakService service = new KeycloakService(secrateProperties.getRealm().get(request.getHeader(TENANT_HEADER)), secrateProperties.getSecret().get(request.getHeader(TENANT_HEADER)), keyClockUserName,
				keyClockPassword,keyClockURL);
		CreateUserResponse response = service.createUser(user);
		if (response.getResponseCode() == 409) {
			service.deleteUser(user.getEmail());
			response = service.createUser(user);
		} 
		if (response.getResponseCode() == 201) {
			OrgUser orgUser = userMapper.userRequestToOrgUser(userRequest);
			orgUser.setUserId(response.getUserId());
			orgUser.setIsActive(Boolean.TRUE);
			orgUser.setCrtBy(getUserId());
			orgUser.setModBy(getUserId());
			orgUser.setCrtTs(new Timestamp(new Date().getTime()));
			orgUser.setModTs(new Timestamp(new Date().getTime()));
			orgUserRepository.save(orgUser);

			// create user default Fav list
			this.createUserDefaultFavList(orgUser.getUserFirstNm(), orgUser.getUserId());

			List<OrgUserToRolesLink> roleList = new ArrayList<OrgUserToRolesLink>();
			for (String role : getDefaultRoles()) {
				OrgUserToRolesLink rl = new OrgUserToRolesLink();
				OrgUserToRolesLinkPK pk = new OrgUserToRolesLinkPK();
				pk.setUserId(response.getUserId());
				if (getRoleMap().containsKey(role)) {
					pk.setRoleId(getRoleMap().get(role));
					rl.setId(pk);
					rl.setCrtBy(getUserId());
					rl.setCrtTs(new Timestamp(new Date().getTime()));
					rl.setModBy(getUserId());
					rl.setModTs(new Timestamp(new Date().getTime()));

					roleList.add(rl);

				}
			}
			orgUserToRolesLinkRepository.saveAll(roleList);
			
			
			OrgUserGroup defaultUserGroup = usergroupService.getUserDetaultUserGroup();
			if(defaultUserGroup !=null && !userRequest.getGroups().contains(defaultUserGroup.getUserGroupId()))
			{
				userRequest.getGroups().add(defaultUserGroup.getUserGroupId());
			}
			this.assignUserGroupsToUser(orgUser.getUserId(), userRequest.getGroups());
			
			try {
				HttpEntity<String> entity = new HttpEntity<String>("Metric-Users", getRequestHeader());
				akilaRestTemplate.postForEntity(loadBalancedRestTemplate, metricServiceURL + "/publishEvent?serviceName=Metric-Users",
						entity, Void.class);
			} catch (HttpStatusCodeException e) {
				log.error("UserService.createUser : Error while updating metrics", e);
			} catch (Exception e) {
				log.error("UserService.createUser : Error while updating metrics", e);
			}
		}

		return response;
	}

	public CreateUserResponse copyUser(UserRequest userRequest) {
		UserRepresentation user = new UserRepresentation();
		user.setEnabled(true);
		user.setUsername(userRequest.getUsrEmail());
		user.setFirstName(userRequest.getUserFirstNm());
		user.setLastName(userRequest.getUserLastNm());
		user.setEmail(userRequest.getUsrEmail());
		KeycloakService service = new KeycloakService(secrateProperties.getRealm().get(request.getHeader(TENANT_HEADER)), secrateProperties.getSecret().get(request.getHeader(TENANT_HEADER)), keyClockUserName,
				keyClockPassword,keyClockURL);
		CreateUserResponse response = service.createUser(user);
		if (response.getResponseCode() == 201) {
			OrgUser orgUser = userMapper.userRequestToOrgUser(userRequest);
			orgUser.setUserId(response.getUserId());
			orgUser.setIsActive(Boolean.TRUE);
			orgUser.setCrtBy(getUserId());
			orgUser.setModBy(getUserId());
			orgUser.setCrtTs(new Timestamp(new Date().getTime()));
			orgUser.setModTs(new Timestamp(new Date().getTime()));
			orgUserRepository.save(orgUser);

			// create user default Fav list
			this.createUserDefaultFavList(orgUser.getUserFirstNm(), orgUser.getUserId());

			// Copy Groups
			this.assignUserGroupsToUser(orgUser.getUserId(), userRequest.getGroups());

			// Copy Role
			this.assignRolesToUser(orgUser.getUserId(), userRequest.getRoles());

			try {
				HttpEntity<String> entity = new HttpEntity<String>("Metric-Users", getRequestHeader());
				akilaRestTemplate.postForEntity(loadBalancedRestTemplate, metricServiceURL + "/publishEvent?serviceName=Metric-Users",
						entity, Void.class);
			}catch (HttpStatusCodeException e) {
				log.error("UserService.copyUser : Error while updating metrics", e);
			} catch (Exception e) {
				log.error("UserService.copyUser : Error while updating metrics", e);
			}

		}

		return response;
	}

	public List<OrgUser> getAllUsers(String role) {

		if (role == null) {
			return orgUserRepository.findAll();
		} else {
			if (getRoleMap().containsKey(role)) {
				throw new RuntimeException("Method not implemented");
				//return orgUserRepository.findByOrgUserToRolesLink_RoleId(getRoleMap().get(role));
			} else {
				return new ArrayList<OrgUser>();
			}
		}
	}

	public UserResponse getUser(String id) {
		KeycloakService service = new KeycloakService(secrateProperties.getRealm().get(request.getHeader(TENANT_HEADER)), secrateProperties.getSecret().get(request.getHeader(TENANT_HEADER)), keyClockUserName,
				keyClockPassword,keyClockURL);
		
		OrgUser orgUser = orgUserRepository.findById(id).orElse(null);
		UserResponse response = service.getUser(id);
		if(orgUser!=null) {
			response.setUsrSecondaryEmail(orgUser.getUsrSecondaryEmail());
		}
		// Add User Groups from Database
		List<OrgUserGroupToUsersLink> userGroupList = usergroupService.getAllUserGroupsForUser(id);
		for (OrgUserGroupToUsersLink orgUserGroup : userGroupList) {
			response.getGroups().add(orgUserGroup.getId().getUserGroupId());
		}
		return response;
	}

	public ResponseId updateUser(String id, UserRequest userRequest) {

		// Update Values in KeyClock
		KeycloakService service = new KeycloakService(secrateProperties.getRealm().get(request.getHeader(TENANT_HEADER)), secrateProperties.getSecret().get(request.getHeader(TENANT_HEADER)), keyClockUserName,
				keyClockPassword,keyClockURL);
		service.updateUser(id, userRequest);

		// Update Values in DataBase
		OrgUser orgUser = orgUserRepository.getOne(id);
		orgUser.setUserFirstNm(userRequest.getUserFirstNm());
		orgUser.setUserMidNm(userRequest.getUserMidNm());
		orgUser.setUserLastNm(userRequest.getUserLastNm());
		orgUser.setUsrSecondaryEmail(userRequest.getUsrSecondaryEmail());
		orgUser.setModBy(getUserId());
		orgUser.setModTs(new Timestamp(new Date().getTime()));
		orgUserRepository.save(orgUser);
		return new ResponseId(id);
	}

	public void suspendUser(String id) {
		KeycloakService service = new KeycloakService(secrateProperties.getRealm().get(request.getHeader(TENANT_HEADER)), secrateProperties.getSecret().get(request.getHeader(TENANT_HEADER)), keyClockUserName,
				keyClockPassword,keyClockURL);
		service.suspendUser(id);
		OrgUser orgUser = orgUserRepository.getOne(id);
		orgUser.setModTs(new Timestamp(new Date().getTime()));
		orgUser.setIsActive(Boolean.FALSE);
		orgUserRepository.save(orgUser);
	}

	public void activateUser(String id) {
		KeycloakService service = new KeycloakService(secrateProperties.getRealm().get(request.getHeader(TENANT_HEADER)), secrateProperties.getSecret().get(request.getHeader(TENANT_HEADER)), keyClockUserName,
				keyClockPassword,keyClockURL);
		service.activateUser(id);
		OrgUser orgUser = orgUserRepository.getOne(id);
		orgUser.setModTs(new Timestamp(new Date().getTime()));
		orgUser.setIsActive(Boolean.TRUE);
		orgUserRepository.save(orgUser);
	}

	public void assignUserGroupsToUser(String userId, List<String> groups) {

		for (String group : groups) {
			OrgUserGroupToUsersLink link = new OrgUserGroupToUsersLink();
			link.setId(getOrgUserGroupToUsersLinkPK(userId, group));
			link.setCrtBy(getUserId());
			link.setModBy(getUserId());
			link.setCrtTs(new Timestamp(new Date().getTime()));
			link.setModTs(new Timestamp(new Date().getTime()));
			orgUserGroupToUsersLinkRepository.save(link);
		}

	}

	public UserCommunityResponse getCommunityForUserOwner() {
		UserCommunityResponse userCommunityResponse = new UserCommunityResponse();
		userCommunityResponse.setUserId(super.getUserId());
		List<OrgCommunity> list = orgCommunityRepository.findByOwnerId(super.getUserId());

		List<OrgCommunitySme> smeList = orgCommunitySmeRepository.findByIdUserId(super.getUserId());

		List<OrgCommunityAdmin> adminList = orgCommunityAdminRepository.findByIdUserId(super.getUserId());

		if (list.size() > 0) {

			List<String> communityIds = new ArrayList<String>();

			list.forEach(l -> {

				communityIds.add(l.getCommunityId());

			});
			userCommunityResponse.setOrgCommunityOwnerIdList(communityIds);
			userCommunityResponse.setIsCommunityOwner(Boolean.TRUE);
		} else {
			userCommunityResponse.setOrgCommunityOwnerIdList(Collections.emptyList());
		}
		if (smeList.size() > 0) {
			userCommunityResponse.setIsSME(Boolean.TRUE);
		}
		if (adminList.size() > 0) {
			List<String> adminIds = new ArrayList<String>();

			adminList.forEach(admin -> {

				adminIds.add(admin.getOrgCommunity().getCommunityId());

			});
			userCommunityResponse.setOrgCommunityAdminIdList(adminIds);
			userCommunityResponse.setIsCommunityAdmin(Boolean.TRUE);
		} else {
			userCommunityResponse.setOrgCommunityAdminIdList(Collections.emptyList());
		}
		return userCommunityResponse;
	}

	public void removeUserGroupsToUser(String userId, List<String> groups) {

		for (String group : groups) {
			OrgUserGroupToUsersLink link = new OrgUserGroupToUsersLink();
			link.setId(getOrgUserGroupToUsersLinkPK(userId, group));
			orgUserGroupToUsersLinkRepository.delete(link);
		}

	}

	public void assignRolesToUser(String userId, List<String> roles) {
		KeycloakService service = new KeycloakService(secrateProperties.getRealm().get(request.getHeader(TENANT_HEADER)), secrateProperties.getSecret().get(request.getHeader(TENANT_HEADER)), keyClockUserName,
				keyClockPassword,keyClockURL);
		
		service.addRoleToUser(userId, roles);
		List<OrgUserToRolesLink> roleList = new ArrayList<OrgUserToRolesLink>();
		for (String role : roles) {
			OrgUserToRolesLink rl = new OrgUserToRolesLink();
			OrgUserToRolesLinkPK pk = new OrgUserToRolesLinkPK();
			pk.setUserId(userId);
			if (getRoleMap().containsKey(role)) {
				pk.setRoleId(getRoleMap().get(role));
				rl.setId(pk);
				rl.setCrtBy(getUserId());
				rl.setCrtTs(new Timestamp(new Date().getTime()));
				rl.setModBy(getUserId());
				rl.setModTs(new Timestamp(new Date().getTime()));

				roleList.add(rl);

			}
		}
		orgUserToRolesLinkRepository.saveAll(roleList);
	}

	public void unAssignRolesToUser(String userId, List<String> roles) {

		KeycloakService service = new KeycloakService(secrateProperties.getRealm().get(request.getHeader(TENANT_HEADER)), secrateProperties.getSecret().get(request.getHeader(TENANT_HEADER)), keyClockUserName,
				keyClockPassword,keyClockURL);
		service.unAssignRolesToUser(userId, roles);

		List<OrgUserToRolesLink> roleList = new ArrayList<OrgUserToRolesLink>();
		for (String role : roles) {
			OrgUserToRolesLink rl = new OrgUserToRolesLink();
			OrgUserToRolesLinkPK pk = new OrgUserToRolesLinkPK();
			pk.setUserId(userId);
			if (getRoleMap().containsKey(role)) {
				pk.setRoleId(getRoleMap().get(role));
				rl.setId(pk);
				rl.setCrtBy(getUserId());
				rl.setCrtTs(new Timestamp(new Date().getTime()));
				rl.setModBy(getUserId());
				rl.setModTs(new Timestamp(new Date().getTime()));

				roleList.add(rl);

			}
		}
		orgUserToRolesLinkRepository.deleteAll(roleList);
	}

	public OrgUserToRolesLinkPK getOrgUserToRolesLinkPK(String userId, String roleId) {
		OrgUserToRolesLinkPK orgUserToRolesLinkPK = new OrgUserToRolesLinkPK();
		orgUserToRolesLinkPK.setUserId(userId);
		orgUserToRolesLinkPK.setRoleId(roleId);
		return orgUserToRolesLinkPK;
	}

	public OrgUserGroupToUsersLinkPK getOrgUserGroupToUsersLinkPK(String userId, String userGroupId) {
		OrgUserGroupToUsersLinkPK orgUserGroupToUsersLinkPK = new OrgUserGroupToUsersLinkPK();
		orgUserGroupToUsersLinkPK.setUserId(userId);
		orgUserGroupToUsersLinkPK.setUserGroupId(userGroupId);
		return orgUserGroupToUsersLinkPK;
	}

	public Map<String, String> getRoleMap() {
		if (roleMap == null) {
			roleMap = new HashMap<String, String>();
			try {
				HttpEntity<String> entity = new HttpEntity<String>("org-services", getRequestHeader());
				ResponseEntity<String> response = akilaRestTemplate.exchange(loadBalancedRestTemplate, platformServiceURL + "/roles",
						HttpMethod.GET, entity, String.class);
				String responseBody = response.getBody();
				ObjectMapper objectMapper = new ObjectMapper();
				RoleResponse[] role = objectMapper.readValue(responseBody, RoleResponse[].class);
				for (int i = 0; i < role.length; i++) {
					roleMap.put(role[i].getRoleNm(), role[i].getRoleId());
				}
			}catch (HttpStatusCodeException e) {
				log.error("getRoleMap : " + e.getMessage(), e);
			}  catch (Exception e) {
				log.error("getRoleMap : " + e.getMessage(), e);
			}
		}
		return roleMap;
	}

	public List<String> getDefaultRoles() {
		List<String> roles = new ArrayList<String>();
		roles.add("user");
		roles.add("uma_authorization");
		roles.add("offline_access");
		roles.add("org-user");
		return roles;
	}

	public void createUserDefaultFavList(String userFirstName, String userId) {
		OrgUserFavlist orgUserFavlist = new OrgUserFavlist();

		orgUserFavlist.setDescription("Default auto generated list");
		orgUserFavlist.setIsShared(Boolean.FALSE);
		orgUserFavlist.setFavlistNm(userFirstName + "\'s" + " list");

		orgUserFavlist.setId(getOrgUserFavlistPK(UUID.randomUUID().toString(), userId));
		orgUserFavlist.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgUserFavlist.setModTs(new Timestamp(System.currentTimeMillis()));
		orgUserFavlist.setCrtBy(getUserId());
		orgUserFavlist.setModBy(getUserId());
		orgUserFavlist.setIsDefault(Boolean.TRUE);
		orgUserFavlistRepository.save(orgUserFavlist);
	}

	public OrgUserFavlistPK getOrgUserFavlistPK(String favlistId, String userId) {
		OrgUserFavlistPK orgUserFavlistPK = new OrgUserFavlistPK();
		orgUserFavlistPK.setUserId(userId);
		orgUserFavlistPK.setFavlistId(favlistId);
		return orgUserFavlistPK;
	}

	public void loginUser(String userId) {
		try {
			OrgUser orgUser = orgUserRepository.findById(getUserId()).orElse(null);
			if(orgUser!=null) {
				orgUser.setUserLastLoginTime(new Timestamp(new Date().getTime()));
				orgUserRepository.save(orgUser);
			}
			HttpEntity<String> entity = new HttpEntity<String>("Metric-Active-Users", getRequestHeader());
			akilaRestTemplate.postForEntity(loadBalancedRestTemplate,
					metricServiceURL + "/publishEvent?serviceName=Metric-Active-Users", entity, Void.class);
		}catch (HttpStatusCodeException e) {
			log.error("UserService.loginUser : Error while updating metrics", e);
		} catch (Exception e) {
			log.error("UserService.loginUser : Error while updating metrics and updating user last login time", e);
		}
	}

	public List<OrgUser> getUserByEmail(String usrEmail) {
		return orgUserRepository.findByUsrEmailIgnoreCase(usrEmail);
	}

	public List<String> getUserGroup(String userId) {

		List<String> userGpList = new ArrayList<String>();

		try {

			List<OrgUserGroupToUsersLink> userGroupList = usergroupService.getAllUserGroupsForUser(userId);

			for (OrgUserGroupToUsersLink orgUserGroup : userGroupList) {

				userGpList.add(orgUserGroup.getId().getUserGroupId());
			}
		}catch (JDBCException e) {
			log.error("UserService.getUserGroup : Error while getting groups for user", e);
		} catch (Exception e) {
			log.error("UserService.getUserGroup : Error while getting groups for user", e);
		}

		return userGpList;
	}
	
	public List<OrgBulkUser> getBulkUserConfig() {
		return orgBulkUserRepository.findAllByOrderByCrtTsDesc();
	}
	
	public OrgBulkUser getBulkUserConfig(UUID id) {
		return orgBulkUserRepository.findById(id).orElse(null);
	}
	
	@Transactional
	public void uploadBulkUser(MultipartFile file, String configName) throws Exception {

		OrgBulkUser orgBulkUser = new OrgBulkUser();
		orgBulkUser.setUploadId(UUID.randomUUID());
		orgBulkUser.setFileNm(file.getOriginalFilename());
		orgBulkUser.setStatus(1);
		orgBulkUser.setUploadConfigNm(configName);
		Set<OrgBulkUserDetails> orgBulkUserDetailsList = new HashSet<OrgBulkUserDetails>();

		// Create Workbook instance holding reference to .xlsx file
		XSSFWorkbook workbook = new XSSFWorkbook(file.getInputStream());

		// Get first/desired sheet from the workbook
		XSSFSheet sheet = workbook.getSheetAt(0);

		// Iterate through each rows one by one
		Iterator<org.apache.poi.ss.usermodel.Row> rowIterator = sheet.iterator();

		int rowCount = 0;
		while (rowIterator.hasNext()) {

			Row row = rowIterator.next();

			if (++rowCount == 1) {
				continue;
			}

			String email = row.getCell(0).getStringCellValue().trim();
			String firstName = row.getCell(1).getStringCellValue().trim();
			String lastName = row.getCell(2).getStringCellValue().trim();
			String groups = row.getCell(3).getStringCellValue().trim();
			String roles = row.getCell(4).getStringCellValue().trim();

			OrgBulkUserDetails orgBulkUserDetails = new OrgBulkUserDetails();
			orgBulkUserDetails.setUploadRowId(UUID.randomUUID());
			orgBulkUserDetails.setUploadId(orgBulkUser.getUploadId());

			orgBulkUserDetails.setUsrFirstNm(firstName);
			orgBulkUserDetails.setUsrLastNm(lastName);
			orgBulkUserDetails.setUsrEmail(email);
			orgBulkUserDetails.setUsrGroups(groups);
			orgBulkUserDetails.setUsrRoles(roles);
			orgBulkUserDetails.setStatus(1);
			orgBulkUserDetails.setModTs(new Timestamp(System.currentTimeMillis()));

			orgBulkUserDetailsList.add(orgBulkUserDetails);

		}

		orgBulkUser.setTotalRecords(rowCount - 1);
		orgBulkUser.setFailureRecords(0);
		orgBulkUser.setSuccessRecords(0);
		orgBulkUser.setCrtBy(super.getUserId());
		orgBulkUser.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgBulkUserRepository.save(orgBulkUser);
		orgBulkUserDetailsRepository.saveAll(orgBulkUserDetailsList);

	}

	public ByteArrayInputStream getBulkUserFile(UUID id) {
		List<OrgBulkUserDetails> orgBulkUserDetailsList = orgBulkUserDetailsRepository.findByUploadId(id);
		if(orgBulkUserDetailsList == null) {
			orgBulkUserDetailsList = new ArrayList<OrgBulkUserDetails>();
		}
		ByteArrayInputStream in = this.orgBulkUserDetailsToExcel(orgBulkUserDetailsList);
		return in;
	}

	public ByteArrayInputStream orgBulkUserDetailsToExcel(List<OrgBulkUserDetails> orgBulkUserDetailsList) {
		String[] HEADERs = { "Email", "First Name", "Last Name", "Groups", "Roles", "Status" };
		String SHEET = "Users";
		Map<Integer,String> refCodeMap = new HashMap<Integer, String>();
		List<BaseRefCodeType> refCodeList = refcodeService.getAllRefCodes();
		for (BaseRefCodeType baseRefCodeType : refCodeList) {
			if(baseRefCodeType.getRefCodeType().equalsIgnoreCase("USER_UPLOAD_EVENT_TYPE_CD")) {
				
				for (OrgRefCode orgRefCode : baseRefCodeType.getOrgRefCodes()) {
					refCodeMap.put(orgRefCode.getRefCodeStoreVal(), orgRefCode.getRefCodeDisplayVal());
				}
				break;
			}
		}
		try {
			Workbook workbook = new XSSFWorkbook();
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			Sheet sheet = workbook.createSheet(SHEET);

			// Header
			Row headerRow = sheet.createRow(0);

			for (int col = 0; col < HEADERs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(HEADERs[col]);
			}

			int rowIdx = 1;
			for (OrgBulkUserDetails orgBulkUserDetails : orgBulkUserDetailsList) {
				Row row = sheet.createRow(rowIdx++);

				row.createCell(0).setCellValue(orgBulkUserDetails.getUsrEmail());
				row.createCell(1).setCellValue(orgBulkUserDetails.getUsrFirstNm());
				row.createCell(2).setCellValue(orgBulkUserDetails.getUsrLastNm());
				row.createCell(3).setCellValue(orgBulkUserDetails.getUsrGroups());
				row.createCell(4).setCellValue(orgBulkUserDetails.getUsrRoles());
				row.createCell(5).setCellValue(refCodeMap.get(orgBulkUserDetails.getStatus()));
			}

			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (IOException e) {
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}
	}
	
	public ByteArrayInputStream getBulkUserSampleFile() {
		ByteArrayInputStream in = this.createSampleExcel();
		return in;
	}
	
	public ByteArrayInputStream createSampleExcel() {
		String[] HEADERs = { "User email", "User first name", "User last name", "User groups", "User roles" };
		String SHEET = "Users";
		try {
			Workbook workbook = new XSSFWorkbook();
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			Sheet sheet = workbook.createSheet(SHEET);
			// Header
			Row headerRow = sheet.createRow(0);

			for (int col = 0; col < HEADERs.length; col++) {
				Cell cell = headerRow.createCell(col);
				cell.setCellValue(HEADERs[col]);
			}

			Row row = sheet.createRow(1);

			row.createCell(0).setCellValue("xxxxx@xxxx.com");
			row.createCell(1).setCellValue("xxxxxxxxxxxxxxx");
			row.createCell(2).setCellValue("xxxxxxxxxxxxxxx");
			row.createCell(3).setCellValue("Account|HR");
			row.createCell(4).setCellValue("org-user|content-manager");
			workbook.write(out);
			return new ByteArrayInputStream(out.toByteArray());
		} catch (IOException e) {
			throw new RuntimeException("fail to import data to Excel file: " + e.getMessage());
		}
	}
	
	
	
	public boolean isUserLimitAllow() {
		boolean limit = false;
		int userLimit =  getUserLimit();
		int userCount =  getUserCount();
		log.info("isUserLimitAllow >> userLimit : " + userLimit+", userCount : "+userCount);
		if(userCount < userLimit) {
			limit = true;
		}
		
		return limit;
		
	}
	
	private int getUserCount() {
		return orgUserRepository.activeUserCount();
	}
	
	private int getUserLimit() {
		try {
			HttpEntity<String> entity = new HttpEntity<String>("platform-services", getRequestHeader());
			ResponseEntity<String> response = akilaRestTemplate.exchange(loadBalancedRestTemplate, platformServiceURL + "/plans/service?serviceName=Users",
					HttpMethod.GET, entity, String.class);
			String responseBody = response.getBody();
			log.info("getUserLimit >> responseBody : " + responseBody);
			return Integer.parseInt(responseBody);
		}catch (HttpStatusCodeException e) {
			log.error("getUserLimit : " + e.getMessage(), e);
			return totalUserLimit;
		} catch (Exception e) {
			log.error("getUserLimit : " + e.getMessage(), e);
			return totalUserLimit;
		}
		
	}

}
