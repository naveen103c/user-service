package com.akila.orgservices.tag;

import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import com.akila.orgservices.OrgServicesApplication;
import com.akila.orgservices.tag.bean.TagResponse;

@SpringBootTest(classes = OrgServicesApplication.class)
@TestPropertySource(locations="classpath:application-test.properties")
public class TagControllerTest {

	@Autowired
	private TagController tagController;

	int count = 1;

	private String tagId;

	@Test
	public void getAllTagsTest() {
		List<TagResponse> tagResponseList = tagController.getAllTags(1);
		count += tagResponseList.size();
		TagResponse tagResponse = new TagResponse();
		Iterator<TagResponse> itr = tagResponseList.iterator();
		while (itr.hasNext()) {
			tagResponse = itr.next();
		}
	}

	@Test
	public void getTagsTest() {
		//TagResponse tagResponse = tagController.getTag("d06a5bee-af0b-4db8-9632-8dad62c7a335");
		//System.out.println("tagResponse.getTagMnemonic() = " + tagResponse.getTagId());
	}

	@Test
	public void createTag() {
		/*
		TagRequest tagRequest = new TagRequest();
		tagRequest.setTagMnemonic("automation" + count++);
		tagRequest.setTagTypeCd(1);
		tagRequest.setCrtTs(new Timestamp(System.currentTimeMillis()));
		tagRequest.setModTs(new Timestamp(System.currentTimeMillis()));

		tagId = tagController.createTag(tagRequest).getId();
		this.setTagId(tagId);
		System.out.println("tagController.createTag(tagRequest) = " + tagId); */
	}

	@Test
	public void updateTag() {
		/*TagRequest tagRequest = new TagRequest();
		tagRequest.setTagMnemonic("search" + count++);
		tagRequest.setTagTypeCd(1);
		tagRequest.setCrtTs(new Timestamp(System.currentTimeMillis()));
		tagRequest.setModTs(new Timestamp(System.currentTimeMillis()));

		System.out.println("tagController.createTag(tagRequest) = "
				+ tagController.updateTag("d06a5bee-af0b-4db8-9632-8dad62c7a335", tagRequest));*/
	}

	@Test
	public void deleteTag() {
		/*
		 * TagResponse tagResponse = tagController.getTag(this.getTagId());
		 * System.out.println("tagId = " + tagResponse.getTagId());
		 */
	}

	public String getTagId() {
		return tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

}