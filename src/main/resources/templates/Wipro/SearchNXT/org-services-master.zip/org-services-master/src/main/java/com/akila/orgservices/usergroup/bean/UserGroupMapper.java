package com.akila.orgservices.usergroup.bean;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.akila.orgservices.entity.OrgUserGroup;

@Mapper(
    componentModel = "spring"
)
public interface UserGroupMapper {
  UserGroupMapper INSTANCE = Mappers.getMapper(UserGroupMapper.class);
  ;

  @Mappings({})
  UserGroupResponse orgUserGroupToUsergroupResponse(OrgUserGroup orgUserGroup);
  
  @Mappings({})
  List<UserGroupGetAllResponse> orgUserGroupToUsergroupResponseList(List<OrgUserGroup> orgUserGroup);

  @Mappings({})
  OrgUserGroup usergroupRequestToOrgUserGroup(UserGroupRequest usergroupRequest);
}
