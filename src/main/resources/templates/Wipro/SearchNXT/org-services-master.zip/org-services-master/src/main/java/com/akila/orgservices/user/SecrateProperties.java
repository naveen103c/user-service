package com.akila.orgservices.user;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "keyclock")
public class SecrateProperties 
{

	Map<String,String> secret = new HashMap<String,String>();
	
	Map<String,String> realm = new HashMap<String,String>();

	public Map<String, String> getSecret() {
		return secret;
	}

	public void setSecret(Map<String, String> secret) {
		this.secret = secret;
	}

	public Map<String, String> getRealm() {
		return realm;
	}

	public void setRealm(Map<String, String> realm) {
		this.realm = realm;
	}
	
}
