package com.akila.orgservices.tag.bean;

import com.akila.AkilaRequest;

import java.lang.Integer;
import java.lang.String;
import java.sql.Timestamp;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class TagRequest extends AkilaRequest {
  private String crtBy;

  private Timestamp crtTs;

  @NotEmpty(message = "{DESC.MANDATORY}")
  @Pattern(regexp = "[a-zA-Z][a-zA-Z0-9 ]*", message = "{DESC.FORMAT}")
  @Size(min = 2, max = 100, message = "{DESC.LENGTH}")
  private String description;

  private String modBy;

  private Timestamp modTs;

  @NotEmpty(message = "{TAG.NAME.MANDATORY}")
  @Pattern(regexp = "[a-zA-Z][a-zA-Z0-9 ]*", message = "{TAG.NAME.FORMAT}")
  @Size(min = 2, max = 20, message = "{TAG.NAME.LENGTH}")
  private String tagMnemonic;

  @NotNull(message = "{TAG.TYPE.NOTNULL}")
  @Min(1)
  private Integer tagTypeCd;

  private String tagId;

  public String getTagId() {
	return tagId;
  }

  public void setTagId(String tagId) {
	this.tagId = tagId;
  }  
  
  public void setCrtBy(String crtBy) {
    this.crtBy = crtBy;
  }

  public void setCrtTs(Timestamp crtTs) {
    this.crtTs = crtTs;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setModBy(String modBy) {
    this.modBy = modBy;
  }

  public void setModTs(Timestamp modTs) {
    this.modTs = modTs;
  }

  public void setTagMnemonic(String tagMnemonic) {
    this.tagMnemonic = tagMnemonic;
  }

  public void setTagTypeCd(Integer tagTypeCd) {
    this.tagTypeCd = tagTypeCd;
  }

  public String getCrtBy() {
    return crtBy;
  }

  public Timestamp getCrtTs() {
    return crtTs;
  }

  public String getDescription() {
    return description;
  }

  public String getModBy() {
    return modBy;
  }

  public Timestamp getModTs() {
    return modTs;
  }

  public String getTagMnemonic() {
    return tagMnemonic == null ? tagMnemonic : tagMnemonic.trim();
  }

  public Integer getTagTypeCd() {
    return tagTypeCd;
  }
}
