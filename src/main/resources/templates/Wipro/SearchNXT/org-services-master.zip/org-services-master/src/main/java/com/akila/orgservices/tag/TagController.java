package com.akila.orgservices.tag;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.orgservices.entity.OrgTag;
import com.akila.orgservices.skill.bean.ResponseStatus;
import com.akila.orgservices.tag.bean.TagRequest;
import com.akila.orgservices.tag.bean.TagResponse;
import com.akila.response.ResponseId;

@RestController
public class TagController extends AkilaController {
  @Autowired
  private TagService tagService;
  private int STATUS_FAILED = 0;
  private int STATUS_PASS = 1;
  
  @PostMapping(
      path = "/tags"
  )
  public ResponseEntity<ResponseStatus> createTag(@Valid @RequestBody TagRequest tagRequest) {
	  
		if (tagRequest.getTagMnemonic() != null && tagRequest.getTagMnemonic().trim().length() > 0) {
			List<OrgTag> mnemonicList = tagService.getByTagMnemonicByName(tagRequest.getTagMnemonic());
			if (mnemonicList.size()>0) {
				ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
						("Tag Mnemonic '" + tagRequest.getTagMnemonic() + "' Already Exist"), 102);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
		} else {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "", ("Tag Mnemonic can't be null or blank"),
					101);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		ResponseId id = tagService.createTag(tagRequest);
		ResponseStatus status = getResponseStatus(STATUS_PASS, id.getId(), "Tag successfully created", 0);
		
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
  }

  @PutMapping(
      path = "/tags/{id}"
  )
  public ResponseEntity<ResponseStatus> updateTag(@PathVariable String id,@Valid  @RequestBody TagRequest tagRequest) {
	  
		if (tagRequest.getTagMnemonic() != null && tagRequest.getTagMnemonic().trim().length() > 0) {
			List<OrgTag> mnemonicList = tagService.getByTagMnemonicAndId(tagRequest.getTagMnemonic(), tagRequest.getTagId());
			if (mnemonicList.size()>0) {
				ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
						("Tag Mnemonic '" + tagRequest.getTagMnemonic() + "' Already Exist"), 102);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
		} else {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "", ("Tag Mnemonic can't be null or blank"),
					101);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		ResponseId responseId = tagService.updateTag(id, tagRequest);
		ResponseStatus status = getResponseStatus(STATUS_PASS, responseId.getId(), "Tag successfully Updated", 0);
		
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);	  
  }

  @GetMapping(
      path = "/tags/{id}"
  )
  public TagResponse getTag(@PathVariable String id) {
    return tagService.getTag(id);
  }

  @GetMapping(
      path = "/tags"
  )
  public List<TagResponse> getAllTags(@RequestParam(required = false) Integer tagTypeCd) {
    return tagService.getAllTags(tagTypeCd);
  }

  @DeleteMapping(
      path = "/tags/{id}"
  )
  public ResponseId deleteTag(@PathVariable String id) {
    return tagService.deleteTag(id);
  }
  
  private ResponseStatus getResponseStatus(int statusCd, String id, String message, int errorCode) {
		ResponseStatus status = new ResponseStatus();
		status.setStatusCode(statusCd);
		status.setId(id);
		status.setMessage(message);
		status.setErrorCode(errorCode);
		return status;
	}
}
