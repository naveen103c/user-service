package com.akila.orgservices.community.bean;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.akila.orgservices.entity.OrgCommunity;
import com.akila.orgservices.entity.OrgCommunitySme;

@Mapper(
    componentModel = "spring"
)
public interface CommunityMapper {
  CommunityMapper INSTANCE = Mappers.getMapper(CommunityMapper.class);
  ;

  @Mappings({})
  CommunityResponse orgCommunitySmeToCommunityResponse(OrgCommunitySme orgCommunitySme);

  @Mappings({})
  List<CommunityResponse> orgCommunitySmeToCommunityResponseList(
      List<OrgCommunitySme> orgCommunitySme);
  
  @Mappings({})
  CommunityResponse orgCommunityToCommunityResponse(OrgCommunity orgCommunity);
  
  @Mappings({})
  List<CommunityResponse> orgCommunityListToCommunityResponseList(List<OrgCommunity> orgCommunityList);

  @Mappings({})
  OrgCommunitySme communityRequestToOrgCommunitySme(CommunityRequest communityRequest);
  

  
  @Mappings({
	  @Mapping(source = "orgCommunityTags", ignore = true, target = "orgCommunityTags"),
	  @Mapping(source = "orgCommunityAdmins", ignore = true, target = "orgCommunityAdmins"),
	  @Mapping(source = "orgCommunityUserGroups", ignore = true, target = "orgCommunityUserGroups")
  })
  OrgCommunity communityRequestToOrgCommunity(CommunityRequest communityRequest);
  
  
}
