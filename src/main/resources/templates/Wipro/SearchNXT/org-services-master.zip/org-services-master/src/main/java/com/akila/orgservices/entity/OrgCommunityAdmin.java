package com.akila.orgservices.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the org_community_smes database table.
 * 
 */
@Entity
@Table(name="org_community_admins")
@NamedQuery(name="OrgCommunityAdmin.findAll", query="SELECT o FROM OrgCommunityAdmin o")
public class OrgCommunityAdmin extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgCommunityAdminPK id;

	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="community_id",  insertable=false, updatable=false)
	private OrgCommunity orgCommunity;

	public OrgCommunityAdmin() {
	}

	public OrgCommunityAdminPK getId() {
		return this.id;
	}

	public void setId(OrgCommunityAdminPK id) {
		this.id = id;
	}

	public OrgCommunity getOrgCommunity() {
		return this.orgCommunity;
	}

	public void setOrgCommunity(OrgCommunity orgCommunity) {
		this.orgCommunity = orgCommunity;
	}

}