package com.akila.orgservices.user.bean;

import com.akila.orgservices.entity.OrgUser;
import com.akila.orgservices.entity.OrgUserToRolesLink;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface UserMapper {
  UserMapper INSTANCE = Mappers.getMapper(UserMapper.class);
  ;

  @Mappings({})
  UserResponse orgUserToRolesLinkToUserResponse(OrgUserToRolesLink orgUserToRolesLink);

  @Mappings({})
  List<UserResponse> orgUserToRolesLinkToUserResponseList(
      List<OrgUserToRolesLink> orgUserToRolesLink);

  @Mappings({})
  OrgUserToRolesLink userRequestToOrgUserToRolesLink(UserRequest userRequest);
  
  @Mappings({})
  OrgUser userRequestToOrgUser(UserRequest request);
  
}
