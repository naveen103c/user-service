package com.akila.orgservices.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the org_bulk_user_upload_details database table.
 * 
 */
@Entity
@Table(name="org_bulk_user_upload_details")
@NamedQuery(name="OrgBulkUserDetails.findAll", query="SELECT o FROM OrgBulkUserDetails o")
public class OrgBulkUserDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="upload_row_id")
	private UUID uploadRowId;
	
	@Column(name="upload_id")
	private UUID uploadId;

	@Column(name="usr_first_nm")
	private String usrFirstNm;
	
	@Column(name="user_last_nm")
	private String usrLastNm;
	
	@Column(name="usr_email")
	private String usrEmail;
	
	@Column(name="usr_groups")
	private String usrGroups;

	@Column(name="usr_roles")
	private String usrRoles;

	@Column(name="status")
	private Integer status;

	@Column(name="mod_ts")
	private Timestamp modTs;

	public OrgBulkUserDetails() {
	}

	public UUID getUploadRowId() {
		return uploadRowId;
	}

	public void setUploadRowId(UUID uploadRowId) {
		this.uploadRowId = uploadRowId;
	}

	public UUID getUploadId() {
		return uploadId;
	}

	public void setUploadId(UUID uploadId) {
		this.uploadId = uploadId;
	}

	public String getUsrFirstNm() {
		return usrFirstNm;
	}

	public void setUsrFirstNm(String usrFirstNm) {
		this.usrFirstNm = usrFirstNm;
	}

	public String getUsrLastNm() {
		return usrLastNm;
	}

	public void setUsrLastNm(String usrLastNm) {
		this.usrLastNm = usrLastNm;
	}

	public String getUsrEmail() {
		return usrEmail;
	}

	public void setUsrEmail(String usrEmail) {
		this.usrEmail = usrEmail;
	}

	public String getUsrGroups() {
		return usrGroups;
	}

	public void setUsrGroups(String usrGroups) {
		this.usrGroups = usrGroups;
	}

	public String getUsrRoles() {
		return usrRoles;
	}

	public void setUsrRoles(String usrRoles) {
		this.usrRoles = usrRoles;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Timestamp getModTs() {
		return modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

}

