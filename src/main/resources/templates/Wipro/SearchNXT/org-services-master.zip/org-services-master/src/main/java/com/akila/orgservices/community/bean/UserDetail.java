package com.akila.orgservices.community.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class UserDetail implements Serializable {

	private static final long serialVersionUID = 1L;
	private String userId;
	private String userEmail;
	private String userFirstNm;
	private String userLastNm;
	@JsonIgnore
	private boolean active;
	

	public UserDetail(String userId, String userEmail, String userFirstNm, String userLastNm, boolean active) {
		super();
		this.userId = userId;
		this.userEmail = userEmail;
		this.userFirstNm = userFirstNm;
		this.userLastNm = userLastNm;
		this.active = active;
	}
	public UserDetail() {
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserFirstNm() {
		return userFirstNm;
	}
	public void setUserFirstNm(String userFirstNm) {
		this.userFirstNm = userFirstNm;
	}
	public String getUserLastNm() {
		return userLastNm;
	}
	public void setUserLastNm(String userLastNm) {
		this.userLastNm = userLastNm;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}

}
