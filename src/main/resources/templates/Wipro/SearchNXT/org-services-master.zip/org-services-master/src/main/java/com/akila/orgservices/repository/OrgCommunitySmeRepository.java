package com.akila.orgservices.repository;

import com.akila.orgservices.entity.OrgCommunitySme;
import com.akila.orgservices.entity.OrgCommunitySmePK;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgCommunitySmeRepository extends JpaRepository<OrgCommunitySme, OrgCommunitySmePK> {
	
	List<OrgCommunitySme> findByIdUserId(String userId);
}
