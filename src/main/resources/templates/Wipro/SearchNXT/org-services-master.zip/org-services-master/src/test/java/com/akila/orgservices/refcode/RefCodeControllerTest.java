package com.akila.orgservices.refcode;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import com.akila.orgservices.OrgServicesApplication;

@SpringBootTest(classes = OrgServicesApplication.class)
@TestPropertySource(locations="classpath:application-test.properties")
public class RefCodeControllerTest {

	@Autowired
	private RefcodeController refcodeController;

	@Test
	public void getAllRefCodesTest() {
		refcodeController.getAllRefCodes();
		
	}

}