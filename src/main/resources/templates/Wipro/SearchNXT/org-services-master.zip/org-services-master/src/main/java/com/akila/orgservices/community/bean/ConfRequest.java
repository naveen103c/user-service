package com.akila.orgservices.community.bean;

import java.util.List;

import com.akila.AkilaRequest;

public class ConfRequest extends AkilaRequest {

	String confName;
	
	Integer sourceExtractionTypeCd;
	
	Integer sourceTypeCd;
	
	List<String> sourceAllowedUserGroupList;
	
	String sourceDescription;
	
	List<String> sourceTagIdList;
	
	Schedule sourceScheduleJson;
	
	List<SourceTypeField> sourceTypeFields;
	
	List<ConfFilter> filter;

	public String getConfName() {
		return confName;
	}

	public void setConfName(String confName) {
		this.confName = confName;
	}

	public Integer getSourceExtractionTypeCd() {
		return sourceExtractionTypeCd;
	}

	public void setSourceExtractionTypeCd(Integer sourceExtractionTypeCd) {
		this.sourceExtractionTypeCd = sourceExtractionTypeCd;
	}

	public Integer getSourceTypeCd() {
		return sourceTypeCd;
	}

	public void setSourceTypeCd(Integer sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}

	public List<String> getSourceAllowedUserGroupList() {
		return sourceAllowedUserGroupList;
	}

	public void setSourceAllowedUserGroupList(List<String> sourceAllowedUserGroupList) {
		this.sourceAllowedUserGroupList = sourceAllowedUserGroupList;
	}

	public String getSourceDescription() {
		return sourceDescription;
	}

	public void setSourceDescription(String sourceDescription) {
		this.sourceDescription = sourceDescription;
	}

	public List<String> getSourceTagIdList() {
		return sourceTagIdList;
	}

	public void setSourceTagIdList(List<String> sourceTagIdList) {
		this.sourceTagIdList = sourceTagIdList;
	}

	public Schedule getSourceScheduleJson() {
		return sourceScheduleJson;
	}

	public void setSourceScheduleJson(Schedule sourceScheduleJson) {
		this.sourceScheduleJson = sourceScheduleJson;
	}

	public List<SourceTypeField> getSourceTypeFields() {
		return sourceTypeFields;
	}

	public void setSourceTypeFields(List<SourceTypeField> sourceTypeFields) {
		this.sourceTypeFields = sourceTypeFields;
	}

	public List<ConfFilter> getFilter() {
		return filter;
	}

	public void setFilter(List<ConfFilter> filter) {
		this.filter = filter;
	}

}
