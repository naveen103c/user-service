package com.akila.workflowservices.workflow.bean;

import com.akila.workflowservices.entity.OrgContentMetadata;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface WorkflowMapper {
  WorkflowMapper INSTANCE = Mappers.getMapper(WorkflowMapper.class);
  ;

  @Mappings({})
  WorkflowResponse orgContentMetadataToWorkflowResponse(OrgContentMetadata orgContentMetadata);

  @Mappings({})
  List<WorkflowResponse> orgContentMetadataToWorkflowResponseList(
      List<OrgContentMetadata> orgContentMetadata);

  @Mappings({})
  OrgContentMetadata workflowRequestToOrgContentMetadata(WorkflowRequest workflowRequest);
}
