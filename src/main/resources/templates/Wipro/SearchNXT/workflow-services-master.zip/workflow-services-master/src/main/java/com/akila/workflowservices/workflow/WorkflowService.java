package com.akila.workflowservices.workflow;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaConstants.ContentFormatType;
import com.akila.AkilaConstants.ContentType;
import com.akila.AkilaConstants.StorageStreamType;
import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.commons.storage.bean.StorageRequest;
import com.akila.commons.storage.bean.StorageResponse;
import com.akila.commons.storage.service.StorageFactory;
import com.akila.response.ResponseId;
import com.akila.workflowservices.entity.OrgContentMetadata;
import com.akila.workflowservices.entity.OrgUserContentMetadata;
import com.akila.workflowservices.repository.OrgContentMetadataRepository;
import com.akila.workflowservices.workflow.bean.WorkflowItemRequest;
import com.akila.workflowservices.workflow.bean.WorkflowRequest;
import com.akila.workflowservices.workflow.bean.WorkflowResponse;
import com.amazonaws.util.IOUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class WorkflowService extends AkilaService {

  @PersistenceContext
  private EntityManager entityManager;
  
  @Autowired
  private OrgContentMetadataRepository orgContentMetadataRepository;

  @Value("${content.type.query}")
  private Integer contentType;
  
  @Value("${followup.action.status.cd}")
  private Integer followupActionStatusCd;
  
  @Value("${action.status.code}")
  private List<Integer> actionStatusCd;
  
  @Value("${action.status.code.open}")
  private List<Integer> statusCdOpen;
  
  @Value("${action.status.code.close}")
  private List<Integer> statusCdClose;
  
  @Autowired
  private AkilaRestTemplate akilaRestTemplate;
  
  @Autowired
  @Qualifier("loadBalanced")
  private RestTemplate loadBalancedRestTemplate;
  
  @Value("${platform.service.url}")
  private String platformServiceURL;
  
  @Value("${ask.content.length}")
  private int askContentLength;
  
  private static Logger log = LogManager.getLogger(WorkflowService.class);
  

  @Autowired
  private StorageFactory s3StorageService;
	
  public ResponseId create(WorkflowRequest workflowRequest) {
    //OrgContentMetadata orgContentMetadata = workflowMapper.workflowRequestToOrgContentMetadata(workflowRequest);
     //   orgContentMetadata = orgContentMetadataRepository.save(orgContentMetadata);
        return null;
  }

  public ResponseId trigger(WorkflowRequest workflowRequest) {
    return null;
  }

  public List<WorkflowResponse> query(@RequestParam List<String> filterBy) 
  {
	  String sql = "select ocm from OrgContentMetadata ocm inner join OrgCommunitySme ocs on ocm.communityId = ocs.id.communityId where ocs.id.userId = :userId"
	  		+ " and not exists (select contentId from OrgContentRelationship ocr where ocm.contentId = ocr.contentId)";
	  
	  sql += getFilterByQuery(filterBy, "ocm");
	  String userId = getUserId();
	  Query query = entityManager.createQuery(sql, OrgContentMetadata.class);
	  query.setParameter("userId", userId);
	  List<OrgContentMetadata> list = query.getResultList();
	  
	  sql = "select ocma from OrgContentMetadata ocma where ocma.createdByUserId = :userId and contentTypeCd not in (4,5,6) ";
	//  sql += getFilterByQuery(filterBy, "ocma");
	  query = entityManager.createQuery(sql, OrgContentMetadata.class);
	  query.setParameter("userId", userId);
	  List<OrgContentMetadata> ownerList = query.getResultList();
	  list.addAll(ownerList);
	  Set<OrgContentMetadata> uniqueData = new HashSet<OrgContentMetadata>(list);
	  
	  sql = "select o from OrgUserContentMetadata o where o.id.userId = :userId ";
	  query = entityManager.createQuery(sql, OrgUserContentMetadata.class);
	  query.setParameter("userId", userId);
	  List<OrgUserContentMetadata> userContentDataList = query.getResultList();
	  return workFlowResponseMapper(new ArrayList<OrgContentMetadata>(uniqueData),userContentDataList);
  }
  
 
public List<WorkflowResponse> getItems(WorkflowItemRequest workflowItemRequest) 
  {
	 return getFilterItems(workflowItemRequest, getUserId());
  }

private List<WorkflowResponse> getFilterItems(WorkflowItemRequest workflowItemRequest, String userId) {
	  
	List<WorkflowResponse> workflowResponses = new ArrayList<>();
	Timestamp startTime = workflowItemRequest.getModifiedDateFrom() != null && !workflowItemRequest.getModifiedDateFrom().isEmpty() ?
			Timestamp.valueOf(workflowItemRequest.getModifiedDateFrom() + " 00:00:00") : null;
	Timestamp endTime = workflowItemRequest.getModifiedDateTo() != null && !workflowItemRequest.getModifiedDateTo().isEmpty() ?
			Timestamp.valueOf(workflowItemRequest.getModifiedDateTo() + " 23:59:59") : null;
	String actionStatus = workflowItemRequest.getStatus()!=null && !workflowItemRequest.getStatus().isEmpty() ? workflowItemRequest.getStatus() : null;
	List<Integer> filterActionStatusCd = null;
	boolean flag = true;
	if(actionStatus != null ) {
		filterActionStatusCd=  actionStatus.equalsIgnoreCase("Open") ? statusCdOpen : statusCdClose;
		flag = actionStatus.equalsIgnoreCase("Open") ? true : false ;
	}
	List<String> communities = workflowItemRequest.getCommunities()!=null && workflowItemRequest.getCommunities().size()>0 ? 
			workflowItemRequest.getCommunities() : null;
	boolean starred = workflowItemRequest.isStarred();
	boolean archived = workflowItemRequest.isArchived();
	List<OrgContentMetadata> contentMetadatas = orgContentMetadataRepository.getCommunitiesDataForUserAction(userId, contentType, filterActionStatusCd != null ? 
			filterActionStatusCd : actionStatusCd, startTime, endTime, communities);
	List<OrgContentMetadata> contentMetadatas2 = orgContentMetadataRepository.getUserDataForUserAction(userId, contentType, flag ? followupActionStatusCd : -1,
			startTime, endTime, communities);
	
	String orgId = "";
	try {
		orgId = getS3BucketName();
	} catch (JsonMappingException e) {
		log.error("WorkflowService:getFilterItems - JsonMappingException : " + e.getMessage());
	} catch (JsonProcessingException e) {
		log.error("WorkflowService:getFilterItems - JsonProcessingException : " + e.getMessage());
	} catch (Exception e) {
		log.error("WorkflowService:getFilterItems - Exception :  " + e.getMessage());
	 }
	workflowResponses = getUniqueData(contentMetadatas, contentMetadatas2, userId, orgId);
	return workflowResponses;
	}
 
private List<WorkflowResponse> getUniqueData(List<OrgContentMetadata> userContentDataList, List<OrgContentMetadata> ownerList, String userId, String orgId) {
	userContentDataList.addAll(ownerList);
	Set<OrgContentMetadata> uniqueData = new HashSet<OrgContentMetadata>(userContentDataList);
	List<WorkflowResponse> workflowResponses = itemWorkFlowResponseMapper(new ArrayList<OrgContentMetadata>(uniqueData));
		workflowResponses.forEach(workflowResponse -> {
			StorageRequest storageRequest = null;
			try {
				storageRequest = getStorageRequest(workflowResponse, ContentType.QUERY.getValue());
				storageRequest.setUserId(userId);
				storageRequest.setOrgId(orgId);
				storageRequest.setContentMaxLength(askContentLength);
				storageRequest.setModTs(workflowResponse.getModTs());
				StorageResponse storageResponse = s3StorageService.getContent(storageRequest);
				workflowResponse.setContent(new String(storageResponse.getContent()));
			} catch (JsonMappingException e) {
				log.error("WorkflowService:getUniqueData - JsonMappingException : " + e.getMessage());
			} catch (JsonProcessingException e) {
				log.error("WorkflowService:getUniqueData - JsonProcessingException : " + e.getMessage());
			} catch (Exception e) {
				log.error("WorkflowService:getUniqueData - Exception :  " + e.getMessage());
			 }
		});
	 workflowResponses.sort(Comparator.comparing(WorkflowResponse::getCrtTs).reversed());
	return workflowResponses;
 }
  
private String getFilterByQuery(List<String> filterBy, String alias)
  {
	  String actionStatusCdSql = "";
	  if(filterBy == null || filterBy.size() == 0)
	  {
		  actionStatusCdSql += "and "+alias+".actionStatusCd not in (0,2,4,6)";
	  }
	  else
	  {
		  actionStatusCdSql += " and "+alias+".actionStatusCd in (";
		  for(String filter : filterBy)
		  {
			  actionStatusCdSql += filter + ",";
		  }
		  actionStatusCdSql = actionStatusCdSql.substring(0, actionStatusCdSql.length() - 1) + ")";
	  }
	  return actionStatusCdSql;
  }

  private List<WorkflowResponse>  workFlowResponseMapper(List<OrgContentMetadata> contentMetaDataList,List<OrgUserContentMetadata> userContentDataList){
	  
	  List<WorkflowResponse> responseList = new ArrayList<WorkflowResponse>();
	  
	  for(OrgContentMetadata contentMetadata : contentMetaDataList) {
		  WorkflowResponse response = new WorkflowResponse();
		  response.setContentId(contentMetadata.getContentId());
		  response.setAuthor(getValue(contentMetadata.getAuthor()));
		  response.setContentStatusCd(getValue(contentMetadata.getContentStatusCd()));
		  response.setContentTypeCd(getValue(contentMetadata.getContentTypeCd()));
		  response.setCreatedByUserId(getValue(contentMetadata.getCreatedByUserId()));
		  response.setCrtTs(contentMetadata.getCrtTs());
		  response.setActionStatusCd(getValue(contentMetadata.getActionStatusCd()));
		  response.setCommunityId(getValue(contentMetadata.getCommunityId()));
		  response.setIsPrivate(contentMetadata.getIsPrivate());
		  response.setKeyValList(getValue(contentMetadata.getKeyValList()));
		  response.setMediaCd(getValue((contentMetadata.getMediaCd())));
		  response.setModTs(contentMetadata.getModTs());
		  response.setTagList(getValue(contentMetadata.getTagList()));
		  response.setPublishedTs(contentMetadata.getPublishedTs());
		  response.setTitle(getValue(contentMetadata.getTitle()));
		  response.setVersionNum(getValue(contentMetadata.getVersionNum()));
		  for(OrgUserContentMetadata userContentMetadata : userContentDataList) {
			  if(userContentMetadata.getId().getContentId().equals(contentMetadata.getContentId())) {
				  response.setIsFavourite(userContentMetadata.getIsFavorite());
			  }
		  }
		  responseList.add(response);
	  }
	  
	  return responseList;
  }
  
  private List<WorkflowResponse>  itemWorkFlowResponseMapper(List<OrgContentMetadata> contentMetaDataList){
	  
		List<WorkflowResponse> responseList = new ArrayList<WorkflowResponse>();
		if (contentMetaDataList != null && !contentMetaDataList.isEmpty()) {
			for (OrgContentMetadata contentMetadata : contentMetaDataList) {
				WorkflowResponse response = new WorkflowResponse();
				response.setContentId(contentMetadata.getContentId());
				response.setAuthor(getValue(contentMetadata.getAuthor()));
				response.setContentStatusCd(getValue(contentMetadata.getContentStatusCd()));
				response.setContentTypeCd(getValue(contentMetadata.getContentTypeCd()));
				response.setCreatedByUserId(getValue(contentMetadata.getCreatedByUserId()));
				response.setCrtTs(contentMetadata.getCrtTs());
				response.setActionStatusCd(getValue(contentMetadata.getActionStatusCd()));
				response.setCommunityId(getValue(contentMetadata.getCommunityId()));
				response.setIsPrivate(contentMetadata.getIsPrivate());
				response.setKeyValList(getValue(contentMetadata.getKeyValList()));
				response.setMediaCd(getValue((contentMetadata.getMediaCd())));
				response.setModTs(contentMetadata.getModTs());
				response.setTagList(getValue(contentMetadata.getTagList()));
				response.setPublishedTs(contentMetadata.getPublishedTs());
				response.setTitle(getValue(contentMetadata.getTitle()));
				response.setVersionNum(getValue(contentMetadata.getVersionNum()));
				response.setIsArchived(false);
				response.setIsFavourite(false);
				responseList.add(response);
			}
		}
		return responseList;
 }
  
  
  @Transactional
  public void update(String id, @RequestParam Integer actionStatusCd) 
  {
	  orgContentMetadataRepository.updateStatus(id, actionStatusCd);
  }

  public ResponseId next(String id, WorkflowRequest workflowRequest) {
    return null;
  }

  public ResponseId back(String id, WorkflowRequest workflowRequest) {
    return null;
  }

  public String getValue(String str) {
		if (str != null) {
			return str;
		} else {
			return "";
		}
  }

  public Integer getValue(Integer itr) {
		if (itr != null) {
			return itr;
		} else {
			return 0;
		}
  }
  
	private StorageRequest getStorageRequest(WorkflowResponse content, String contentType)
			throws JsonMappingException, JsonProcessingException, Exception {
		StorageRequest request = new StorageRequest();
		request.setInputStreamType(StorageStreamType.STRING.name());
		request.setFormatType(ContentFormatType.ORIGINAL.getValue());
		request.setContentType(contentType);
		request.setContentId(content.getContentId());
		return request;
	}
	
	private String getS3BucketName() throws JsonMappingException, JsonProcessingException, Exception {
		HttpEntity<String> entity = new HttpEntity<String>("Org-Details", super.getRequestHeader());
		ResponseEntity<String> response = akilaRestTemplate.exchange(loadBalancedRestTemplate,
				platformServiceURL + "/orgs/" + getOrgId(), HttpMethod.GET, entity, String.class);
		String responseBody = response.getBody();
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode node = objectMapper.readTree(responseBody);
		String ssStorageFolder = node.get("storageFolderNm").asText();
		log.info("ssStorageFolder : " + ssStorageFolder + ". OrgId : " + getOrgId());
		return ssStorageFolder;
	}
}
