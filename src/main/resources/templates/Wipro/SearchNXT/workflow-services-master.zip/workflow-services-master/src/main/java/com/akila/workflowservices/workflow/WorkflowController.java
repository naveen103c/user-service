package com.akila.workflowservices.workflow;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.response.ResponseId;
import com.akila.workflowservices.workflow.bean.WorkflowItemRequest;
import com.akila.workflowservices.workflow.bean.WorkflowRequest;
import com.akila.workflowservices.workflow.bean.WorkflowResponse;

@RestController
public class WorkflowController extends AkilaController {
  @Autowired
  private WorkflowService workflowService;

  @PostMapping(
      path = "/workflows/create"
  )
  public ResponseId create(@RequestBody WorkflowRequest workflowRequest) {
    return workflowService.create(workflowRequest);
  }

  @PostMapping(
      path = "/workflows/trigger"
  )
  public ResponseId trigger(@RequestBody WorkflowRequest workflowRequest) {
    return workflowService.trigger(workflowRequest);
  }

  @GetMapping(
      path = "/workflows"
  )
  public List<WorkflowResponse> query(@RequestParam(required = false) List<String> filterby) 
  {
	  return workflowService.query(filterby);
  }

  @PutMapping(path = "/workflows/{id}/update")
  public void update(@PathVariable String id, @RequestParam Integer actionStatusCd) 
  {
    	workflowService.update(id, actionStatusCd);
  }

  @PutMapping(
      path = "/workflows/{id}/next"
  )
  public ResponseId next(@PathVariable String id, @RequestBody WorkflowRequest workflowRequest) {
    return workflowService.next(id, workflowRequest);
  }

  @PutMapping(
      path = "/workflows/{id}/back"
  )
  public ResponseId back(@PathVariable String id, @RequestBody WorkflowRequest workflowRequest) {
    return workflowService.back(id, workflowRequest);
  }
  
  @PostMapping(
	      path = "/workflows"
	  )
	  public List<WorkflowResponse> getItems(@RequestBody WorkflowItemRequest workflowItemRequest) 
	  {
		  return workflowService.getItems(workflowItemRequest);
	  }
}
