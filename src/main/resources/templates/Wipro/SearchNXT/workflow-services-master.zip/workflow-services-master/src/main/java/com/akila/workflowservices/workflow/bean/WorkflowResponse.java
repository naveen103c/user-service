package com.akila.workflowservices.workflow.bean;

import com.akila.AkilaResponse;
import java.lang.Boolean;
import java.lang.Integer;
import java.lang.String;
import java.sql.Timestamp;

public class WorkflowResponse extends AkilaResponse {

	private String contentId;

	private String author;

	private String communityId;

	private Integer contentStatusCd;

	private Integer actionStatusCd;

	private Integer contentTypeCd;

	private String createdByUserId;

	private Timestamp crtTs;

	private Boolean isPrivate;

	private String keyValList;

	private Integer mediaCd;

	private Timestamp modTs;

	private Timestamp publishedTs;

	private String tagList;

	private String title;

	private Integer versionNum;

	private Boolean isFavourite;
	
	private Boolean isArchived;
	
	private String content;

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getCommunityId() {
		return communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public Integer getContentStatusCd() {
		return contentStatusCd;
	}

	public void setContentStatusCd(Integer contentStatusCd) {
		this.contentStatusCd = contentStatusCd;
	}

	public Integer getActionStatusCd() {
		return actionStatusCd;
	}

	public void setActionStatusCd(Integer actionStatusCd) {
		this.actionStatusCd = actionStatusCd;
	}

	public Integer getContentTypeCd() {
		return contentTypeCd;
	}

	public void setContentTypeCd(Integer contentTypeCd) {
		this.contentTypeCd = contentTypeCd;
	}

	public String getCreatedByUserId() {
		return createdByUserId;
	}

	public void setCreatedByUserId(String createdByUserId) {
		this.createdByUserId = createdByUserId;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public Boolean getIsPrivate() {
		return isPrivate;
	}

	public void setIsPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}

	public String getKeyValList() {
		return keyValList;
	}

	public void setKeyValList(String keyValList) {
		this.keyValList = keyValList;
	}

	public Integer getMediaCd() {
		return mediaCd;
	}

	public void setMediaCd(Integer mediaCd) {
		this.mediaCd = mediaCd;
	}

	public Timestamp getModTs() {
		return modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public Timestamp getPublishedTs() {
		return publishedTs;
	}

	public void setPublishedTs(Timestamp publishedTs) {
		this.publishedTs = publishedTs;
	}

	public String getTagList() {
		return tagList;
	}

	public void setTagList(String tagList) {
		this.tagList = tagList;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(Integer versionNum) {
		this.versionNum = versionNum;
	}

	public Boolean getIsFavourite() {
		return isFavourite;
	}

	public void setIsFavourite(Boolean isFavourite) {
		this.isFavourite = isFavourite;
	}

	public Boolean getIsArchived() {
		return isArchived;
	}

	public void setIsArchived(Boolean isArchived) {
		this.isArchived = isArchived;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
}
