package com.akila.workflowservices.workflow.bean;

import com.akila.AkilaRequest;
import java.lang.Boolean;
import java.lang.Integer;
import java.lang.String;
import java.sql.Timestamp;

public class WorkflowRequest extends AkilaRequest {
  private String author;

  private Integer contentStatusCd;

  private Integer contentTypeCd;

  private String createdByUserId;

  private Timestamp crtTs;

  private String fileHash;

  private String fileNm;

  private Boolean isPrivate;

  private String jobId;

  private String keyValList;

  private Integer mediaCd;

  private Timestamp modTs;

  private Timestamp publishedTs;

  private String tagList;

  private String title;

  private Integer versionNum;

  public void setAuthor(String author) {
    this.author = author;
  }

  public void setContentStatusCd(Integer contentStatusCd) {
    this.contentStatusCd = contentStatusCd;
  }

  public void setContentTypeCd(Integer contentTypeCd) {
    this.contentTypeCd = contentTypeCd;
  }

  public void setCreatedByUserId(String createdByUserId) {
    this.createdByUserId = createdByUserId;
  }

  public void setCrtTs(Timestamp crtTs) {
    this.crtTs = crtTs;
  }

  public void setFileHash(String fileHash) {
    this.fileHash = fileHash;
  }

  public void setFileNm(String fileNm) {
    this.fileNm = fileNm;
  }

  public void setIsPrivate(Boolean isPrivate) {
    this.isPrivate = isPrivate;
  }

  public void setJobId(String jobId) {
    this.jobId = jobId;
  }

  public void setKeyValList(String keyValList) {
    this.keyValList = keyValList;
  }

  public void setMediaCd(Integer mediaCd) {
    this.mediaCd = mediaCd;
  }

  public void setModTs(Timestamp modTs) {
    this.modTs = modTs;
  }

  public void setPublishedTs(Timestamp publishedTs) {
    this.publishedTs = publishedTs;
  }

  public void setTagList(String tagList) {
    this.tagList = tagList;
  }

  public void setTitle(String title) {
    this.title = title;
  }

  public void setVersionNum(Integer versionNum) {
    this.versionNum = versionNum;
  }

  public String getAuthor() {
    return author;
  }

  public Integer getContentStatusCd() {
    return contentStatusCd;
  }

  public Integer getContentTypeCd() {
    return contentTypeCd;
  }

  public String getCreatedByUserId() {
    return createdByUserId;
  }

  public Timestamp getCrtTs() {
    return crtTs;
  }

  public String getFileHash() {
    return fileHash;
  }

  public String getFileNm() {
    return fileNm;
  }

  public Boolean getIsPrivate() {
    return isPrivate;
  }

  public String getJobId() {
    return jobId;
  }

  public String getKeyValList() {
    return keyValList;
  }

  public Integer getMediaCd() {
    return mediaCd;
  }

  public Timestamp getModTs() {
    return modTs;
  }

  public Timestamp getPublishedTs() {
    return publishedTs;
  }

  public String getTagList() {
    return tagList;
  }

  public String getTitle() {
    return title;
  }

  public Integer getVersionNum() {
    return versionNum;
  }
}
