package com.akila.workflowservices.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.workflowservices.entity.OrgContentMetadata;

@Repository
public interface OrgContentMetadataRepository extends JpaRepository<OrgContentMetadata, String> 
{
	@Modifying
	@Query("update OrgContentMetadata set actionStatusCd = :statusCd where contentId = :contentId")
	public void updateStatus(String contentId, Integer statusCd);
	
	@Query("select ocm from OrgContentMetadata ocm inner join OrgCommunitySme ocs on ocm.communityId = ocs.id.communityId where ocs.id.userId = :userId"
		      + " and not exists (select contentId from OrgContentRelationship ocr where ocm.contentId = ocr.contentId) and ocm.actionStatusCd in (:actionStatusCd)"
		      + " and ocm.contentTypeCd = :contentType and (cast(:startTime as timestamp) is null or cast(:endTime as timestamp) is null or ocm.crtTs between :startTime and :endTime)"
		      + " and (COALESCE(:communities, NULL) is null or ocm.communityId in (:communities))")
	public List<OrgContentMetadata> getCommunitiesDataForUserAction(String userId, Integer contentType, List<Integer> actionStatusCd,
			   Timestamp startTime, Timestamp endTime, List<String> communities);
	
	@Query("select ocm from OrgContentMetadata ocm where ocm.createdByUserId = :userId and ocm.contentTypeCd = :contentType and"
			+ " ocm.actionStatusCd = :actionStatusCd and (cast(:startTime as timestamp) is null or cast(:endTime as timestamp) is null or ocm.crtTs between :startTime and :endTime)"
			+ " and (COALESCE(:communities, NULL) is null or ocm.communityId in (:communities))")
	public List<OrgContentMetadata> getUserDataForUserAction(String userId, Integer contentType, Integer actionStatusCd,
			   Timestamp startTime, Timestamp endTime, List<String> communities);
	
	
}
