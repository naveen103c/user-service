package com.akila.queryservices.query;

import java.io.IOException;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.akila.AkilaController;
import com.akila.queryservices.query.bean.QueryItemRequest;
import com.akila.queryservices.query.bean.QueryRequest;
import com.akila.queryservices.query.bean.QueryResponse;
import com.akila.queryservices.query.bean.SimilarQueriesData;
import com.akila.queryservices.query.bean.SimilarQueriesResponse;
import com.akila.response.ResponseId;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

@RestController
public class QueryController extends AkilaController {
  @Autowired
  private QueryService queryService;

  @GetMapping(
      path = "/queries/{id}"
  )
  public QueryResponse getQuery(@PathVariable String id) {
    return queryService.getQuery(id);
  }

  @GetMapping(
      path = "/queries"
  )
  public List<QueryResponse> getAllQueries(@RequestParam(required = false) Integer actionStatusCd) {
    return queryService.getAllQueries(actionStatusCd);
  }

  @PostMapping(
      path = "/queries"
  )
  public ResponseId createQuery(@Valid @RequestBody QueryRequest queryRequest) {
    return queryService.createQuery(queryRequest);
  }

  @PutMapping(
      path = "/queries/{id}"
  )
  public ResponseId updateQuery(@PathVariable String id,@Valid @RequestBody QueryRequest queryRequest) {
    return queryService.updateQuery(id, queryRequest);
  }

  @DeleteMapping(
      path = "/queries/{id}"
  )
  public ResponseId deleteQuery(@PathVariable String id) {
    return queryService.deleteQuery(id);
  }
  
  @PostMapping(
	      path = "/queries/filter"
	  )
	  public List<QueryResponse> queryFilter(@RequestBody QueryItemRequest queryItemRequest) 
	  {
		  return queryService.queryFilter(queryItemRequest);
	  }
  
  @GetMapping(
		  path = "/queries/similar-queries"
	)
	public SimilarQueriesData similarQueries(@RequestParam String queryText) {
		return queryService.similarQueries(queryText);
	}  
  
  
}
