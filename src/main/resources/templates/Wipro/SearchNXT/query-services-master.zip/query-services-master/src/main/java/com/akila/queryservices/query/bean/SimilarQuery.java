package com.akila.queryservices.query.bean;

import java.io.Serializable;

public class SimilarQuery implements Serializable {
	private static final long serialVersionUID = 1L;

	private String contentId;
	private String pageLink;
	private String title;
	private String summary;
	private String modifiedDate;
	private String author;
	private int interactionCnt;

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getPageLink() {
		return pageLink;
	}

	public void setPageLink(String pageLink) {
		this.pageLink = pageLink;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getInteractionCnt() {
		return interactionCnt;
	}

	public void setInteractionCnt(int i) {
		this.interactionCnt = i;
	}

	@Override
	public String toString() {
		return "SimilarQuery [contentId=" + contentId + ", pageLink=" + pageLink + ", title=" + title + ", summary="
				+ summary + ", modifiedDate=" + modifiedDate + ", author=" + author + ", interactionCnt="
				+ interactionCnt + "]";
	}

}
