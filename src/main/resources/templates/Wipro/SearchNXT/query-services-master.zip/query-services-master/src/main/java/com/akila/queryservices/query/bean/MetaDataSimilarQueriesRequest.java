package com.akila.queryservices.query.bean;

import java.io.Serializable;
import java.util.List;

public class MetaDataSimilarQueriesRequest implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<String> confId;
	private String orgId;
	private String queryText;

	public List<String> getConfId() {
		return confId;
	}

	public void setConfId(List<String> confId) {
		this.confId = confId;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getQueryText() {
		return queryText;
	}

	public void setQueryText(String queryText) {
		this.queryText = queryText;
	}

	@Override
	public String toString() {
		return "MetaDataSimilarQueriesRequest [confId=" + confId + ", orgId=" + orgId + ", queryText=" + queryText
				+ "]";
	}

}
