package com.akila.queryservices.chatsession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;

@RestController
public class ChatSessionController extends AkilaController {
  @Autowired
  private ChatSessionService chatsessionService;

  @GetMapping(
      path = "/chat-sessions"
  )
  public String query(@RequestParam String query, @RequestParam String[] contentIds) {
    return chatsessionService.query(query, contentIds);
  }
}
