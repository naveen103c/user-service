package com.akila.queryservices.chatsession.bean;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface ChatSessionMapper {
  ChatSessionMapper INSTANCE = Mappers.getMapper(ChatSessionMapper.class);
  ;
}
