package com.akila.queryservices.query.bean;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface QueryMapper {
  QueryMapper INSTANCE = Mappers.getMapper(QueryMapper.class);
  ;
}
