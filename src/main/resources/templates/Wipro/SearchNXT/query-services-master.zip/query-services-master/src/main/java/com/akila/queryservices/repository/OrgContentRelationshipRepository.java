package com.akila.queryservices.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.queryservices.entity.OrgContentRelationship;


@Repository
public interface OrgContentRelationshipRepository extends JpaRepository<OrgContentRelationship, String> 
{
	OrgContentRelationship findByContentId(String contentId);
	
	long countByRootContentId(String rootContentId);
	
	List<OrgContentRelationship> findByRootContentIdIn(List<String> rootContentIdList);
}
