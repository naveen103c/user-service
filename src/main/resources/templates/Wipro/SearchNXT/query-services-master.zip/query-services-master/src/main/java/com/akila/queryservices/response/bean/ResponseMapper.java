package com.akila.queryservices.response.bean;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface ResponseMapper {
  ResponseMapper INSTANCE = Mappers.getMapper(ResponseMapper.class);
  ;
}
