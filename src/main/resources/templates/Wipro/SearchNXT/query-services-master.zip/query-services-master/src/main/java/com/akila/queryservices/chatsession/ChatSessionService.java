package com.akila.queryservices.chatsession;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.queryservices.chatsession.bean.ChatSessionRequest;

@Service
public class ChatSessionService extends AkilaService {
	@Autowired
	@Qualifier("pythonService")
	private RestTemplate restTemplate;

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate restTemplateloadBalanced;
	
    @Value("${python.chat.api.url}")
	private String pythonChatApiURL;

    @Value("${metric.service.url}")
	private String metricServiceURL;

    @Autowired
    private AkilaRestTemplate akilaRestTemplate;
    
	public String query(String query, String[] contentIds) {
		ChatSessionRequest request = new ChatSessionRequest();
		request.setQuery(query);
		request.setOrgId(getOrgId());
		request.setQueryId(UUID.randomUUID().toString());
		request.setContentIds(contentIds);
		HttpEntity<ChatSessionRequest> entity = new HttpEntity<ChatSessionRequest>(request);
		ResponseEntity<String> response = akilaRestTemplate.postForEntity(restTemplate, pythonChatApiURL, entity,
				String.class);
			HttpEntity<String> entity1 = new HttpEntity<String>("Metric-Search-Count", getRequestHeader());
			akilaRestTemplate.postForEntity(restTemplateloadBalanced,
					metricServiceURL + "/publishEvent?serviceName=Metric-Search-Count", entity1, Void.class);
		return response.getBody();
	}
}
