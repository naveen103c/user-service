package com.akila.queryservices.chatsession.bean;

import com.akila.AkilaRequest;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ChatSessionRequest extends AkilaRequest 
{
	@JsonProperty("org_id")
	private String orgId;
	@JsonProperty("query_id")
	private String queryId;
	private String query;
	@JsonProperty("contents")
	private String[] contentIds;
	
	
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getQueryId() {
		return queryId;
	}
	public void setQueryId(String queryId) {
		this.queryId = queryId;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String[] getContentIds() {
		return contentIds;
	}
	public void setContentIds(String[] contentIds) {
		this.contentIds = contentIds;
	}
	
}
