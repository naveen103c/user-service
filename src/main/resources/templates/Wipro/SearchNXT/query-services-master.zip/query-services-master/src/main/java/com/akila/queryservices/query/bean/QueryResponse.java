package com.akila.queryservices.query.bean;

import java.sql.Timestamp;
import java.util.List;

import com.akila.AkilaResponse;

public class QueryResponse extends AkilaResponse 
{
	private String id;
	private String parentContentId;
	private String author;
	private Integer contentStatusCd;
	private Integer contentTypeCd;
	private String createdByUserId;
	private Timestamp crtTs;
	private String fileHash;
	private String fileNm;
	private Boolean isPrivate;
	private String jobId;
	private String keyValList;
	private Integer mediaCd;
	private Timestamp modTs;
	private Timestamp publishedTs;
	private String tagList;
	private String title;
	private String content;
	private Integer versionNum;
	private List<QueryResponse> children;
	private Integer actionStatusCd;
    private Boolean isFavourite;
	private Boolean isArchived;
	private String communityId;
	
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public Integer getContentStatusCd() {
		return contentStatusCd;
	}
	public void setContentStatusCd(Integer contentStatusCd) {
		this.contentStatusCd = contentStatusCd;
	}
	public Integer getContentTypeCd() {
		return contentTypeCd;
	}
	public void setContentTypeCd(Integer contentTypeCd) {
		this.contentTypeCd = contentTypeCd;
	}
	public String getCreatedByUserId() {
		return createdByUserId;
	}
	public void setCreatedByUserId(String createdByUserId) {
		this.createdByUserId = createdByUserId;
	}
	public Timestamp getCrtTs() {
		return crtTs;
	}
	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}
	public String getFileHash() {
		return fileHash;
	}
	public void setFileHash(String fileHash) {
		this.fileHash = fileHash;
	}
	public String getFileNm() {
		return fileNm;
	}
	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}
	public Boolean getIsPrivate() {
		return isPrivate;
	}
	public void setIsPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getKeyValList() {
		return keyValList;
	}
	public void setKeyValList(String keyValList) {
		this.keyValList = keyValList;
	}
	public Integer getMediaCd() {
		return mediaCd;
	}
	public void setMediaCd(Integer mediaCd) {
		this.mediaCd = mediaCd;
	}
	public Timestamp getModTs() {
		return modTs;
	}
	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}
	public Timestamp getPublishedTs() {
		return publishedTs;
	}
	public void setPublishedTs(Timestamp publishedTs) {
		this.publishedTs = publishedTs;
	}
	public String getTagList() {
		return tagList;
	}
	public void setTagList(String tagList) {
		this.tagList = tagList;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Integer getVersionNum() {
		return versionNum;
	}
	public void setVersionNum(Integer versionNum) {
		this.versionNum = versionNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<QueryResponse> getChildren() {
		return children;
	}
	public void setChildren(List<QueryResponse> children) {
		this.children = children;
	}
	public String getParentContentId() {
		return parentContentId;
	}
	public void setParentContentId(String parentContentId) {
		this.parentContentId = parentContentId;
	}
	public Integer getActionStatusCd() {
		return actionStatusCd;
	}
	public void setActionStatusCd(Integer actionStatusCd) {
		this.actionStatusCd = actionStatusCd;
	}
	public Boolean getIsFavourite() {
		return isFavourite;
	}
	public void setIsFavourite(Boolean isFavourite) {
		this.isFavourite = isFavourite;
	}
	public Boolean getIsArchived() {
		return isArchived;
	}
	public void setIsArchived(Boolean isArchived) {
		this.isArchived = isArchived;
	}
	public String getCommunityId() {
		return communityId;
	}
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}
}
