package com.akila.queryservices.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.akila.queryservices.entity.OrgContentMetadata;

@Repository
public interface OrgContentMetadataRepository extends JpaRepository<OrgContentMetadata, String> {
	@Transactional
	@Modifying
	@Query("update OrgContentMetadata set actionStatusCd = :actionStatusCd where contentId = :contentId")
	public void updateActionStatusCd(String contentId, int actionStatusCd);

	long countByContentTypeCdInAndActionStatusCdNotAndOrgContentRelationshipRootContentId(List<Integer> ContentTypeCd,
			int ActionStatusCd, String contentId);

	@Query("select ocm from OrgContentMetadata ocm where ocm.createdByUserId = :userId and ocm.contentTypeCd = :contentType and"
			+ " (:actionStatusCd is null or ocm.actionStatusCd = :actionStatusCd) and (cast(:startTime as timestamp) is null or cast(:endTime as timestamp) is null or ocm.crtTs between :startTime and :endTime)"
			+ " and (COALESCE(:communities, NULL) is null or ocm.communityId in (:communities))")
	public List<OrgContentMetadata> getUserDataForUserAction(String userId, Integer contentType, Integer actionStatusCd,
			Timestamp startTime, Timestamp endTime, List<String> communities);

}
