package com.akila.queryservices.file;

import java.io.IOException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.akila.AkilaController;
import com.akila.queryservices.status.bean.ResponseStatus;
import com.azure.core.annotation.Delete;

@RestController
public class FileController extends AkilaController {
	private static final Logger logger = LogManager.getLogger(FileController.class);
	
	@Autowired
	private FileService fileService;
	
	@Autowired
	private FileVirusScanService fileVirusScanService;
	
	@Value("${virus.scan.enable:false}")
	private boolean odsEnable;

	String defaultUserId = "a9daaf8e-0a5b-46c2-b281-650ab5dda384";
	String defaultOrgId = "84a7c96e-089c-11eb-adc1-0242ac120002";

	@PostMapping(path = "/files")
	public ResponseEntity<ResponseStatus> uploadFile(@RequestParam("file") MultipartFile file) throws IOException, Exception  {
		String orgId = defaultOrgId;
		logger.info("uploadFile :  orgId : "+orgId+", File Name : "+file.getOriginalFilename());
		if (getOrgId() != null && getOrgId().trim().length() > 0) {
			orgId = getOrgId();
		}
		String type = null;
		String extn = null;
		try {
			if(odsEnable && !fileVirusScanService.scanFile(file)) {
				ResponseStatus status = new ResponseStatus(0, file.getOriginalFilename(), "File contains malware", 120);
				logger.error("uploadFile : File contains malware, File Name : "+file.getOriginalFilename());
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
			Tika tika = new Tika();
			type = tika.detect(file.getInputStream());
			String fileName = file.getOriginalFilename();
			extn = fileName.substring(fileName.lastIndexOf(".")+1);
			logger.info("uploadFile : Name : "+file.getOriginalFilename()+", File Type : "+type+", Extn : "+extn);
		} catch (IOException e) {
			ResponseStatus status = new ResponseStatus(0, file.getOriginalFilename(), "File format not supported", 116);
			logger.error("uploadFile : Invalid file   File Name : "+file.getOriginalFilename(),e);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ResponseStatus status = new ResponseStatus(0, file.getOriginalFilename(), "Error while validating file", 116);
			logger.error("uploadFile : Error while validating file File Name : "+file.getOriginalFilename(),e);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(type != null && fileService.getMineType().contains(type.toLowerCase())) {
			if(extn != null && fileService.getExtn().contains(extn.toLowerCase()) && file.getOriginalFilename().toLowerCase().indexOf(".exe.") < 0) {
				ResponseStatus status = null;
				if(!fileService.fileExist(file.getOriginalFilename())) {
				fileService.uploadFile(orgId, file.getOriginalFilename(), file.getInputStream(),defaultUserId);
				status = new ResponseStatus(1, file.getOriginalFilename(), "File uploaded Successfuly", 0);
				logger.info("uploadFile : Filed successfully uploaded into system, File Name : "+file.getOriginalFilename());
				}
				else {
				 status = new ResponseStatus(1, file.getOriginalFilename(), "File Already exist", 0);
				 logger.info("uploadFile : Filed Already exist in system, File Name : "+file.getOriginalFilename());
				}
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
			} else {
				ResponseStatus status = new ResponseStatus(0, file.getOriginalFilename(), "File extn not supported", 116);
				logger.error("uploadFile : Invalid File Extn, File Name : "+file.getOriginalFilename()+", File Type : "+type+", Extn : "+extn);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
			
		} else {
			ResponseStatus status = new ResponseStatus(0, file.getOriginalFilename(), "File format not supported", 116);
			logger.error("uploadFile : Invalid file,  File Name : "+file.getOriginalFilename()+", File Type : "+type+", Extn : "+extn);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
	}
	
	@DeleteMapping(path = "/files")
	public ResponseEntity<ResponseStatus> deleteFiles(@RequestParam String files) {
	fileService.deleteFiles(files);
	ResponseStatus status = new ResponseStatus(1, "", "File/s Successfully Deleted", 0);
	return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	}
}
