package com.akila.queryservices.response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.queryservices.query.bean.QueryRequest;
import com.akila.response.ResponseId;

@RestController
public class ResponseController extends AkilaController {
  @Autowired
  private ResponseService responseService;

  @Value("${contentType.response}")
  private int contentTypeResponse;
  
  @Value("${contentType.followup}")
  private int contentTypeFollowup;
  
  @PostMapping(
      path = "/queries/{id}/responses"
  )
  public ResponseId createResponse(@RequestBody QueryRequest queryRequest,@PathVariable String id) 
  {
	  queryRequest.setParentContentId(id);
	  return responseService.createResponse(queryRequest, contentTypeResponse);
  }

  @PutMapping(
	      path = "/queries/{queryid}/responses/{id}"
	  )
	  public ResponseId updateResponse(@RequestBody QueryRequest queryRequest, @PathVariable String queryid, @PathVariable String id) {
	    return responseService.updateResponse(queryid, id, queryRequest, contentTypeResponse);
	  }
  
  @PostMapping(
	      path = "/queries/{id}/followup"
	  )
	  public ResponseId createFollowup(@RequestBody QueryRequest queryRequest,@PathVariable String id) 
	  {
		  queryRequest.setParentContentId(id);
		  return responseService.createResponse(queryRequest, contentTypeFollowup);
	  }

	  @PutMapping(
		      path = "/queries/{queryid}/followup/{id}"
		  )
		  public ResponseId updateFollowup(@RequestBody QueryRequest queryRequest, @PathVariable String queryid, @PathVariable String id) {
		    return responseService.updateResponse(queryid, id, queryRequest, contentTypeFollowup);
		  }
  
}
