package com.akila.queryservices.query;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.akila.AkilaConstants.ContentFormatType;
import com.akila.AkilaConstants.ContentType;
import com.akila.AkilaConstants.StorageStreamType;
import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.commons.storage.bean.StorageRequest;
import com.akila.commons.storage.bean.StorageResponse;
import com.akila.commons.storage.service.StorageFactory;
import com.akila.queryservices.entity.OrgBatchJobConf;
import com.akila.queryservices.repository.OrgBatchJobConfRepository;
import com.akila.queryservices.repository.OrgUserGroupToUsersLinkRepository;
import com.akila.queryservices.entity.OrgContentMetadata;
import com.akila.queryservices.entity.OrgContentRelationship;
import com.akila.queryservices.query.bean.MetaDataSimilarQueriesRequest;
import com.akila.queryservices.query.bean.QueryItemRequest;
import com.akila.queryservices.query.bean.QueryRequest;
import com.akila.queryservices.query.bean.QueryResponse;
import com.akila.queryservices.query.bean.SimilarQueriesData;
import com.akila.queryservices.query.bean.SimilarQueriesResponse;
import com.akila.queryservices.repository.OrgContentMetadataRepository;
import com.akila.queryservices.repository.OrgContentRelationshipRepository;
import com.akila.response.ResponseId;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class QueryService extends AkilaService {

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate restTemplate;

	@Value("${contentType.query}")
	private int contentTypeQuery;

	@Value("${metric.service.url}")
	private String metricServiceURL;

	@Value("${content.service.url}")
	private String contentServiceURL;

	@Value("${contentType.query}")
	private String contentTypeCd;
	
	@Value("${python.similar.questions.url}")
	private String pythonSimilarQuestionsURL;

	@Autowired
	private AkilaRestTemplate akilaRestTemplate;

	private static Logger log = LogManager.getLogger(QueryService.class);

	@Autowired
	private OrgContentMetadataRepository orgContentMetadataRepository;
	
	@Autowired
	private OrgBatchJobConfRepository orgBatchJobConfRepository;

	@Autowired
	private OrgUserGroupToUsersLinkRepository orgUserGroupToUsersLinkRepository;

	@Value("${platform.service.url}")
	private String platformServiceURL;

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate loadBalancedRestTemplate;

	@Value("${ask.content.length}")
	private int askContentLength;
	 
	@Autowired
	private StorageFactory s3StorageService;
	
	@Autowired
	OrgContentRelationshipRepository orgContentRelationshipRepository;
	  
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public QueryResponse getQuery(String id) {
		HttpHeaders headers = super.getRequestHeader();
		headers.add("contentType", ContentType.QUERY.getValue());
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<QueryResponse> response = null;
		response = akilaRestTemplate.exchange(restTemplate, contentServiceURL + "/content/" + id, HttpMethod.GET,
				entity, QueryResponse.class);
		return response.getBody();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<QueryResponse> getAllQueries(final Integer actionStatusCd) {
		HttpHeaders headers = super.getRequestHeader();
		headers.add("contentTypeCd", contentTypeCd);
		headers.add("actionStatusCd", actionStatusCd == null ? "-1" : actionStatusCd.toString());
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<?> response = akilaRestTemplate.exchange(restTemplate, contentServiceURL + "/content",
				HttpMethod.GET, entity, List.class);
		return (List<QueryResponse>) response.getBody();
	}

	public ResponseId createQuery(QueryRequest queryRequest) {
		HttpHeaders headers = super.getRequestHeader();
		headers.add("contentType", ContentType.QUERY.getValue());
		queryRequest.setContentTypeCd(contentTypeQuery);
		log.info("query community id " + queryRequest.getCommunityId());
		HttpEntity<QueryRequest> entity = new HttpEntity<QueryRequest>(queryRequest, headers);
		ResponseEntity<ResponseId> response = akilaRestTemplate.postForEntity(restTemplate,
				contentServiceURL + "/content", entity, ResponseId.class);
		HttpEntity<String> entity1 = new HttpEntity<String>("Metric-Queries-Unanswered", headers);
		akilaRestTemplate.postForEntity(restTemplate,
				metricServiceURL + "/publishEvent?serviceName=Metric-Queries-Unanswered", entity1, Void.class);
		return response.getBody();
	}

	public ResponseId updateQuery(String id, QueryRequest queryRequest) {
		HttpHeaders headers = super.getRequestHeader();
		headers.add("contentType", ContentType.QUERY.getValue());
		queryRequest.setContentTypeCd(contentTypeQuery);
		HttpEntity<QueryRequest> entity = new HttpEntity<QueryRequest>(queryRequest, headers);
		ResponseEntity<ResponseId> response = akilaRestTemplate.exchange(restTemplate,
				contentServiceURL + "/content/" + id, HttpMethod.PUT, entity, ResponseId.class);
		return response.getBody();
	}

	public ResponseId deleteQuery(String id) {
		HttpHeaders headers = super.getRequestHeader();
		headers.add("contentType", ContentType.QUERY.getValue());
		HttpEntity<QueryRequest> entity = new HttpEntity<QueryRequest>(headers);
		ResponseEntity<ResponseId> response = akilaRestTemplate.exchange(restTemplate,
				contentServiceURL + "/content/" + id, HttpMethod.DELETE, entity, ResponseId.class);
		return response.getBody();
	}

	public List<QueryResponse> queryFilter(QueryItemRequest queryItemRequest) {
		return getFilterItems(queryItemRequest, getUserId());
	}

	private List<QueryResponse> getFilterItems(QueryItemRequest queryItemRequest, String userId) {
		log.info("QueryService:getFilterItems start getting the filtered data for query");
		List<QueryResponse> queryResponses = new ArrayList<>();
		Timestamp startTime = queryItemRequest.getModifiedDateFrom() != null
				&& !queryItemRequest.getModifiedDateFrom().isEmpty()
						? Timestamp.valueOf(queryItemRequest.getModifiedDateFrom() + " 00:00:00")
						: null;
		Timestamp endTime = queryItemRequest.getModifiedDateTo() != null
				&& !queryItemRequest.getModifiedDateTo().isEmpty()
						? Timestamp.valueOf(queryItemRequest.getModifiedDateTo() + " 23:59:59")
						: null;
		String actionStatusCd = queryItemRequest.getStatus() != null && !queryItemRequest.getStatus().isEmpty()
				? queryItemRequest.getStatus()
				: null;
		List<String> communities = queryItemRequest.getCommunities() != null
				&& queryItemRequest.getCommunities().size() > 0 ? queryItemRequest.getCommunities() : null;
		boolean starred = queryItemRequest.isStarred();
		boolean archived = queryItemRequest.isArchived();
		List<OrgContentMetadata> orgContentMetadatas = orgContentMetadataRepository.getUserDataForUserAction(userId,
				Integer.valueOf(contentTypeCd), actionStatusCd == null ? null : Integer.valueOf(actionStatusCd),
				startTime, endTime, communities);

		String orgId = "";
		try {
			orgId = getS3BucketName();
		} catch (JsonMappingException e) {
			log.error("QueryService:getFilterItems - JsonMappingException : " + e.getMessage());
		} catch (JsonProcessingException e) {
			log.error("QueryService:getFilterItems - JsonProcessingException : " + e.getMessage());
		} catch (Exception e) {
			log.error("QueryService:getFilterItems - Exception :  " + e.getMessage());
		}
		queryResponses = getQueryContent(orgContentMetadatas, userId, orgId);
		log.info("QueryService:getFilterItems filter data process query has been completed");
		return queryResponses;
	}

	private String getS3BucketName() throws JsonMappingException, JsonProcessingException, Exception {
		HttpEntity<String> entity = new HttpEntity<String>("Org-Details", super.getRequestHeader());
		ResponseEntity<String> response = akilaRestTemplate.exchange(loadBalancedRestTemplate,
				platformServiceURL + "/orgs/" + getOrgId(), HttpMethod.GET, entity, String.class);
		String responseBody = response.getBody();
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode node = objectMapper.readTree(responseBody);
		String ssStorageFolder = node.get("storageFolderNm").asText();
		log.info("ssStorageFolder : " + ssStorageFolder + ". OrgId : " + getOrgId());
		return ssStorageFolder;
	}

	private List<QueryResponse> getQueryContent(List<OrgContentMetadata> contentMetadatas, String userId,
			String orgId) {
		List<QueryResponse> queryResponses = itemQueryResponseMapper(
				new ArrayList<OrgContentMetadata>(contentMetadatas));
		queryResponses.forEach(queryResponse -> {
			StorageRequest storageRequest = null;
			try {
				storageRequest = getStorageRequest(queryResponse, ContentType.QUERY.getValue());
				storageRequest.setUserId(userId);
				storageRequest.setOrgId(orgId);
				storageRequest.setContentMaxLength(askContentLength);
				storageRequest.setModTs(queryResponse.getModTs());
				StorageResponse storageResponse = s3StorageService.getContent(storageRequest);
				queryResponse.setContent(new String(storageResponse.getContent()));
			} catch (JsonMappingException e) {
				log.error("QueryService:getUniqueData - JsonMappingException : " + e.getMessage());
			} catch (JsonProcessingException e) {
				log.error("QueryService:getUniqueData - JsonProcessingException : " + e.getMessage());
			} catch (Exception e) {
				log.error("QueryService:getUniqueData - Exception :  " + e.getMessage());
			}
		});
		queryResponses.sort(Comparator.comparing(QueryResponse::getCrtTs).reversed());
		return queryResponses;
	}

	private List<QueryResponse> itemQueryResponseMapper(List<OrgContentMetadata> contentMetaDataList) {
		List<QueryResponse> responseList = new ArrayList<QueryResponse>();
		if (contentMetaDataList != null && !contentMetaDataList.isEmpty()) {
			for (OrgContentMetadata contentMetadata : contentMetaDataList) {
				QueryResponse response = new QueryResponse();
				response.setId(contentMetadata.getContentId());
				response.setAuthor(getValue(contentMetadata.getAuthor()));
				response.setContentStatusCd(getValue(contentMetadata.getContentStatusCd()));
				response.setContentTypeCd(getValue(contentMetadata.getContentTypeCd()));
				response.setCreatedByUserId(getValue(contentMetadata.getCreatedByUserId()));
				response.setCrtTs(contentMetadata.getCrtTs());
				response.setActionStatusCd(getValue(contentMetadata.getActionStatusCd()));
				response.setCommunityId(getValue(contentMetadata.getCommunityId()));
				response.setIsPrivate(contentMetadata.getIsPrivate());
				response.setKeyValList(getValue(contentMetadata.getKeyValList()));
				response.setMediaCd(getValue((contentMetadata.getMediaCd())));
				response.setModTs(contentMetadata.getModTs());
				response.setTagList(getValue(contentMetadata.getTagList()));
				response.setPublishedTs(contentMetadata.getPublishedTs());
				response.setTitle(getValue(contentMetadata.getTitle()));
				response.setVersionNum(getValue(contentMetadata.getVersionNum()));
				response.setIsArchived(false);
				response.setIsFavourite(false);
				responseList.add(response);
			}
		}
		return responseList;
	}
	
	private StorageRequest getStorageRequest(QueryResponse content, String contentType)
			throws JsonMappingException, JsonProcessingException, Exception {
		StorageRequest request = new StorageRequest();
		request.setInputStreamType(StorageStreamType.STRING.name());
		request.setFormatType(ContentFormatType.ORIGINAL.getValue());
		request.setContentType(contentType);
		request.setContentId(content.getId());
		return request;
	}
	
	 public Integer getValue(Integer itr) {
			if (itr != null) {
				return itr;
			} else {
				return 0;
			}
	  }
	 
	 public String getValue(String str) {
			if (str != null) {
				return str;
			} else {
				return "";
			}
	  }

	public SimilarQueriesData similarQueries(String queryText) {
		HttpHeaders headers = getRequestHeader();
		MetaDataSimilarQueriesRequest metaDataSimilarQueriesRequest = new MetaDataSimilarQueriesRequest();
		metaDataSimilarQueriesRequest.setConfId(getAllowedConfIdList());
		metaDataSimilarQueriesRequest.setOrgId(getOrgId());
		metaDataSimilarQueriesRequest.setQueryText(queryText);
		log.info("QueryService->Fetching similar queries MetaDataSimilarQueriesRequest-> "+metaDataSimilarQueriesRequest);
		HttpEntity<MetaDataSimilarQueriesRequest> entity = new HttpEntity<MetaDataSimilarQueriesRequest>(
				metaDataSimilarQueriesRequest, headers);
		ResponseEntity<SimilarQueriesResponse> similarQueriesResponse = akilaRestTemplate.postForEntity(restTemplate,
				pythonSimilarQuestionsURL, entity, SimilarQueriesResponse.class);
		log.info("QueryService->Fetched similar queries from python successfully -> " + similarQueriesResponse);
		List<String> ContentIdList = similarQueriesResponse.getBody().getData().getSimilarQueries().stream()
				.map(p -> p.getContentId()).collect(Collectors.toList());
		List<OrgContentRelationship> RootContentIdList = orgContentRelationshipRepository
				.findByRootContentIdIn(ContentIdList);
		if (RootContentIdList.size() > 0) {
			similarQueriesResponse.getBody().getData().getSimilarQueries().forEach(p -> {
				RootContentIdList.stream().forEach(q -> {
					if (q.getRootContentId().equals(p.getContentId())) {
						p.setInteractionCnt(p.getInteractionCnt() + 1);
					}
				});
			});
		}
		return similarQueriesResponse.getBody().getData();
	}
	
	private List<String> getAllowedConfIdList() {
		String userId = getUserId();
		ObjectMapper mapper = new ObjectMapper();
		List<String> allowedConfIdList = new ArrayList<>();
		List<String> userGroupIds = orgUserGroupToUsersLinkRepository.getUserGroupIdsByuserId(userId);
		List<OrgBatchJobConf> list = orgBatchJobConfRepository.findByBatchJobConfStatusCdNot(9);
		for (OrgBatchJobConf orgBatchJobConf : list) {
			if(orgBatchJobConf.getSourceAllowedUserGroupList().equals("[]")) {
				allowedConfIdList.add(orgBatchJobConf.getConfId());
			}else {
				List<String> groupList = null;
				try {
					groupList = mapper.readValue(orgBatchJobConf.getSourceAllowedUserGroupList(), ArrayList.class);
				} catch (JsonMappingException e) {
					log.error("Exception occurred while fetching group id for filter", e);
				} catch (JsonProcessingException e) {
					log.error("Exception occurred while updating metda data", e);
				}
				if (groupList != null) {
					List<String> tempList = (List<String>) CollectionUtils.intersection(userGroupIds, groupList);
					if (!tempList.isEmpty()) {
						allowedConfIdList.add(orgBatchJobConf.getConfId());
					}
				}
			}
		}
		return allowedConfIdList;
	}
}
