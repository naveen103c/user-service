package com.akila.queryservices.repository;


import java.util.List;
import com.akila.queryservices.entity.OrgUserGroupToUsersLink;
import com.akila.queryservices.entity.OrgUserGroupToUsersLinkPK;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgUserGroupToUsersLinkRepository extends JpaRepository<OrgUserGroupToUsersLink, OrgUserGroupToUsersLinkPK> {
	
	@Query(value = "SELECT o.id.userGroupId FROM OrgUserGroupToUsersLink o WHERE o.id.userId = (:userId)" )
	public List<String> getUserGroupIdsByuserId(@Param("userId") String userId);
	
}
