package com.akila.queryservices.query.bean;

import java.io.Serializable;

public class SimilarQueriesResponse implements Serializable {
	private static final long serialVersionUID = 1L;

	private Boolean status;
	private String message;
	private SimilarQueriesData data;

	public Boolean getStatus() {
		return status;
	}

	public void setStatus(Boolean status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public SimilarQueriesData getData() {
		return data;
	}

	public void setData(SimilarQueriesData data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "SimilarQueriesResponse [status=" + status + ", message=" + message + ", data=" + data + "]";
	}

}
