package com.akila.queryservices.query.bean;

import java.io.Serializable;
import java.util.List;

public class SimilarQueriesData implements Serializable {
	private static final long serialVersionUID = 1L;

	private List<SimilarQuery> similarQueries;

	public List<SimilarQuery> getSimilarQueries() {
		return similarQueries;
	}

	public void setSimilarQueries(List<SimilarQuery> similarQueries) {
		this.similarQueries = similarQueries;
	}

	@Override
	public String toString() {
		return "SimilarQueries [similarQueries=" + similarQueries + "]";
	}

}
