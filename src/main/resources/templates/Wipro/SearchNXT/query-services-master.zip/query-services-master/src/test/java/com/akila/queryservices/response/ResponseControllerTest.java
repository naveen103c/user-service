package com.akila.queryservices.response;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.queryservices.QueryServicesApplication;
import com.akila.queryservices.query.bean.QueryRequest;

@SpringBootTest(classes = QueryServicesApplication.class)
public class ResponseControllerTest 
{
	/*
	 * @Autowired private ResponseController controller;
	 */
	
	@Test
	public void createResponse()
	{
		QueryRequest request = new QueryRequest();
		request.setTitle("My Content Title query");
		request.setContent("My content body this is query ");
		request.setPrivateContent(true);
		request.setContentStatusCd(1);
		request.setTags(new String[] {"tags"});
		request.setParentContentId("4f3f5957-8b07-4d37-b095-89923cc2c8a4");
		request.setRootContentId("4f3f5957-8b07-4d37-b095-89923cc2c8a4");
	//	controller.createResponse(request, "4f3f5957-8b07-4d37-b095-89923cc2c8a4");
	}

}
