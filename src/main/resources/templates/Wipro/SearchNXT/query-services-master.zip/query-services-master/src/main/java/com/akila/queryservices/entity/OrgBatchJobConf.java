package com.akila.queryservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;


/**
 * The persistent class for the org_batch_job_confs database table.
 * 
 */
@Entity
@Table(name="org_batch_job_confs")
@NamedQuery(name="OrgBatchJobConf.findAll", query="SELECT o FROM OrgBatchJobConf o")
public class OrgBatchJobConf extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="conf_id")
	private String confId;

	@Column(name="conf_name")
	private String confName;

	@Column(name="source_allowed_user_group_list")
	private String sourceAllowedUserGroupList;

	@Column(name="source_classification_json")
	private String sourceClassificationJson;

	@Column(name="source_description")
	private String sourceDescription;

	@Column(name="source_extraction_type_cd")
	private Integer sourceExtractionTypeCd;

	@Column(name="source_password")
	private String sourcePassword;

	@Column(name="source_schedule_json")
	private String sourceScheduleJson;

	@Column(name="source_type_cd")
	private Integer sourceTypeCd;

	@Column(name="source_url")
	private String sourceUrl;

	@Column(name="source_user_id")
	private String sourceUserId;
	
	@Column(name = "batch_job_conf_status_cd")
	Integer batchJobConfStatusCd;

	public OrgBatchJobConf() {
	}

	public String getConfId() {
		return this.confId;
	}

	public void setConfId(String confId) {
		this.confId = confId;
	}

	public String getConfName() {
		return this.confName;
	}

	public void setConfName(String confName) {
		this.confName = confName;
	}

	public String getSourceAllowedUserGroupList() {
		return this.sourceAllowedUserGroupList;
	}
	
	public void setSourceAllowedUserGroupList(String sourceAllowedUserGroupList) {
		this.sourceAllowedUserGroupList = sourceAllowedUserGroupList;
	}

	public String getSourceClassificationJson() {
		return this.sourceClassificationJson;
	}

	public void setSourceClassificationJson(String sourceClassificationJson) {
		this.sourceClassificationJson = sourceClassificationJson;
	}

	public String getSourceDescription() {
		return this.sourceDescription;
	}

	public void setSourceDescription(String sourceDescription) {
		this.sourceDescription = sourceDescription;
	}

	public Integer getSourceExtractionTypeCd() {
		return this.sourceExtractionTypeCd;
	}

	public void setSourceExtractionTypeCd(Integer sourceExtractionTypeCd) {
		this.sourceExtractionTypeCd = sourceExtractionTypeCd;
	}

	public String getSourcePassword() {
		return this.sourcePassword;
	}

	public void setSourcePassword(String sourcePassword) {
		this.sourcePassword = sourcePassword;
	}

	public String getSourceScheduleJson() {
		return this.sourceScheduleJson;
	}

	public void setSourceScheduleJson(String sourceScheduleJson) {
		this.sourceScheduleJson = sourceScheduleJson;
	}

	public Integer getSourceTypeCd() {
		return this.sourceTypeCd;
	}

	public void setSourceTypeCd(Integer sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}

	public String getSourceUrl() {
		return this.sourceUrl;
	}

	public void setSourceUrl(String sourceUrl) {
		this.sourceUrl = sourceUrl;
	}

	public String getSourceUserId() {
		return this.sourceUserId;
	}

	public void setSourceUserId(String sourceUserId) {
		this.sourceUserId = sourceUserId;
	}

	public Integer getBatchJobConfStatusCd() {
		return batchJobConfStatusCd;
	}

	public void setBatchJobConfStatusCd(Integer batchJobConfStatusCd) {
		this.batchJobConfStatusCd = batchJobConfStatusCd;
	}
	
}