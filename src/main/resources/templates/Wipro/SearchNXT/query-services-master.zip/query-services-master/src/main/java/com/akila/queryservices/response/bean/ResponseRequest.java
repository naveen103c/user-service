package com.akila.queryservices.response.bean;

import com.akila.AkilaRequest;

public class ResponseRequest extends AkilaRequest {
}
