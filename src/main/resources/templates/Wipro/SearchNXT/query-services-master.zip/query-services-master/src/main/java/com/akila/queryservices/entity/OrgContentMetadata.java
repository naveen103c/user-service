package com.akila.queryservices.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the org_content_metadata database table.
 * 
 */
@Entity
@Table(name="org_content_metadata")
@NamedQuery(name="OrgContentMetadata.findAll", query="SELECT o FROM OrgContentMetadata o")
public class OrgContentMetadata implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="content_id")
	private String contentId;

	private String author;

	@Column(name="content_status_cd")
	private Integer contentStatusCd;

	@Column(name="content_type_cd")
	private Integer contentTypeCd;

	@Column(name="created_by_user_id")
	private String createdByUserId;

	@Column(name="crt_ts")
	private Timestamp crtTs;

	@Column(name="file_hash")
	private String fileHash;

	@Column(name="file_nm")
	private String fileNm;

	@Column(name="is_private")
	private Boolean isPrivate;

	@Column(name="job_id")
	private String jobId;

	@Column(name="key_val_list")
	private String keyValList;

	@Column(name="media_cd")
	private Integer mediaCd;

	@Column(name="mod_ts")
	private Timestamp modTs;

	@Column(name="published_ts")
	private Timestamp publishedTs;

	@Column(name="sys_version_num")
	private String sysVersionNum;

	@Column(name="tag_list")
	private String tagList;

	private String title;

	@Column(name="version_num")
	private Integer versionNum;
	
	@Column(name="action_status_cd")
	private Integer actionStatusCd;
	
	@Column(name="community_id")
	private String communityId;
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "content_id", insertable = false, updatable = false)
    private Set<OrgContentRelationship> orgContentRelationship;

	public OrgContentMetadata() {
	}

	public String getContentId() {
		return this.contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Integer getContentStatusCd() {
		return this.contentStatusCd;
	}

	public void setContentStatusCd(Integer contentStatusCd) {
		this.contentStatusCd = contentStatusCd;
	}

	public Integer getContentTypeCd() {
		return this.contentTypeCd;
	}

	public void setContentTypeCd(Integer contentTypeCd) {
		this.contentTypeCd = contentTypeCd;
	}

	public String getCreatedByUserId() {
		return this.createdByUserId;
	}

	public void setCreatedByUserId(String createdByUserId) {
		this.createdByUserId = createdByUserId;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getFileHash() {
		return this.fileHash;
	}

	public void setFileHash(String fileHash) {
		this.fileHash = fileHash;
	}

	public String getFileNm() {
		return this.fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public Boolean getIsPrivate() {
		return this.isPrivate;
	}

	public void setIsPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}

	public String getJobId() {
		return this.jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getKeyValList() {
		return this.keyValList;
	}

	public void setKeyValList(String keyValList) {
		this.keyValList = keyValList;
	}

	public Integer getMediaCd() {
		return this.mediaCd;
	}

	public void setMediaCd(Integer mediaCd) {
		this.mediaCd = mediaCd;
	}

	public Timestamp getModTs() {
		return this.modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public Timestamp getPublishedTs() {
		return this.publishedTs;
	}

	public void setPublishedTs(Timestamp publishedTs) {
		this.publishedTs = publishedTs;
	}

	public String getSysVersionNum() {
		return this.sysVersionNum;
	}

	public void setSysVersionNum(String sysVersionNum) {
		this.sysVersionNum = sysVersionNum;
	}

	public String getTagList() {
		return this.tagList;
	}

	public void setTagList(String tagList) {
		this.tagList = tagList;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getVersionNum() {
		return this.versionNum;
	}

	public void setVersionNum(Integer versionNum) {
		this.versionNum = versionNum;
	}

	public Integer getActionStatusCd() {
		return actionStatusCd;
	}

	public void setActionStatusCd(Integer actionStatusCd) {
		this.actionStatusCd = actionStatusCd;
	}

	public Set<OrgContentRelationship> getOrgContentRelationship() {
		return orgContentRelationship;
	}

	public void setOrgContentRelationship(Set<OrgContentRelationship> orgContentRelationship) {
		this.orgContentRelationship = orgContentRelationship;
	}

	public String getCommunityId() {
		return communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}
	
	
}