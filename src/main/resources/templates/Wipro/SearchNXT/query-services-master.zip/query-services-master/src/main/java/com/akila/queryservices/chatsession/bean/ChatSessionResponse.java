package com.akila.queryservices.chatsession.bean;

import com.akila.AkilaResponse;

public class ChatSessionResponse extends AkilaResponse {
}
