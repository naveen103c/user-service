package com.akila.queryservices.response.bean;

import com.akila.AkilaResponse;

public class ResponseResponse extends AkilaResponse {
}
