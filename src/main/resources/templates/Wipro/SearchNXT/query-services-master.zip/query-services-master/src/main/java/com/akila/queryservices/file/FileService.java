package com.akila.queryservices.file;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;

import com.akila.AkilaService;
import com.akila.commons.storage.service.StorageFactory;

@Service
public class FileService extends AkilaService {
	private static final Logger logger = LogManager.getLogger(FileService.class);
	
	@Autowired
	StorageFactory S3StorageService;
	
	@Value("${batchjob.upload.file.tikaminetype:application/x-tika-msoffice,application/x-tika-ooxml,application/vnd.ms-excel,application/pdf,application/x-tika-msoffice,video/mp4,text/html,text/plain,video/quicktime,message/rfc822}")
	private String tikaMineType;
	
	@Value("${batchjob.upload.file.extns:doc,docx,ppt,pptx,xls,xlsx,pdf,mp4,txt,html,msg,eml}")
	private String fileExtns;
	
	@Value("${upload.folder.name}")
	private String uploadFolder;
	
	public void uploadFile(String orgId, String fileName, InputStream in, String userId) throws HttpStatusCodeException, NullPointerException, Exception  {
		
		File file = new File(uploadFolder +"/" +getUserId());
		if (!file.exists()){
			file.mkdirs();
		}
		Files.copy(in, file.toPath().resolve(fileName));
	}
	
	public boolean fileExist(String fileName) {
		File file = new File(uploadFolder +"/" +getUserId());
		if(file.listFiles()!=null) {
        for(File f : file.listFiles()) {
        	if(f.getName().equalsIgnoreCase(fileName)) {
        		return true;
        	}
          }
        }
        return false;
	}

	public List<String> getExtn() {
		List<String> list = Arrays.asList(fileExtns.split(","));
		logger.info("getExtn : Extn : "+list);	
		return list;
	}
	
	public List<String> getMineType() {
		List<String> list = Arrays.asList(tikaMineType.split(","));
		logger.info("getMineType : Tika Mine Types : "+list);	
		return list;
	}
	
	public void deleteFiles(String files) {
		String fileNames[] = files.split(":");
		for (String file : fileNames) {
			File f = new File(uploadFolder +"/"+ getUserId() +"/"+ file);
			f.delete();
		}
	}
}
