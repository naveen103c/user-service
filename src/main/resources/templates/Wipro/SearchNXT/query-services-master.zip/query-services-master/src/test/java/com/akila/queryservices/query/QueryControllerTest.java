package com.akila.queryservices.query;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.akila.queryservices.QueryServicesApplication;
import com.akila.queryservices.query.bean.QueryRequest;
import com.akila.queryservices.query.bean.QueryResponse;
import com.akila.response.ResponseId;

@SpringBootTest(classes = QueryServicesApplication.class)
public class QueryControllerTest 
{
	/*
	 * @Autowired private QueryController controller;
	 */
	
	@Test
	public void createWiki()
	{
		QueryRequest request = new QueryRequest();
		request.setTitle("My Content Title query");
		request.setContent("My content body this is query ");
		request.setPrivateContent(true);
		request.setContentStatusCd(1);
		request.setTags(new String[] {"tags"});
		//ResponseId response = controller.createQuery(request);
		//System.out.println(response.getId());
	}
	
	@Test
	public void getWiki()
	{
		/*
		 * QueryResponse response =
		 * controller.getQuery("92a7a03b-6e8c-4137-b7cb-65418f9d6525");
		 * System.out.println(response.getContent());
		 */
	}

}
