package com.akila.queryservices.query.bean;

import java.util.List;

public class QueryItemRequest {
	
private List<String> itemType;
private String modifiedDateFrom;
private String modifiedDateTo;
private String status;
private List<String> communities;
private boolean starred;
private boolean archived;

public List<String> getItemType() {
	return itemType;
}
public void setItemType(List<String> itemType) {
	this.itemType = itemType;
}
public String getModifiedDateFrom() {
	return modifiedDateFrom;
}
public void setModifiedDateFrom(String modifiedDateFrom) {
	this.modifiedDateFrom = modifiedDateFrom;
}
public String getModifiedDateTo() {
	return modifiedDateTo;
}
public void setModifiedDateTo(String modifiedDateTo) {
	this.modifiedDateTo = modifiedDateTo;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public List<String> getCommunities() {
	return communities;
}
public void setCommunities(List<String> communities) {
	this.communities = communities;
}
public boolean isStarred() {
	return starred;
}
public void setStarred(boolean starred) {
	this.starred = starred;
}
public boolean isArchived() {
	return archived;
}
public void setArchived(boolean archived) {
	this.archived = archived;
}
@Override
public String toString() {
	return "WorkflowQueryRequest [itemType=" + itemType + ", modifiedDateFrom=" + modifiedDateFrom + ", modifiedDateTo="
			+ modifiedDateTo + ", status=" + status + ", communities=" + communities + ", starred=" + starred
			+ ", archived=" + archived + "]";
}
}

