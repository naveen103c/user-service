package com.akila.queryservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.akila.queryservices.entity.OrgBatchJobConf;

@Repository
public interface OrgBatchJobConfRepository extends JpaRepository<OrgBatchJobConf, String> {

	@Query(value = "SELECT o.confId FROM OrgBatchJobConf o WHERE o.sourceAllowedUserGroupList like '%' || :userGroupId || '%'")
	public List<String> getAllowedConfId(@Param("userGroupId") String userGroupId);
	
	public List<OrgBatchJobConf> findByBatchJobConfStatusCdNot(@Param("batchJobConfStatusCd") int batchJobConfStatusCd);

}
