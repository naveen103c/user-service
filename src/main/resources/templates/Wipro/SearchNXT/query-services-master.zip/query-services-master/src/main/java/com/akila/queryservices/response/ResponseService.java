package com.akila.queryservices.response;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaConstants.ContentType;
import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.queryservices.entity.OrgContentMetadata;
import com.akila.queryservices.entity.OrgContentRelationship;
import com.akila.queryservices.query.QueryService;
import com.akila.queryservices.query.bean.QueryRequest;
import com.akila.queryservices.repository.OrgContentMetadataRepository;
import com.akila.queryservices.repository.OrgContentRelationshipRepository;
import com.akila.response.ResponseId;

@Service
public class ResponseService extends AkilaService 
{
  @Autowired
  @Qualifier("loadBalanced")
  private RestTemplate restTemplate;
  
  @Autowired
  private QueryService queryService;
  
  @Value("${metric.service.url}")
  private String metricServiceURL;
  
  @Value("${content.service.url}")
  private String contentServiceURL;
  
  @Value("${response.action.status.cd}")
  private String responseActionStatusCd;
  
  @Value("${followup.action.status.cd}")
  private String followupActionStatusCd;
  
  @Value("${contentType.followup}")
  private int contentTypeFollowup;
  
  @Value("${contentType.query}")
  private int contentTypeCd;
  
  @Autowired
  private AkilaRestTemplate akilaRestTemplate;
  
  @Autowired
  private OrgContentMetadataRepository orgContentMetadataRepository;
  
  @Autowired
  OrgContentRelationshipRepository orgContentRelationshipRepository;

  public ResponseId createResponse(QueryRequest queryRequest, Integer contentType) {
	  HttpHeaders headers = super.getRequestHeader();
	  headers.add("contentType", ContentType.QUERY.getValue());
	  queryRequest.setContentTypeCd(contentType);
	  HttpEntity<QueryRequest> entity = new HttpEntity<QueryRequest>(queryRequest, headers);
	  ResponseEntity<ResponseId> response = akilaRestTemplate.postForEntity(restTemplate, contentServiceURL + "/content", entity, ResponseId.class);
	  updateActionStatusCode(queryRequest.getParentContentId(), 
			  queryRequest.getContentTypeCd()==Integer.parseInt(responseActionStatusCd)?responseActionStatusCd:followupActionStatusCd,
			  response.getBody().getId());
	  createEvent("Metric-Queries-Answered");
	  long childCount = orgContentRelationshipRepository.countByRootContentId(queryRequest.getRootContentId());
		if (childCount == 1) {
			 createEvent("Metric-Queries-Unanswered");
		}
	  return response.getBody();
  }

  public ResponseId updateResponse(String queryId, String id, QueryRequest queryRequest, Integer contentType) {
  	  HttpHeaders headers = super.getRequestHeader();
	  headers.add("contentType", ContentType.QUERY.getValue());
	  queryRequest.setContentTypeCd(contentType);
	  HttpEntity<QueryRequest> entity = new HttpEntity<QueryRequest>(queryRequest, headers);
	  ResponseEntity<ResponseId> response = akilaRestTemplate.exchange(restTemplate, contentServiceURL + "/content/"+id, HttpMethod.PUT, entity, ResponseId.class);
	  return response.getBody();
  }
  
	@Transactional
	public void updateActionStatusCode(String parentContentId, String actionStatusCd, String responseId) {
		OrgContentRelationship orgContentRelationship = orgContentRelationshipRepository.findByContentId(responseId);
        OrgContentMetadata contentMetadata = orgContentMetadataRepository.findById(orgContentRelationship.getRootContentId()).orElse(null);
        
        if(contentMetadata.getAuthor().equals(getUserId()) && actionStatusCd.equalsIgnoreCase(responseActionStatusCd))
        {
               return;
        }
		
		orgContentMetadataRepository.updateActionStatusCd(parentContentId, Integer.parseInt(actionStatusCd));
		
		if (orgContentRelationship != null) {
			String rootContentId = orgContentRelationship.getRootContentId();
			if (actionStatusCd.equals(followupActionStatusCd)) {
				orgContentMetadataRepository.updateActionStatusCd(rootContentId,
						Integer.parseInt(followupActionStatusCd));
			} else if (actionStatusCd.equals(responseActionStatusCd)) {
				List<Integer> contentTypes = new ArrayList<Integer>();
				contentTypes.add(contentTypeFollowup);
				contentTypes.add(contentTypeCd);
				long count = orgContentMetadataRepository.countByContentTypeCdInAndActionStatusCdNotAndOrgContentRelationshipRootContentId(
						contentTypes, Integer.parseInt(responseActionStatusCd) , rootContentId);
				if (count == 0) {
					orgContentMetadataRepository.updateActionStatusCd(rootContentId,
							Integer.parseInt(responseActionStatusCd));
				}
			}
		}
	}
}
