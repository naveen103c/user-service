package com.akila.health;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;

@RestController
public class HealthController extends AkilaController {

  @GetMapping(
      path = "/",produces = { "application/json"}
  )
  public HealthResponse getHealth() {
    return new HealthResponse("UP");
  }
  
}
