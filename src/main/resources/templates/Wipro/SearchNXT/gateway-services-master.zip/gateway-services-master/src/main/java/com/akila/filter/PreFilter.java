package com.akila.filter;

import java.net.URL;
import java.security.Principal;
import java.util.Arrays;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.keycloak.KeycloakPrincipal;
import org.keycloak.KeycloakSecurityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;

import com.akila.whitelistedip.configuration.WhiteListIpProperties;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

public class PreFilter extends ZuulFilter {
	private static Logger logger = LogManager.getLogger(PreFilter.class);
	private static final String CORRELATION_ID_HEADER_NAME = "x-correlation-id";
	private static final String CORRELATION_ID_LOG_VAR_NAME = "correlationId";
	
	@Value("${white.list.hosts:searchnxt.wipro.com,akiladev.wipro.com}")
	private String whiteListHosts;
	
	@Autowired
	WhiteListIpProperties whitListIpProperties;
	
	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		String correlationId =  generateUniqueCorrelationId();
		ThreadContext.put(CORRELATION_ID_LOG_VAR_NAME,correlationId);
		
		RequestContext ctx = RequestContext.getCurrentContext();
		HttpServletRequest request = ctx.getRequest();
		
		validateReferer(ctx);
		
		ctx.addZuulRequestHeader(CORRELATION_ID_HEADER_NAME, correlationId);
		ctx.addZuulRequestHeader(CORRELATION_ID_HEADER_NAME, correlationId);
		
		ThreadContext.put("ipAddress", request.getRemoteAddr());
		ThreadContext.put("sessionId", request.getSession().getId());

		ThreadContext.put("requestURI", request.getRequestURI());
		ThreadContext.put("User-Agent", request.getHeader("User-Agent"));

		Date date = new Date();
		ThreadContext.put("executionStartTime", date.getTime() + "");

		ThreadContext.put("executionStartDateTime", date + "");

		Principal principal = request.getUserPrincipal();
		if (principal != null) {
			ThreadContext.put("userId", principal.getName());
			
			if (principal instanceof KeycloakPrincipal) {
				KeycloakPrincipal<KeycloakSecurityContext> kp = (KeycloakPrincipal<KeycloakSecurityContext>) principal;

				ThreadContext.put("username", kp.getKeycloakSecurityContext().getToken().getPreferredUsername());

				Set<String> roles = kp.getKeycloakSecurityContext().getToken().getRealmAccess().getRoles();
				ThreadContext.put("User-Role", roles.toString());
			}
		}
		logger.info("GateWay PreFilter - Start of API call " + request.getRequestURI());
		return null;
	}

	@Override
	public String filterType() {
		return "pre";
	}

	@Override
	public int filterOrder() {
		return 0;
	}

	private String generateUniqueCorrelationId() {
        return UUID.randomUUID().toString();
    }
	
	private void validateReferer(RequestContext ctx) {
		String referer = null;
		boolean isRefererValid = true;
		try {
			referer = ctx.getRequest().getHeader("Referer");
			if(referer != null && referer.trim().length() > 0) {
				String host;
				String ip;
				try {
					URL url =  new URL(referer);
					host = url.getHost();
					ip =  getClientIpAddress(ctx.getRequest()); 
					
					//Adding this code to give the access only whitelisted ips
					String tenant = ctx.getRequest().getHeader("tenant");
					logger.info("Tenant is : "+tenant);
					List<String> whiteListedIps =  whitListIpProperties.getWhiteListedIps(tenant);
					if(whiteListedIps != null && whiteListedIps.size() > 0) {
						if(!whiteListedIps.contains(ip)) {
							 logger.warn("Unauthorized Access from  blacklisted ips : " + ip + " Whitelisted ips are : "+whiteListedIps);
							 isRefererValid = false;
						}
					}

					List<String> hostList = Arrays.asList(whiteListHosts.split(","));
					logger.info("Referer host : " + host+", White list hosts : "+hostList);
					if(!hostList.contains(host.toLowerCase())) {
						 logger.warn("Unauthorized Access from  Referer : " + referer);
						 isRefererValid = false;
					}
				} catch (Exception e) {
					 logger.error("Unauthorized Access from  Referer : " + referer,e);
					 isRefererValid = false;
				}
			} else {
				  logger.info("No referer found.");
				 /* String remoteAdd = ctx.getRequest().getRemoteAddr();
				  String remoteHost = ctx.getRequest().getRemoteHost();
				  List<String> hostList = Arrays.asList(whiteListHosts.split(","));
				  logger.info("Remote Address : " + remoteAdd+", Remote Host : "+remoteHost+" , White list hosts : "+hostList);
				  if(!hostList.contains(remoteAdd)) {
					  logger.info("Unauthorized Access from  remoteAdd : " + remoteAdd);
					  isRefererValid = false;
				  } */
			}
			
		} catch (Exception e) {
			isRefererValid = false;
			logger.error("Error while validating referer :  " + e.getMessage(),e);
		}
		
		if(!isRefererValid) {
			 logger.warn("Unauthorized Access from  remote Host1 : " + ctx.getRequest().getRemoteAddr());
			 ctx.unset();
			 ctx.setResponseStatusCode(HttpStatus.UNAUTHORIZED.value());
		}
	}
	
	public  String getClientIpAddress(HttpServletRequest request) {
	    String xForwardedForHeader = request.getHeader("X-Forwarded-For");
	    getRequestHeadersInMap(request);
	    if (xForwardedForHeader == null) {
	        return request.getRemoteAddr();
	    } else {
	    	return new StringTokenizer(xForwardedForHeader, ",").nextToken().trim();
	    }
	}
	
	private Map<String, String> getRequestHeadersInMap(HttpServletRequest request) {

        Map<String, String> result = new HashMap<>();

        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            String value = request.getHeader(key);
            result.put(key, value);
        }
     logger.info("PreFilter.getRequestHeadersInMap: Result is : "+result);
        return result;
    }
	
}
