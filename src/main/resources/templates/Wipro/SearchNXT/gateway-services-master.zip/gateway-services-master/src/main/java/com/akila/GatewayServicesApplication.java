package com.akila;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.cloud.netflix.zuul.filters.Route;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;

import com.akila.commons.AkilaCommonsApplication;
import com.akila.filter.PostFilter;
import com.akila.filter.PreFilter;
import com.akila.whitelistedip.configuration.WhiteListIpProperties;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.config.RateLimitKeyGenerator;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.config.RateLimitUtils;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.config.properties.RateLimitProperties;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.config.properties.RateLimitProperties.Policy.MatchType;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.config.properties.RateLimitType;
import com.marcosbarbero.cloud.autoconfigure.zuul.ratelimit.support.DefaultRateLimitKeyGenerator;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableEncryptableProperties
@EnableSwagger2
@EnableDiscoveryClient
@EnableZuulProxy
@EnableScheduling
@PropertySources({ @PropertySource("classpath:app.properties"),
		@PropertySource(name = "prod", value = "file:${external.config}", ignoreResourceNotFound = true) })
@Import(value = { AkilaCommonsApplication.class, WhiteListIpProperties.class })
public class GatewayServicesApplication {
	public static void main(String[] args) {
		SpringApplication.run(GatewayServicesApplication.class, args);
	}

	@Bean
	public PreFilter getFilter() {
		return new PreFilter();
	}

	@Bean
	public PostFilter postFilter() {
		return new PostFilter();
	}

	@Bean("loadBalanced")
	//@LoadBalanced
	public RestTemplate restTemplateLoadBalanced(RestTemplateBuilder builder) {
		return builder.build();
	}

	 @Bean
	  public RateLimitKeyGenerator ratelimitKeyGenerator(RateLimitProperties properties, RateLimitUtils rateLimitUtils) {
	      return new DefaultRateLimitKeyGenerator(properties, rateLimitUtils) {
	          @Override
	          public String key(HttpServletRequest request, Route route, RateLimitProperties.Policy policy) {
	        	String userId =   request.getHeader("userId");
	        	String tenant =  request.getHeader("tenant");
	        	MatchType type =new MatchType(RateLimitType.HTTPMETHOD,"post");
	        	List<MatchType> list = new ArrayList<MatchType>();
	        	list.add(type);
	        	policy.setType(list);
	            return super.key(request, route, policy) + ":" + userId + ":" + tenant + ":" + request.getMethod();
	          }
	      };
	  }
	 
	 
}
