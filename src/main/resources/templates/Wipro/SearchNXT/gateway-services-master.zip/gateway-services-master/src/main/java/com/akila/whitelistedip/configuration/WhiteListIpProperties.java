package com.akila.whitelistedip.configuration;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;

@Service
@ConfigurationProperties(prefix = "whitelisted")
public class WhiteListIpProperties 
{
	private Map<String, List<String>> ip = new LinkedHashMap<>();
	

	  public Map<String, List<String>> getIp() {
	    return ip;
	  }

	  public void setIp(Map<String, List<String>> ip) {
	    ip.forEach((key, value) -> this.ip.put(key, value));
	  }

	  public List<String> getWhiteListedIps(String tenant){
		  return ip.get(tenant);
	  }
	  
}
