package com.akila.filter;

import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.keycloak.KeycloakPrincipal;
import org.keycloak.KeycloakSecurityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.akila.bean.Notification;
import com.akila.commons.AkilaRestTemplate;
import com.akilacommons.tenant.TenantContext;
import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

public class PostFilter extends ZuulFilter {

	private static Logger logger = LogManager.getLogger(PostFilter.class);

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate restTemplateloadBalanced;

	@Value("${incentive.service.url}")
	private String incentiveServiceURL;
	
	@Autowired
	AkilaRestTemplate akilaRestTemplate;
	
	@Override
	public boolean shouldFilter() {
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		RequestContext ctx = RequestContext.getCurrentContext();
		HttpServletRequest request = ctx.getRequest();

		String startTimeS = ThreadContext.get("executionStartTime");

		long startTime = Long.valueOf(startTimeS);

		long currentTime = new Date().getTime();
		long duration = currentTime - startTime;

		ThreadContext.put("executionEndTime", getDate(currentTime) + "");
		ThreadContext.put("executionTimeDuration", duration + "");

		ThreadContext.put("ipAddress", request.getRemoteAddr());
		ThreadContext.put("sessionId", request.getSession().getId());

		ThreadContext.put("requestURI", request.getRequestURI());
		ThreadContext.put("User-Agent", request.getHeader("User-Agent"));
		ThreadContext.put("requestMethod", request.getMethod());
		Date date = new Date();
		ThreadContext.put("executionStartTime", date.getTime() + "");

		ThreadContext.put("executionStartDateTime", date + "");

		Principal principal = request.getUserPrincipal();
		if (principal != null) {
			ThreadContext.put("userId", principal.getName());

			if (principal instanceof KeycloakPrincipal) {
				KeycloakPrincipal<KeycloakSecurityContext> kp = (KeycloakPrincipal<KeycloakSecurityContext>) principal;

				ThreadContext.put("username", kp.getKeycloakSecurityContext().getToken().getPreferredUsername());

				Set<String> roles = kp.getKeycloakSecurityContext().getToken().getRealmAccess().getRoles();
				ThreadContext.put("User-Role", roles.toString());
			}
		}
		boolean isMediaContentRequest = false;
		String reqURI= request.getRequestURI();
		if(reqURI.toLowerCase().contains("/media-services/content/")) {
			isMediaContentRequest = true;
		}
		updateMetric(ctx, request, principal); 
		//Adding Response header
		HttpServletResponse response = ctx.getResponse();
		response.setHeader("X-Frame-Options", "SAMEORIGIN");
		response.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
		if(isMediaContentRequest) {
			response.setHeader("Content-Security-Policy", "default-src * 'unsafe-inline' 'unsafe-eval'; script-src * 'unsafe-inline' 'unsafe-eval'; connect-src * 'unsafe-inline'; img-src * data: blob: 'unsafe-inline'; frame-src *; style-src * 'unsafe-inline';");
		} else {
			response.setHeader("Content-Security-Policy", "default-src 'self'");
		}
		response.setHeader("Access-Control-Allow-Origin", "https://searchnxt.wipro.com");
		response.setHeader("Strict-Transport-Security", "max-age=3600; includeSubDomains");
		response.setHeader("X-Content-Type-Options", "nosniff");
		response.setHeader("Cache-Control", "no-store");

		logger.info("End of API call " + request.getRequestURI());
		return null;
	}

	private void updateMetric(RequestContext ctx, HttpServletRequest request, Principal principal) {
		String requestURI = request.getRequestURI();
		if(requestURI.startsWith("/api"))
		{
			requestURI = requestURI.replaceFirst("/api", "");
		}

		if (ctx.getResponse().getStatus() == 200 && !requestURI.equals("/core-services/ui-logs")
				&& !request.getMethod().equals("GET")) {

				TenantContext.setCurrentTenant(request.getHeader("tenant"));

				Notification notification = new Notification();
				notification.setHttpMethod(request.getMethod());
				notification.setRequestUri(requestURI);
				notification.setQueryString(request.getQueryString());
				notification.setTenant(request.getHeader("tenant"));
				if(principal != null) {
					notification.setUserId(principal.getName());
				}
				
				ExecutorService executorService = Executors.newSingleThreadExecutor();
			    executorService.execute(new Runnable() {
			        @Override
					public void run() {
						try {
							logger.info("Event Will push in queue in Run--" + notification.toString());
							HttpHeaders headers = new HttpHeaders();
							headers.setContentType(MediaType.APPLICATION_JSON);
							headers.set("tenant", notification.getTenant());
							headers.set("userId", notification.getUserId());
							HttpEntity<Notification> entity = new HttpEntity<Notification>(notification,
									headers);
							akilaRestTemplate.exchange(restTemplateloadBalanced, incentiveServiceURL + "/publishevent",HttpMethod.POST, entity, Void.class);
							logger.info("Event pushed in queue");
						} catch (Exception e) {
							logger.error("Error in updateMetric : " + e.getMessage(),e);
						}

					}
				});
			}
	}

	@Override
	public String filterType() {
		return "post";
	}

	@Override
	public int filterOrder() {
		return 0;
	}

	@PostConstruct
	public void init() {

	}

	public String getDate(long timeInMills) {

		Date date = new Date(timeInMills);
		SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss.SSS");
		Calendar c = Calendar.getInstance();
		formatter.setTimeZone(c.getTimeZone());
		String formatted = formatter.format(date);

		return formatted;
	}
}
