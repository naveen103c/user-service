
package com.akila.keycloak;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.keycloak.adapters.KeycloakConfigResolver;
import org.keycloak.adapters.KeycloakDeployment;
import org.keycloak.adapters.KeycloakDeploymentBuilder;
import org.keycloak.adapters.OIDCHttpFacade;
import org.keycloak.representations.adapters.config.AdapterConfig;


public class MultitenantConfigResolver implements KeycloakConfigResolver {

	private static final Logger logger = LogManager.getLogger(MultitenantConfigResolver.class);
	private final Map<String, KeycloakDeployment> cache = new ConcurrentHashMap<String, KeycloakDeployment>();
	private static AdapterConfig adapterConfig;

	public KeycloakDeployment resolve(OIDCHttpFacade.Request request) {
		String tenant = request.getHeader("tenant");
		if (tenant == null) {
			tenant = request.getQueryParamValue("tenant");
			if (tenant == null) {
				tenant = "base";
			}
		}

		KeycloakDeployment deployment = cache.get(tenant);
		if (null == deployment) {
			// not found on the simple cache, try to load it from the file system
			InputStream is = getClass().getResourceAsStream("/" + tenant + "-keycloak.json");
			if (is == null) {
				File file = new File("/properties/" + tenant + "-keycloak.json");
				try {
					is = new FileInputStream(file);
				} catch (FileNotFoundException e) {
					logger.error("GateWayService:MultitenantConfigResolver File not found - > TenantId : " + tenant);	
					throw new IllegalStateException("file Not Found /" + tenant + "-keycloak.json");
				}
			}
			deployment = KeycloakDeploymentBuilder.build(is);
			cache.put(tenant, deployment);
		}

		return deployment;
	}

	public static void setAdapterConfig(AdapterConfig adapterConfig) {
		MultitenantConfigResolver.adapterConfig = adapterConfig;
	}

}
