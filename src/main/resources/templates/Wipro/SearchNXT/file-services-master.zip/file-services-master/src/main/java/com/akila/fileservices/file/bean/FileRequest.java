package com.akila.fileservices.file.bean;

import com.akila.AkilaRequest;

public class FileRequest extends AkilaRequest {
}
