package com.akila.fileservices.file;

import com.akila.AkilaController;
import com.akila.fileservices.file.bean.FileRequest;
import com.akila.fileservices.file.bean.FileResponse;
import com.akila.response.ResponseId;
import java.lang.String;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FileController extends AkilaController {
  @Autowired
  private FileServiceImpl fileService;

  @PostMapping(
      path = "/files"
  )
  public ResponseId uploadFile(@RequestBody FileRequest fileRequest) {
    return fileService.uploadFile(fileRequest);
  }

  @GetMapping(
      path = "/files"
  )
  public List<FileResponse> getAllFiles() {
    return fileService.getAllFiles();
  }

  @GetMapping(
      path = "/files/{id}"
  )
  public FileResponse getFile(@PathVariable String id) {
    return fileService.getFile(id);
  }

  @PutMapping(
      path = "/files/{id}"
  )
  public ResponseId updateFile(@PathVariable String id, @RequestBody FileRequest fileRequest) {
    return fileService.updateFile(id, fileRequest);
  }

  @DeleteMapping(
      path = "/files/{id}"
  )
  public ResponseId deleteFile(@PathVariable String id) {
    return fileService.deleteFile(id);
  }
}
