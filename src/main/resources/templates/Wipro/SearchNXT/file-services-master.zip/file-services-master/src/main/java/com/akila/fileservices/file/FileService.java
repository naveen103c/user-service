package com.akila.fileservices.file;

import com.akila.AkilaService;
import com.akila.fileservices.file.bean.FileMapper;
import com.akila.fileservices.file.bean.FileRequest;
import com.akila.fileservices.file.bean.FileResponse;
import com.akila.response.ResponseId;
import java.lang.String;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FileService extends AkilaService {
  @Autowired
  private FileMapper fileMapper;

  public ResponseId uploadFile(FileRequest fileRequest) {
    return null;
  }

  public List<FileResponse> getAllFiles() {
    return null;
  }

  public FileResponse getFile(String id) {
    return null;
  }

  public ResponseId updateFile(String id, FileRequest fileRequest) {
    return null;
  }

  public ResponseId deleteFile(String id) {
    return null;
  }
}
