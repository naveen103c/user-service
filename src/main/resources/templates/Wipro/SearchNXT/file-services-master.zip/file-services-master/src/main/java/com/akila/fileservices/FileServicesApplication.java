package com.akila.fileservices;

import java.lang.String;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.ControllerAdvice;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@SpringBootApplication
@EnableEncryptableProperties
@EnableSwagger2
@EnableTransactionManagement
@ControllerAdvice(
    basePackages = "com.akila.*"
)
@EntityScan(
    basePackages = "com.akila.*"
)
public class FileServicesApplication {
  public static void main(String[] args) {
    SpringApplication.run(FileServicesApplication.class, args);
  }
}
