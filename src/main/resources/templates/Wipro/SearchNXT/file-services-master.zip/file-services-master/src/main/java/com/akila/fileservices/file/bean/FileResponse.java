package com.akila.fileservices.file.bean;

import com.akila.AkilaResponse;

public class FileResponse extends AkilaResponse {
}
