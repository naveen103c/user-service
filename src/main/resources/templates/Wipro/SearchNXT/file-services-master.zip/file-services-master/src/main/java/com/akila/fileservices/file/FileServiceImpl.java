package com.akila.fileservices.file;

import com.akila.fileservices.file.bean.FileMapper;
import com.akila.fileservices.file.bean.FileRequest;
import com.akila.fileservices.file.bean.FileResponse;
import com.akila.response.ResponseId;
import java.lang.String;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FileServiceImpl extends FileService {
  @Autowired
  private FileMapper fileMapper;

  public ResponseId uploadFile(FileRequest fileRequest) {
    return super.uploadFile(fileRequest);
  }

  public List<FileResponse> getAllFiles() {
    return super.getAllFiles();
  }

  public FileResponse getFile(String id) {
    return super.getFile(id);
  }

  public ResponseId updateFile(String id, FileRequest fileRequest) {
    return super.updateFile(id, fileRequest);
  }

  public ResponseId deleteFile(String id) {
    return super.deleteFile(id);
  }
}
