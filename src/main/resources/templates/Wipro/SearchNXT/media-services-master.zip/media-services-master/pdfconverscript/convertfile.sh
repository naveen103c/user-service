
#!/bib/bash
#cp /mnt/akila-dv-logs-efs/tmpscanfiles/$1  /mnt/akila-dv-properties-efs/convertfile/$1
sudo  docker cp  /mnt/akila-dv-logs-efs/tmpscanfiles/$1  libreoffice:/tmp/$1
echo libreoffice:/tmp/$1
sudo docker exec -ti libreoffice unoconv   --connection 'socket,host=127.0.0.1,port=8100,tcpNoDelay=1;urp;StarOffice.ComponentContext'   -f pdf /tmp/$1
echo /tmp/$1
sleep 2s
echo 'After sleep-----------------'
# docker cp libreoffice:/tmp/$2  /mnt/akila-dv-properties-efs/convertfile/
sudo docker cp libreoffice:/tmp/$2 /mnt/akila-dv-logs-efs/tmpconvertedpdf/
echo libreoffice:/tmp/$2
cd /mnt/akila-dv-logs-efs/tmpconvertedpdf
ls
echo "Finished !"
