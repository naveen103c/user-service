#!/bin/bash
#**********************************************
#Author:Govind Singh Mahara
#this script uses "convert.sh" to convert any file format to pdf
#source file directory:/mnt/akila-dv-logs-efs/tmpscanfiles/
#converted pdf file directory: /mnt/akila-dv-logs-efs/tmpconvertedpdf
#**********************************************
DIR_FILE_PICKED=/mnt/akila-dv-logs-efs/tmpscanfiles/
RESULT=$(ls $DIR_FILE_PICKED );
echo $RESULT;
if [ $(ls -1U $DIR_FILE_PICKED |wc -l ) -gt 0 ] ; 
then 
	fcount=$(ls -1U $DIR_FILE_PICKED |wc -l) ;

	echo "number of files in directory : $fcount "
cd $DIR_FILE_PICKED;
       	for file in *; 
 	do 
		file="${file}"; 
		file_to_be_converted=${file};
		file_pdf=${file}".pdf";
		echo "file for pdf conversion  $file_to_be_converted";
		echo "file pdf $file_pdf";
                sudo -S  /mnt/akila-dv-properties-efs/convertfile/convertfile.sh $file_to_be_converted $file_pdf  
		echo "Pdf Conversion Done for File : ${file}"; 
	done

	echo "All File are converted into  pdf! ";
else
	echo"These is no file for pdf conversion!"
fi
