package com.akila.file;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MediaServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
