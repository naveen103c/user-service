package com.akila.media;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaCommonsConfiguration;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@SpringBootApplication
@EnableEncryptableProperties
@EnableDiscoveryClient
@Import(AkilaCommonsConfiguration.class)
@PropertySources({
	@PropertySource("classpath:app.properties"),
	@PropertySource(name="prod", value = "file:${external.config}", ignoreResourceNotFound = true)
})
public class MediaServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediaServicesApplication.class, args);
	}

	@Bean("loadBalanced")
	@LoadBalanced
	public RestTemplate restTemplateLoadBalanced(RestTemplateBuilder builder) {
		return builder.build();
	}
}
