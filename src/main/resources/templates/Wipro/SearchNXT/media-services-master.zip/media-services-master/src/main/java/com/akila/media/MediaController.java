package com.akila.media;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.akila.commons.storage.bean.StorageResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;


@RestController
public class MediaController {
	private static final Logger logger = LogManager.getLogger(MediaController.class);
	
	@Autowired
	MediaSevices mediaSevices;
		
	@GetMapping(path = "/video")
	public ResponseEntity<StreamingResponseBody> getVideo(@RequestParam String videoName,@RequestHeader(value = "Range", required = false) String range) throws IOException {
		logger.info("MediaController:getVideo > videoName : "+videoName+" , Range : "+range);
		long rangeStart = 0;
        long rangeEnd;
        byte[] data;
        Long fileSize;
        
        StorageResponse res = mediaSevices.getVideoInputStream(videoName);
       
		if(res !=null && res.getDataStream() != null){
			 InputStream is = res.getDataStream();
			 if (range == null) {
				StreamingResponseBody responseBody = response -> {
					byte[] buf = new byte[is.available()];
				    int length;
				    while ((length = is.read(buf)) > 0) {
				    	response.write(buf, 0, length);
				    }
			     };
			     
			     return ResponseEntity.ok()
			           .contentType(MediaType.APPLICATION_OCTET_STREAM)
			           .body(responseBody);
			 } else {
				 	fileSize = res.getContentLenght();
				    String[] ranges = range.split("-");
		            rangeStart = Long.parseLong(ranges[0].substring(6));
		            if (ranges.length > 1) {
		                rangeEnd = Long.parseLong(ranges[1]);
		            } else {
		                rangeEnd = fileSize - 1;
		            }
		            if (fileSize < rangeEnd) {
		                rangeEnd = fileSize - 1;
		            }
		            
		            String contentLength = String.valueOf((rangeEnd - rangeStart) + 1);
		            ByteArrayOutputStream bufferedOutputStream = new ByteArrayOutputStream();
		            data = new byte[1024];
		            int nRead;
		            while ((nRead = is.read(data, 0, data.length)) != -1) {
		                bufferedOutputStream.write(data, 0, nRead);
		            }
		            bufferedOutputStream.flush();
		            byte[] result = new byte[(int) (rangeEnd - rangeStart) + 1];
		            System.arraycopy(bufferedOutputStream.toByteArray(), (int) rangeStart, result, 0, result.length);
		            StreamingResponseBody responseBody = response -> {
		            	response.write(result);
				     };
				     
		            return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT)
		                    .header("Content-Type",MediaType.APPLICATION_OCTET_STREAM.toString())
		                    .header("Accept-Ranges", "bytes")
		                    .header("Content-Length", contentLength)
		                    .header("Content-Range", "bytes" + " " + rangeStart + "-" + rangeEnd + "/" + fileSize)
		                    .body(responseBody);
			 }
		}else {
			return ResponseEntity.notFound().build();
		}
		
	}
	
	@GetMapping(path = "/media")
	public ResponseEntity<StreamingResponseBody> getEntContVideo(@RequestParam String videoUrl, 
			@RequestHeader(value = "Range", required = false) String range) throws IOException {
		logger.info("MediaController:getEntContVideo > VideoUrl : "+videoUrl+" , Range : "+range);
		long rangeStart = 0;
        long rangeEnd;
        byte[] data;
        Long fileSize;
        
        StorageResponse res = mediaSevices.getEntContVideoInputStream(videoUrl);
       
		if(res !=null && res.getDataStream() != null){
			 InputStream is = res.getDataStream();
			 if (range == null) {
				StreamingResponseBody responseBody = response -> {
					byte[] buf = new byte[is.available()];
				    int length;
				    while ((length = is.read(buf)) > 0) {
				    	response.write(buf, 0, length);
				    }
				    is.close();
			     };
			     
			     return ResponseEntity.ok()
			           .contentType(MediaType.APPLICATION_OCTET_STREAM)
			           .body(responseBody);
			 } else {
				 	fileSize = res.getContentLenght();
				    String[] ranges = range.split("-");
		            rangeStart = Long.parseLong(ranges[0].substring(6));
		            if (ranges.length > 1) {
		                rangeEnd = Long.parseLong(ranges[1]);
		            } else {
		                rangeEnd = rangeStart + 2000000; // fileSize - 1;
		            }
		            if (fileSize < rangeEnd) {
		                rangeEnd = fileSize - 1;
		            }
		            
		            long contentLength = (rangeEnd - rangeStart) + 1;
		            ByteArrayOutputStream bufferedOutputStream = new ByteArrayOutputStream();
		            data = new byte[1024];
		            int nRead;
		            is.skip(rangeStart);
		            long size = 0;
		            while ((nRead = is.read(data, 0, data.length)) != -1 && size <= contentLength) {
		                bufferedOutputStream.write(data, 0, nRead);
		                size += nRead; 
		            }
		            bufferedOutputStream.flush();
		            is.close();
		            byte[] result = new byte[(int) (rangeEnd - rangeStart) + 1];
		            System.arraycopy(bufferedOutputStream.toByteArray(), 0, result, 0, result.length);
		            StreamingResponseBody responseBody = response -> {
		            	response.write(result);
				     };
				     bufferedOutputStream.close();
				    HttpStatus status = HttpStatus.PARTIAL_CONTENT;
				    if(rangeEnd + 1 == fileSize) {
				    	//status = HttpStatus.OK;
				    }
		            return ResponseEntity.status(status)
		                    .header("Content-Type",MediaType.APPLICATION_OCTET_STREAM.toString())
		                    .header("Accept-Ranges", "bytes")
		                    .header("Content-Length", contentLength + "")
		                    .header("Content-Range", "bytes" + " " + rangeStart + "-" + rangeEnd + "/" + fileSize)
		                    .body(responseBody);
			 }
		}else {
			return ResponseEntity.notFound().build();
		}
		
	}
	/**
	 * New Method to get content as pdf
	 * @param contentId
	 * @param contentType
	 * @param formatType
	 * @param docType
	 * @param fileName
	 * @return stream of generated pdf
	 * @throws JsonMappingException
	 * @throws JsonProcessingException
	 */
	  
	@GetMapping(path = "/content/V2/{contentId}")
	public ResponseEntity<InputStreamResource> getOriginalContentAsPdf(@PathVariable String contentId, @RequestParam ( required = false) String contentType, 
			@RequestParam ( required = false) String formatType, @RequestParam ( required = false) String docType,
			@RequestParam String fileName) throws JsonMappingException, JsonProcessingException  {
		logger.info("content, contentId :  "+contentId+", fileName : "+fileName);
		StorageResponse res = null;
		//get file extension from file name 
		String fileExtension = mediaSevices.getFileExtension(fileName);
		logger.info("Media Servicve: File extension "+fileExtension);
 		// converting file to pdf and stream 
     	if(docType.equalsIgnoreCase("pdf") || docType.contains("pdf")
				||docType.equalsIgnoreCase("html")||docType.contains("html"))
		{	
			 res = mediaSevices.getContent(contentId,contentType,formatType, fileName);
		}
		else 
		{
			res = mediaSevices.getPdfContent(contentId,contentType,formatType);
			 
		}
		HttpHeaders headers = new HttpHeaders();
		if(fileName != null) {
			headers.add("Content-Disposition", "inline; filename="+fileName+".pdf");
		} else if(docType != null) {
			headers.add("Content-Disposition", "inline; filename="+contentId+".pdf");//+docType);
		} else {
			headers.add("Content-Disposition", "inline; filename="+contentId+".pdf");
		}
		
		if(formatType != null && formatType.equalsIgnoreCase("StandardHTML")) {
			fileName = fileName + ".html";
		}
	   return ResponseEntity
	                .ok()
	                .headers(headers)
	                .contentType(getContentType(fileName))
	                .body(new InputStreamResource(res.getDataStream()));
	}
	
	
	
	@GetMapping(path = "/content/{contentId}")
	public ResponseEntity<InputStreamResource> getOriginalContent(@PathVariable String contentId, @RequestParam ( required = false) String contentType, 
			@RequestParam ( required = false) String formatType, @RequestParam ( required = false) String docType,
			@RequestParam String fileName) throws JsonMappingException, JsonProcessingException  {
		logger.info("content, contentId :  "+contentId+", fileName : "+fileName);
		
		StorageResponse res = mediaSevices.getContent(contentId,contentType,formatType, fileName);
		
		HttpHeaders headers = new HttpHeaders();
		if(fileName != null) {
			headers.add("Content-Disposition", "inline; filename="+fileName);
		} else if(docType != null) {
			headers.add("Content-Disposition", "inline; filename="+contentId+"."+docType);
		} else {
			headers.add("Content-Disposition", "inline; filename="+contentId);
		}
		
		if(formatType != null && formatType.equalsIgnoreCase("StandardHTML")) {
			fileName = fileName + ".html";
		}
		
	     return ResponseEntity
	                .ok()
	                .headers(headers)
	                .contentType(getContentType(fileName))
	                .body(new InputStreamResource(res.getDataStream()));
	 
	}
	
	private MediaType getContentType(String fileName) {
		MediaType contentType = MediaType.APPLICATION_OCTET_STREAM;
		
		if(fileName != null && fileName.trim().length() > 0 && fileName.indexOf(".") > 0) {
			String extn = fileName.substring(fileName.lastIndexOf(".") + 1,fileName.length());
			logger.info("MediaController:getContentType, extn :  "+extn);
			if(extn.equalsIgnoreCase("doc")) {
				contentType = MediaType.valueOf("application/msword");
			} else if(extn.equalsIgnoreCase("docx")) {
				contentType = MediaType.valueOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
			} else if(extn.equalsIgnoreCase("pdf")) {
				contentType = MediaType.APPLICATION_PDF;
			} else if(extn.equalsIgnoreCase("xls")) {
				contentType = MediaType.valueOf("application/vnd.ms-excel");
			} else if(extn.equalsIgnoreCase("xlsx")) {
				contentType = MediaType.valueOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
			} else if(extn.equalsIgnoreCase("ppt")) {
				contentType = MediaType.valueOf("application/vnd.ms-powerpoint");
			} else if(extn.equalsIgnoreCase("pptx")) {
				contentType = MediaType.valueOf("application/vnd.openxmlformats-officedocument.presentationml.presentation");
			}else if(extn.equalsIgnoreCase("html")) {
				contentType = MediaType.valueOf("text/html");
			}else if(extn.equalsIgnoreCase("htm")) {
				contentType = MediaType.valueOf("text/html");
			} else if(extn.equalsIgnoreCase("txt")) {
				contentType = MediaType.valueOf("text/html");
			} else if(extn.equalsIgnoreCase("json")) {
				contentType = MediaType.APPLICATION_JSON;
			} else if(extn.equalsIgnoreCase("rtf")) {
				contentType = MediaType.valueOf("application/rtf") ;
			}else if(extn.equalsIgnoreCase("xml")) {
				contentType = MediaType.valueOf("application/xml") ;
			}
		} 
		logger.info("MediaController:getContentType, Content Type :  "+contentType.getType());
		
		return contentType;
	}
	
	@GetMapping(path = "/release-notes/{fileName}")
	public ResponseEntity<InputStreamResource> getReleaseNoteFile(@PathVariable String fileName) {
		logger.info("MediaController.getReleaseNoteFile: file name is : " + fileName);
		StorageResponse res = mediaSevices.getFileInputStream(fileName);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=" + fileName);
		return ResponseEntity.ok().headers(headers).contentType(getContentType(fileName))
				.body(new InputStreamResource(res.getDataStream()));

	}
}
