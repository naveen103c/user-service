package com.akila.media;
/* Modified for file to pdf converstion and stream back to UI"
 * Modified by: Govind [GSM]
 * copyright  Searchnxt */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.commons.storage.bean.StorageRequest;
import com.akila.commons.storage.bean.StorageResponse;
import com.akila.commons.storage.service.StorageFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class MediaSevices extends AkilaService{
	private static final Logger logger = LogManager.getLogger(MediaSevices.class);
	
	@Autowired
	StorageFactory S3StorageService;
	
	@Value("${static.content.bucket}")
	String bucket;
	
	@Value("${static.content.type}")
	String contentType;
	
	@Value("${static.content.format.type}")
	String formatType;
	
	@Value("${storage.service.name:s3}")
	private String StorageServiceName;
	
	@Value("${tmp.convertfile.location}")  //GSM
	String tmpConvertFileStoreLocation;  
	
	@Value("${convertfile.host.ip}")
	String serverHost;
	
	@Value("${convertfile.host.user:user}")
	String user;
	
	@Value("${convertfile.host.password:password}")
	String password;
	
	@Value("${convertfile.script.path:path}")
	String convertFileScript;
	
	@Value("${tmp.convertpdffile.location}")  //GSM
	String tmpconvertedpdfLocation;
	 
	
	int dealyForFile ; 
	
	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate loadBalancedRestTemplate;
	
	@Value("${platform.service.url}")
	private String platformServiceURL;
	
	@Autowired
	private AkilaRestTemplate akilaRestTemplate;
	
	@Value("${static.content.release.notes}")
	private String releaseNotes;
	
	public StorageResponse getVideoInputStream(String fileName){
		logger.info("MediaSevices:getVideoInputStream > Bucket Name : "+bucket+", Content Type : "+contentType+", Format Type : "+formatType+", Video Name : "+fileName);
		StorageRequest request = new StorageRequest();
		request.setOrgId(bucket);
		request.setContentType(contentType);
		request.setFormatType(formatType);
		request.setContentId(fileName);
		StorageResponse res = S3StorageService.getObject(request);
		return res;
	}
	
	public StorageResponse getEntContVideoInputStream(String videoUrl){
		logger.info("MediaSevices:getEntContVideoInputStream > videoUrl : "+videoUrl);
		
		StorageRequest request = new StorageRequest();
		logger.info("MediaSevices:getEntContVideoInputStream > StorageServiceName : "+StorageServiceName);
		if(StorageServiceName.equalsIgnoreCase("azure")) {
			request = getAzureContainDetains(videoUrl);
		} else {
			request = getS3ContainDetains(videoUrl);
		}
		logger.info("MediaSevices:getEntContVideoInputStream > bucketName : "+request.getOrgId());
		logger.info("MediaSevices:getEntContVideoInputStream > Content Type : "+request.getContentType()+", Format Type : "+request.getFormatType()+", Video Name : "+request.getContentId());
		
		StorageResponse res = S3StorageService.getObject(request);
		return res;
	}
	
	private StorageRequest getS3ContainDetains(String videoUrl) {
		StorageRequest request = new StorageRequest();
		String bucketName = videoUrl.substring(8, videoUrl.indexOf("."));
		String url = videoUrl.substring(videoUrl.indexOf("amazonaws.com")+14);
		logger.info("MediaSevices:getEntContVideoInputStream > url : "+url);
		String [] urls = url.split("/");
		request.setOrgId(bucketName);
		request.setContentType(urls[0]);
		request.setFormatType(urls[1]+"/"+urls[2]);
		request.setContentId(urls[3]);
		
		return request;
	}

	private static StorageRequest getAzureContainDetains(String videoUrl) {
		StorageRequest request = new StorageRequest();
		String url = videoUrl.substring(videoUrl.indexOf("blob.core.windows.net")+22);
		logger.info("MediaSevices:getEntContVideoInputStream > url : "+url);
		String [] urls = url.split("/");
		request.setOrgId(urls[0]);
		request.setContentType(urls[1]);
		request.setFormatType(urls[2]+"/"+urls[3]);
		request.setContentId(urls[4]);
		return request;
	}
	/**
	 * [GSM] created for  converter for all type of files into pdf 
	 * @param contentId
	 * @param contentType
	 * @param formatType
	 * @return Object of StorageResponse with stream of pdf fiels.
	 * @throws JsonMappingException
	 * @throws JsonProcessingException
	 */
	
	public StorageResponse getPdfContent(String contentId, String contentType, String formatType) throws JsonMappingException, JsonProcessingException {
		logger.info("MediaSevices:getContent > contentId : " + contentId + ", Content Type : " + contentType
				+ ", Format Type : " + formatType);
		StorageRequest request = new StorageRequest();
		StorageResponse resPdf = new StorageResponse();
		String bucket = "whrs-bu-in";
		bucket = getS3BucketName();
		logger.info("MediaSevices:getContent > contentId : " + contentId + ", Bucket Name : " + bucket);
		request.setOrgId(bucket);
		if (formatType != null) {
			request.setFormatType(formatType);
		} else {
			request.setFormatType("original");
		}
		if (contentType != null) {
			request.setContentType(contentType);
		} else {
			request.setContentType("ent-cont");
		}
		logger.info("MediaSevices:getContent > contentId : " + contentId + ", ContentType : " + request.getContentType());
		logger.info("MediaSevices:getContent > contentId : " + contentId + ", formatType : " + request.getFormatType());
		request.setContentId(contentId);
		StorageResponse res = S3StorageService.getObject(request);
		logger.info("MediaSevices:getContent > contentId : " + contentId + ", Response : " + res);
		boolean result = false;
		File f = null;
		try {
			try {
				String fname = tmpConvertFileStoreLocation + File.separator + contentId;
				logger.info("MediaServices:created file name :" + fname);
				f = new File(fname);
			} catch (Exception ex) {
				logger.info("MediaServices:path is not coming correctly :");
			}
			// saving file in content directory which is /mnt/..
			logger.info("MediaServices:ready for outstream");
			OutputStream out = new FileOutputStream(f);
			logger.info("MediaServices:ConvertFile : downloading file to temp location for converting to pdf orignal file name : "
					+ contentId);
			int bytes = IOUtils.copy(res.getDataStream(), out);
			out.close();
			
			if (bytes == -1) {
				// file not copied
				logger.info("MediaServices: File Not copied");
			} else {
				dealyForFile = bytes/ 10; 
				logger.info("MediaServices: Bytes calculated :"+ dealyForFile);
				//recheck file presence
			    String tmpfilename = tmpconvertedpdfLocation+File.separator+contentId+"."+"pdf";
				for (  int retryCount =0 ; retryCount< 3 ;retryCount++ )
				{
					try {
						Thread.sleep(30000); //wait for 
						logger.info("MediaServices: : Checking for pdf availablity "+tmpfilename);
						File pdfFile  =new File(tmpfilename);
						if (pdfFile.exists() )
						{
							result = true;
							logger.info("MediaServices: :  pdf availablity ");
							break;
						}
						}catch (Exception ex) {
							logger.error("MediaServices: : ERROR Pdf not available checking again for availablity ");
							continue;
						}
				}
				 
				if (result) {
					logger.info("MediaServices:File available in path :" + tmpfilename);
					//creating stream for response
					String pdfFilename = tmpconvertedpdfLocation + "/" + contentId + "." + "pdf";
					logger.info("MediaServices:File available in path :" + pdfFilename);
					InputStream in = new FileInputStream(pdfFilename);
					if (in.available() > 0) {
						resPdf.setDataStream(in);
						resPdf.setVersionId("");
						//deleting file original file as pdf is generated and file  is stream 
						File downloadedFile = new File( tmpConvertFileStoreLocation + File.separator + contentId);
						try {
								if (downloadedFile.delete()) // returns Boolean value
								{
									logger.info("MediaServices: File Deleted from path :" + downloadedFile.getName() + " deleted"); 
								} 
								else 
								{
									logger.info("MediaService:  File Deleting failed !!" + downloadedFile.getName());
								}
							}
						catch (Exception ex) {
							logger.info("MediaService: Exception File Deleting failed !!" + downloadedFile.getName());
						}
					} else {
						logger.info("MediaServices:there is no stream for access !!", pdfFilename);
					}
				} else {

				}
			}
		} catch (Exception ex) {
			logger.error("MediaService :ConvertFile : downloading file to temp location for converting to pdf got error content id: "
					+ contentId);
		}
		return resPdf;
	}
	
	public StorageResponse getContent(String contentId, String contentType, String formatType, String fileName) throws JsonMappingException, JsonProcessingException {
		logger.info("MediaSevices:getContent > contentId : "+contentId+", Content Type : "+contentType+", Format Type : "+formatType + ", File Name : "+fileName);
		StorageRequest request = new StorageRequest();
		String bucket="whrs-bu-in";
		bucket = getS3BucketName();
		
		logger.info("MediaSevices:getContent > contentId : "+contentId+", Bucket Name : "+bucket);
		
		request.setOrgId(bucket);
		
		if(formatType != null) {
			request.setFormatType(formatType+ "/" + contentId);
		}else {
			request.setFormatType("original" +"/"+ contentId);
		}
		if(contentType != null) {
			request.setContentType(contentType);
		}else {
			request.setContentType("ent-cont");
		}
		logger.info("MediaSevices:getContent > contentId : "+contentId+", ContentType : "+request.getContentType());
		logger.info("MediaSevices:getContent > contentId : "+contentId+", formatType : "+request.getFormatType());
		request.setContentId(fileName);
		StorageResponse res = S3StorageService.getObject(request);
		logger.info("MediaSevices:getContent > contentId : "+contentId+", Response : "+res);
		return res;
	}
		
	private String getS3BucketName() throws JsonMappingException, JsonProcessingException {
		ResponseEntity<String> response = akilaRestTemplate.getForEntity(loadBalancedRestTemplate, platformServiceURL + "/orgs/" + getOrgId(), String.class);
		String responseBody = response.getBody();
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode node = objectMapper.readTree(responseBody);
		String ssStorageFolder = node.get("storageFolderNm").asText();
		logger.info("MediaSevices:s3StorageFolder : "+ssStorageFolder+". OrgId : "+getOrgId());
		return ssStorageFolder;
	}
	public  String getFileExtension(String fileName) {
        if (fileName == null) {
        	logger.info("MediaServiceController: fileName must not be null!");
        }

        String extension = "";

        int index = fileName.lastIndexOf('.');
        if (index > 0) {
            extension = fileName.substring(index + 1);
        }

        return extension;

    }
	
	public StorageResponse getFileInputStream(String fileName){
		logger.info("MediaSevices:getFileInputStream > Bucket Name : "+bucket+", Content Type : "+contentType+", Format Type : "+formatType+", Video Name : "+fileName);
		StorageRequest request = new StorageRequest();
		request.setOrgId(bucket);
		request.setContentType(contentType);
		request.setFormatType(releaseNotes);
		request.setContentId(fileName);
		StorageResponse res = S3StorageService.getObject(request);
		return res;
	}
}
