#!/bin/bash

while true
do
	echo "starting script "
	/mnt/akila-dv-properties-efs/convertfile/pdfwatcher.sh 
	echo "called !"
	sleep 5;
done
