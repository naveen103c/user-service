package com.akila.metricservices.brainindexmetric;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.metricservices.brainindexmetric.bean.BrainIndexMetricCommunityResponse;
import com.akila.metricservices.brainindexmetric.bean.BrainIndexMetricResponse;
import com.akila.metricservices.entity.OrgCommunitySmePK;
import com.akila.metricservices.entity.OrgUserMetric;
import com.akila.metricservices.entity.OrgUserMetricPK;
import com.akila.metricservices.repository.OrgCommunitySmeRepository;
import com.akila.metricservices.repository.OrgUserMetricRepository;
import com.akila.utility.MetricServiceUtility;

@Service
public class BrainindexmetricService extends AkilaService {

	@Autowired
	private OrgCommunitySmeRepository orgCommunitySmeRepository;

	@Autowired
	private OrgUserMetricRepository orgUserMetricRepository;

	public List<BrainIndexMetricResponse> getUserActivityMetric(String id, Integer periodCd, Integer count) {
		List<String> userIds = new ArrayList<String>();
		userIds.add(id);
		List<OrgUserMetric> orgUserMetricList = orgUserMetricRepository.getUserActivityById(userIds, periodCd);
		return getBrainIndexMetricResponseList(orgUserMetricList);
	}

	public BrainIndexMetricResponse getUserSkillScoreMetric(String id, Integer periodCd, String count) {
		return null;
	}

	public List<BrainIndexMetricCommunityResponse> getCommunityActivityMetric(String id, Integer periodCd,
			String count) {

		List<String> userIds = orgCommunitySmeRepository.getUserIds(id);
		List<OrgUserMetric> orgUserMetricList = orgUserMetricRepository.getUserActivityById(userIds, periodCd);

		return getBrainIndexMetricCommunityResponseList(orgUserMetricList);
	}

	public BrainIndexMetricResponse getCommunitySkillScoreMetric(String id, Integer periodCd, String count) {
		return null;
	}

	public OrgUserMetricPK getOrgUserMetricPK(String id, Integer periodCd) {
		OrgUserMetricPK orgUserMetricPK = new OrgUserMetricPK();
		orgUserMetricPK.setMetricPeriodCd(periodCd);
		orgUserMetricPK.setUserId(id);
		return orgUserMetricPK;
	}

	public OrgCommunitySmePK getOrgCommunitySmePK(String communityId, String userId) {
		OrgCommunitySmePK orgCommunitySmePK = new OrgCommunitySmePK();
		orgCommunitySmePK.setCommunityId(communityId);
		orgCommunitySmePK.setUserId(userId);
		return orgCommunitySmePK;
	}

	public List<BrainIndexMetricResponse> getBrainIndexMetricResponseList(List<OrgUserMetric> orgUserMetricList) {

		List<BrainIndexMetricResponse> brainIndexMetricResponseList = new ArrayList<BrainIndexMetricResponse>();
		for (OrgUserMetric userMetric : orgUserMetricList) {
			BrainIndexMetricResponse brainIndexMetricResponse = new BrainIndexMetricResponse();
			brainIndexMetricResponse.setAnswerCt(MetricServiceUtility.getValue(userMetric.getAnswerCt()));
			brainIndexMetricResponse.setCommentCt(MetricServiceUtility.getValue(userMetric.getCommentCt()));
			brainIndexMetricResponse.setMetricPeriodDt(
					MetricServiceUtility.getValue(userMetric.getId().getMetricPeriodDt().toString()));
			brainIndexMetricResponse.setQueryCt(MetricServiceUtility.getValue(userMetric.getQueryCt()));
			brainIndexMetricResponse.setSessionCt(MetricServiceUtility.getValue(userMetric.getSessionCt()));
			brainIndexMetricResponse.setWikiCt(MetricServiceUtility.getValue(userMetric.getWikiCt()));

			brainIndexMetricResponseList.add(brainIndexMetricResponse);
		}

		return brainIndexMetricResponseList;
	}

	public List<BrainIndexMetricCommunityResponse> getBrainIndexMetricCommunityResponseList(
			List<OrgUserMetric> orgUserMetricList) {

		List<BrainIndexMetricCommunityResponse> brainIndexMetricCommunityResponseList = new ArrayList<BrainIndexMetricCommunityResponse>();
		for (OrgUserMetric userMetric : orgUserMetricList) {
			BrainIndexMetricCommunityResponse brainIndexMetricCommunityResponse = new BrainIndexMetricCommunityResponse();
			brainIndexMetricCommunityResponse.setUserId(MetricServiceUtility.getValue(userMetric.getId().getUserId()));
			brainIndexMetricCommunityResponse.setAnswerCt(MetricServiceUtility.getValue(userMetric.getAnswerCt()));
			brainIndexMetricCommunityResponse.setCommentCt(MetricServiceUtility.getValue(userMetric.getCommentCt()));
			brainIndexMetricCommunityResponse.setMetricPeriodDt(
					MetricServiceUtility.getValue(userMetric.getId().getMetricPeriodDt().toString()));
			brainIndexMetricCommunityResponse.setQueryCt(MetricServiceUtility.getValue(userMetric.getQueryCt()));
			brainIndexMetricCommunityResponse.setSessionCt(MetricServiceUtility.getValue(userMetric.getSessionCt()));
			brainIndexMetricCommunityResponse.setWikiCt(MetricServiceUtility.getValue(userMetric.getWikiCt()));

			brainIndexMetricCommunityResponseList.add(brainIndexMetricCommunityResponse);
		}

		return brainIndexMetricCommunityResponseList;
	}

}
