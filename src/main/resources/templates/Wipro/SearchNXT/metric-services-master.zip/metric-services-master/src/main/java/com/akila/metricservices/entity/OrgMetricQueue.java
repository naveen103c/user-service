package com.akila.metricservices.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="org_metric_queue")
public class OrgMetricQueue implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="metric_id")
	String metricId;
	
	@Column(name="service_nm")
	String serviceNm;
	
	@Column(name="metric_json")
	String metricJson;
	
	@Column(name="crt_ts")
	Timestamp crtTs;
	
	@Column(name="status")
	int status = 0;

	public String getMetricId() {
		return metricId;
	}

	public void setMetricId(String metricId) {
		this.metricId = metricId;
	}

	public String getServiceNm() {
		return serviceNm;
	}

	public void setServiceNm(String serviceNm) {
		this.serviceNm = serviceNm;
	}

	public String getMetricJson() {
		return metricJson;
	}

	public void setMetricJson(String metricJson) {
		this.metricJson = metricJson;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
	
}
