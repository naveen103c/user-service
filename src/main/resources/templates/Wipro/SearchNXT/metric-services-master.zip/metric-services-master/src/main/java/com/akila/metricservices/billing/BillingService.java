package com.akila.metricservices.billing;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.JDBCException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.metricservices.billing.bean.BillingResponse;
import com.akila.metricservices.entity.BaseServices;
import com.akila.metricservices.entity.OrgMonthlyInvoice;
import com.akila.metricservices.entity.OrgMonthlyInvoiceDetails;
import com.akila.metricservices.repository.BaseServiceRepository;
import com.akila.metricservices.repository.OrgCommunityRepository;
import com.akila.metricservices.repository.OrgMonthlyInvoiceDetailsRepository;
import com.akila.metricservices.repository.OrgMonthlyInvoiceRepository;
import com.akila.metricservices.repository.OrgUserGroupsRepository;
import com.akila.metricservices.repository.OrgUsersRepository;
import com.akila.metricservices.servicemetric.PlanService;
import com.akila.metricservices.servicemetric.ServiceMetricService;
import com.akilacommons.tenant.TenantContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class BillingService extends AkilaService {

	private static final Logger logger = LogManager.getLogger(BillingService.class);
	@Autowired
	protected BaseServiceRepository baseServiceRepository;

	@Autowired
	ServiceMetricService serviceMetricService;
	
	@Autowired
	OrgMonthlyInvoiceRepository orgMonthlyInvoiceRepository;
	
	@Autowired
	OrgMonthlyInvoiceDetailsRepository orgMonthlyInvoiceDetailsRepository;
	
	@Autowired
	OrgUsersRepository orgUsersRepository;
	
	@Autowired
	OrgUserGroupsRepository orgUserGroupsRepository;

	@Autowired
	OrgCommunityRepository orgCommunityRepository;
	
	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate restTemplate;
	
	@Value("${platform.billing.url}")
	private String platformBillingDetailsUrl;
	
	@Autowired
	private AkilaRestTemplate akilaRestTemplate;
	
	public BillingResponse getUsageBill(@RequestParam Integer periodCd, @RequestParam String count) {
		return null;
	}

	public BillingResponse getHistoryAndForecast(@RequestParam Integer periodCd, @RequestParam String count) {
		return null;
	}

	public BillingResponse getBudgetAndUsages(@RequestParam Integer periodCd, @RequestParam String count) {
		return null;
	}

	public BillingResponse getBillPaymentHistory(@RequestParam Integer periodCd, @RequestParam String count) {
		return null;
	}

	public List<PlanService> getInvoiceDetails(Integer month, Integer year)
			throws HttpStatusCodeException, NullPointerException, JDBCException, Exception {
		
		if(isCurrentMonth(month, year)) {
			return getMonthlyBill(month,year);
		}else {
			
			OrgMonthlyInvoice orgMonthlyInvoice = orgMonthlyInvoiceRepository.findByInvoiceMonthAndInvoiceYear(month, year);
			if(orgMonthlyInvoice !=null) {
				return getPreviousMonthBill(orgMonthlyInvoice,month,year);
			}else {
				return getMonthlyBill(month,year);
			}
		}

	}

	public List<PlanService> getPreviousMonthBill(OrgMonthlyInvoice orgMonthlyInvoice, int month, int year)
			throws JsonMappingException, JsonProcessingException {

		List<PlanService> servicesList = new ArrayList<PlanService>();
		List<OrgMonthlyInvoiceDetails> orgMonthlyInvoiceDetailsList = orgMonthlyInvoiceDetailsRepository
				.findByInvoiceId(orgMonthlyInvoice.getInvoiceId());
		for (OrgMonthlyInvoiceDetails orgMonthlyInvoiceDetails : orgMonthlyInvoiceDetailsList) {
			PlanService planService = new PlanService();
			planService.setId(orgMonthlyInvoiceDetails.getServiceId());
			planService.setDescription(orgMonthlyInvoiceDetails.getServiceNm());
			planService.setLabelName("Service Name");
			planService.setAttributeName("serviceName");
			planService.setLabelValue(orgMonthlyInvoiceDetails.getServiceNm());
			planService.getDetails().add(getPlanDetails("Volume Limit", "serviceVolumeLimit",
					orgMonthlyInvoiceDetails.getServiceLimit() + ""));
			planService.getDetails().add(getPlanDetails("Unit Price ($)", "serviceUnitPrice",
					orgMonthlyInvoiceDetails.getServiceUnitPrice() + ""));
			planService.getDetails().add(getPlanDetails("Volume Price ($)", "serviceVolumePrice",
					orgMonthlyInvoiceDetails.getServieVolumePrice() + ""));
			planService.getDetails().add(getPlanDetails("Utilization", "serviceUtilization",
					orgMonthlyInvoiceDetails.getServiceUtilizaton() + ""));
			planService.getDetails().add(getPlanDetails("Utilization Unit", "serviceUtilizationUnit",
					orgMonthlyInvoiceDetails.getServiceUtilizatonUnit() + ""));
			planService
					.getDetails().add(
							getPlanDetails(
									"Price", "servicePrice", String
											.valueOf(Double.valueOf(orgMonthlyInvoiceDetails.getServiceUtilizatonUnit())
													* Double.valueOf(orgMonthlyInvoiceDetails.getServiceUnitPrice()))
											+ ""));
			servicesList.add(planService);
		}
		return servicesList;
	}
	
	
	public List<PlanService> getMonthlyBill(int month, int year) throws JsonMappingException, JsonProcessingException {

		HttpHeaders headers = new HttpHeaders();
		headers.add("tenant", TenantContext.getCurrentTenant());
		headers.add("accept", "*/*");
		HttpEntity<String> entity = new HttpEntity<String>("service-plans", headers);
		ResponseEntity<String> response = akilaRestTemplate.exchange(restTemplate, platformBillingDetailsUrl + month + "/" + year,
				HttpMethod.GET, entity, String.class);
		String body = response.getBody();
		ObjectMapper mapper = new ObjectMapper();
		List<PlanService> servicesList = mapper.readValue(body,
				mapper.getTypeFactory().constructCollectionType(List.class, PlanService.class));
		Map<String, String> allServices = getAllServiceMetric();
		Map<String, Map<String, String>> utilizationMap = serviceMetricService
				.getMonthWiseServiceMetrics(new ArrayList<>(allServices.values()), month, year);

		for (PlanService planService : servicesList) {
			if (planService.getLabelValue().toLowerCase().contains("users")) {
				String serviceId = allServices.get("Metric-Users");
				int count = orgUsersRepository.getActiveUserQuota();
				planService.getDetails().add(getPlanService(count + ""));
				planService.getDetails().add(getPlanServiceUnit(getValue(utilizationMap, serviceId)));
				planService.getDetails().add(getPlanPrice(planService.getDetails(), count + ""));
			} else if (planService.getLabelValue().toLowerCase().contains("search")) {// search count
				String serviceId = allServices.get("Metric-Search-Count");
				planService.getDetails().add(getPlanService(getValue(utilizationMap, serviceId)));
				planService.getDetails().add(getPlanServiceUnit(getValue(utilizationMap, serviceId)));
				planService.getDetails()
						.add(getPlanPrice(planService.getDetails(), getValue(utilizationMap, serviceId)));
			} else if (planService.getLabelValue().toLowerCase().contains("wiki")) {// wiki count
				String serviceId = allServices.get("Metric-Wiki-Published");
				String wiki = getValue(utilizationMap, serviceId);
				String serviceId1 = allServices.get("Metric-Queries-Answered");
				String queryA = getValue(utilizationMap, serviceId1);
				String serviceId2 = allServices.get("Metric-Queries-Unanswered");
				String queryU = getValue(utilizationMap, serviceId2);
				int sum = 0;
				if (wiki != null) {
					sum = sum + Integer.parseInt(wiki);
				}
				if (queryA != null) {
					sum = sum + Integer.parseInt(queryA);
				}
				if (queryU != null) {
					sum = sum + Integer.parseInt(queryU);
				}

				planService.getDetails().add(getPlanService("" + sum));
				planService.getDetails().add(getPlanServiceUnit("" + sum));
				planService.getDetails().add(getPlanPrice(planService.getDetails(), "" + sum));
			} else if (planService.getLabelValue().toLowerCase().contains("text")) {// text content sync hours
				String serviceId = allServices.get("Metric-Text-Content-Sync-Hours");
				String val = getValue(utilizationMap, serviceId);
				String tempVal = "0";
				if (val != null) {
					long milliseconds = Long.parseLong(val);
					tempVal = getMintes(milliseconds);
					long minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
					if (minutes == 0) {
						long sec = TimeUnit.MILLISECONDS.toSeconds(milliseconds);
						if (sec == 0) {
							val = milliseconds + " MS";
						} else {
							val = sec + " S";
						}
					} else {
						val = minutes + " M";
					}

				} else {
					val = "0";
				}
				planService.getDetails().add(getPlanService(val));
				planService.getDetails().add(getPlanServiceUnit(tempVal));
				planService.getDetails().add(getPlanPrice(planService.getDetails(), tempVal));
			} else if (planService.getLabelValue().toLowerCase().contains("audio")
					|| planService.getLabelValue().toLowerCase().contains("media")) {// audio/Video content Sync
				String serviceId = allServices.get("Metric-Media-Content-Sync-Hours");
				String val = getValue(utilizationMap, serviceId);
				String tempVal = "0";
				if (val != null) {
					long milliseconds = Long.parseLong(val);
					tempVal = getMintes(milliseconds);
					long minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
					if (minutes == 0) {
						long sec = TimeUnit.MILLISECONDS.toSeconds(milliseconds);
						if (sec == 0) {
							val = milliseconds + " MS";
						} else {
							val = sec + " S";
						}
					} else {
						val = minutes + " M";
					}
				} else {
					val = "0";
				}
				planService.getDetails().add(getPlanService(val));
				planService.getDetails().add(getPlanServiceUnit(tempVal));
				planService.getDetails().add(getPlanPrice(planService.getDetails(), tempVal));
			} else if (planService.getLabelValue().toLowerCase().contains("storage")) {// enterprise Content Storage
				String serviceId = allServices.get("Metric-Enterprise-Content-Storage");
				String val = getValue(utilizationMap, serviceId);
				String tempVal = "0";
				if (val != null) {
					long longVal = Long.parseLong(val);
					val = getSize(longVal);
					tempVal = getSizeInGb(longVal);
				} else {
					val = "0 B";
				}
				planService.getDetails().add(getPlanService(val));
				planService.getDetails().add(getPlanServiceUnit(tempVal));
				planService.getDetails().add(getPlanPrice(planService.getDetails(), tempVal));
			} else if (planService.getLabelValue().toLowerCase().contains("metric-community")) {
				String serviceId = allServices.get("Metric-Community");
				int count = orgCommunityRepository.getCommunityQuota();
				planService.getDetails().add(getPlanService(count + ""));
				planService.getDetails().add(getPlanServiceUnit(getValue(utilizationMap, serviceId)));
				planService.getDetails().add(getPlanPrice(planService.getDetails(), count + ""));
			} else if (planService.getLabelValue().toLowerCase().contains("metric-user-group")) {
				String serviceId = allServices.get("Metric-User-Group");
				int count = orgUserGroupsRepository.getGroupQuota();
				planService.getDetails().add(getPlanService(count + ""));
				planService.getDetails().add(getPlanServiceUnit(getValue(utilizationMap, serviceId)));
				planService.getDetails().add(getPlanPrice(planService.getDetails(), count + ""));
			}
		}
		return servicesList;
	}
	
	public boolean isCurrentMonth(int month,int year) {
		java.util.Date date = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int currentMonth = cal.get(Calendar.MONTH)+1;
		int currentYear = cal.get(Calendar.YEAR);
		if(month == currentMonth && year == currentYear)
			return true;
		else
			return false;
	}

	public Map<String, String> getAllServiceMetric() {
		List<BaseServices> baseServicesList = baseServiceRepository.findAll();
		Map<String, String> data = new HashMap<String, String>();
		for (BaseServices baseService : baseServicesList) {
			data.put(baseService.getServiceNm(), baseService.getServiceId());
		}
		return data;
	}

	private String getValue(Map<String, Map<String, String>> utilizationMap, String serviceId) {
		if (serviceId != null && utilizationMap.containsKey(serviceId)) {
			Map<String, String> utlz = utilizationMap.get(serviceId);
			try {
				return utlz.entrySet().iterator().next().getValue();
			} catch (NullPointerException e) {
				logger.error("BillingService.getValue, Error : " + e.getMessage(), e);
			} catch (Exception e) {
				logger.error("BillingService.getValue, Error : " + e.getMessage(), e);
			}
		}

		return null;
	}

	private PlanService getPlanService(String value) {
		PlanService service = new PlanService();
		service.setLabelName("Utilization");
		service.setAttributeName("serviceUtilization");
		if (value != null) {
			service.setLabelValue(value);
		} else {
			service.setLabelValue("0");
		}

		return service;
	}
	
	private PlanService getPlanDetails(String labelName,String attributeName,String value) {
		PlanService service = new PlanService();
		service.setLabelName(labelName);
		service.setAttributeName(attributeName);
		if (value != null) {
			service.setLabelValue(value);
		} else {
			service.setLabelValue("0");
		}

		return service;
	}

	private PlanService getPlanPrice(List<PlanService> planServiceList, String usedUnit) {

		String price = "0";

		for (PlanService planService : planServiceList) {
			if (planService.getAttributeName().equalsIgnoreCase("serviceUnitPrice")) {
				price = planService.getLabelValue();
				break;
			}
		}

		PlanService service = new PlanService();
		service.setLabelName("Price");
		service.setAttributeName("servicePrice");
		if (usedUnit != null) {
			service.setLabelValue(String.valueOf(new DecimalFormat("######.####").format(Double.valueOf(usedUnit) * Double.valueOf(price))));
		} else {
			service.setLabelValue("0");
		}

		return service;
	}

	private PlanService getPlanServiceUnit(String value) {
		PlanService service = new PlanService();
		service.setLabelName("Utilization Unit");
		service.setAttributeName("serviceUtilizationUnit");
		if (value != null) {
			service.setLabelValue(value);
		} else {
			service.setLabelValue("0");
		}

		return service;
	}

	public static String getSize(long size) {
		long n = 1024;
		String s = "";
		double kb = size / n;
		double mb = kb / n;
		double gb = mb / n;
		double tb = gb / n;
		if (size < n) {
			s = size + " Bytes";
		} else if (size >= n && size < (n * n)) {
			s = String.format("%.2f", kb) + " KB";
		} else if (size >= (n * n) && size < (n * n * n)) {
			s = String.format("%.2f", mb) + " MB";
		} else if (size >= (n * n * n) && size < (n * n * n * n)) {
			s = String.format("%.2f", gb) + " GB";
		} else if (size >= (n * n * n * n)) {
			s = String.format("%.2f", tb) + " TB";
		}
		return s;
	}

	public static String getSizeInGb(long bytes) {
		long n = 1024;
		String s = "";
		double kb = bytes / n;
		double mb = kb / n;
		double gb = mb / n;
		s = String.format("%.2f", gb);

		return s;
	}

	public static String getMintes(long milliseconds) {
		long n = 1000;
		String s = "";
		double sec = milliseconds / n;
		double mins = sec / 60;
		s = String.format("%.2f", mins);

		return s;
	}

}
