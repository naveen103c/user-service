package com.akila.metricservices.servicemetric;

import java.util.ArrayList;
import java.util.List;

public class PlanService {
	
	String id = "";
	String labelName;
	String attributeName;
	String labelValue;
	String description = "";
	List<PlanService> details = new ArrayList<PlanService>();
	
	public String getLabelName() {
		return labelName;
	}
	public void setLabelName(String labelName) {
		this.labelName = labelName;
	}
	public String getAttributeName() {
		return attributeName;
	}
	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}
	public String getLabelValue() {
		return labelValue;
	}
	public void setLabelValue(String labelValue) {
		this.labelValue = labelValue;
	}
	public List<PlanService> getDetails() {
		return details;
	}
	public void setDetails(List<PlanService> details) {
		this.details = details;
	}
	
	public void addDetails(PlanService detail) {
		if(this.details == null){
			this.details = new ArrayList<PlanService>();
		}
		this.details.add(detail);
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

}
