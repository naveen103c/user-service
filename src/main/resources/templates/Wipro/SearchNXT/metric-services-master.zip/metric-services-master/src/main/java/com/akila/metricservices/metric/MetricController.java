package com.akila.metricservices.metric;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.metricservices.entity.OrgUserMetric;
import com.akila.metricservices.metric.bean.ContentMetricRequest;
import com.akila.metricservices.metric.bean.MetricContentResponse;
import com.akila.metricservices.metric.bean.MetricResponse;
import com.akila.metricservices.metric.bean.SearchTermMetricRequest;
import com.akila.response.ResponseId;

@RestController
public class MetricController extends AkilaController 
{
	
  @Autowired
  private MetricService metricService;

  @GetMapping(
      path = "/metric/content/{id}"
  )
  public MetricContentResponse getContentMetric(@PathVariable String id) {
    return metricService.getContentMetric(id);
  }

  @PutMapping(
      path = "/metric/content/{id}"
  )
  public ResponseId updateContentMetric(@PathVariable String id,
      @RequestBody ContentMetricRequest metricRequest) {
    return metricService.updateContentMetric(id, metricRequest);
  }

  @PostMapping(
      path = "/metric/content/{id}"
  )
  public ResponseId createContentMetric(@PathVariable String id,
      @RequestBody(required = false) ContentMetricRequest metricRequest) {
    return metricService.createContentMetric(id, metricRequest);
  }
  
  @PostMapping(path = "/metric/searchterm")
  public ResponseId createSearchTermMetric(@RequestBody(required = true) SearchTermMetricRequest request) {
    return metricService.createSearchTermMetric(request);
  }
  
  @GetMapping(
      path = "/metric/org"
  )
  public MetricResponse getOrgServiceMetric(@RequestParam String level, @RequestParam String metrictype) {
    return metricService.getOrgServiceMetric(level, metrictype);
  }

  @GetMapping(
      path = "/metric/users/{id}"
  )
  public OrgUserMetric getUserMetric(@PathVariable String id) {
    return metricService.getUserMetric(id);
  }

  @GetMapping(
      path = "/metric/users"
  )
  public MetricResponse getOrgUsersMetric() {
    return metricService.getOrgUsersMetric();
  }
  
  @PostMapping(
      path = "/metric/fav/{id}"
  )
  public void updateFavOrgContentMetric(@PathVariable String id) {
     metricService.updateFavOrgContentMetric(id);
  }
  
  @PostMapping(
	      path = "/metric/fav/{id}/remove"
	  )
	  public void removeFavOrgContentMetric(@PathVariable String id) {
	     metricService.removeFavOrgContentMetric(id);
  }
  
  @PostMapping(
      path = "/metric/interaction/{id}"
  )
  public void updateInteractionOrgContentMetric(@PathVariable String id) {
     metricService.updateInteractionOrgContentMetric(id);
  }
  
  @PostMapping(
      path = "/metric/vote/{id}"
  )
  public void updateVoteOrgContentMetric(@PathVariable String id,@RequestParam String vote, @RequestParam String type) {
     metricService.updateVoteOrgContentMetric(id,vote,type);
  }
}
