// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// ----------------------------------------------------------------------------

package com.akila.metricservices.powerbi;

import java.net.MalformedURLException;
import java.util.Collections;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;

/**
 * Service to authenticate using MSAL
 */
@Service
public class AzureADService {
	static final Logger logger = LoggerFactory.getLogger(AzureADService.class);

	@Value("${powerbi.tenantId}")
	private String tenantId;

	@Value("${powerbi.clientId}")
	private String clientId;

	@Value("${powerbi.appSecret}")
	private String appSecret;
	
	public static final String authorityUrl = "https://login.microsoftonline.com/";
	public static final String scopeUrl = "https://analysis.windows.net/powerbi/api/.default";

	/**
	 * Acquires access token for the based on config values
	 * 
	 * @return AccessToken
	 */
	public String getAccessToken() throws MalformedURLException, InterruptedException, ExecutionException 
	{

		if (tenantId.isEmpty()) {
			throw new RuntimeException("Tenant Id is empty");
		}
		return getAccessTokenUsingServicePrincipal(clientId, tenantId, appSecret);

	}

	/**
	 * Acquires access token for the given clientId and app secret
	 * 
	 * @param clientId
	 * @param tenantId
	 * @param appSecret
	 * @return AccessToken
	 */
	private String getAccessTokenUsingServicePrincipal(String clientId, String tenantId, String appSecret)
			throws MalformedURLException, InterruptedException, ExecutionException {

		// Build Confidential Client App
		ConfidentialClientApplication app = ConfidentialClientApplication
				.builder(clientId, ClientCredentialFactory.createFromSecret(appSecret))
				.authority(authorityUrl + tenantId).build();

		ClientCredentialParameters clientCreds = ClientCredentialParameters
				.builder(Collections.singleton(scopeUrl)).build();

		// Acquire new AAD token
		IAuthenticationResult result = app.acquireToken(clientCreds).get();

		// Return access token if token is acquired successfully
		if (result != null && result.accessToken() != null && !result.accessToken().isEmpty()) {
				logger.info("Authenticated with Service Principal mode");
			return result.accessToken();
		} else {
			logger.error("Failed to authenticate with Service Principal mode");
			return null;
		}
	}

	
}