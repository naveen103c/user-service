package com.akila.metricservices.repository;
import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.expertconnect.entity.OrgAppointment;

@Repository
public interface OrgAppointmentRepository extends JpaRepository<OrgAppointment, UUID> {
	
	@Query(value= "SELECT CONCAT(u.user_first_nm,' ', u.user_last_nm) as name, COUNT(o.appointment_id) FROM org_appointments o,  org_users u "
			+ "WHERE o.sme_user_id = u.user_id AND "
			+ "o.appointment_status_cd !=0 AND o.sme_user_id in(select user_id from org_community_smes where community_id = ("
			+ "select community_id from org_community_smes where user_id= :userId))" + 
			"GROUP BY name", nativeQuery = true)
	public List<Object[]> getAppointmentCountBySmeId(@Param("userId") String userId);
	
	@Query(value = "select s.skill_mnemonic ,count(a.appointment_id) from org_appointments a, org_skills s \n" + 
			"where appointment_status_cd !=0 and a.skill_id=s.skill_id \n" + 
			"AND a.sme_user_id in(select user_id from org_community_smes where community_id = (\n" + 
			"select community_id from org_community_smes where user_id= :userId)) group by s.skill_mnemonic\n" + 
			"", nativeQuery= true )
	public List<Object[]> getAppointmentSkillWise(@Param("userId") String userId);
	
}
