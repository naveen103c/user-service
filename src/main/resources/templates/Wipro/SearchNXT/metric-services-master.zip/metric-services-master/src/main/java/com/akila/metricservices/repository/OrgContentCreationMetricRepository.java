package com.akila.metricservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.contentmetric.bean.ContentTrendMetricResponse;
import com.akila.metricservices.contentmetric.bean.EntContentResponse;
import com.akila.metricservices.entity.OrgContentCreationMetric;
import com.akila.metricservices.entity.OrgContentCreationMetricPK;

@Repository
public interface OrgContentCreationMetricRepository
		extends JpaRepository<OrgContentCreationMetric, OrgContentCreationMetricPK> {

	@Query(value = "SELECT new com.akila.metricservices.contentmetric.bean.EntContentResponse(sum(o.creationCt), o.contentSubtype) "
			+ "FROM OrgContentCreationMetric o where o.contentType='ent' group by o.contentSubtype")
	public List<EntContentResponse> getEntContentCount();

	@Query(value = "SELECT o.contentType, count(o.creationCt) FROM OrgContentCreationMetric o group by o.contentType")
	public List<Object[]> getContentCountByContentType();
	
	@Query(value = "SELECT new com.akila.metricservices.contentmetric.bean.ContentTrendMetricResponse(SUM(o.creationCt),o.contentSubtype,o.contentType) "
			+ "FROM OrgContentCreationMetric o group by o.contentType, o.contentSubtype")
	public List<ContentTrendMetricResponse> getContentTrendCount();	

	@Query(value = "select sum(creation_ct) from org_content_creation_metric where"
			+ " concat(date_part('year', metric_period_dt),'-',date_part('month', metric_period_dt))= "
			+ "concat(date_part('year', now()),'-',date_part('month', now()))", nativeQuery = true)
	public Integer getDocQuotaMetric();

	@Query(value = "SELECT concat(date_part('year', metric_period_dt),'-',date_part('month', metric_period_dt))\n"
			+ "	  yearMonth, sum(creation_ct) FROM org_content_creation_metric m where metric_period_dt is not null group by\n"
			+ "	  yearMonth ORDER BY yearMonth desc limit (:limit)", nativeQuery = true)
	public List<Object[]> getDocQuotaTrendMetric(@Param("limit") Integer limit);

}