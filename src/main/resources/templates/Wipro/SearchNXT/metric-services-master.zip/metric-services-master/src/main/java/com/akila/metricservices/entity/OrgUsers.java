package com.akila.metricservices.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.akila.AkilaEntity;


/**
 * The persistent class for the org_users database table.
 * 
 */
@Entity
@Table(name="org_users")
@NamedQuery(name="OrgUsers.findAll", query="SELECT o FROM OrgUsers o")
public class OrgUsers extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="user_id")
	private String userId;

	@Column(name="user_first_nm")
	private String userFirstNm;

	@Column(name="user_mid_nm")
	private String userMidNm;
	
	@Column(name="user_last_nm")
	private String userLastNm;

	@Column(name="usr_email")
	private String UsrEmail;
	
	@Column(name="is_active")
	private Boolean isActive;

	public OrgUsers() {
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserFirstNm() {
		return userFirstNm;
	}

	public void setUserFirstNm(String userFirstNm) {
		this.userFirstNm = userFirstNm;
	}

	public String getUserMidNm() {
		return userMidNm;
	}

	public void setUserMidNm(String userMidNm) {
		this.userMidNm = userMidNm;
	}

	public String getUserLastNm() {
		return userLastNm;
	}

	public void setUserLastNm(String userLastNm) {
		this.userLastNm = userLastNm;
	}

	public String getUsrEmail() {
		return UsrEmail;
	}

	public void setUsrEmail(String usrEmail) {
		UsrEmail = usrEmail;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

}