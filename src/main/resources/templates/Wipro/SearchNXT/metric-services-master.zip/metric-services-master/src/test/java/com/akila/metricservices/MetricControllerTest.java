package com.akila.metricservices;



import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import com.akila.metricservices.metric.MetricController;
import com.akila.metricservices.metric.bean.MetricContentResponse;
import com.akila.metricservices.metric.bean.SearchTermMetricRequest;

@SpringBootTest(classes = MetricServicesApplication.class)
@TestPropertySource(locations="classpath:application-test.properties")
public class MetricControllerTest {
	@Autowired
	private MetricController controller;

	/*
	 * @Test public void createContentMetric() {
	 * //controller.createContentMetric("bdd308fe-7704-454c-9893-dc0346ef7f87",
	 * null); }
	 */

	@Test
	public void getContentMetric() {
		MetricContentResponse response = controller.getContentMetric("bdd308fe-7704-454c-9893-dc0346ef7f87");
		assertNotNull(response);
	}

	@Test
	public void createSearchTermMetric() {
		SearchTermMetricRequest request = new SearchTermMetricRequest();
		request.setSearchTerm("Hippa2");
		request.setSuccessResults(2);
		request.setFailedResults(1);

	//	System.out.println("Result of the create request is :" + controller.createSearchTermMetric(request));
	}

}
