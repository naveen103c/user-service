package com.akila.metricservices.billing.bean;

import com.akila.AkilaResponse;

public class BillingResponse extends AkilaResponse {
}
