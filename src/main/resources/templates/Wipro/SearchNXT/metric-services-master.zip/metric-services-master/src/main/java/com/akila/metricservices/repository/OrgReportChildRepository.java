package com.akila.metricservices.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface OrgReportChildRepository extends OrgReportRepository {
}
