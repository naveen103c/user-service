package com.akila.metricservices.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the org_community_smes database table.
 * 
 */
@Entity
@Table(name = "org_monthly_invoice")
@NamedQuery(name = "OrgMonthlyInvoice.findAll", query = "SELECT o FROM OrgMonthlyInvoice o")
public class OrgMonthlyInvoice implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "invoice_id")
	private String invoiceId;

	@Column(name = "plan_id")
	private String planId;

	@Column(name = "plan_nm")
	private String planNm;

	@Column(name = "invoice_month")
	private int invoiceMonth;

	@Column(name = "invoice_year")
	private int invoiceYear;
	
	@Column(name="crt_ts")
	protected Timestamp crtTs;

	public String getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getPlanNm() {
		return planNm;
	}

	public void setPlanNm(String planNm) {
		this.planNm = planNm;
	}

	public int getInvoiceMonth() {
		return invoiceMonth;
	}

	public void setInvoiceMonth(int invoiceMonth) {
		this.invoiceMonth = invoiceMonth;
	}

	public int getInvoiceYear() {
		return invoiceYear;
	}

	public void setInvoiceYear(int invoiceYear) {
		this.invoiceYear = invoiceYear;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

}