package com.akila.metricservices.brainindexmetric;

import com.akila.AkilaController;
import com.akila.metricservices.brainindexmetric.bean.BrainIndexMetricCommunityResponse;
import com.akila.metricservices.brainindexmetric.bean.BrainIndexMetricResponse;
import java.lang.Integer;
import java.lang.String;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BrainindexmetricController extends AkilaController {
  @Autowired
  private BrainindexmetricService brainindexmetricService;

  @GetMapping(
      path = "/metric/activity/user/{id}"
  )
  public List<BrainIndexMetricResponse> getUserActivityMetric(@PathVariable String id,
      @RequestParam Integer periodCd, @RequestParam Integer count) {
    return brainindexmetricService.getUserActivityMetric(id, periodCd, count);
  }

  @GetMapping(
      path = "/metric/skill-score/user/{id}"
  )
  public BrainIndexMetricResponse getUserSkillScoreMetric(@PathVariable String id,
      @RequestParam Integer periodCd, @RequestParam String count) {
    return brainindexmetricService.getUserSkillScoreMetric(id, periodCd, count);
  }

  @GetMapping(
      path = "/metric/activity/community/{id}"
  )
  public List<BrainIndexMetricCommunityResponse> getCommunityActivityMetric(@PathVariable String id,
      @RequestParam Integer periodCd, @RequestParam String count) {
    return brainindexmetricService.getCommunityActivityMetric(id, periodCd, count);
  }

  @GetMapping(
      path = "/metric/skill-score/community/{id}"
  )
  public BrainIndexMetricResponse getCommunitySkillScoreMetric(@PathVariable String id,
      @RequestParam Integer periodCd, @RequestParam String count) {
    return brainindexmetricService.getCommunitySkillScoreMetric(id, periodCd, count);
  }
}
