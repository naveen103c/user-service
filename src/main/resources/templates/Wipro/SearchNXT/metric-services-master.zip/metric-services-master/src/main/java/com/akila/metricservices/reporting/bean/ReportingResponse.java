package com.akila.metricservices.reporting.bean;

import java.sql.Timestamp;
import java.util.List;

import com.akila.AkilaResponse;
import com.fasterxml.jackson.annotation.JsonIgnore;


public class ReportingResponse extends AkilaResponse {
  private String orgReportId;

  private String reportId;

  private String reportName;

  private String description;

  @JsonIgnore
  private String userRole;
  
  private String crtBy;

  private Timestamp crtTs;
  
  private String modBy;

  private Timestamp modTs;
  
  private List<ReportingResponse> children;
  
  private String pageName;

  public void setOrgReportId(String orgReportId) {
    this.orgReportId = orgReportId;
  }

  public void setReportId(String reportId) {
    this.reportId = reportId;
  }

  public void setReportName(String reportName) {
    this.reportName = reportName;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setUserRole(String userRole) {
    this.userRole = userRole;
  }

  public String getOrgReportId() {
    return orgReportId;
  }

  public String getReportId() {
    return reportId;
  }

  public String getReportName() {
    return reportName;
  }

  public String getDescription() {
    return description;
  }

  public String getUserRole() {
    return userRole;
  }

public String getCrtBy() {
	return crtBy;
}

public void setCrtBy(String crtBy) {
	this.crtBy = crtBy;
}

public Timestamp getCrtTs() {
	return crtTs;
}

public void setCrtTs(Timestamp crtTs) {
	this.crtTs = crtTs;
}

public String getModBy() {
	return modBy;
}

public void setModBy(String modBy) {
	this.modBy = modBy;
}

public Timestamp getModTs() {
	return modTs;
}

public void setModTs(Timestamp modTs) {
	this.modTs = modTs;
 }

public List<ReportingResponse> getChildren() {
	return children;
}

public void setChildren(List<ReportingResponse> children) {
	this.children = children;
}

public String getPageName() {
	return pageName;
}

public void setPageName(String pageName) {
	this.pageName = pageName;
}

}
