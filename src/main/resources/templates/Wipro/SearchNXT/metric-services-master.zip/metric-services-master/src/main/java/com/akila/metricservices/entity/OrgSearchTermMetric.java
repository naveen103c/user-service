package com.akila.metricservices.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the org_search_term_metric database table.
 * 
 */
@Entity
@Table(name="org_search_term_metric")
@NamedQuery(name="OrgSearchTermMetric.findAll", query="SELECT o FROM OrgSearchTermMetric o")
public class OrgSearchTermMetric implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgSearchTermMetricPK id;

	@Column(name="search_count")
	private Integer searchCount;

	@Column(name="search_failure")
	private Integer searchFailure;

	@Column(name="search_success")
	private Integer searchSuccess;

	public OrgSearchTermMetric() {
	}

	public OrgSearchTermMetricPK getId() {
		return this.id;
	}

	public void setId(OrgSearchTermMetricPK id) {
		this.id = id;
	}

	public Integer getSearchCount() {
		return this.searchCount;
	}

	public void setSearchCount(Integer searchCount) {
		this.searchCount = searchCount;
	}

	public Integer getSearchFailure() {
		return this.searchFailure;
	}

	public void setSearchFailure(Integer searchFailure) {
		this.searchFailure = searchFailure;
	}

	public Integer getSearchSuccess() {
		return this.searchSuccess;
	}

	public void setSearchSuccess(Integer searchSuccess) {
		this.searchSuccess = searchSuccess;
	}

}