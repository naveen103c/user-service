package com.akila.metricservices.entity;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.sql.Timestamp;


/**
 * The persistent class for the org_user_content_metadata database table.
 * 
 */
@Entity
@Table(name="org_user_content_metadata")
@NamedQuery(name="OrgUserContentMetadata.findAll", query="SELECT o FROM OrgUserContentMetadata o")
public class OrgUserContentMetadata implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonIgnore
	private OrgUserContentMetadataPK id;

	@Column(name="interaction_count")
	private Integer interactionCount;

	@Column(name="is_favorite")
	private Boolean isFavorite;

	@Column(name="mod_ts")
	private Timestamp modTs;

	@Column(name="voting_status")
	private Boolean votingStatus;

	public OrgUserContentMetadata() {
	}

	public OrgUserContentMetadataPK getId() {
		return this.id;
	}

	public void setId(OrgUserContentMetadataPK id) {
		this.id = id;
	}

	public Integer getInteractionCount() {
		return this.interactionCount;
	}

	public void setInteractionCount(Integer interactionCount) {
		this.interactionCount = interactionCount;
	}

	public Boolean getIsFavorite() {
		return this.isFavorite;
	}

	public void setIsFavorite(Boolean isFavorite) {
		this.isFavorite = isFavorite;
	}

	public Timestamp getModTs() {
		return this.modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public Boolean getVotingStatus() {
		return this.votingStatus;
	}

	public void setVotingStatus(Boolean votingStatus) {
		this.votingStatus = votingStatus;
	}

}