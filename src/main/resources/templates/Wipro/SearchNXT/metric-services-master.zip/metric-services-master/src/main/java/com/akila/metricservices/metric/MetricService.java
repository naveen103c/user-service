package com.akila.metricservices.metric;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.akila.AkilaService;
import com.akila.metricservices.entity.OrgContentMetric;
import com.akila.metricservices.entity.OrgContentMetricPK;
import com.akila.metricservices.entity.OrgSearchTermMetric;
import com.akila.metricservices.entity.OrgSearchTermMetricPK;
import com.akila.metricservices.entity.OrgServiceMetricPK;
import com.akila.metricservices.entity.OrgUserContentMetadata;
import com.akila.metricservices.entity.OrgUserContentMetadataPK;
import com.akila.metricservices.entity.OrgUserMetric;
import com.akila.metricservices.entity.OrgUserMetricPK;
import com.akila.metricservices.metric.bean.ContentMetricRequest;
import com.akila.metricservices.metric.bean.MetricContentResponse;
import com.akila.metricservices.metric.bean.MetricMapper;
import com.akila.metricservices.metric.bean.MetricResponse;
import com.akila.metricservices.metric.bean.SearchTermMetricRequest;
import com.akila.metricservices.repository.OrgContentMetricRepository;
import com.akila.metricservices.repository.OrgSearchTermMetricRepository;
import com.akila.metricservices.repository.OrgServiceMetricRepository;
import com.akila.metricservices.repository.OrgUserContentMetadataRepository;
import com.akila.metricservices.repository.OrgUserMetricRepository;
import com.akila.metricservices.util.DateUtil;
import com.akila.response.ResponseId;

@Service
public class MetricService extends AkilaService {
	@Autowired
	protected OrgUserMetricRepository orgUserMetricRepository;

	@Autowired
	protected OrgServiceMetricRepository orgServiceMetricRepository;

	@Autowired
	protected OrgContentMetricRepository orgContentMetricRepository;

	@Autowired
	protected OrgUserContentMetadataRepository orgUserContentMetadataRepository;

	@Autowired
	protected MetricMapper metricMapper;

	@Autowired
	protected OrgSearchTermMetricRepository orgSearchTermMetricRepository;

	@Value("${day_metric_cd}")
	private int dayMetricCd;

	@Value("${week_metric_cd}")
	private int weekMetricCd;

	@Value("${month_metric_cd}")
	private int monthMetricCd;

	@Value("${quarter_metric_cd}")
	private int quarterMetricCd;

	@Value("${year_metric_cd}")
	private int yearMetricCd;

	@Value("${till_date_metric_cd}")
	private int tillDateMetricCd;

	public MetricContentResponse getContentMetric(String id) {
		OrgContentMetric contentMetric = orgContentMetricRepository.getMetricByContentId(id);
		MetricContentResponse response = metricMapper.orgContentMetricToMetricContentResponse(contentMetric);

		OrgUserContentMetadata userContent = orgUserContentMetadataRepository.findById(getOrgUserContentMetadataPK(id))
				.orElse(null);
		if (userContent != null) {
			response.setOrgUserContentMetadata(userContent);
		}
		return response;
	}

	public ResponseId updateContentMetric(String id, ContentMetricRequest metricRequest) {
		OrgContentMetric contentMetric = metricMapper.metricRequestToOrgContentMetric(metricRequest);
		contentMetric.setModTs(new Timestamp(new Date().getTime()));
		contentMetric.setId(getOrgContentMetricPK(id, tillDateMetricCd, new Date()));

		contentMetric = orgContentMetricRepository.save(contentMetric);
		return new ResponseId(contentMetric.getId().getContentId());
	}

	public ResponseId createSearchTermMetric(SearchTermMetricRequest request) {
		OrgSearchTermMetricPK id = getOrgSearchTermMetricPK(request.getSearchTerm(), tillDateMetricCd,
				DateUtil.getTillDate());
		OrgSearchTermMetric orgSearchTermMetric = new OrgSearchTermMetric();

		if (orgSearchTermMetricRepository.existsById(id)) {
			int searchCount, searchSuccess, searchFailure = 0;
			orgSearchTermMetric = orgSearchTermMetricRepository.getOne(id);
			searchCount = orgSearchTermMetric.getSearchCount() + 1;
			searchSuccess = orgSearchTermMetric.getSearchSuccess() + request.getSuccessResults();
			searchFailure = orgSearchTermMetric.getSearchFailure() + request.getFailedResults();

			orgSearchTermMetricRepository.updatesearchTermMetric(request.getSearchTerm(), searchCount, searchSuccess,
					searchFailure);
			return new ResponseId(id.getSearchTerm());
		} else {
			orgSearchTermMetric.setSearchCount(1);
			orgSearchTermMetric.setId(id);
			orgSearchTermMetric.setSearchFailure(request.getFailedResults());
			orgSearchTermMetric.setSearchSuccess(request.getSuccessResults());
			orgSearchTermMetricRepository.save(orgSearchTermMetric);
			
			orgSearchTermMetric.setId(getOrgSearchTermMetricPK(id.getSearchTerm(), dayMetricCd, DateUtil.getToday()));
			orgSearchTermMetricRepository.save(orgSearchTermMetric);

			orgSearchTermMetric.setId(getOrgSearchTermMetricPK(id.getSearchTerm(), weekMetricCd, DateUtil.getWeek()));
			orgSearchTermMetricRepository.save(orgSearchTermMetric);

			orgSearchTermMetric.setId(getOrgSearchTermMetricPK(id.getSearchTerm(), monthMetricCd, DateUtil.getMonth()));
			orgSearchTermMetricRepository.save(orgSearchTermMetric);

			orgSearchTermMetric.setId(getOrgSearchTermMetricPK(id.getSearchTerm(), quarterMetricCd, DateUtil.getQuarter()));
			orgSearchTermMetricRepository.save(orgSearchTermMetric);

			orgSearchTermMetric.setId(getOrgSearchTermMetricPK(id.getSearchTerm(), yearMetricCd, DateUtil.getYear()));
			orgSearchTermMetricRepository.save(orgSearchTermMetric);
			
			return new ResponseId(id.getSearchTerm());
		}

	}

	@Transactional
	public ResponseId createContentMetric(String id, ContentMetricRequest metricRequest) {
		OrgContentMetric contentMetric = null;
		if (metricRequest == null) {
			contentMetric = new OrgContentMetric();
			contentMetric.setDownVotes(0);
			contentMetric.setUpVotes(0);
			contentMetric.setFavoriteCount(0);
			contentMetric.setInteractionCount(0);
		} else {
			contentMetric = metricMapper.metricRequestToOrgContentMetric(metricRequest);
		}
		contentMetric.setModTs(new Timestamp(new Date().getTime()));
		
		contentMetric.setId(getOrgContentMetricPK(id, dayMetricCd, DateUtil.getToday()));
		orgContentMetricRepository.save(contentMetric);

		contentMetric.setId(getOrgContentMetricPK(id, weekMetricCd, DateUtil.getWeek()));
		orgContentMetricRepository.save(contentMetric);

		contentMetric.setId(getOrgContentMetricPK(id, monthMetricCd, DateUtil.getMonth()));
		orgContentMetricRepository.save(contentMetric);

		contentMetric.setId(getOrgContentMetricPK(id, quarterMetricCd, DateUtil.getQuarter()));
		orgContentMetricRepository.save(contentMetric);

		contentMetric.setId(getOrgContentMetricPK(id, yearMetricCd, DateUtil.getYear()));
		orgContentMetricRepository.save(contentMetric);

		contentMetric.setId(getOrgContentMetricPK(id, tillDateMetricCd, DateUtil.getTillDate()));
		orgContentMetricRepository.save(contentMetric);

		return new ResponseId(contentMetric.getId().getContentId());
	}

	public MetricResponse getOrgServiceMetric(String level, String metrictype) {
		return null;
	}

	public OrgUserMetric getUserMetric(String id) {
		return null;
	}

	public MetricResponse getOrgUsersMetric() {
		return null;
	}

	public OrgUserMetricPK getOrgUserMetricPK(Integer metricPeriodCd, Date metricPeriodDt) {
		OrgUserMetricPK orgUserMetricPK = new OrgUserMetricPK();
		orgUserMetricPK.setUserId(super.getUserId());
		orgUserMetricPK.setMetricPeriodCd(metricPeriodCd);
		orgUserMetricPK.setMetricPeriodDt(metricPeriodDt);
		return orgUserMetricPK;
	}

	public OrgServiceMetricPK getOrgServiceMetricPK(String serviceId, Integer metricPeriodCd, Date metricPeriodDt) {
		OrgServiceMetricPK orgServiceMetricPK = new OrgServiceMetricPK();
		orgServiceMetricPK.setServiceId(serviceId);
		orgServiceMetricPK.setMetricPeriodCd(metricPeriodCd);
		orgServiceMetricPK.setMetricPeriodDt(metricPeriodDt);
		return orgServiceMetricPK;
	}

	public OrgContentMetricPK getOrgContentMetricPK(String contentId, Integer metricPeriodCd, Date metricPeriodDt) {
		OrgContentMetricPK orgContentMetricPK = new OrgContentMetricPK();
		orgContentMetricPK.setContentId(contentId);
		orgContentMetricPK.setMetricPeriodCd(metricPeriodCd);
		orgContentMetricPK.setMetricPeriodDt(metricPeriodDt);
		return orgContentMetricPK;
	}

	public OrgUserContentMetadataPK getOrgUserContentMetadataPK(String contentId) {
		OrgUserContentMetadataPK orgUserContentMetadataPK = new OrgUserContentMetadataPK();
		orgUserContentMetadataPK.setUserId(super.getUserId());
		orgUserContentMetadataPK.setContentId(contentId);
		return orgUserContentMetadataPK;
	}

	public OrgSearchTermMetricPK getOrgSearchTermMetricPK(String searchTerm, Integer metricPeriodCd,
			Date metricPeriodDt) {
		OrgSearchTermMetricPK orgSearchTermMetricPK = new OrgSearchTermMetricPK();
		orgSearchTermMetricPK.setSearchTerm(searchTerm);
		orgSearchTermMetricPK.setMetricPeriodCd(metricPeriodCd);
		orgSearchTermMetricPK.setMetricPeriodDt(metricPeriodDt);
		return orgSearchTermMetricPK;
	}

	public void updateFavOrgContentMetric(String id) {
		List<OrgContentMetric> orgContentMetricList = orgContentMetricRepository.findById_contentIdAndId_metricPeriodCd(id,tillDateMetricCd);
		if(orgContentMetricList != null && orgContentMetricList.size() > 0) {
			for (OrgContentMetric orgContentMetric : orgContentMetricList) {
				orgContentMetric.setFavoriteCount(orgContentMetric.getFavoriteCount() + 1);
				orgContentMetric.setModTs(new Timestamp((new Date().getTime())));
			}
		}else {
			OrgContentMetric orgContentMetric  = getOrgContentMericObj(id);
			orgContentMetric.setFavoriteCount(1);
			orgContentMetricList = new ArrayList<OrgContentMetric>();
			orgContentMetricList.add(orgContentMetric);
		}
		
		orgContentMetricRepository.saveAll(orgContentMetricList);
		
	}

	private OrgContentMetric getOrgContentMericObj(String id) {
		OrgContentMetric contentMetric = new OrgContentMetric();
		OrgContentMetricPK pk = new OrgContentMetricPK();
		pk.setContentId(id);
		pk.setMetricPeriodCd(tillDateMetricCd);
		pk.setMetricPeriodDt(new Date());
		contentMetric.setId(pk);
		contentMetric.setDownVotes(0);
		contentMetric.setUpVotes(0);
		contentMetric.setFavoriteCount(0);
		contentMetric.setInteractionCount(0);
		contentMetric.setModTs(new Timestamp((new Date().getTime())));
		return contentMetric;
	}

	public void updateInteractionOrgContentMetric(String id) {
		List<OrgContentMetric> orgContentMetricList = orgContentMetricRepository.findById_contentIdAndId_metricPeriodCd(id,tillDateMetricCd);
		if(orgContentMetricList != null && orgContentMetricList.size() > 0) {
			for (OrgContentMetric orgContentMetric : orgContentMetricList) {
				orgContentMetric.setInteractionCount(orgContentMetric.getInteractionCount() + 1);
				orgContentMetric.setModTs(new Timestamp((new Date().getTime())));
			}
		}else {
			OrgContentMetric orgContentMetric  = getOrgContentMericObj(id);
			orgContentMetric.setInteractionCount(1);
			orgContentMetricList = new ArrayList<OrgContentMetric>();
			orgContentMetricList.add(orgContentMetric);
		}
		
		orgContentMetricRepository.saveAll(orgContentMetricList);
	}

	public void removeFavOrgContentMetric(String id) {
		List<OrgContentMetric> orgContentMetricList = orgContentMetricRepository.findById_contentIdAndId_metricPeriodCd(id,tillDateMetricCd);
		if(orgContentMetricList != null && orgContentMetricList.size() > 0) {
			for (OrgContentMetric orgContentMetric : orgContentMetricList) {
				if(orgContentMetric.getFavoriteCount() > 0) {
					orgContentMetric.setFavoriteCount(orgContentMetric.getFavoriteCount() - 1);
				}
				
				orgContentMetric.setModTs(new Timestamp((new Date().getTime())));
			}
		}
		orgContentMetricRepository.saveAll(orgContentMetricList);
	}
	
	public void updateVoteOrgContentMetric(String id,String vote, String type) {
		OrgContentMetric orgContentMetric;
		List<OrgContentMetric> orgContentMetricList = orgContentMetricRepository.findById_contentIdAndId_metricPeriodCd(id,tillDateMetricCd);
		if(orgContentMetricList != null && orgContentMetricList.size() > 0) {
			orgContentMetric = orgContentMetricList.get(0);
		}else {
			orgContentMetric  = getOrgContentMericObj(id);
		}
		 
		if(type.equalsIgnoreCase("new"))  {
		  if(vote.equalsIgnoreCase("up")) {
				  orgContentMetric.setUpVotes(orgContentMetric.getUpVotes() + 1);
			  }
			  else {
				 orgContentMetric.setDownVotes(orgContentMetric.getDownVotes() + 1);
			  }
		}
		else {
			  if(vote.equalsIgnoreCase("up")) {
				  orgContentMetric.setUpVotes(orgContentMetric.getUpVotes() + 1);
				  if(orgContentMetric.getDownVotes() > 0) {
					  orgContentMetric.setDownVotes(orgContentMetric.getDownVotes() - 1);
				  }
			  } else  {
				  if(orgContentMetric.getUpVotes() > 0) {
					  orgContentMetric.setUpVotes(orgContentMetric.getUpVotes() - 1);
				  }
				  orgContentMetric.setDownVotes(orgContentMetric.getDownVotes() + 1);
			  }
		}
		 
		orgContentMetricRepository.save(orgContentMetric);
	}

}
