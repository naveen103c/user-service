package com.akila.metricservices.notifications;

import java.sql.Timestamp;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.JDBCException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.metricservices.entity.OrgMetricQueue;
import com.akila.metricservices.repository.OrgMetricQueueRepository;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.azure.core.exception.AzureException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueMessage;

@Service
public class NotificationService extends AkilaService{
	private static final Logger logger = LogManager.getLogger(NotificationService.class);
	
	@Value("${sqs-url}")
	private String sqsUrl;
	
	AmazonSQS sqs = null;
	
	@Value("${metric.queue.impl}")
	private String metricQueueImpl;
	
	@Value("${azure.blob.connection-string:connectionString}")
	String connectionString;
	
	@Value("${azure.metric.queue.name}")
	private String azureQueueName;
	
	@Autowired
	OrgMetricQueueRepository orgMetricQueueRepository;
		
	public AmazonSQS getSqsClient(){
		if(sqs == null) {
			
			sqs = AmazonSQSClientBuilder.standard()
		              .withCredentials(new InstanceProfileCredentialsProvider(false))
		              .build();
		}
		return sqs;
	}
	
	
	public void addMessageInQueue(String serviceName, Double value) {
		
		Notification notification = new Notification();
		notification.setServiceName(serviceName);
		notification.setOrgId(getOrgId());
		notification.setUserId(getUserId());
		notification.setServiceId("");
		notification.setTenant(request.getHeader("tenant"));
		if(value != null){
			notification.setValue(value);
		} else{
			notification.setValue(1);
		}
		
		ObjectMapper mapper = new ObjectMapper();
		try {
			String message = mapper.writeValueAsString(notification);
			if(metricQueueImpl.equalsIgnoreCase("db")) {
				OrgMetricQueue obj = new OrgMetricQueue();
				obj.setMetricId(UUID.randomUUID().toString());
				obj.setServiceNm(serviceName);
				obj.setMetricJson(message);
				obj.setStatus(0);
				obj.setCrtTs(new Timestamp(System.currentTimeMillis()));
				orgMetricQueueRepository.save(obj);
			} else if(metricQueueImpl.equalsIgnoreCase("azure")) {
				CloudStorageAccount storageAccount = CloudStorageAccount.parse(connectionString);
				CloudQueue queue = storageAccount.createCloudQueueClient().getQueueReference(azureQueueName);
				CloudQueueMessage msg = new CloudQueueMessage(message);
				queue.addMessage(msg);
			} else {
				SendMessageRequest send_msg_request = new SendMessageRequest()
				        .withQueueUrl(sqsUrl)
				        .withDelaySeconds(1);
				send_msg_request.setMessageBody(message);
				getSqsClient().sendMessage(send_msg_request);
			}
	        
		} catch (JDBCException | AzureException | NullPointerException e) {
			logger.error("NotificationService:addMessageInQueue : "+e.getMessage(),e);
		} catch (Exception e) {
			logger.error("NotificationService:addMessageInQueue : "+e.getMessage(),e);
		}
	}

}
