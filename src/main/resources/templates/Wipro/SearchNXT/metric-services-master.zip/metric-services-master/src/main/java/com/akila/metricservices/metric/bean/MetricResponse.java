package com.akila.metricservices.metric.bean;

import com.akila.AkilaResponse;
import java.lang.Integer;

public class MetricResponse extends AkilaResponse {
  private Integer answerCt;

  private Integer commentCt;

  private Integer wikiCt;

  public void setAnswerCt(Integer answerCt) {
    this.answerCt = answerCt;
  }

  public void setCommentCt(Integer commentCt) {
    this.commentCt = commentCt;
  }

  public void setWikiCt(Integer wikiCt) {
    this.wikiCt = wikiCt;
  }

  public Integer getAnswerCt() {
    return answerCt;
  }

  public Integer getCommentCt() {
    return commentCt;
  }

  public Integer getWikiCt() {
    return wikiCt;
  }
}
