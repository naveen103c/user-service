package com.akila.metricservices.contentmetric.bean;

public class ContentWikiResponse {

	private long draft;
	private long published;

	public ContentWikiResponse(long draft, long published) {
		super();
		this.draft = draft;
		this.published = published;
	}

	public long getDraft() {
		return draft;
	}

	public void setDraft(long draft) {
		this.draft = draft;
	}

	public long getPublished() {
		return published;
	}

	public void setPublished(long published) {
		this.published = published;
	}

}
