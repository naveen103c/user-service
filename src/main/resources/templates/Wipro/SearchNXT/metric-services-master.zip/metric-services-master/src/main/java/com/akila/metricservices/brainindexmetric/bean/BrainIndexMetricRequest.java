package com.akila.metricservices.brainindexmetric.bean;

import com.akila.AkilaRequest;

public class BrainIndexMetricRequest extends AkilaRequest {
}
