package com.akila.metricservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The persistent class for the org_communities database table.
 * 
 */
@Entity
@Table(name="org_communities")
@NamedQuery(name="OrgCommunity.findAll", query="SELECT o FROM OrgCommunity o")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class OrgCommunity extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="community_id")
	private String communityId;

	@Column(name="community_nm")
	private String communityNm;

	@Column(name="community_owner")
	private String communityOwner;

	@Column(name="parent_community_nm")
	private String parentCommunityNm;

	public OrgCommunity() {
	}

	public String getCommunityId() {
		return communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public String getCommunityNm() {
		return communityNm;
	}

	public void setCommunityNm(String communityNm) {
		this.communityNm = communityNm;
	}

	public String getCommunityOwner() {
		return communityOwner;
	}

	public void setCommunityOwner(String communityOwner) {
		this.communityOwner = communityOwner;
	}

	public String getParentCommunityNm() {
		return parentCommunityNm;
	}

	public void setParentCommunityNm(String parentCommunityNm) {
		this.parentCommunityNm = parentCommunityNm;
	}

}