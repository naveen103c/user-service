package com.akila.metricservices.usermetric;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.metricservices.repository.OrgUserGroupsRepository;
import com.akila.metricservices.repository.OrgUsersRepository;
import com.akila.metricservices.usermetric.bean.UserCategoryGroupCount;
import com.akila.metricservices.usermetric.bean.UserCountMetricResponse;

@Service
public class UserMetricService extends AkilaService {

	@Autowired
	protected OrgUsersRepository orgUsersRepository;

	@Autowired
	protected OrgUserGroupsRepository orgUserGroupsRepository;

	public UserCountMetricResponse getUserActivityMetric(Integer count) {
		UserCountMetricResponse userCountMetricResponse = orgUsersRepository.getUserActivity();
		return userCountMetricResponse;

	}

	public Map<String, Long> getUserCategoryMetric(Integer count) {
		Map<String, Long> data = new HashMap<String, Long>();
		List<UserCategoryGroupCount> userCategoryGroupCountList = orgUserGroupsRepository.getUserCategoryGroupCount();
		for (UserCategoryGroupCount usrCategoryCount : userCategoryGroupCountList) {
			data.put(usrCategoryCount.getUserGroupName(), usrCategoryCount.getCount());
		}
		return data;

	}

}
