package com.akila.metricservices.billing.bean;

import com.akila.AkilaResponse;
import java.lang.Integer;
import java.lang.String;
import java.sql.Timestamp;

import javax.persistence.Column;

public class PlanResponse extends AkilaResponse {
  private String planId;

  private String crtBy;

  private Timestamp crtTs;

  private String modBy;

  private Timestamp modTs;

  private String planDescription;

  private Integer planNm;
  
  private double monthlyCost;
	
  private double yearlyCost;

  public void setPlanId(String planId) {
    this.planId = planId;
  }

  public void setCrtBy(String crtBy) {
    this.crtBy = crtBy;
  }

  public void setCrtTs(Timestamp crtTs) {
    this.crtTs = crtTs;
  }

  public void setModBy(String modBy) {
    this.modBy = modBy;
  }

  public void setModTs(Timestamp modTs) {
    this.modTs = modTs;
  }

  public void setPlanDescription(String planDescription) {
    this.planDescription = planDescription;
  }

  public void setPlanNm(Integer planNm) {
    this.planNm = planNm;
  }

  public String getPlanId() {
    return planId;
  }

  public String getCrtBy() {
    return crtBy;
  }

  public Timestamp getCrtTs() {
    return crtTs;
  }

  public String getModBy() {
    return modBy;
  }

  public Timestamp getModTs() {
    return modTs;
  }

  public String getPlanDescription() {
    return planDescription;
  }

	public Integer getPlanNm() {
		return planNm;
	}

	public double getMonthlyCost() {
		return monthlyCost;
	}

	public void setMonthlyCost(double monthlyCost) {
		this.monthlyCost = monthlyCost;
	}

	public double getYearlyCost() {
		return yearlyCost;
	}

	public void setYearlyCost(double yearlyCost) {
		this.yearlyCost = yearlyCost;
	}
  
}
