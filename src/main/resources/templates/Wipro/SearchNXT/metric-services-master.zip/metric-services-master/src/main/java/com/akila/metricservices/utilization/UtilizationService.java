package com.akila.metricservices.utilization;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.akila.AkilaService;
import com.akila.metricservices.repository.OrgContentCreationMetricRepository;
import com.akila.metricservices.repository.OrgSearchTermMetricRepository;
import com.akila.metricservices.repository.OrgUsersRepository;

@Service
public class UtilizationService extends AkilaService {

	@Autowired
	private OrgContentCreationMetricRepository orgContentCreationMetricRepository;

	@Autowired
	EntityManager entityManager;

	@Autowired
	private OrgUsersRepository orgUsersRepository;
	
	@Autowired
	OrgSearchTermMetricRepository orgSearchTermMetricRepository;

	public Map<String, Integer> getDocQuotaMetric(@RequestParam Integer periodCd, @RequestParam String count) {
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("quota", 1000);
		map.put("used", orgContentCreationMetricRepository.getDocQuotaMetric());

		return map;
	}

	public Map<String, String> getDocQuotaTrendMetric(@RequestParam Integer periodCd, @RequestParam Integer count) {
		Map<String, String> map = new HashMap<String, String>();

		List<Object[]> responseList = orgContentCreationMetricRepository.getDocQuotaTrendMetric(count);
		for (Object[] obj : responseList) {
			map.put(obj[0].toString(), obj[1].toString());
		}

		return map;
	}

	public Map<String, Integer> getSearchQuotaMetric(@RequestParam Integer periodCd, @RequestParam String count) {
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("quota", 1000);
		map.put("used", orgSearchTermMetricRepository.getSearchQuota());

		return map;
	}

	public Map<String, String> getSearchQuotaTrendMetric(@RequestParam Integer periodCd, @RequestParam Integer count) {
		Map<String, String> map = new HashMap<String, String>();
		List<Object[]> resultList = orgSearchTermMetricRepository.getSearchQuotaTrendMetric(count);
		for (Object[] obj : resultList) {
			map.put(obj[0].toString(), obj[1].toString());
		}
		return map;

	}

	public Map<String, Integer> getUserQuotaMetric(@RequestParam Integer periodCd, @RequestParam String count) {
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("quota", 1000);
		map.put("used", orgUsersRepository.getUserQuota());

		return map;
	}

	public Map<String, String> getUserQuotaTrendMetric(@RequestParam Integer periodCd, @RequestParam Integer count) {
		Map<String, String> map = new HashMap<String, String>();
		List<Object[]> resultList = orgUsersRepository.getUserQuotaTrendMetric(count);
		for (Object[] obj : resultList) {
			map.put(obj[0].toString(), obj[1].toString());
		}
		return map;
	}

	public Map<String, Long> getStorageQuotaMetric(@RequestParam Integer periodCd, @RequestParam Integer count) {
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("quota", 1000l);
		map.put("used", getSyncOrStorageQuota(count, null));
		return map;
	}

	public Map<String, String> getStorageQuotaTrendMetric(@RequestParam Integer periodCd, @RequestParam Integer count) {
		return getSyncOrStorageQuotaTrend(count, null);
	}

	public Map<String, Long> getSyncHourQuotaMetric(@RequestParam Integer periodCd, @RequestParam Integer count) {
		Map<String, Long> map = new HashMap<String, Long>();
		map.put("quota", 2000l);
		map.put("used", getSyncOrStorageQuota(count, "sync"));
		return map;
	}

	public Map<String, String> getSyncHourQuotaTrendMetric(@RequestParam Integer periodCd,
			@RequestParam Integer count) {
		return getSyncOrStorageQuotaTrend(count, "sync");
	}

	public long getSyncOrStorageQuota(Integer count, String metric)

	{
		String sql;
		if (metric != null && metric.equals("sync")) {
			sql = "select Sum(minute_consumed) from org_sync_metric";
		} else {
			sql = "select Sum(storage_consumed_mb) from org_storage_metric";
		}
		Query query = entityManager.createNativeQuery(sql);
		long result = query.getFirstResult();

		return result;
	}

	public Map<String, String> getSyncOrStorageQuotaTrend(Integer count, String metric) {
		String sql;
		if (metric != null && metric.equalsIgnoreCase("sync")) {
			sql = "SELECT concat(date_part('year', metric_period_dt),'-',date_part('month', metric_period_dt))\n"
					+ "		  yearMonth, count(*) FROM org_sync_metric m where metric_period_dt is not null group by\n"
					+ "		  yearMonth ORDER BY yearMonth desc limit (:limit)";
		} else {
			sql = "SELECT concat(date_part('year', metric_period_dt),'-',date_part('month', metric_period_dt))\n"
					+ "		  yearMonth, count(*) FROM org_storage_metric m where metric_period_dt is not null group by\n"
					+ "		  yearMonth ORDER BY yearMonth desc limit (:limit)";
		}
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("limit", count);
		List<Object[]> resultList = query.getResultList();
		Map<String, String> map = new HashMap<String, String>();
		for (Object[] obj : resultList) {
			map.put(obj[0].toString(), obj[1].toString());
		}

		return map;
	}

}