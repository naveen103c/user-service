package com.akila.metricservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;


/**
 * The persistent class for the org_user_groups database table.
 * 
 */
@Entity
@Table(name="org_user_groups")
@NamedQuery(name="OrgUserGroups.findAll", query="SELECT o FROM OrgUserGroups o")
public class OrgUserGroups extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="user_group_id")
	private String userGroupId;

	@Column(name="user_group_desc")
	private String userGroupDesc;

	@Column(name="user_group_nm")
	private String userGroupNm;
	
	public OrgUserGroups() {
	}

	public String getUserGroupId() {
		return this.userGroupId;
	}

	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}

	public String getUserGroupDesc() {
		return this.userGroupDesc;
	}

	public void setUserGroupDesc(String userGroupDesc) {
		this.userGroupDesc = userGroupDesc;
	}

	public String getUserGroupNm() {
		return this.userGroupNm;
	}

	public void setUserGroupNm(String userGroupNm) {
		this.userGroupNm = userGroupNm;
	}

	/*
	 * public List<OrgUserGroupToUsersLink> getUsers() { return users; }
	 * 
	 * public void setUsers(List<OrgUserGroupToUsersLink> users) { this.users =
	 * users; }
	 */

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}