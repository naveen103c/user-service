package com.akila.metricservices.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the org_user_group_to_users_link database table.
 * 
 */
@Embeddable
public class OrgUserGroupToUsersLinkPK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "user_group_id", insertable = false, updatable = false)
	private String userGroupId;

	@Column(name = "user_id", insertable = false, updatable = false)
	private String userId;

	public OrgUserGroupToUsersLinkPK() {
	}

	public String getUserGroupId() {
		return this.userGroupId;
	}

	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof OrgUserGroupToUsersLinkPK)) {
			return false;
		}
		OrgUserGroupToUsersLinkPK castOther = (OrgUserGroupToUsersLinkPK) other;
		return this.userGroupId.equals(castOther.userGroupId) && this.userId.equals(castOther.userId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.userGroupId.hashCode();
		hash = hash * prime + this.userId.hashCode();

		return hash;
	}
}