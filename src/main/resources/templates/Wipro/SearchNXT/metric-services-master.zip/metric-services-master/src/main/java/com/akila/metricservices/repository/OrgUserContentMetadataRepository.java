package com.akila.metricservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.entity.OrgUserContentMetadata;
import com.akila.metricservices.entity.OrgUserContentMetadataPK;

@Repository
public interface OrgUserContentMetadataRepository extends JpaRepository<OrgUserContentMetadata, OrgUserContentMetadataPK> {
}
