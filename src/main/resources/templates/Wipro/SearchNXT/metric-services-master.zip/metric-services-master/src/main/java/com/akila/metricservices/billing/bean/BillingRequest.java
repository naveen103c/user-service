package com.akila.metricservices.billing.bean;

import com.akila.AkilaRequest;

public class BillingRequest extends AkilaRequest {
}
