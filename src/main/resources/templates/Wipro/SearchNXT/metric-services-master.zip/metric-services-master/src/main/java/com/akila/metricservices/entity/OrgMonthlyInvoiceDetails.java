package com.akila.metricservices.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the org_community_smes database table.
 * 
 */
@Entity
@Table(name = "org_monthly_invoice_details")
@NamedQuery(name = "OrgMonthlyInvoiceDetails.findAll", query = "SELECT o FROM OrgMonthlyInvoiceDetails o")
public class OrgMonthlyInvoiceDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "invoice_detailed_id")
	private String invoice_detailed_id;

	@Column(name = "invoice_id")
	private String invoiceId;

	@Column(name = "service_id")
	private String serviceId;

	@Column(name = "service_nm")
	private String serviceNm;

	@Column(name = "service_limit")
	private int serviceLimit;

	@Column(name = "service_unit_price")
	private double serviceUnitPrice;

	@Column(name = "servie_volume_price")
	private double servieVolumePrice;

	@Column(name = "servie_utilizaton")
	private String serviceUtilizaton;
	
	@Column(name = "servie_utilizaton_unit")
	private double serviceUtilizatonUnit;

	@Column(name = "total_price")
	private double totalPrice;

	@Column(name="crt_ts")
	protected Timestamp crtTs;
	
	public String getInvoice_detailed_id() {
		return invoice_detailed_id;
	}

	public String getInvoiceId() {
		return invoiceId;
	}

	public void setInvoiceId(String invoiceId) {
		this.invoiceId = invoiceId;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceNm() {
		return serviceNm;
	}

	public void setServiceNm(String serviceNm) {
		this.serviceNm = serviceNm;
	}

	public int getServiceLimit() {
		return serviceLimit;
	}

	public void setServiceLimit(int serviceLimit) {
		this.serviceLimit = serviceLimit;
	}

	public double getServiceUnitPrice() {
		return serviceUnitPrice;
	}

	public void setServiceUnitPrice(double serviceUnitPrice) {
		this.serviceUnitPrice = serviceUnitPrice;
	}

	public double getServieVolumePrice() {
		return servieVolumePrice;
	}

	public void setServieVolumePrice(double servieVolumePrice) {
		this.servieVolumePrice = servieVolumePrice;
	}

	public String getServiceUtilizaton() {
		return serviceUtilizaton;
	}

	public void setServiceUtilizaton(String serviceUtilizaton) {
		this.serviceUtilizaton = serviceUtilizaton;
	}

	public double getServiceUtilizatonUnit() {
		return serviceUtilizatonUnit;
	}

	public void setServiceUtilizatonUnit(double serviceUtilizatonUnit) {
		this.serviceUtilizatonUnit = serviceUtilizatonUnit;
	}

	public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public void setInvoice_detailed_id(String invoice_detailed_id) {
		this.invoice_detailed_id = invoice_detailed_id;
	}

}