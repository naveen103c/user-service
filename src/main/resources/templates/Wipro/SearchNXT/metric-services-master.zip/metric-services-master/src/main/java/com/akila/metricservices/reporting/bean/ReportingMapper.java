package com.akila.metricservices.reporting.bean;

import com.akila.metricservices.entity.OrgReport;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface ReportingMapper {
  ReportingMapper INSTANCE = Mappers.getMapper(ReportingMapper.class);
  ;

  @Mappings({})
  List<ReportingResponse> orgReportToReportingResponse(List<OrgReport> orgReport);

  @Mappings({})
  OrgReport reportingRequestToOrgReport(ReportingRequest reportingRequest);
  
  @Mappings({})
  ReportingResponse orgReportToReportingResponse(OrgReport orgReport);
}
