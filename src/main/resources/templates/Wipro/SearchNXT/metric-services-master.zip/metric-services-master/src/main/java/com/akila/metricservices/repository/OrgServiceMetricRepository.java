package com.akila.metricservices.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.entity.OrgServiceMetric;
import com.akila.metricservices.entity.OrgServiceMetricPK;

@Repository
public interface OrgServiceMetricRepository extends JpaRepository<OrgServiceMetric, OrgServiceMetricPK> {

	@Query(value = "SELECT o FROM OrgServiceMetric o WHERE o.id.metricPeriodCd = (:metricPeriodCd) and o.id.serviceId IN (:serviceIds) "
			+ "ORDER BY o.id.metricPeriodDt DESC")
	List<OrgServiceMetric> getServiceMetricList(@Param("metricPeriodCd") Integer metricPeriodCd, @Param("serviceIds") List<String> serviceIds );

	List<OrgServiceMetric> findByIdServiceIdInAndIdMetricPeriodCd(List<String> ids, Integer periodCd);

	List<OrgServiceMetric> findByIdServiceIdInAndIdMetricPeriodCdAndIdMetricPeriodDt(List<String> ids, Integer periodCd,
			Date date);

	List<OrgServiceMetric> findByIdServiceIdInAndIdMetricPeriodCdAndIdMetricPeriodDtGreaterThanEqualAndIdMetricPeriodDtLessThan(
			List<String> ids, Integer periodCd, Date startDate, Date endDate);

	List<OrgServiceMetric> findByIdServiceIdAndIdMetricPeriodCdOrderByIdMetricPeriodDtDesc(String searchServiceId,
			int periodCd);
}
