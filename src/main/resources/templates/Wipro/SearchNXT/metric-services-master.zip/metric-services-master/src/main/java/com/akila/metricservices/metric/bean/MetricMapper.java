package com.akila.metricservices.metric.bean;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.akila.metricservices.entity.OrgContentMetric;
import com.akila.metricservices.entity.OrgUserMetric;

@Mapper(
    componentModel = "spring"
)
public interface MetricMapper {
  MetricMapper INSTANCE = Mappers.getMapper(MetricMapper.class);
  ;

  @Mappings({})
  MetricResponse orgUserMetricToMetricResponse(OrgUserMetric orgUserMetric);

  @Mappings({})
  List<MetricResponse> orgUserMetricToMetricResponseList(List<OrgUserMetric> orgUserMetric);

  @Mappings({})
  OrgContentMetric metricRequestToOrgContentMetric(ContentMetricRequest metricRequest);
  
  @Mappings({
	  @Mapping(source = "id.contentId" , target = "contentId"),
	  @Mapping(source = "id.metricPeriodCd" , target = "metricPeriodCd"),
	  @Mapping(source = "id.metricPeriodDt" , target = "metricPeriodDt")
  })
  MetricContentResponse orgContentMetricToMetricContentResponse(OrgContentMetric metric);
  
}
