package com.akila.metricservices.metric.bean;

import java.sql.Timestamp;

import com.akila.AkilaRequest;

public class ContentMetricRequest extends AkilaRequest 
{
	private Integer downVotes;

	private Integer interactionCount;

	private Timestamp modTs;

	private Integer upVotes;

	public Integer getDownVotes() 
	{
		if(downVotes == null)
		{
			return 0;
		}
		return downVotes;
	}

	public void setDownVotes(Integer downVotes) {
		this.downVotes = downVotes;
	}

	public Integer getInteractionCount() {
		if(interactionCount == null)
		{
			return 0;
		}
		return interactionCount;
	}

	public void setInteractionCount(Integer interactionCount) {
		this.interactionCount = interactionCount;
	}

	public Timestamp getModTs() 
	{
		return modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public Integer getUpVotes() 
	{
		if(upVotes == null)
		{
			return 0;
		}
		return upVotes;
	}

	public void setUpVotes(Integer upVotes) {
		this.upVotes = upVotes;
	}

 
}
