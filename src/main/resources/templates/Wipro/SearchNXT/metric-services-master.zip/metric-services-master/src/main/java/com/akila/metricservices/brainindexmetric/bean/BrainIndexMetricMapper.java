package com.akila.metricservices.brainindexmetric.bean;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.akila.metricservices.entity.OrgUserMetric;

@Mapper(
    componentModel = "spring"
)
public interface BrainIndexMetricMapper {
  BrainIndexMetricMapper INSTANCE = Mappers.getMapper(BrainIndexMetricMapper.class);
  ;
  
  @Mappings({})
  List<BrainIndexMetricResponse> orgUserMetricListToBrainIndexMetricResponseList(
      List<OrgUserMetric> orgUserMetricsList);
  
}
