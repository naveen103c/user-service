package com.akila.metricservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.entity.OrgUserGroups;
import com.akila.metricservices.usermetric.bean.UserCategoryGroupCount;

@Repository
public interface OrgUserGroupsRepository extends JpaRepository<OrgUserGroups, String> {

	@Query("SELECT new com.akila.metricservices.usermetric.bean.UserCategoryGroupCount(o.userGroupNm, COUNT(l.id.userId)) from OrgUserGroups o , \n"
			+ "	OrgUserGroupToUsersLink l where o.userGroupId = l.id.userGroupId\n" + "	group by o.userGroupNm order by COUNT(l.id.userId) DESC")
	List<UserCategoryGroupCount> getUserCategoryGroupCount();
	
	@Query(value = "SELECT count(*) from OrgUserGroups")
	int getGroupQuota();

}