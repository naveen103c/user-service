package com.akila.metricservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.entity.OrgCommunitySme;
import com.akila.metricservices.entity.OrgCommunitySmePK;

@Repository
public interface OrgCommunitySmeRepository extends JpaRepository<OrgCommunitySme, OrgCommunitySmePK> {

	@Query(value = "select c.id.userId from OrgCommunitySme c where c.id.communityId = (:communityId)")
	List<String> getUserIds(@Param("communityId") String communityId);

}
