package com.akila.metricservices.contentmetric.bean;

public class ContentTrendMetricResponse {

	private long creationCt;
	private String contentSubtype;
	private String contentType;
	

	public ContentTrendMetricResponse(long creationCt, String contentSubtype, String contentType) {
		super();
		this.creationCt = creationCt;
		this.contentType = contentType;
		this.contentSubtype = contentSubtype;
	}


	public long getCreationCt() {
		return creationCt;
	}


	public void setCreationCt(long creationCt) {
		this.creationCt = creationCt;
	}


	public String getContentSubtype() {
		return contentSubtype;
	}


	public void setContentSubtype(String contentSubtype) {
		this.contentSubtype = contentSubtype;
	}


	public String getContentType() {
		return contentType;
	}


	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	

}
