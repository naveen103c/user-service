package com.akila.metricservices.contentmetric;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.metricservices.contentmetric.bean.ContentQueryResponse;
import com.akila.metricservices.contentmetric.bean.ContentWikiResponse;

@RestController
public class ContentMetricController extends AkilaController {

	@Autowired
	private ContentMetricService contentMetricService;

	@GetMapping(path = "/content-metric/queries")
	public ContentQueryResponse getQueryMetric(@RequestParam Integer periodCd,
			@RequestParam Integer count) {
		return contentMetricService.getQueryMetric(periodCd, count);
	}

	@GetMapping(path = "/content-metric/wikis")
	public ContentWikiResponse getWikiMetric(@RequestParam Integer periodCd,
			@RequestParam Integer count) {
		return contentMetricService.getWikiMetric(periodCd, count);
	}
	
	@GetMapping(path = "/content-metric/ent-contents")
	public Map<String, Long> getEntContentMetric(@RequestParam Integer periodCd,
			@RequestParam Integer count) {
		return contentMetricService.getEntContentMetric(periodCd, count);
	}
	
	@GetMapping(path = "/content-metric/trends")
	public Map<String, Map<String, Long>> getContentTrendMetric(@RequestParam Integer periodCd,
			@RequestParam Integer count) {
		return contentMetricService.getContentTrendMetric(periodCd, count);
	}

}
