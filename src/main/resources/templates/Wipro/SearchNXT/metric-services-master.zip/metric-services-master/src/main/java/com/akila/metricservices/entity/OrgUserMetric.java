package com.akila.metricservices.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the org_user_metric database table.
 * 
 */
@Entity
@Table(name="org_user_metric")
@NamedQuery(name="OrgUserMetric.findAll", query="SELECT o FROM OrgUserMetric o")
public class OrgUserMetric implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgUserMetricPK id;

	@Column(name="answer_ct")
	private Integer answerCt;

	@Column(name="comment_ct")
	private Integer commentCt;

	@Column(name="wiki_ct")
	private Integer wikiCt;
	
	@Column(name="query_ct")
	private Integer queryCt;
	
	@Column(name="session_ct")
	private Integer sessionCt;

	public OrgUserMetric() {
	}

	public OrgUserMetricPK getId() {
		return this.id;
	}

	public void setId(OrgUserMetricPK id) {
		this.id = id;
	}

	public Integer getAnswerCt() {
		return this.answerCt;
	}

	public void setAnswerCt(Integer answerCt) {
		this.answerCt = answerCt;
	}

	public Integer getCommentCt() {
		return this.commentCt;
	}

	public void setCommentCt(Integer commentCt) {
		this.commentCt = commentCt;
	}

	public Integer getWikiCt() {
		return this.wikiCt;
	}

	public void setWikiCt(Integer wikiCt) {
		this.wikiCt = wikiCt;
	}

	public Integer getQueryCt() {
		return queryCt;
	}

	public void setQueryCt(Integer queryCt) {
		this.queryCt = queryCt;
	}

	public Integer getSessionCt() {
		return sessionCt;
	}

	public void setSessionCt(Integer sessionCt) {
		this.sessionCt = sessionCt;
	}

}