package com.akila.metricservices.usermetric;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.metricservices.usermetric.bean.UserCountMetricResponse;

@RestController
public class UserMetricController extends AkilaController {

	@Autowired
	private UserMetricService userMetricService;

	@GetMapping(path = "/user-metric/activities")
	public UserCountMetricResponse getUserActivityMetric(@RequestParam Integer count) {
		return userMetricService.getUserActivityMetric(count);
	}

	@GetMapping(path = "/user-metric/categories")
	public Map<String, Long> getUserCategoryMetric(@RequestParam Integer count) {
		return userMetricService.getUserCategoryMetric(count);
	}

}
