package com.akila.metricservices.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the org_user_content_metadata database table.
 * 
 */
@Embeddable
public class OrgUserContentMetadataPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="user_id", insertable=false, updatable=false)
	private String userId;

	@Column(name="content_id", insertable=false, updatable=false)
	private String contentId;

	public OrgUserContentMetadataPK() {
	}
	public String getUserId() {
		return this.userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getContentId() {
		return this.contentId;
	}
	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof OrgUserContentMetadataPK)) {
			return false;
		}
		OrgUserContentMetadataPK castOther = (OrgUserContentMetadataPK)other;
		return 
			this.userId.equals(castOther.userId)
			&& this.contentId.equals(castOther.contentId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.userId.hashCode();
		hash = hash * prime + this.contentId.hashCode();
		
		return hash;
	}
}