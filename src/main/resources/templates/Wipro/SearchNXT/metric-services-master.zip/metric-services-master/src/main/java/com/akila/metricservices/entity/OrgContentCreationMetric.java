package com.akila.metricservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the org_content_creation_metric database table.
 * 
 */
@Entity
@Table(name = "org_content_creation_metric")
@NamedQuery(name = "OrgContentCreationMetric.findAll", query = "SELECT o FROM OrgContentCreationMetric o")
public class OrgContentCreationMetric implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgContentCreationMetricPK id;

	@Column(name = "content_type")
	private String contentType;

	@Column(name = "content_subtype")
	private String contentSubtype;

	@Column(name = "creation_ct")
	private Integer creationCt;
	
	public OrgContentCreationMetricPK getId() {
		return id;
	}

	public void setId(OrgContentCreationMetricPK id) {
		this.id = id;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getContentSubtype() {
		return contentSubtype;
	}

	public void setContentSubtype(String contentSubtype) {
		this.contentSubtype = contentSubtype;
	}

	public Integer getCreationCt() {
		return creationCt;
	}

	public void setCreationCt(Integer creationCt) {
		this.creationCt = creationCt;
	}

}