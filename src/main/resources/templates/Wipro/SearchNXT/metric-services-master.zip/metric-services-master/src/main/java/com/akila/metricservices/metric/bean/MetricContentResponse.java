package com.akila.metricservices.metric.bean;

import java.sql.Timestamp;

import com.akila.metricservices.entity.OrgUserContentMetadata;

public class MetricContentResponse 
{
	private String contentId;

	private Integer metricPeriodCd;

	private java.util.Date metricPeriodDt;
	
	private Integer downVotes;

	private Integer interactionCount;

	private Timestamp modTs;

	private Integer upVotes;
	
	private OrgUserContentMetadata orgUserContentMetadata;

	

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public Integer getMetricPeriodCd() {
		return metricPeriodCd;
	}

	public void setMetricPeriodCd(Integer metricPeriodCd) {
		this.metricPeriodCd = metricPeriodCd;
	}

	public java.util.Date getMetricPeriodDt() {
		return metricPeriodDt;
	}

	public void setMetricPeriodDt(java.util.Date metricPeriodDt) {
		this.metricPeriodDt = metricPeriodDt;
	}

	public Integer getDownVotes() {
		return downVotes;
	}

	public void setDownVotes(Integer downVotes) {
		this.downVotes = downVotes;
	}

	public Integer getInteractionCount() {
		return interactionCount;
	}

	public void setInteractionCount(Integer interactionCount) {
		this.interactionCount = interactionCount;
	}

	public Timestamp getModTs() {
		return modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public Integer getUpVotes() {
		return upVotes;
	}

	public void setUpVotes(Integer upVotes) {
		this.upVotes = upVotes;
	}

	public OrgUserContentMetadata getOrgUserContentMetadata() {
		return orgUserContentMetadata;
	}

	public void setOrgUserContentMetadata(OrgUserContentMetadata orgUserContentMetadata) {
		this.orgUserContentMetadata = orgUserContentMetadata;
	}
	
}
