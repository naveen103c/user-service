package com.akila.metricservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.entity.OrgUsers;
import com.akila.metricservices.usermetric.bean.UserCountMetricResponse;

@Repository
public interface OrgUsersRepository extends JpaRepository<OrgUsers, String> {

	@Query(value = "SELECT new com.akila.metricservices.usermetric.bean.UserCountMetricResponse( (count(c.userId)), (SELECT count(a.userId) "
			+ "FROM OrgUsers a WHERE a.isActive ='true'),(SELECT count(b.userId) FROM OrgUsers b WHERE b.isActive ='false')) "
			+ "FROM OrgUsers c")
	UserCountMetricResponse getUserActivity();

	@Query(value = "SELECT concat(date_part('year', crt_ts),'-',date_part('month', crt_ts)) yearMonth,\n"
			+ "			  count(*) FROM org_users m where crt_ts is not null\n"
			+ "			  group by yearMonth\n"
			+ "			 ORDER BY yearMonth desc limit (:limit)", nativeQuery = true)
	List<Object[]> getUserQuotaTrendMetric(@Param("limit") Integer limit);
	
	@Query(value = "SELECT count(*) from OrgUsers")
	int getUserQuota();
	
	@Query(value = "SELECT count(*) from OrgUsers where isActive = true ")
	int getActiveUserQuota();

}
