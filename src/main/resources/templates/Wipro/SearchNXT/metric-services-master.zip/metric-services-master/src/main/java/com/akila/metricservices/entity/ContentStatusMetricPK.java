package com.akila.metricservices.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the content_status_metric database table.
 * 
 */
@Embeddable
public class ContentStatusMetricPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="metric_period_cd")
	private Integer metricPeriodCd;

	@Temporal(TemporalType.DATE)
	@Column(name="metric_period_dt")
	private java.util.Date metricPeriodDt;

	public Integer getMetricPeriodCd() {
		return this.metricPeriodCd;
	}
	public void setMetricPeriodCd(Integer metricPeriodCd) {
		this.metricPeriodCd = metricPeriodCd;
	}
	public java.util.Date getMetricPeriodDt() {
		return this.metricPeriodDt;
	}
	public void setMetricPeriodDt(java.util.Date metricPeriodDt) {
		this.metricPeriodDt = metricPeriodDt;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof ContentStatusMetricPK)) {
			return false;
		}
		ContentStatusMetricPK castOther = (ContentStatusMetricPK)other;
		return 
			this.metricPeriodCd.equals(castOther.metricPeriodCd)
			&& this.metricPeriodDt.equals(castOther.metricPeriodDt);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.metricPeriodCd.hashCode();
		hash = hash * prime + this.metricPeriodDt.hashCode();
		
		return hash;
	}
}