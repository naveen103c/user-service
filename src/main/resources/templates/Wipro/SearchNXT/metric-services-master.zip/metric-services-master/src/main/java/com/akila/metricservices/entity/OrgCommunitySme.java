package com.akila.metricservices.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;

/**
 * The persistent class for the org_community_smes database table.
 * 
 */
@Entity
@Table(name = "org_community_smes")
@NamedQuery(name = "OrgCommunitySme.findAll", query = "SELECT o FROM OrgCommunitySme o")
public class OrgCommunitySme extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgCommunitySmePK id;

	public OrgCommunitySme() {
	}

	public OrgCommunitySmePK getId() {
		return this.id;
	}

	public void setId(OrgCommunitySmePK id) {
		this.id = id;
	}

}