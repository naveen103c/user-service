package com.akila.metricservices.reporting.bean;

import com.akila.AkilaRequest;
import java.lang.String;

public class ReportingRequest extends AkilaRequest {
  private String orgReportId;

  private String reportId;

  private String reportName;

  private String description;

  private String userRole;

  public void setOrgReportId(String orgReportId) {
    this.orgReportId = orgReportId;
  }

  public void setReportId(String reportId) {
    this.reportId = reportId;
  }

  public void setReportName(String reportName) {
    this.reportName = reportName;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setUserRole(String userRole) {
    this.userRole = userRole;
  }

  public String getOrgReportId() {
    return orgReportId;
  }

  public String getReportId() {
    return reportId;
  }

  public String getReportName() {
    return reportName;
  }

  public String getDescription() {
    return description;
  }

  public String getUserRole() {
    return userRole;
  }
}
