package com.akila.metricservices.servicemetric;

import java.util.List;
import java.util.Map;

import org.hibernate.JDBCException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;

import com.akila.AkilaController;

@RestController
public class ServiceMetricController extends AkilaController {

	@Autowired
	private ServiceMetricService serviceMetricService;

	@GetMapping(path = "/service-metric/services")
	public Map<String, Map<String, String>> getServiceMetrics(@RequestParam List<String> ids,@RequestParam Integer periodCd) {
		return serviceMetricService.getServiceMetrics(ids, periodCd);
	}

	@GetMapping(path = "/service-metric/baseservices")
	public Map<String, String> getAllService() {
		return serviceMetricService.getAllServiceMetric();
	}
	
	@GetMapping(path = "/service-metric/searchMetric")
	public Map<Integer,SearchMetricBean> getSearchMetrics() {
		return serviceMetricService.getSearchMetrics();
	}
	
	@GetMapping(path = "/service-metric/utilizationMetric")
	public List<PlanService> getUtilizationMetric() throws HttpStatusCodeException , NullPointerException,JDBCException,Exception{
		return serviceMetricService.getUtilizationMetric();
	}
	
}
