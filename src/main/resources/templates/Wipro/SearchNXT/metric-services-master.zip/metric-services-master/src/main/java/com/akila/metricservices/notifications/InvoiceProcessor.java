package com.akila.metricservices.notifications;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.akila.commons.AkilaRestTemplate;
import com.akila.metricservices.billing.BillingService;
import com.akila.metricservices.billing.bean.PlanResponse;
import com.akila.metricservices.entity.OrgMonthlyInvoice;
import com.akila.metricservices.entity.OrgMonthlyInvoiceDetails;
import com.akila.metricservices.repository.OrgMetricQueueRepository;
import com.akila.metricservices.repository.OrgMonthlyInvoiceDetailsRepository;
import com.akila.metricservices.repository.OrgMonthlyInvoiceRepository;
import com.akila.metricservices.servicemetric.PlanService;
import com.akila.metricservices.servicemetric.ServiceMetricService;
import com.akilacommons.tenant.DataSourceProperties;
import com.akilacommons.tenant.TenantContext;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
@EnableScheduling
public class InvoiceProcessor {
	private static final Logger logger = LogManager.getLogger(InvoiceProcessor.class);

	@Autowired
	ServiceMetricService ServiceMetricService;

	@Autowired
	OrgMetricQueueRepository orgMetricQueueRepository;

	@Autowired
	DataSourceProperties dataSourceProperties;

	@Autowired
	OrgMonthlyInvoiceRepository orgMonthlyInvoiceRepository;

	@Autowired
	BillingService billingService;

	@Autowired
	OrgMonthlyInvoiceDetailsRepository orgMonthlyInvoiceDetailsRepository;

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate restTemplate;

	@Value("${platform.billing.url}")
	private String platformBillingDetailsUrl;
	
	@Autowired
	private AkilaRestTemplate akilaRestTemplate;
	
	@Scheduled(cron = "${billing.invoice.process.cron}")
	public void processQueue() {
		processInvoice();
	}

	private void processInvoice() {

		Map<Object, Object> datasources = dataSourceProperties.getDatasources();

		for (Map.Entry<Object, Object> datasource : datasources.entrySet()) {
			if (String.valueOf(datasource.getKey()).equalsIgnoreCase("base")) {
				continue;
			}
			String tenamtName = String.valueOf(datasource.getKey());
			TenantContext.setCurrentTenant(String.valueOf(datasource.getKey()));

			LocalDate now = LocalDate.now();
			LocalDate earlier = now.minusMonths(1);
			int month = earlier.getMonthValue();
			int year = earlier.getYear();

			OrgMonthlyInvoice orgMonthlyInvoice = orgMonthlyInvoiceRepository.findByInvoiceMonthAndInvoiceYear(month,
					year);

			if (orgMonthlyInvoice == null) {
				logger.info("InvoiceProcessor.invoiceQueue Database, Going To Generate Invoice for : " + month
						+ "- Year -" + year);

				try {
					List<PlanService> planServiceList = billingService.getMonthlyBill(month, year);

					// Insert invoice data in history table
					saveInvoiceRecords(planServiceList, month, year, tenamtName);
				} catch (JsonProcessingException e) {
					logger.error("InvoiceProcessor.invoiceQueue Database, Going To Generate Invoice for : " + month
							+ "- Year -" + year, e);
				}

			}
		}
	}

	public PlanResponse getPlan(String tenamtName, int month, int year)
			throws JsonMappingException, JsonProcessingException {
		HttpHeaders headers = new HttpHeaders();
		headers.add("tenant", tenamtName);
		headers.add("accept", "*/*");
		HttpEntity<String> entity = new HttpEntity<String>("org-details", headers);
		ResponseEntity<String> response = akilaRestTemplate.exchange(restTemplate, platformBillingDetailsUrl + month + "/" + year,
				HttpMethod.GET, entity, String.class);
		String body = response.getBody();
		ObjectMapper mapper = new ObjectMapper();
		logger.info("InvoiceProcessor.getPlan Received data : "+body);
		return mapper.readValue(body, PlanResponse.class);
	}

	@Transactional
	public void saveInvoiceRecords(List<PlanService> planServiceList, int month, int year, String tenamtName)
			throws JsonMappingException, JsonProcessingException {

		// Fetch Org Details to Fetch planId
		PlanResponse planResponse = getPlan(tenamtName, month, year);

		OrgMonthlyInvoice OrgMonthlyInvoice = new OrgMonthlyInvoice();
		OrgMonthlyInvoice.setInvoiceId(UUID.randomUUID().toString());
		OrgMonthlyInvoice.setInvoiceMonth(month);
		OrgMonthlyInvoice.setInvoiceYear(year);
		OrgMonthlyInvoice.setPlanId(planResponse.getPlanId());
		OrgMonthlyInvoice.setPlanNm(planResponse.getPlanDescription());
		OrgMonthlyInvoice.setCrtTs(new Timestamp(System.currentTimeMillis()));

		List<OrgMonthlyInvoiceDetails> orgMonthlyInvoiceDetailsList = new ArrayList<OrgMonthlyInvoiceDetails>();

		for (PlanService planService : planServiceList) {

			OrgMonthlyInvoiceDetails orgMonthlyInvoiceDetails = new OrgMonthlyInvoiceDetails();
			orgMonthlyInvoiceDetails.setInvoice_detailed_id(UUID.randomUUID().toString());
			orgMonthlyInvoiceDetails.setInvoiceId(OrgMonthlyInvoice.getInvoiceId());
			orgMonthlyInvoiceDetails.setServiceId(planService.getId());
			orgMonthlyInvoiceDetails.setServiceNm(planService.getLabelValue());
			orgMonthlyInvoiceDetails.setServiceLimit(Integer.valueOf(planService.getDetails().get(0).getLabelValue()));
			
			orgMonthlyInvoiceDetails
					.setServiceUnitPrice(Double.valueOf(planService.getDetails().get(1).getLabelValue()));
			orgMonthlyInvoiceDetails
					.setServieVolumePrice(Double.valueOf(planService.getDetails().get(2).getLabelValue()));
			orgMonthlyInvoiceDetails
					.setServiceUtilizaton(planService.getDetails().get(3).getLabelValue());
			orgMonthlyInvoiceDetails
					.setServiceUtilizatonUnit(Double.valueOf(planService.getDetails().get(4).getLabelValue()));
			orgMonthlyInvoiceDetails.setTotalPrice(Double.valueOf(planService.getDetails().get(5).getLabelValue()));
			orgMonthlyInvoiceDetails.setCrtTs(new Timestamp(System.currentTimeMillis()));
			orgMonthlyInvoiceDetailsList.add(orgMonthlyInvoiceDetails);
			
		}

		orgMonthlyInvoiceRepository.save(OrgMonthlyInvoice);
		orgMonthlyInvoiceDetailsRepository.saveAll(orgMonthlyInvoiceDetailsList);
	}

}
