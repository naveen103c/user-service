package com.akila.metricservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.apache.logging.log4j.core.config.Scheduled;

import com.akila.AkilaEntity;


/**
 * The persistent class for the base_services database table.
 * 
 */
@Entity
@Table(name="base_services", schema = "base")
@NamedQuery(name="BaseServices.findAll", query="SELECT b FROM BaseServices b")
public class BaseServices extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="service_id")
	private String serviceId;

	@Column(name="service_nm")
	private String serviceNm;

	@Column(name="service_unit_cd")
	private Integer serviceUnitCd;
	
	@Column(name="service_description")
	private String serviceDescription;
	
	
	public BaseServices() {
	}


	public String getServiceId() {
		return serviceId;
	}


	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}


	public String getServiceNm() {
		return serviceNm;
	}


	public void setServiceNm(String serviceNm) {
		this.serviceNm = serviceNm;
	}


	public Integer getServiceUnitCd() {
		return serviceUnitCd;
	}


	public void setServiceUnitCd(Integer serviceUnitCd) {
		this.serviceUnitCd = serviceUnitCd;
	}


	public String getServiceDescription() {
		return serviceDescription;
	}


	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}

}