package com.akila.metricservices.repository;

import com.akila.metricservices.entity.OrgUserMetric;
import com.akila.metricservices.entity.OrgUserMetricPK;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgUserMetricRepository extends JpaRepository<OrgUserMetric, OrgUserMetricPK> {

	@Query(value = "select o from OrgUserMetric o where o.id.userId IN (:userIds) and o.id.metricPeriodCd = (:metricPeriodCd) \n"
			+ "order by o.id.metricPeriodDt desc")
	List<OrgUserMetric> getUserActivityById(@Param("userIds") List<String> userIds,
			@Param("metricPeriodCd") Integer metricPeriodCd);
	
}
