package com.akila.metricservices.contentmetric.bean;

public class EntContentResponse {

	private String subType;
	private long subTypeCount;
	
	public EntContentResponse(long subTypeCount, String subType) {
		super();
		this.subTypeCount = subTypeCount;
		this.subType = subType;
	}
	public long getSubTypeCount() {
		return subTypeCount;
	}
	public void setSubTypeCount(long subTypeCount) {
		this.subTypeCount = subTypeCount;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}

	
}
