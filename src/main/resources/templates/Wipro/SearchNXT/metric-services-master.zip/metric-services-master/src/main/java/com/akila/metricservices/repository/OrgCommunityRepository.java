package com.akila.metricservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.entity.OrgCommunity;

@Repository
public interface OrgCommunityRepository extends JpaRepository<OrgCommunity, String> {

	@Query(value = "SELECT count(*) from OrgCommunity")
	int getCommunityQuota();
	
}
