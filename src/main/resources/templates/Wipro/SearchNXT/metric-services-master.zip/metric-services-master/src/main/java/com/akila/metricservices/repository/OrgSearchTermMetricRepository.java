package com.akila.metricservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.akila.metricservices.entity.OrgSearchTermMetric;
import com.akila.metricservices.entity.OrgSearchTermMetricPK;

@Repository
public interface OrgSearchTermMetricRepository extends JpaRepository<OrgSearchTermMetric, OrgSearchTermMetricPK> {
	
	@Transactional
	@Modifying
    @Query(value = "UPDATE OrgSearchTermMetric o SET o.searchCount = :searchCount, o.searchSuccess = :searchSuccess, o.searchFailure= :searchFailure "
    		+ "WHERE o.id.searchTerm = :searchTerm")
    Integer updatesearchTermMetric(@Param("searchTerm") String searchTerm,@Param("searchCount") Integer searchCount, @Param("searchSuccess") Integer searchSuccess,
    		@Param("searchFailure") Integer searchFailure);
	
	@Query(value = "Select o from OrgSearchTermMetric o WHERE o.id.metricPeriodCd = :metricPeriodCd order by o.searchCount DESC ")
    List<OrgSearchTermMetric> getSearchTrendMetric(@Param("metricPeriodCd") Integer metricPeriodCd );
	
	@Query(value = "Select o from OrgSearchTermMetric o WHERE o.id.metricPeriodCd = :metricPeriodCd order by o.searchSuccess DESC ")
    List<OrgSearchTermMetric> getSearchEfficiencyMetric(@Param("metricPeriodCd") Integer metricPeriodCd );
	
	@Query(value = "select sum(search_count) from org_search_term_metric where \n" + 
			"		   concat(date_part('year', metric_period_dt),'-',date_part('month', metric_period_dt))= \n" + 
			"		 concat(date_part('year', now()),'-',date_part('month', now()))", nativeQuery = true)
	Integer getSearchQuota();
	
	@Query(value = "SELECT concat(date_part('year', metric_period_dt),'-',date_part('month', metric_period_dt))\n" + 
			"		  yearMonth, sum(search_count) FROM org_search_term_metric m where metric_period_dt is not null group by\n" + 
			"		  yearMonth ORDER BY yearMonth desc limit (:limit)", nativeQuery = true)
	List<Object[]> getSearchQuotaTrendMetric(@Param("limit") Integer limit);
}
