package com.akila.metricservices.reporting;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.metricservices.entity.OrgReport;
import com.akila.metricservices.reporting.bean.ReportingMapper;
import com.akila.metricservices.reporting.bean.ReportingResponse;
import com.akila.metricservices.repository.OrgReportChildRepository;

@Service
public class ReportingService extends AkilaService {
	@Autowired
	private OrgReportChildRepository orgReportRepository;

	@Autowired
	private ReportingMapper reportingMapper;

	public List<ReportingResponse> getReports() {
		List<OrgReport> orgReports = orgReportRepository.findByParentIdNull();
		List<ReportingResponse> reportingResponses = reportingMapper.orgReportToReportingResponse(orgReports);
		reportingResponses.forEach(reportingResponse -> {
			List<OrgReport> childrens = orgReportRepository.findByParentId(reportingResponse.getOrgReportId());
			List<ReportingResponse> children = reportingMapper.orgReportToReportingResponse(childrens);
			reportingResponse.setChildren(children);
		});

		return reportingResponses;
	}

	public ReportingResponse getReportById(String id) {
		OrgReport orgReport = orgReportRepository.getOne(id);
		return reportingMapper.orgReportToReportingResponse(orgReport);
	}
}
