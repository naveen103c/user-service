package com.akila.metricservices.servicemetric;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.JDBCException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.metricservices.entity.BaseServices;
import com.akila.metricservices.entity.OrgServiceMetric;
import com.akila.metricservices.entity.OrgServiceMetricPK;
import com.akila.metricservices.notifications.Utils;
import com.akila.metricservices.repository.BaseServiceRepository;
import com.akila.metricservices.repository.OrgServiceMetricRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ServiceMetricService extends AkilaService {

	@Autowired
	protected OrgServiceMetricRepository orgServiceMetricRepository;

	@Autowired
	protected BaseServiceRepository baseServiceRepository;
	
	private static final Logger logger = LogManager.getLogger(ServiceMetricService.class);
	
	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate restTemplate;

	@Value("${platform.service.url}")
	private String platformServiceURL;
	
	@Autowired
	private AkilaRestTemplate akilaRestTemplate;
	  
	public Map<String, Map<String, String>> getServiceMetrics(List<String> ids, Integer periodCd) {
		Date date = new Date();
		List<OrgServiceMetric> orgServiceMetricList = new ArrayList<OrgServiceMetric>();
		if(periodCd == 1){
			orgServiceMetricList = getServiceMetricsCount(ids, periodCd,date);
		}
		else if(periodCd == 2){
			orgServiceMetricList = getServiceMetricsCount(ids, periodCd, Utils.getWeekStartDate(date),Utils.getWeekEndDate(date));
		}
		else if(periodCd == 3){
			orgServiceMetricList = getServiceMetricsCount(ids, periodCd, Utils.getMonthStartDate(date),Utils.getMonthEndDate(date));
		}
		else if(periodCd == 4){
			orgServiceMetricList = getServiceMetricsCount(ids, periodCd, Utils.getQuarterStartDate(date),Utils.getQuarterEndDate(date));
		}
		else if(periodCd == 5){
			orgServiceMetricList = getServiceMetricsCount(ids, periodCd, Utils.getYearStartDate(date),Utils.getYearEndDate(date));
		}
		else if(periodCd == 6){
			orgServiceMetricList = getServiceMetricsCount(ids, periodCd);
		}
		//List<OrgServiceMetric> orgServiceMetricList = orgServiceMetricRepository.getServiceMetricList(periodCd, ids);
		Map<String, Map<String, String>> data = new HashMap<String, Map<String, String>>();
		Date currDate= new Date();
		for (String str : ids) {
			Map<String, String> temp = new HashMap<String, String>();
			boolean isFound = false;
			for (OrgServiceMetric orgServiceMetric : orgServiceMetricList) {
				if (str.equals(orgServiceMetric.getId().getServiceId())) {
					temp.put(orgServiceMetric.getId().getMetricPeriodDt().toString(),orgServiceMetric.getServiceMetric().toString());
					isFound = true;
					break;
				}
			}
			if(!isFound){
				temp.put(currDate.toString(),"0");
			}
			data.put(str, temp);
		}
		return data;
	}
	
	public Map<String, Map<String, String>> getMonthWiseServiceMetrics(List<String> ids, Integer month,Integer year) {
		List<OrgServiceMetric> orgServiceMetricList = new ArrayList<OrgServiceMetric>();
		orgServiceMetricList = getServiceMetricsCount(ids, 3, Utils.getMonthStartDate(month,year),Utils.getMonthEndDate(month,year));
		
		Map<String, Map<String, String>> data = new HashMap<String, Map<String, String>>();
		Date currDate= new Date();
		for (String str : ids) {
			Map<String, String> temp = new HashMap<String, String>();
			boolean isFound = false;
			for (OrgServiceMetric orgServiceMetric : orgServiceMetricList) {
				if (str.equals(orgServiceMetric.getId().getServiceId())) {
					temp.put(orgServiceMetric.getId().getMetricPeriodDt().toString(),orgServiceMetric.getServiceMetric().toString());
					isFound = true;
					break;
				}
			}
			if(!isFound){
				temp.put(currDate.toString(),"0");
			}
			data.put(str, temp);
		}
		return data;
	}

	public Map<String, String> getAllServiceMetric() {
		List<BaseServices> baseServicesList = baseServiceRepository.findAll();
		Map<String, String> data = new HashMap<String, String>();
		for (BaseServices baseService : baseServicesList) {
			data.put(baseService.getServiceNm(), baseService.getServiceId());
		}
		return data;
	}

	public OrgServiceMetricPK getServiceMetricPK(String serviceId, Integer metricPeriodCd, Date metricPeriodDt) {

		OrgServiceMetricPK orgServiceMetricPK = new OrgServiceMetricPK();
		orgServiceMetricPK.setServiceId(serviceId);
		orgServiceMetricPK.setMetricPeriodCd(metricPeriodCd);
		orgServiceMetricPK.setMetricPeriodDt(metricPeriodDt);

		return orgServiceMetricPK;
	}
	
	public List<OrgServiceMetric> getServiceMetricsCount(List<String> ids, Integer periodCd,Date startDate, Date endDate) {
		// weekly, monthly, Quarterly, yearly
		return	orgServiceMetricRepository.findByIdServiceIdInAndIdMetricPeriodCdAndIdMetricPeriodDtGreaterThanEqualAndIdMetricPeriodDtLessThan(ids,periodCd,startDate,endDate);
	}
	
	public List<OrgServiceMetric> getServiceMetricsCount(List<String> ids, Integer periodCd, Date date) {
		// daily
		return	orgServiceMetricRepository.findByIdServiceIdInAndIdMetricPeriodCdAndIdMetricPeriodDt(ids,periodCd,date);
	}
	
	public List<OrgServiceMetric> getServiceMetricsCount(List<String> ids, Integer periodCd) {
		// till date
		return	orgServiceMetricRepository.findByIdServiceIdInAndIdMetricPeriodCd(ids,periodCd);
	}
	
	public void saveServiceMetrics(OrgServiceMetric orgServiceMetric){
		orgServiceMetricRepository.save(orgServiceMetric);
	}
	
	public void saveServiceMetrics(List<OrgServiceMetric> orgServiceMetricList){
		orgServiceMetricRepository.saveAll(orgServiceMetricList);
	}

	public Map<Integer,SearchMetricBean> getSearchMetrics() {
		Map<Integer,SearchMetricBean> resultList = new  LinkedHashMap<Integer,SearchMetricBean>();
		Map<String, String> serviceMap = getAllServiceMetric();
		String searchServiceId = serviceMap.get("Metric-Search-Count");
		if(searchServiceId != null){
			List<OrgServiceMetric> orgServiceMetricList = orgServiceMetricRepository.findByIdServiceIdAndIdMetricPeriodCdOrderByIdMetricPeriodDtDesc(searchServiceId,3);
			List<Integer> yearList = new ArrayList<Integer>();
			SearchMetricBean metric = null;
			for (OrgServiceMetric orgServiceMetric : orgServiceMetricList) {
				int year  = getYear(orgServiceMetric.getId().getMetricPeriodDt());
				int month  = getMonth(orgServiceMetric.getId().getMetricPeriodDt());
				if(!yearList.contains(year)){
					metric = new SearchMetricBean();
					yearList.add(year);
					resultList.put(year,metric);
				} 
				String count = convertNumber(orgServiceMetric.getServiceMetric().longValue());
				if(month == 0){
					metric.setJan(count);
				} else if(month == 1) {
					metric.setFeb(count);
				} else if(month == 2) {
					metric.setMar(count);
				} else if(month == 3) {
					metric.setApr(count);
				} else if(month == 4) {
					metric.setMay(count);
				} else if(month == 5) {
					metric.setJun(count);
				} else if(month == 6) {
					metric.setJul(count);
				} else if(month == 7) {
					metric.setAug(count);
				} else if(month == 8) {
					metric.setSep(count);
				} else if(month == 9) {
					metric.setOct(count);
				} else if(month == 10) {
					metric.setNov(count);
				} else if(month == 11) {
					metric.setDec(count);
				}
				
			}
		}
		return resultList;
	}

	private int getYear(Date date){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.YEAR);
	}
	
	private int getMonth(Date date){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.MONTH);
	}
	
	public static String convertNumber(long count) {
	    if (count < 1000) return "" + count;
	    int exp = (int) (Math.log(count) / Math.log(1000));
	    return String.format("%.1f%c",
	                         count / Math.pow(1000, exp),
	                         "kMGTPE".charAt(exp-1));
	}
	
	public List<PlanService> getUtilizationMetric() throws HttpStatusCodeException , NullPointerException,JDBCException, Exception{
		 HttpEntity<String> entity = new HttpEntity<String>("service-plans",getRequestHeader());
		 ResponseEntity<String> response = akilaRestTemplate.exchange(restTemplate, platformServiceURL + "/plans/details", HttpMethod.GET,entity, String.class);
		 //ResponseEntity<String> response = new RestTemplate().exchange("http://localhost:9091/plans/details", HttpMethod.GET,entity, String.class);
		 String body = response.getBody();
		 ObjectMapper mapper = new ObjectMapper();
		 List<PlanService>  servicesList =  mapper.readValue(body, mapper.getTypeFactory().constructCollectionType(List.class, PlanService.class));
		 Map<String, String> allServices = getAllServiceMetric();
		 Map<String, Map<String, String>> utilizationMap =  getServiceMetrics(new ArrayList<>(allServices.values()),3);
		 
		 for (PlanService planService : servicesList) {
			 if(planService.getLabelValue().toLowerCase().contains("users")){
				String serviceId =  allServices.get("Metric-Users");
				planService.getDetails().add(getPlanService(getValue(utilizationMap,serviceId)));
				planService.getDetails().add(getPlanServiceUnit(getValue(utilizationMap,serviceId)));
			 } else if(planService.getLabelValue().toLowerCase().contains("search")){//search count
				 String serviceId =  allServices.get("Metric-Search-Count");
				 planService.getDetails().add(getPlanService(getValue(utilizationMap,serviceId)));
				 planService.getDetails().add(getPlanServiceUnit(getValue(utilizationMap,serviceId)));
			 } else if(planService.getLabelValue().toLowerCase().contains("wiki")){//wiki count
				 String serviceId =  allServices.get("Metric-Wiki-Published");
				 String wiki = getValue(utilizationMap,serviceId);
				 String serviceId1 =  allServices.get("Metric-Queries-Answered");
				 String queryA = getValue(utilizationMap,serviceId1);
				 String serviceId2 =  allServices.get("Metric-Queries-Unanswered");
				 String queryU = getValue(utilizationMap,serviceId2);
				 int sum= 0;
				 if(wiki != null){
					 sum = sum + Integer.parseInt(wiki);
				 }
				 if(queryA != null){
					 sum = sum + Integer.parseInt(queryA);
				 }
				 if(queryU != null){
					 sum = sum + Integer.parseInt(queryU);
				 }
				
				 planService.getDetails().add(getPlanService(""+sum));
				 planService.getDetails().add(getPlanServiceUnit(""+sum));
			 }else if(planService.getLabelValue().toLowerCase().contains("text")){//text content sync hours
				 String serviceId =  allServices.get("Metric-Text-Content-Sync-Hours");
				 String val = getValue(utilizationMap,serviceId);
				 String tempVal = "0";
				 if(val!= null){
					 long milliseconds = Long.parseLong(val);
					 tempVal = getMintes(milliseconds);
					 long minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
					 if(minutes == 0){
						 long sec = TimeUnit.MILLISECONDS.toSeconds(milliseconds);
						 if(sec == 0){
							 val = milliseconds+" MilliSeconds";
						 } else {
							 val = sec+" Seconds";
						 }
					 } else{
						 val = minutes+" Minutes";
					 }
					
				 }else {
					 val = "0";
				 }
				 planService.getDetails().add(getPlanService(val));
				 planService.getDetails().add(getPlanServiceUnit(tempVal));
			 }else if(planService.getLabelValue().toLowerCase().contains("audio") || planService.getLabelValue().toLowerCase().contains("media")){//audio/Video content Sync
				 String serviceId =  allServices.get("Metric-Media-Content-Sync-Hours");
				 String val = getValue(utilizationMap,serviceId);
				 String tempVal = "0";
				 if(val!= null){
					 long milliseconds = Long.parseLong(val);
					 tempVal = getMintes(milliseconds);
					 long minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds);
					 if(minutes == 0){
						 long sec = TimeUnit.MILLISECONDS.toSeconds(milliseconds);
						 if(sec == 0){
							 val = milliseconds+" MilliSeconds";
						 } else {
							 val = sec+" Seconds";
						 }
					 } else{
						 val = minutes+" Minutes";
					 }
				 }else {
					 val = "0";
				 }
				 planService.getDetails().add(getPlanService(val));
				 planService.getDetails().add(getPlanServiceUnit(tempVal));
			 } else if(planService.getLabelValue().toLowerCase().contains("storage")){//enterprise Content Storage
				 String serviceId =  allServices.get("Metric-Enterprise-Content-Storage");
				 String val = getValue(utilizationMap,serviceId);
				 String tempVal = "0";
				 if(val!= null){
					 long longVal = Long.parseLong(val);
					 val =  getSize(longVal);
					 tempVal = getSizeInGb(longVal);
				 }else {
					 val = "0 Bytes";
				 }
				 planService.getDetails().add(getPlanService(val));
				 planService.getDetails().add(getPlanServiceUnit(tempVal));
			 }
		}
	
		 return servicesList;
	}

	private String getValue(Map<String, Map<String, String>> utilizationMap, String serviceId) {
		if(serviceId !=null && utilizationMap.containsKey(serviceId)) {
			 Map<String, String> utlz =  utilizationMap.get(serviceId);
			 try {
				return utlz.entrySet().iterator().next().getValue();
			} catch (NullPointerException e) {
				logger.error("ServiceMetricService.getValue, Error : " + e.getMessage(), e);
			} catch (Exception e) {
				logger.error("ServiceMetricService.getValue, Error : " + e.getMessage(), e);
			}
		}
		
		return null;
	}
	
	private PlanService getPlanService(String value){
		 PlanService service  = new PlanService();
		 service.setLabelName("Service Utilization");
		 service.setAttributeName("serviceUtilization");
		 if(value !=null){
			 service.setLabelValue(value);
		 } else {
			 service.setLabelValue("0");
		 }
		 
		 return service;
	}
	
	private PlanService getPlanPrice(List<PlanService> planServiceList, String usedUnit) {

		String price = "0";

		for (PlanService planService : planServiceList) {
			if (planService.getAttributeName().equalsIgnoreCase("serviceUnitPrice")) {
				price = planService.getLabelValue();
				break;
			}
		}

		PlanService service = new PlanService();
		service.setLabelName("Service Price");
		service.setAttributeName("servicePrice");
		if (usedUnit != null) {
			service.setLabelValue(String.valueOf(Double.valueOf(usedUnit) * Double.valueOf(price)));
		} else {
			service.setLabelValue("0");
		}

		return service;
	}
	
	private PlanService getPlanServiceUnit(String value){
		 PlanService service  = new PlanService();
		 service.setLabelName("Service Utilization Unit");
		 service.setAttributeName("serviceUtilizationUnit");
		 if(value !=null){
			 service.setLabelValue(value);
		 } else {
			 service.setLabelValue("0");
		 }
		 
		 return service;
	}
	
	public static String getSize(long size) {
        long n = 1024;
        String s = "";
        double kb = size / n;
        double mb = kb / n;
        double gb = mb / n;
        double tb = gb / n;
        if(size < n) {
            s = size + " Bytes";
        } else if(size >= n && size < (n * n)) {
            s =  String.format("%.2f", kb) + " KB";
        } else if(size >= (n * n) && size < (n * n * n)) {
            s = String.format("%.2f", mb) + " MB";
        } else if(size >= (n * n * n) && size < (n * n * n * n)) {
            s = String.format("%.2f", gb) + " GB";
        } else if(size >= (n * n * n * n)) {
            s = String.format("%.2f", tb) + " TB";
        }
        return s;
    }
	
	public static String getSizeInGb(long bytes) {
        long n = 1024;
        String s = "";
        double kb = bytes / n;
        double mb = kb / n;
        double gb = mb / n;
        s = String.format("%.2f", gb);
        
        return s;
	}
	
	public static String getMintes(long milliseconds) {
        long n = 1000;
        String s = "";
        double sec = milliseconds / n;
        double mins = sec / 60;
        s = String.format("%.2f", mins);
        
        return s;
	}
}
