package com.akila.metricservices.usermetric.bean;

public class UserCategoryGroupCount {
	
	private String userGroupNm;
	private long count;
	
	public UserCategoryGroupCount(String userGroupName, long count) {
		super();
		this.userGroupNm = userGroupName;
		this.count = count;
	}
	public String getUserGroupName() {
		return userGroupNm;
	}
	public void setUserGroupName(String userGroupName) {
		this.userGroupNm = userGroupName;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	
}
