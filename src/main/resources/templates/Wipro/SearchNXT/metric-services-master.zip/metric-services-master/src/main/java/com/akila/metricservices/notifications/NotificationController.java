package com.akila.metricservices.notifications;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;


@RestController
public class NotificationController extends AkilaController {
	
	@Autowired
	NotificationService notificationService;
	
	@Autowired
	QueueProcessor queueProcessor;
	
	@PostMapping(path = "/publishEvent")
	public void publishEvent(@RequestParam String serviceName,@RequestParam(required = false) Double value){
		notificationService.addMessageInQueue(serviceName,value);
	}
	
	@GetMapping(path = "/processQueue")
	public void notification(){
		queueProcessor.processQueue();
	}
}
