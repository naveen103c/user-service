package com.akila.metricservices.usermetric.bean;

public class UserCountMetricResponse {

	private long totalUsers;
	private long activeUsers;
	private long dormantUsers;
	
	public UserCountMetricResponse(long totalUsers, long activeUsers, long dormantUsers) {
		super();
		this.totalUsers = totalUsers;
		this.activeUsers = activeUsers;
		this.dormantUsers = dormantUsers;
	}
	public long getTotalUsers() {
		return totalUsers;
	}
	public void setTotalUsers(long totalUsers) {
		this.totalUsers = totalUsers;
	}
	public long getActiveUsers() {
		return activeUsers;
	}
	public void setActiveUsers(long activeUsers) {
		this.activeUsers = activeUsers;
	}
	public long getDormantUsers() {
		return dormantUsers;
	}
	public void setDormantUsers(long dormantUsers) {
		this.dormantUsers = dormantUsers;
	}
	
}
