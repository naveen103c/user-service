package com.akila.metricservices.entity;

import com.akila.AkilaEntity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the org_reports database table.
 * 
 */
@Entity
@Table(name="org_reports")
@NamedQuery(name="OrgReport.findAll", query="SELECT o FROM OrgReport o")
public class OrgReport extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="org_report_id")
	private String orgReportId;
	
	@Column(name="report_id")
	private String reportId;
	
	@Column(name="report_name")
	private String reportName;
	
	@Column(name="description")
	private String description;
	
	@Column(name="user_role")
	private String userRole;

	@Column(name="page_name")
	private String pageName;
	
	@Column(name="parent_id")
	private String parentId;
	
	public String getOrgReportId() {
		return orgReportId;
	}

	public void setOrgReportId(String orgReportId) {
		this.orgReportId = orgReportId;
	}

	public String getReportId() {
		return reportId;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUserRole() {
		return userRole;
	}

	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	
}