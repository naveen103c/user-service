package com.akila.metricservices.powerbi;

import java.net.MalformedURLException;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.http.HttpStatus;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;


@RestController
public class PowerBIReportController 
{
	private static final Logger logger = LogManager.getLogger(PowerBIReportController.class);
	@Value("${powerbi.workspaceId}")
	private String workspaceId;
	
	@Autowired
	private AzureADService adService;
	
	@Autowired
	private PowerBIService biService;
	
	@GetMapping("/powerbi/getToken/{reportId}")
	public ResponseEntity getToken(@PathVariable String reportId, @RequestParam(required = false) String pageName)
	{
		String accessToken;
		try {
			accessToken = adService.getAccessToken();
		} catch (ExecutionException | MalformedURLException | RuntimeException ex) {
			logger.error("error while fetching token", ex);
			return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body(ex.getMessage());

		} catch (InterruptedException interruptedEx) {
			logger.error(interruptedEx.getMessage());
			Thread.currentThread().interrupt();
			return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body(interruptedEx.getMessage());
		}
		
		try {

			EmbedConfig reportEmbedConfig = biService.getEmbedConfig(accessToken, workspaceId, reportId, pageName);
			TokenResponse tokenResponse = new TokenResponse();
			tokenResponse.setEmbedToken(reportEmbedConfig.embedToken.token);
			tokenResponse.setEmbedReports(reportEmbedConfig.embedReports);
			tokenResponse.setTokenExpiry(reportEmbedConfig.embedToken.expiration);
			return ResponseEntity.ok(tokenResponse);

		} catch (HttpClientErrorException hcex) {
			StringBuilder errMsgStringBuilder = new StringBuilder("Error: "); 
			errMsgStringBuilder.append(hcex.getMessage());

			// Get Request Id
			HttpHeaders header = hcex.getResponseHeaders();
			List<String> requestIds = header.get("requestId");
			if (requestIds != null) {
				for (String requestId: requestIds) {
					errMsgStringBuilder.append("\nRequest Id: ");
					errMsgStringBuilder.append(requestId);
				}
			}
			
			// Error message string to be returned
			String errMsg = errMsgStringBuilder.toString();
			logger.error(errMsg);
			return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body(errMsg);
		} catch (RuntimeException rex) {
			logger.error(rex.getMessage());
			return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body(rex.getMessage());
		} catch (JsonMappingException e) {
			logger.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body(e.getMessage());
		} catch (JsonProcessingException e) {
			logger.error(e.getMessage());
			return ResponseEntity.status(HttpStatus.SC_INTERNAL_SERVER_ERROR).body(e.getMessage());
		}
		
	}
	
	
	
	
}
