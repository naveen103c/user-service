package com.akila.metricservices.brainindexmetric.bean;

public class BrainIndexMetricCommunityResponse extends BrainIndexMetricResponse {
	
	private String userId;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}

