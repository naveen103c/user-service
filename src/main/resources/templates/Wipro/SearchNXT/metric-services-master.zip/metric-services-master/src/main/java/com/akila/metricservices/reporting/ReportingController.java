package com.akila.metricservices.reporting;

import com.akila.AkilaController;
import com.akila.metricservices.reporting.bean.ReportingResponse;
import java.lang.String;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ReportingController extends AkilaController {
  @Autowired
  private ReportingService reportingService;

  @GetMapping(
      path = "/reports"
  )
  public List<ReportingResponse> getReports() {
    return reportingService.getReports();
  }

  @GetMapping(
      path = "/report/{id}"
  )
  public ReportingResponse getReportById(@PathVariable String id) {
    return reportingService.getReportById(id);
  }
}
