package com.akila.utility;

public class MetricServiceUtility {

	public static String getValue(String str) {
		if (str != null) {
			return str;
		} else {
			return "";
		}
	}
	
	public static Integer getValue(Integer itr) {
		if (itr != null) {
			return itr;
		} else {
			return 0;
		}
	}
	
}
