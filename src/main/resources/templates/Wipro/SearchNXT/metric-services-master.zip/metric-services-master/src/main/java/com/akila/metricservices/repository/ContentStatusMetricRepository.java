package com.akila.metricservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.contentmetric.bean.ContentQueryResponse;
import com.akila.metricservices.contentmetric.bean.ContentWikiResponse;
import com.akila.metricservices.entity.ContentStatusMetric;
import com.akila.metricservices.entity.ContentStatusMetricPK;

@Repository
public interface ContentStatusMetricRepository extends JpaRepository<ContentStatusMetric, ContentStatusMetricPK> {

	@Query(value = "SELECT new com.akila.metricservices.contentmetric.bean.ContentQueryResponse(SUM(c.askedCt) , SUM(c.answeredCt) , SUM(c.closedCt)) "
			+ "FROM ContentStatusMetric c")
	ContentQueryResponse getAskedAnsweredAndClosedCount();

	@Query(value = "SELECT new com.akila.metricservices.contentmetric.bean.ContentWikiResponse(SUM(c.draftCt), SUM(c.publishedCt)) FROM ContentStatusMetric c")
	ContentWikiResponse getDraftAndPublishedCount();

}