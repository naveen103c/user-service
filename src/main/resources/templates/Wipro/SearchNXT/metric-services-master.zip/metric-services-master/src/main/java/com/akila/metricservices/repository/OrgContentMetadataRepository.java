package com.akila.metricservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.entity.OrgContentMetadata;

@Repository
public interface OrgContentMetadataRepository extends JpaRepository<OrgContentMetadata, String> 
{
	
}
