package com.akila.metricservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the content_status_metric database table.
 * 
 */
@Entity
@Table(name="content_status_metric")
@NamedQuery(name="ContentStatusMetric.findAll", query="SELECT o FROM ContentStatusMetric o")
public class ContentStatusMetric implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ContentStatusMetricPK id;
	
	@Column(name="asked_ct")
	private Integer askedCt;

	@Column(name="answered_ct")
	private Integer answeredCt;

	@Column(name="closed_ct")
	private Integer closedCt;

	@Column(name="draft_ct")
	private Integer draftCt;

	@Column(name="published_ct")
	private Integer publishedCt;
	
	@Column(name="comment_ct")
	private Integer commentCt;

	@Column(name="response_ct")
	private Integer responseCt;

	public ContentStatusMetric() {
	}

	public ContentStatusMetricPK getId() {
		return id;
	}

	public void setId(ContentStatusMetricPK id) {
		this.id = id;
	}

	public Integer getAskedCt() {
		return askedCt;
	}

	public void setAskedCt(Integer askedCt) {
		this.askedCt = askedCt;
	}

	public Integer getAnsweredCt() {
		return answeredCt;
	}

	public void setAnsweredCt(Integer answeredCt) {
		this.answeredCt = answeredCt;
	}

	public Integer getClosedCt() {
		return closedCt;
	}

	public void setClosedCt(Integer closedCt) {
		this.closedCt = closedCt;
	}

	public Integer getDraftCt() {
		return draftCt;
	}

	public void setDraftCt(Integer draftCt) {
		this.draftCt = draftCt;
	}

	public Integer getPublishedCt() {
		return publishedCt;
	}

	public void setPublishedCt(Integer publishedCt) {
		this.publishedCt = publishedCt;
	}

	public Integer getCommentCt() {
		return commentCt;
	}

	public void setCommentCt(Integer commentCt) {
		this.commentCt = commentCt;
	}

	public Integer getResponseCt() {
		return responseCt;
	}

	public void setResponseCt(Integer responseCt) {
		this.responseCt = responseCt;
	}

}