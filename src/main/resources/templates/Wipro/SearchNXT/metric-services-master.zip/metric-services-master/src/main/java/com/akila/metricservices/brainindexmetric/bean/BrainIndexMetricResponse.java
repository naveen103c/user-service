package com.akila.metricservices.brainindexmetric.bean;

import com.akila.AkilaResponse;
import com.akila.metricservices.entity.OrgUserMetricPK;

public class BrainIndexMetricResponse extends AkilaResponse {
	
	private String metricPeriodDt;

	private Integer answerCt;

	private Integer commentCt;

	private Integer wikiCt;
	
	private Integer queryCt;
	
	private Integer sessionCt;

	public Integer getAnswerCt() {
		return answerCt;
	}

	public void setAnswerCt(Integer answerCt) {
		this.answerCt = answerCt;
	}

	public Integer getCommentCt() {
		return commentCt;
	}

	public void setCommentCt(Integer commentCt) {
		this.commentCt = commentCt;
	}

	public Integer getWikiCt() {
		return wikiCt;
	}

	public void setWikiCt(Integer wikiCt) {
		this.wikiCt = wikiCt;
	}

	public Integer getQueryCt() {
		return queryCt;
	}

	public void setQueryCt(Integer queryCt) {
		this.queryCt = queryCt;
	}

	public Integer getSessionCt() {
		return sessionCt;
	}

	public void setSessionCt(Integer sessionCt) {
		this.sessionCt = sessionCt;
	}

	public String getMetricPeriodDt() {
		return metricPeriodDt;
	}

	public void setMetricPeriodDt(String metricPeriodDt) {
		this.metricPeriodDt = metricPeriodDt;
	}
	
	
}

