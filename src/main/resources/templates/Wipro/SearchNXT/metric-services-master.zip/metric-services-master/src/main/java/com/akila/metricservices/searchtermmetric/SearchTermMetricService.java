package com.akila.metricservices.searchtermmetric;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.metricservices.entity.OrgSearchTermMetric;
import com.akila.metricservices.repository.OrgSearchTermMetricRepository;
import com.akila.metricservices.searchtermmetric.bean.SearchTermMetricEfficiencyResponse;

@Service
public class SearchTermMetricService extends AkilaService {
	@Autowired
	protected OrgSearchTermMetricRepository orgSearchTermMetricRepository;

	public Map<String, Long> getSearchTrendMetric(Integer metricPeriodCd, Integer count) {
		Map<String, Long> data = new HashMap<String, Long>();
		List<OrgSearchTermMetric> orgSearchTermMetricList = orgSearchTermMetricRepository
				.getSearchTrendMetric(metricPeriodCd);

		for (OrgSearchTermMetric orgSearchTermMetric : orgSearchTermMetricList) {
			data.put(orgSearchTermMetric.getId().getSearchTerm(), orgSearchTermMetric.getSearchCount().longValue());
		}
		return data;
	}

	public List<SearchTermMetricEfficiencyResponse> getSearchEfficiencyMetric(Integer metricPeriodCd, Integer count) {

		List<OrgSearchTermMetric> orgSearchTermMetricList = orgSearchTermMetricRepository
				.getSearchEfficiencyMetric(metricPeriodCd);

		return mapOrgSearchTermMetricToSearchTermMetricEfficiencyResponse(orgSearchTermMetricList);
	}

	public List<SearchTermMetricEfficiencyResponse> mapOrgSearchTermMetricToSearchTermMetricEfficiencyResponse(
			List<OrgSearchTermMetric> orgSearchTermMetricList) {

		List<SearchTermMetricEfficiencyResponse> responseList = new ArrayList<SearchTermMetricEfficiencyResponse>();

		for (OrgSearchTermMetric orgSearchTermMetric : orgSearchTermMetricList) {
			SearchTermMetricEfficiencyResponse searchTermMetricEfficiencyResponse = new SearchTermMetricEfficiencyResponse();
			searchTermMetricEfficiencyResponse.setFailedSearches(orgSearchTermMetric.getSearchFailure());
			searchTermMetricEfficiencyResponse.setTotalSearches(orgSearchTermMetric.getSearchCount());
			responseList.add(searchTermMetricEfficiencyResponse);
		}

		return responseList;
	}

}
