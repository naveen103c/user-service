package com.akila.metricservices.expertconnect;

import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;

@RestController
public class ExpertConnectMetricController extends AkilaController {

	@Autowired
	private ExpertConnectMetricService dashboardMetricService;

	@GetMapping(path = "/expertconnect/appointments/userwise")
	public Map<String, String> getSessionsByUser(@RequestParam String userId) {
		return dashboardMetricService.getSessionsByUser(userId);
	}

	@GetMapping(path = "/expertconnect/appointments/skillwise")
	public Map<String, String> getAppointmentsSkillWise(@RequestParam String userId) {
		return dashboardMetricService.getAppointmentsSkillWise(userId);
	}

}
