package com.akila.metricservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.entity.OrgMonthlyInvoice;

@Repository
public interface OrgMonthlyInvoiceRepository extends JpaRepository<OrgMonthlyInvoice, String> {

	OrgMonthlyInvoice findByInvoiceMonthAndInvoiceYear(@Param("month") int month, @Param("year") int year);
}
