package com.akila.metricservices.repository;

import com.akila.metricservices.entity.OrgReport;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgReportRepository extends JpaRepository<OrgReport, String> {
	
	List<OrgReport> findByParentIdNull();

	List<OrgReport> findByParentId(String orgReportId);
	
}
