package com.akila.metricservices.brainindexmetric.test;



import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import com.akila.metricservices.MetricServicesApplication;
import com.akila.metricservices.brainindexmetric.BrainindexmetricController;
import com.akila.metricservices.brainindexmetric.bean.BrainIndexMetricCommunityResponse;
import com.akila.metricservices.brainindexmetric.bean.BrainIndexMetricResponse;

@SpringBootTest(classes = MetricServicesApplication.class)
@TestPropertySource(locations="classpath:application-test.properties")
public class BrainindexmetricControllerTest {
	@Autowired
	private BrainindexmetricController controller;

	@Test
	public void getUserActivityMetric() {
		List<BrainIndexMetricResponse> brainIndexMetricResponseList = controller
				.getUserActivityMetric("934e39ab-fd79-4fe9-ab10-a9980a4dd2b3", 3, 3);

		for (BrainIndexMetricResponse response : brainIndexMetricResponseList) {
			assertNotNull(response);
		}

	}

	@Test
	public void getUserActivityMetricbyCommunityId() {
		List<BrainIndexMetricCommunityResponse> brainIndexMetricResponseList = controller
				.getCommunityActivityMetric("bdd308fe-7704-454c-9893-dc0346ef7f87", 3, null);

		for (BrainIndexMetricResponse response : brainIndexMetricResponseList) {
			assertNotNull(response);
		}

	}

}
