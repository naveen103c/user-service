package com.akila.metricservices.searchtermmetric.bean;

public class SearchTermMetricEfficiencyResponse {
	
	private Integer totalSearches;
	
	private Integer failedSearches;

	public Integer getTotalSearches() {
		return totalSearches;
	}

	public void setTotalSearches(Integer totalSearches) {
		this.totalSearches = totalSearches;
	}

	public Integer getFailedSearches() {
		return failedSearches;
	}

	public void setFailedSearches(Integer failedSearches) {
		this.failedSearches = failedSearches;
	}

}
