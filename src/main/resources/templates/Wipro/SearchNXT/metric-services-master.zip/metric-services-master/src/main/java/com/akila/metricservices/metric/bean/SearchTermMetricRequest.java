package com.akila.metricservices.metric.bean;

public class SearchTermMetricRequest 
{
	private String searchTerm;
	private int successResults;
	private int failedResults;
	
	
	public String getSearchTerm() {
		return searchTerm;
	}
	public void setSearchTerm(String searchTerm) {
		this.searchTerm = searchTerm;
	}
	public int getSuccessResults() {
		return successResults;
	}
	public void setSuccessResults(int successResults) {
		this.successResults = successResults;
	}
	public int getFailedResults() {
		return failedResults;
	}
	public void setFailedResults(int failedResults) {
		this.failedResults = failedResults;
	}

}
