package com.akila.metricservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.client.RestTemplate;

import com.akila.commons.AkilaCommonsApplication;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableEncryptableProperties
@EnableSwagger2
@EnableTransactionManagement
@ControllerAdvice(
    basePackages = "com.akila.*"
)
@EntityScan(
    basePackages = "com.akila.*"
)
@EnableDiscoveryClient
@PropertySources({
	@PropertySource("classpath:app.properties"),
	@PropertySource(name="prod", value = "file:${external.config}", ignoreResourceNotFound = true)
})
@Import(value = { AkilaCommonsApplication.class})

public class MetricServicesApplication {
  public static void main(String[] args) {
    SpringApplication.run(MetricServicesApplication.class, args);
  }
  
	@Bean("loadBalanced")
	@Primary
	@LoadBalanced
	public RestTemplate restTemplateLoadBalanced(RestTemplateBuilder builder) {
		return builder.build();
	}
  
//  @Bean
//  @LoadBalanced
//  public RestTemplate restTemplate(RestTemplateBuilder builder) {
//	  return builder.build();
//  }
}
