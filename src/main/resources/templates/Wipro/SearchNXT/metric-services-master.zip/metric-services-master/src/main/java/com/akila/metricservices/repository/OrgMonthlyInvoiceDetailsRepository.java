package com.akila.metricservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.entity.OrgMonthlyInvoiceDetails;

@Repository
public interface OrgMonthlyInvoiceDetailsRepository extends JpaRepository<OrgMonthlyInvoiceDetails, String> {

	List<OrgMonthlyInvoiceDetails> findByInvoiceId(@Param("invoiceId") String invoiceId);
	

}
