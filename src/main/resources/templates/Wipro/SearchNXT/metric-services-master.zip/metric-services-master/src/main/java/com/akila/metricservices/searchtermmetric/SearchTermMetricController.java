package com.akila.metricservices.searchtermmetric;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.metricservices.searchtermmetric.bean.SearchTermMetricEfficiencyResponse;

@RestController
public class SearchTermMetricController extends AkilaController {

	@Autowired
	private SearchTermMetricService searchTermMetricService;

	@GetMapping(path = "/search-metric/trends")
	public Map<String, Long> getSearchTrendMetric(@RequestParam Integer periodCd,
			@RequestParam Integer count) {
		return searchTermMetricService.getSearchTrendMetric(periodCd, count);
	}

	@GetMapping(path = "/search-metric/efficiency")
	public List<SearchTermMetricEfficiencyResponse> getSearchEfficiencyMetric(@RequestParam Integer periodCd,
			@RequestParam Integer count) {
		return searchTermMetricService.getSearchEfficiencyMetric(periodCd, count);
	}

}
