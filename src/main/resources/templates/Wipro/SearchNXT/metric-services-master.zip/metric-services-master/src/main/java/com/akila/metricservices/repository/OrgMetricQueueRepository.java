package com.akila.metricservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.metricservices.entity.OrgMetricQueue;

@Repository
public interface OrgMetricQueueRepository extends JpaRepository<OrgMetricQueue, String> {

	public List<OrgMetricQueue> findByStatus(int i);

}
