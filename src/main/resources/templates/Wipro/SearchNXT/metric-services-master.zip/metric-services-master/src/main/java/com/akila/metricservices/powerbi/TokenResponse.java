package com.akila.metricservices.powerbi;

import java.util.List;

public class TokenResponse 
{
	private String embedToken;
	private List<ReportConfig> embedReports;
	private String tokenExpiry;
	
	
	public String getEmbedToken() {
		return embedToken;
	}
	public void setEmbedToken(String embedToken) {
		this.embedToken = embedToken;
	}
	public List<ReportConfig> getEmbedReports() {
		return embedReports;
	}
	public void setEmbedReports(List<ReportConfig> embedReports) {
		this.embedReports = embedReports;
	}
	public String getTokenExpiry() {
		return tokenExpiry;
	}
	public void setTokenExpiry(String tokenExpiry) {
		this.tokenExpiry = tokenExpiry;
	}
	
}
