package com.akila.metricservices.notifications;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.ListUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.akila.metricservices.entity.OrgMetricQueue;
import com.akila.metricservices.entity.OrgServiceMetric;
import com.akila.metricservices.entity.OrgServiceMetricPK;
import com.akila.metricservices.repository.OrgMetricQueueRepository;
import com.akila.metricservices.servicemetric.ServiceMetricService;
import com.akilacommons.tenant.DataSourceProperties;
import com.akilacommons.tenant.TenantContext;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.Message;
import com.amazonaws.services.sqs.model.ReceiveMessageRequest;
import com.azure.core.exception.AzureException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.queue.CloudQueue;
import com.microsoft.azure.storage.queue.CloudQueueMessage;

@Configuration
@EnableScheduling
public class QueueProcessor {
	private static final Logger logger = LogManager.getLogger(QueueProcessor.class);

	@Autowired
	ServiceMetricService ServiceMetricService;
	@Autowired
	OrgMetricQueueRepository orgMetricQueueRepository;

	@Value("${sqs-url}")
	private String sqsUrl;
	@Value("${queue.processing.batch.size}")
	private int queueProcessingBatchSize;
	@Value("${metric.queue.impl}")
	private String metricQueueImpl;

	@Value("${azure.blob.connection-string:connectionString}")
	String connectionString;
	@Value("${azure.metric.queue.name}")
	private String azureQueueName;

	AmazonSQS sqs = null;

	@Autowired
	DataSourceProperties dataSourceProperties;

	public AmazonSQS getSqsClient() {
		if (sqs == null) {
			sqs = AmazonSQSClientBuilder.standard().withCredentials(new InstanceProfileCredentialsProvider(false))
					.build();

		}
		return sqs;
	}

	//@Scheduled(cron = "${metric.queue.process.cron}")
	public void processQueue() {
		if (metricQueueImpl.equalsIgnoreCase("db")) {
			getDataFromDatabase();
		} else if (metricQueueImpl.equalsIgnoreCase("azure")) {
			getDataFromAzure();
		} else {
			getDataFromSQS();
		}
	}

	private void getDataFromAzure() {
		try {
			CloudStorageAccount storageAccount = CloudStorageAccount.parse(connectionString);
			CloudQueue queue = storageAccount.createCloudQueueClient().getQueueReference(azureQueueName);
			queue.downloadAttributes();
			int count = (int) queue.getApproximateMessageCount();
			if (count > 0) {
				int loop = (count / 32) + 1;
				Map<String, String> servicesMap = ServiceMetricService.getAllServiceMetric();
				ObjectMapper mapper = new ObjectMapper();
				for (int i = 1; i <= loop; i++) {
					Iterable<CloudQueueMessage> msg = queue.retrieveMessages(32 * i);
					Map<String, Map<String, BigDecimal>> serviceCountMap = new HashMap<String, Map<String, BigDecimal>>();
					for (CloudQueueMessage cloudQueueMessage : msg) {
						logger.info("QueueProcessor.processQueue, Message : "
								+ cloudQueueMessage.getMessageContentAsString());
						try {
							Notification notification = mapper.readValue(cloudQueueMessage.getMessageContentAsString(),
									Notification.class);
							getServiceCountMap(servicesMap, serviceCountMap, notification);
						} catch (NullPointerException e) {
							logger.error("QueueProcessor.processQueue - error while parsing message, Message : "
									+ cloudQueueMessage.getMessageContentAsString(), e);
						} catch (Exception e) {
							logger.error("QueueProcessor.processQueue - error while parsing message, Message : "
									+ cloudQueueMessage.getMessageContentAsString(), e);
						}
					}

					for (Map.Entry<String, Map<String, BigDecimal>> map : serviceCountMap.entrySet()) {
						TenantContext.setCurrentTenant(map.getKey());
						saveMetric(map.getValue());
					}

					logger.info("QueueProcessor.processQueue, Deleting messages.... : ");
					for (CloudQueueMessage cloudQueueMessage : msg) {
						queue.deleteMessage(cloudQueueMessage, null, null);
					}
					logger.info("QueueProcessor.processQueue, Deleted messages : ");

				}
			}
		} catch (NullPointerException | AzureException e) {
			logger.error("QueueProcessor.getDataFromAzure, Error : " + e.getMessage(), e);
		} catch (Exception e) {
			logger.error("QueueProcessor.getDataFromAzure, Error : " + e.getMessage(), e);
		}

	}

	private void getDataFromSQS() {
		ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest();
		receiveMessageRequest.setQueueUrl(sqsUrl);
		receiveMessageRequest.setMaxNumberOfMessages(10);
		List<Message> messages = getSqsClient().receiveMessage(receiveMessageRequest).getMessages();
		if (messages != null && messages.size() > 0) {

			logger.info("QueueProcessor.processQueue, Total Messages in SQS : " + messages.size());
			List<List<Message>> subList = ListUtils.partition(messages, queueProcessingBatchSize);
			Map<String, String> servicesMap = ServiceMetricService.getAllServiceMetric();
			ObjectMapper mapper = new ObjectMapper();
			for (List<Message> list : subList) {
				Map<String, Map<String, BigDecimal>> serviceCountMap = new HashMap<String, Map<String, BigDecimal>>();
				for (Message message : list) {
					logger.info("QueueProcessor.processQueue, Message : " + message.getBody());
					try {
						Notification notification = mapper.readValue(message.getBody(), Notification.class);
						getServiceCountMap(servicesMap, serviceCountMap, notification);
					} catch (NullPointerException e) {
						logger.error("QueueProcessor.processQueue - error while parsing message, Message : "
								+ message.getBody(), e);
					} catch (Exception e) {
						logger.error("QueueProcessor.processQueue - error while parsing message, Message : "
								+ message.getBody(), e);
					}
				}

				for (Map.Entry<String, Map<String, BigDecimal>> map : serviceCountMap.entrySet()) {
					TenantContext.setCurrentTenant(map.getKey());
					saveMetric(map.getValue());
				}

				logger.info("QueueProcessor.processQueue, Deleting messages.... : " + list.size());
				for (Message message : list) {
					sqs.deleteMessage(sqsUrl, message.getReceiptHandle());
				}
				logger.info("QueueProcessor.processQueue, Deleted messages : ");
			}
			
			if(messages.size() == 10) {
				getDataFromSQS();
			}
		}

	}

	private void getDataFromDatabase() {

		Map<Object, Object> datasources = dataSourceProperties.getDatasources();

		for (Map.Entry<Object, Object> datasource : datasources.entrySet()) {
			if (String.valueOf(datasource.getKey()).equalsIgnoreCase("base")) {
				continue;
			}
			TenantContext.setCurrentTenant(String.valueOf(datasource.getKey()));

			List<OrgMetricQueue> messages = getMessagesFromDB();
			if (messages != null && messages.size() > 0) {
				logger.info("QueueProcessor.processQueue Database, Total Messages in SQS : " + messages.size());
				List<List<OrgMetricQueue>> subList = ListUtils.partition(messages, queueProcessingBatchSize);
				Map<String, String> servicesMap = ServiceMetricService.getAllServiceMetric();
				ObjectMapper mapper = new ObjectMapper();
				for (List<OrgMetricQueue> list : subList) {
					Map<String, Map<String, BigDecimal>> serviceCountMap = new HashMap<String, Map<String, BigDecimal>>();
					for (OrgMetricQueue message : list) {
						System.out.println("messages in SQS ------------------------>" + message.getMetricJson());
						logger.info("QueueProcessor.processQueue, Message : " + message.getMetricJson());
						try {
							Notification notification = mapper.readValue(message.getMetricJson(), Notification.class);
							getServiceCountMap(servicesMap, serviceCountMap, notification);
						} catch (NullPointerException e) {
							logger.error("QueueProcessor.processQueue - error while parsing message, Message : "
									+ message.getMetricJson(), e);
						} catch (Exception e) {
							logger.error("QueueProcessor.processQueue - error while parsing message, Message : "
									+ message.getMetricJson(), e);
						}

					}
					for (Map.Entry<String, Map<String, BigDecimal>> map : serviceCountMap.entrySet()) {
						TenantContext.setCurrentTenant(map.getKey());
						saveMetric(map.getValue());
					}

					logger.info("QueueProcessor.processQueue, Deleting messages.... : " + list.size());

					orgMetricQueueRepository.deleteInBatch(list);

					logger.info("QueueProcessor.processQueue, Deleted messages : ");
				}
			}
		}
	}

	private List<String> saveMetric(Map<String, BigDecimal> serviceCountMap) {
		List<String> serviceIdList = new ArrayList<String>(serviceCountMap.keySet());
		logger.info("QueueProcessor.processQueue, saveMetric....Tenant : "+TenantContext.getCurrentTenant());
		List<OrgServiceMetric> updatedList = getMetricsForAllPeriods(serviceCountMap, serviceIdList);

		logger.info("QueueProcessor.processQueue, update metric...."+updatedList);
		ServiceMetricService.saveServiceMetrics(updatedList);
		logger.info("QueueProcessor.processQueue, updated metric. ");
		return serviceIdList;
	}

	private void getServiceCountMap(Map<String, String> servicesMap,
			Map<String, Map<String, BigDecimal>> serviceCountMap, Notification notification) {
		if (servicesMap.containsKey(notification.getServiceName())) {
			Map<String, BigDecimal> notificationMap = serviceCountMap.get(notification.getTenant());
			if (notificationMap == null) {
				notificationMap = new HashMap<String, BigDecimal>();
				serviceCountMap.put(notification.getTenant(), notificationMap);
			}
			String serviceId = servicesMap.get(notification.getServiceName());
			if (notificationMap.containsKey(serviceId)) {
				notificationMap.put(serviceId, notificationMap.get(serviceId).add(new BigDecimal(notification.value)));
			} else {
				notificationMap.put(serviceId, new BigDecimal(notification.value));
			}
		} else {
			logger.error("QueueProcessor.processQueue - Service Name is incorrect, Service Name  : "
					+ notification.getServiceName());
		}
	}

	private List<OrgServiceMetric> getMetricsForAllPeriods(Map<String, BigDecimal> serviceCountMap,
			List<String> serviceIdList) {
		List<Integer> periodCdList = getPeriodCd();
		List<OrgServiceMetric> list = null;
		List<OrgServiceMetric> updatedList = new ArrayList<OrgServiceMetric>();
		Date date = new Date();
		for (Integer cd : periodCdList) {
			if (cd == 1) {
				list = ServiceMetricService.getServiceMetricsCount(serviceIdList, cd, date);
			} else if (cd == 2) {
				list = ServiceMetricService.getServiceMetricsCount(serviceIdList, cd, Utils.getWeekStartDate(date),
						Utils.getWeekEndDate(date));
			} else if (cd == 3) {
				list = ServiceMetricService.getServiceMetricsCount(serviceIdList, cd, Utils.getMonthStartDate(date),
						Utils.getMonthEndDate(date));
			} else if (cd == 4) {
				list = ServiceMetricService.getServiceMetricsCount(serviceIdList, cd, Utils.getQuarterStartDate(date),
						Utils.getQuarterEndDate(date));
			} else if (cd == 5) {
				list = ServiceMetricService.getServiceMetricsCount(serviceIdList, cd, Utils.getYearStartDate(date),
						Utils.getYearEndDate(date));
			} else if (cd == 6) {
				list = ServiceMetricService.getServiceMetricsCount(serviceIdList, cd);
			}

			if (list != null && list.size() > 0) {
				for (Map.Entry<String, BigDecimal> entry : serviceCountMap.entrySet()) {
					boolean isFound = false;
					for (OrgServiceMetric orgServiceMetric : list) {
						if (entry.getKey().equals(orgServiceMetric.getId().getServiceId())) {
							BigDecimal total = orgServiceMetric.getServiceMetric().add(entry.getValue());
							if (total.longValue() < 0) {
								total = new BigDecimal(0);
							}
							orgServiceMetric.setServiceMetric(total);
							updatedList.add(orgServiceMetric);
							isFound = true;
							break;
						}
					}

					if (!isFound) {
						getMetricObj(updatedList, date, cd, entry);
					}
				}
			} else {
				for (Map.Entry<String, BigDecimal> entry : serviceCountMap.entrySet()) {
					getMetricObj(updatedList, date, cd, entry);
				}
			}

		}
		return updatedList;
	}

	private void getMetricObj(List<OrgServiceMetric> updatedList, Date date, Integer cd,
			Map.Entry<String, BigDecimal> entry) {
		OrgServiceMetric orgServiceMetric = new OrgServiceMetric();
		OrgServiceMetricPK orgServiceMetricPK = new OrgServiceMetricPK();
		orgServiceMetricPK.setMetricPeriodCd(cd);
		orgServiceMetricPK.setMetricPeriodDt(date);
		orgServiceMetricPK.setServiceId(entry.getKey());
		orgServiceMetric.setId(orgServiceMetricPK);
		if (entry.getValue().longValue() < 0) {
			orgServiceMetric.setServiceMetric(new BigDecimal(0));
		} else {
			orgServiceMetric.setServiceMetric(entry.getValue());
		}

		updatedList.add(orgServiceMetric);
	}

	private List<Integer> getPeriodCd() {
		List<Integer> periodCdList = new ArrayList<Integer>();
		periodCdList.add(1);
		periodCdList.add(2);
		periodCdList.add(3);
		periodCdList.add(4);
		periodCdList.add(5);
		periodCdList.add(6);
		return periodCdList;
	}

	private List<OrgMetricQueue> getMessagesFromDB() {
		List<OrgMetricQueue> list = orgMetricQueueRepository.findByStatus(0);
		for (OrgMetricQueue orgMetricQueue : list) {
			orgMetricQueue.setStatus(1);
		}
		orgMetricQueueRepository.saveAll(list);

		return list;
	}

}
