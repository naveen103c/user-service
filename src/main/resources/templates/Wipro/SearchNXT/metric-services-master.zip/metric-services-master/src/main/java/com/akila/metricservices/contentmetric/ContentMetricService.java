package com.akila.metricservices.contentmetric;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.metricservices.contentmetric.bean.ContentQueryResponse;
import com.akila.metricservices.contentmetric.bean.ContentTrendMetricResponse;
import com.akila.metricservices.contentmetric.bean.ContentWikiResponse;
import com.akila.metricservices.contentmetric.bean.EntContentResponse;
import com.akila.metricservices.entity.ContentStatusMetricPK;
import com.akila.metricservices.repository.ContentStatusMetricRepository;
import com.akila.metricservices.repository.OrgContentCreationMetricRepository;
import com.akila.metricservices.searchtermmetric.bean.SearchTermMetricResponse;

@Service
public class ContentMetricService extends AkilaService {

	@Autowired
	protected ContentStatusMetricRepository contentStatusMetricRepository;

	@Autowired
	protected OrgContentCreationMetricRepository orgContentCreationRepository;

	public ContentQueryResponse getQueryMetric(Integer periodCd, Integer count) {
		ContentQueryResponse contentQueryResponse = contentStatusMetricRepository.getAskedAnsweredAndClosedCount();
		return contentQueryResponse;
	}

	public ContentWikiResponse getWikiMetric(Integer periodCd, Integer count) {
		ContentWikiResponse contentWikiResponse = contentStatusMetricRepository.getDraftAndPublishedCount();
		return contentWikiResponse;
	}

	public Map<String, Long> getEntContentMetric(Integer periodCd, Integer count) {
		List<EntContentResponse> entContentResponseList = orgContentCreationRepository.getEntContentCount();
		Map<String, Long> data = new HashMap<String, Long>();
		for (EntContentResponse entContentResponse : entContentResponseList) {
			data.put(entContentResponse.getSubType(), entContentResponse.getSubTypeCount());
		}
		return data;
	}

	public Map<String, Map<String, Long>> getContentTrendMetric(Integer periodCd, Integer count) {
		Map<String, Map<String, Long>> data = new HashMap<String, Map<String, Long>>();
		List<Object[]> response = orgContentCreationRepository.getContentCountByContentType();
		List<ContentTrendMetricResponse> contentTrendMetricResponseList = orgContentCreationRepository.getContentTrendCount();
		for (Object[] obj : response) {
			Map<String, Long> value = new HashMap<String, Long>();
			for (ContentTrendMetricResponse contentTrendMetricResponse : contentTrendMetricResponseList) {
				if (obj[0].toString().equals(contentTrendMetricResponse.getContentType())) {
					value.put(contentTrendMetricResponse.getContentSubtype(), contentTrendMetricResponse.getCreationCt());
				}
			}
			data.put(obj[0].toString(), value);
		}
		return data;
	}

	public ContentStatusMetricPK getContentStatusMetricPK(Integer metricPeriodCd, Date metricPeriodDt) {

		ContentStatusMetricPK contentStatusMetricPK = new ContentStatusMetricPK();
		contentStatusMetricPK.setMetricPeriodCd(metricPeriodCd);
		contentStatusMetricPK.setMetricPeriodDt(metricPeriodDt);

		return contentStatusMetricPK;
	}

}
