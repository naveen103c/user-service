package com.akila.metricservices.contentmetric.bean;

public class ContentQueryResponse {

	private long asked;
	private long answered;
	private long closed;

	public ContentQueryResponse(long asked, long answered, long closed) {
		super();
		this.asked = asked;
		this.answered = answered;
		this.closed = closed;
	}
	
	public long getAsked() {
		return asked;
	}

	public void setAsked(long asked) {
		this.asked = asked;
	}

	public long getAnswered() {
		return answered;
	}

	public void setAnswered(long answered) {
		this.answered = answered;
	}

	public long getClosed() {
		return closed;
	}

	public void setClosed(long closed) {
		this.closed = closed;
	}

}
