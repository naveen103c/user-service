package com.akila.metricservices.searchtermmetric.bean;

import java.util.HashMap;
import java.util.Map;

public class SearchTermMetricResponse {
	
	Map<String, Long> data = new HashMap<String, Long>();

	public Map<String, Long> getData() {
		return data;
	}

	public void setData(Map<String, Long> data) {
		this.data = data;
	}

}
