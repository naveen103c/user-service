package com.akila.metricservices.repository;

import com.akila.metricservices.entity.OrgContentMetric;
import com.akila.metricservices.entity.OrgContentMetricPK;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgContentMetricRepository extends JpaRepository<OrgContentMetric, OrgContentMetricPK> 
{
	@Query(value="select oc from OrgContentMetric oc where oc.id.contentId = :contentId and oc.id.metricPeriodCd = 6")
	public OrgContentMetric getMetricByContentId(String contentId);

	public List<OrgContentMetric> findById_contentIdAndId_metricPeriodCd(String id, int tillDateMetricCd);
	
}
