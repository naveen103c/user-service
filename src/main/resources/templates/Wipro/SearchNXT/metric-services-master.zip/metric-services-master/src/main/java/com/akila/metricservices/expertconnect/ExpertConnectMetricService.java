package com.akila.metricservices.expertconnect;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.metricservices.repository.OrgAppointmentRepository;

@Service
public class ExpertConnectMetricService extends AkilaService {

	@Autowired
	protected OrgAppointmentRepository orgAppointmentRepository;

	public Map<String, String> getSessionsByUser(String userId) {
		List<Object[]> responseList= orgAppointmentRepository.getAppointmentCountBySmeId(userId);
		return mapResponseListToJson(responseList);
	}

	public Map<String, String> getAppointmentsSkillWise(String userId) {
		List<Object[]> responseList= orgAppointmentRepository.getAppointmentSkillWise(userId);
		return mapResponseListToJson(responseList);
	}
	
	public Map<String, String> mapResponseListToJson(List<Object[]> responseList){
		Map<String, String> data = new HashMap<String, String>();
		for(Object[] obj : responseList) {
			data.put(obj[0].toString(), obj[1].toString());
		}
		return data;
	}

}
