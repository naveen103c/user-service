package com.akila.metricservices.notifications;

import java.util.Calendar;
import java.util.Date;

public class Utils {

	public static Date getWeekStartDate(Date date){
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_WEEK,
                calendar.getActualMinimum(Calendar.DAY_OF_WEEK));
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date begining = calendar.getTime();
		return begining;
	}
	
	public static Date getWeekEndDate(Date date){
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_WEEK,
                calendar.getActualMaximum(Calendar.DAY_OF_WEEK));
        calendar.add(Calendar.DATE, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date end = calendar.getTime();
		return end;
	}
	
	public static Date getMonthStartDate(Date date){
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH,
                calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
         calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date begining = calendar.getTime();
		return begining;
	}
	
	public static Date getMonthStartDate(int month,int year){
		Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.MONTH, month-1);
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.DAY_OF_MONTH,
                calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
        
         calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date begining = calendar.getTime();
		return begining;
	}
	
	public static Date getMonthEndDate(int month,int year){
		Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.MONTH, month-1);
        calendar.set(Calendar.YEAR, year);
        calendar.set(Calendar.DAY_OF_MONTH,
                calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        calendar.add(Calendar.DATE, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date end = calendar.getTime();
		return end;
	}
	
	public static Date getMonthEndDate(Date date){
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_MONTH,
                calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
        calendar.add(Calendar.DATE, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date end = calendar.getTime();
		return end;
	}
	
	public static Date getQuarterStartDate(Date date){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH)/3 * 3);
	    return calendar.getTime();
	}
	
	public static Date getQuarterEndDate(Date date){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
	    calendar.set(Calendar.DAY_OF_MONTH, 1);
	    calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH)/3 * 3 + 2);
	    calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
	    calendar.add(Calendar.DATE, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
	    return calendar.getTime();
	}
	
	public static Date getYearStartDate(Date date){
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_YEAR,
                calendar.getActualMinimum(Calendar.DAY_OF_YEAR));
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date begining = calendar.getTime();
		return begining;
	}
	
	public static Date getYearEndDate(Date date){
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
        calendar.set(Calendar.DAY_OF_YEAR,
                calendar.getActualMaximum(Calendar.DAY_OF_YEAR));
        calendar.add(Calendar.DATE, 1);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date end = calendar.getTime();
		return end;
	}
	
}
