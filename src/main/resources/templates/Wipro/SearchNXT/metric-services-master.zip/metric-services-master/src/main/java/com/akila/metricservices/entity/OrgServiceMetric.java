package com.akila.metricservices.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;


/**
 * The persistent class for the org_service_metric database table.
 * 
 */
@Entity
@Table(name="org_service_metric")
@NamedQuery(name="OrgServiceMetric.findAll", query="SELECT o FROM OrgServiceMetric o")
public class OrgServiceMetric implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgServiceMetricPK id;

	@Column(name="service_metric")
	private BigDecimal serviceMetric;

	public OrgServiceMetric() {
	}

	public OrgServiceMetricPK getId() {
		return this.id;
	}

	public void setId(OrgServiceMetricPK id) {
		this.id = id;
	}

	public BigDecimal getServiceMetric() {
		return this.serviceMetric;
	}

	public void setServiceMetric(BigDecimal serviceMetric) {
		this.serviceMetric = serviceMetric;
	}
	
	@Override
	public String toString() {
		return id.getServiceId()+" # "+id.getMetricPeriodCd()+" # "+id.getMetricPeriodDt()+" # "+serviceMetric+" | ";
	}

}