package com.akila.metricservices.metric.bean;

public class UserContentMetadata 
{
	

}
