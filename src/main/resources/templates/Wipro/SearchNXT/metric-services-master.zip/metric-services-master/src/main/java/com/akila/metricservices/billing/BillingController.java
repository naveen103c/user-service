package com.akila.metricservices.billing;

import com.akila.AkilaController;
import com.akila.metricservices.billing.bean.BillingResponse;
import com.akila.metricservices.servicemetric.PlanService;

import java.lang.Integer;
import java.lang.String;
import java.util.List;

import org.hibernate.JDBCException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;

@RestController
public class BillingController extends AkilaController {
  @Autowired
  private BillingService billingService;

  @GetMapping(
      path = "/billing-metric/usage"
  )
  public BillingResponse getUsageBill(@RequestParam Integer periodCd, @RequestParam String count) {
    return billingService.getUsageBill(periodCd, count);
  }

  @GetMapping(
      path = "/billing-metric/history-forecast"
  )
  public BillingResponse getHistoryAndForecast(@RequestParam Integer periodCd,
      @RequestParam String count) {
    return billingService.getHistoryAndForecast(periodCd, count);
  }

  @GetMapping(
      path = "/billing-metric/budget-usages"
  )
  public BillingResponse getBudgetAndUsages(@RequestParam Integer periodCd,
      @RequestParam String count) {
    return billingService.getBudgetAndUsages(periodCd, count);
  }

  @GetMapping(
      path = "/billing-metric/payments"
  )
  public BillingResponse getBillPaymentHistory(@RequestParam Integer periodCd,
      @RequestParam String count) {
    return billingService.getBillPaymentHistory(periodCd, count);
  }

  @GetMapping(
      path = "/billing-metric/invoice"
  )
  public List<PlanService> getInvoiceDetails(@RequestParam Integer month, @RequestParam Integer year) throws HttpStatusCodeException , NullPointerException,JDBCException,Exception{
		return billingService.getInvoiceDetails(month,year);
  }
}
