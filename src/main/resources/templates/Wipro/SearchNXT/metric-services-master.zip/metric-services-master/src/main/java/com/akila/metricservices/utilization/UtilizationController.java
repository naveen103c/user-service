package com.akila.metricservices.utilization;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;

@RestController
public class UtilizationController extends AkilaController 
{
	
  @Autowired
  private UtilizationService utilizationService;

  @GetMapping(
      path = "/utilization/docs/quota"
  )
  public Map<String, Integer> getDocQuotaMetric(@RequestParam Integer periodCd,
      @RequestParam String count) {
    return utilizationService.getDocQuotaMetric(periodCd, count);
  }

  @GetMapping(
      path = "/utilization/docs/trends"
  )
  public Map<String, String> getDocQuotaTrendMetric(@RequestParam Integer periodCd,
      @RequestParam Integer count) {
    return utilizationService.getDocQuotaTrendMetric(periodCd, count);
  }

  @GetMapping(
      path = "/utilization/searches/quota"
  )
  public Map<String, Integer> getSearchQuotaMetric(@RequestParam Integer periodCd,
      @RequestParam String count) {
    return utilizationService.getSearchQuotaMetric(periodCd, count);
  }

  @GetMapping(
      path = "/utilization/searches/trends"
  )
  public Map<String, String> getSearchQuotaTrendMetric(@RequestParam Integer periodCd,
      @RequestParam Integer count) {
    return utilizationService.getSearchQuotaTrendMetric(periodCd, count);
  }

  @GetMapping(
      path = "/utilization/users/quota"
  )
  public Map<String, Integer> getUserQuotaMetric(@RequestParam Integer periodCd,
      @RequestParam String count) {
    return utilizationService.getUserQuotaMetric(periodCd, count);
  }

  @GetMapping(
      path = "/utilization/users/trends"
  )
  public Map<String, String> getUserQuotaTrendMetric(@RequestParam Integer periodCd,
      @RequestParam Integer count) {
    return utilizationService.getUserQuotaTrendMetric(periodCd, count);
  }

  @GetMapping(
      path = "/utilization/storage/quota"
  )
  public Map<String, Long> getStorageQuotaMetric(@RequestParam Integer periodCd,
      @RequestParam Integer count) {
    return utilizationService.getStorageQuotaMetric(periodCd, count);
  }

  @GetMapping(
      path = "/utilization/storage/trends"
  )
  public Map<String, String> getStorageQuotaTrendMetric(@RequestParam Integer periodCd,
      @RequestParam Integer count) {
    return utilizationService.getStorageQuotaTrendMetric(periodCd, count);
  }

  @GetMapping(
      path = "/utilization/sync-hours/quota"
  )
  public Map<String, Long> getSyncHourQuotaMetric(@RequestParam Integer periodCd,
      @RequestParam Integer count) {
    return utilizationService.getSyncHourQuotaMetric(periodCd, count);
  }

  @GetMapping(
      path = "/utilization/sync-hours/trends"
  )
  public Map<String, String> getSyncHourQuotaTrendMetric(@RequestParam Integer periodCd,
      @RequestParam Integer count) {
    return utilizationService.getSyncHourQuotaTrendMetric(periodCd, count);
  }
}
