package com.akila.healthservices;

public class HealthMetric {
    private String name;
    private String metric;

    public HealthMetric() {
    }

    public HealthMetric(String name, String metric) {
        this.name = name;
        this.metric = metric;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMetric() {
        return this.metric;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

       
}