package com.akila.healthservices;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class HealthServicesController {
  
	
  
  @GetMapping(
      path = "/health"
  )
  public List<HealthMetric> getAllHealthMetric() {
	ArrayList<HealthMetric> mList = new ArrayList<HealthMetric>();
	mList.add(new HealthMetric("available","true"));
	mList.add(new HealthMetric("alive","60 s"));
	mList.add(new HealthMetric("cpu","1 vcpu"));
	mList.add(new HealthMetric("memory","1 GB"));
	
    return mList;
  }

  @GetMapping(
      path = "/health/{id}"
  )
  public HealthMetric getRegistration(@PathVariable String id) {
	  
    return new HealthMetric("cpu","1 vcpu");
  }
  
}
