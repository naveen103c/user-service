package com.akila.healthservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HealthServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(HealthServicesApplication.class, args);
	}

}
