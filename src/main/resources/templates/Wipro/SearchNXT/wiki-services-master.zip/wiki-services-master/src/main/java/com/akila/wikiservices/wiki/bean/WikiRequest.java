package com.akila.wikiservices.wiki.bean;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.akila.AkilaRequest;

public class WikiRequest extends AkilaRequest 
{
	@NotEmpty(message = "{WIKI.TITLE.MANDATORY}")
	private String title;
	
	@NotEmpty(message = "{WIKI.CONTENT.MANDATORY}")
	private String content;
	
	private String[] tags;
	
	@NotNull(message = "{WIKI.ISPRIVATE.NOTNULL}")
	private boolean privateContent;
	
	@Min(value = 1, message = "{WIKI.ALLOW.INTEGER}")
	private int contentStatusCd;
	
	@NotNull(message = "{WIKI.ROOT.COONTENT.NOTNULL}")
	private String rootContentId;
	
	@NotNull(message = "{WIKI.PARENT.CONTENT.NOTNULL}")
	private String parentContentId;
	
	@Min(value = 1, message = "{WIKI.ALLOW.INTEGER}")
	private int mediaCd;

	@Min(value = 1, message = "{WIKI.ALLOW.INTEGER}")
	private int versionNum;
	
	@NotNull(message = "WIKI.KEYLIST.MANDATORY")
	private String keyValList;
	
	private int contentTypeCd;
	
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String[] getTags() {
		return tags;
	}
	public void setTags(String[] tags) {
		this.tags = tags;
	}
	public boolean isPrivateContent() {
		return privateContent;
	}
	public void setPrivateContent(boolean privateContent) {
		this.privateContent = privateContent;
	}
	public int getContentStatusCd() {
		return contentStatusCd;
	}
	public void setContentStatusCd(int contentStatusCd) {
		this.contentStatusCd = contentStatusCd;
	}
	public String getRootContentId() {
		return rootContentId;
	}
	public void setRootContentId(String rootContentId) {
		this.rootContentId = rootContentId;
	}
	public String getParentContentId() {
		return parentContentId;
	}
	public void setParentContentId(String parentContentId) {
		this.parentContentId = parentContentId;
	}
	public int getMediaCd() {
		return mediaCd;
	}
	public void setMediaCd(int mediaCd) {
		this.mediaCd = mediaCd;
	}
	public int getVersionNum() {
		return versionNum;
	}
	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}
	public String getKeyValList() {
		return keyValList;
	}
	public void setKeyValList(String keyValList) {
		this.keyValList = keyValList;
	}
	public int getContentTypeCd() {
		return contentTypeCd;
	}
	public void setContentTypeCd(int contentTypeCd) {
		this.contentTypeCd = contentTypeCd;
	}
	
	
}
