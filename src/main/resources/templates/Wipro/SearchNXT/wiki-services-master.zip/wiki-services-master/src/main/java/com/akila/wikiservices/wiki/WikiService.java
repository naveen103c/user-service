package com.akila.wikiservices.wiki;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaConstants.ContentType;
import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.response.ResponseId;
import com.akila.wikiservices.wiki.bean.WikiRequest;
import com.akila.wikiservices.wiki.bean.WikiResponse;

@Service
public class WikiService extends AkilaService {
	private static final Logger logger = LogManager.getLogger(WikiService.class);
	@Autowired
	private RestTemplate restTemplate;
	
	 @Value("${contentType.wiki}")
	 private int contentTypeWiki;
	 
	 @Value("${metric.service.url}")
	 private String metricServiceURL;
	 
	 @Value("${content.service.url}")
	 private String contentServiceURL;
	 
	@Autowired
	private AkilaRestTemplate akilaRestTemplate;	
	
	@Value("${contentType.wiki}")
	private String contentTypeCd;
	 
	public ResponseEntity<ResponseId> createWiki(WikiRequest wikiRequest) {
		HttpHeaders headers = super.getRequestHeader();
		headers.add("contentType", ContentType.WIKI.getValue());
		wikiRequest.setContentTypeCd(contentTypeWiki);
		HttpEntity<WikiRequest> entity = new HttpEntity<WikiRequest>(wikiRequest, headers);
		ResponseEntity<ResponseId> response = akilaRestTemplate.postForEntity(restTemplate, contentServiceURL + "/content", entity,
				ResponseId.class);
		try {
			if(wikiRequest.getContentStatusCd() == 1){
				 HttpEntity<String> entity1 = new HttpEntity<String>("Metric-Wiki-Drafts",headers);
				 akilaRestTemplate.postForEntity(restTemplate, metricServiceURL + "/publishEvent?serviceName=Metric-Wiki-Drafts", entity1, Void.class);
			} else if(wikiRequest.getContentStatusCd() == 3){
				 HttpEntity<String> entity1 = new HttpEntity<String>("Metric-Wiki-Published",headers);
				 akilaRestTemplate.postForEntity(restTemplate, metricServiceURL + "/publishEvent?serviceName=Metric-Wiki-Published", entity1, Void.class);
			}
		} catch (RestClientException e) {
			logger.error("WikiService.createWiki : Errro while updating metrics",e);
		}
		catch (Exception e) {
			logger.error("WikiService.createWiki : Errro while updating metrics",e);
		}
		return response;
	}

	public WikiResponse getWiki(String id) {
		HttpHeaders headers = super.getRequestHeader();
		headers.add("contentType", "wiki");
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<WikiResponse> response = akilaRestTemplate.exchange(restTemplate,contentServiceURL + "/content/" + id,
					HttpMethod.GET, entity, WikiResponse.class);
		return response.getBody();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<WikiResponse> getAllWikis(Integer contentStatusCd) {
		HttpHeaders headers = super.getRequestHeader();
		headers.add("contentTypeCd", contentTypeCd);
		headers.add("contentStatusCd", contentStatusCd == null ? "-1"  : contentStatusCd.toString());
		HttpEntity entity = new HttpEntity(headers);
		ResponseEntity<?> response = akilaRestTemplate.exchange(restTemplate,contentServiceURL + "/content/wiki", HttpMethod.GET, entity, List.class);
		return (List<WikiResponse>) response.getBody();
	}


	public ResponseId updateWiki(String id, WikiRequest wikiRequest) {
		HttpHeaders headers = getRequestHeader();
		headers.add("contentType", ContentType.WIKI.getValue());
		wikiRequest.setContentTypeCd(contentTypeWiki);
		HttpEntity<WikiRequest> entity = new HttpEntity<WikiRequest>(wikiRequest, headers);
		akilaRestTemplate.exchange(restTemplate, contentServiceURL + "/content/"+id, HttpMethod.PUT, entity, ResponseId.class);
		
		if(wikiRequest.getContentStatusCd() == 3 && wikiRequest.getVersionNum() == 1){
			 HttpEntity<String> entity1 = new HttpEntity<String>("Metric-Wiki-Published",headers);
			 akilaRestTemplate.postForEntity(restTemplate, metricServiceURL + "/publishEvent?serviceName=Metric-Wiki-Published", entity1, Void.class);
			 
			 HttpEntity<String> entity2 = new HttpEntity<String>("Metric-Wiki-Drafts",headers);
			 akilaRestTemplate.postForEntity(restTemplate, metricServiceURL + "/publishEvent?serviceName=Metric-Wiki-Drafts&value=-1", entity2, Void.class);
		}
		
		return new ResponseId(id) ;
	}

	public ResponseId deleteWiki(String id) {
		HttpHeaders headers = getRequestHeader();
		headers.add("contentType", ContentType.WIKI.getValue());
		HttpEntity<WikiRequest> entity = new HttpEntity<WikiRequest>(headers);
		ResponseEntity<ResponseId> response = akilaRestTemplate.exchange(restTemplate, contentServiceURL + "/content/"+id, HttpMethod.DELETE, entity, ResponseId.class);
		return response.getBody();
	}
}
