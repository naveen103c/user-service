package com.akila.wikiservices.wiki;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.response.ResponseId;
import com.akila.wikiservices.wiki.bean.WikiRequest;
import com.akila.wikiservices.wiki.bean.WikiResponse;

@RestController
public class WikiController extends AkilaController {
  @Autowired
  private WikiService wikiService;

  @PostMapping(
      path = "/wikis"
  )
  public ResponseEntity<ResponseId> createWiki(@Valid @RequestBody WikiRequest wikiRequest,
		  @RequestParam("contentStatusCd") String contentStatusCd) {
    return wikiService.createWiki(wikiRequest);
  }

  @GetMapping(
      path = "/wikis"
  )
  public List<WikiResponse> getAllWikis(@RequestParam(required = false) Integer contentStatusCd) {
    return wikiService.getAllWikis(contentStatusCd);
  }
  
  @GetMapping(
      path = "/wikis/{id}"
  )
  public WikiResponse getWiki(@PathVariable String id) {
    return wikiService.getWiki(id);
  }

  @PutMapping(
      path = "/wikis/{id}"
  )
  public ResponseId updateWiki(@PathVariable String id,@Valid @RequestBody WikiRequest wikiRequest,
		  @RequestParam("contentStatusCd") String contentStatusCd) {
    return wikiService.updateWiki(id, wikiRequest);
  }

  @DeleteMapping(
      path = "/wikis/{id}"
  )
  public ResponseId deleteWiki(@PathVariable String id) {
    return wikiService.deleteWiki(id);
  }
}
