package com.akila.wikiservices;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.WikiServicesApplication;
import com.akila.wikiservices.wiki.WikiController;
import com.akila.wikiservices.wiki.bean.WikiRequest;


@SpringBootTest(classes = WikiServicesApplication.class)
public class WikiControllerTest 
{
	/*
	 * @Autowired private WikiController controller;
	 */
	
	@Test
	public void createWiki()
	{
		WikiRequest request = new WikiRequest();
		request.setTitle("My Content Title");
		request.setContent("My content body");
		request.setPrivateContent(true);
		request.setContentStatusCd(1);
		request.setTags(new String[] {"tags"});
		//ResponseEntity<ResponseId> response = controller.createWiki(request);
		//System.out.println(response.getBody().getId());
	}
	
	@Test
	public void getWiki()
	{
		// WikiResponse response = controller.getWiki("5dfff9f1-7118-44f0-98f7-e41ad7d4eb60");
		//System.out.println(response.getContent());
	}

}
