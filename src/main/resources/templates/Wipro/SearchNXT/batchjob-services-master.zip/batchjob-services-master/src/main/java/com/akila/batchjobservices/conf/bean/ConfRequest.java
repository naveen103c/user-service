package com.akila.batchjobservices.conf.bean;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.akila.AkilaRequest;

public class ConfRequest extends AkilaRequest {

	String confId;
	
	@NotNull(message = "{CONFIG.NAME.MANDATORY}")
	@NotBlank(message = "{CONFIG.NAME.MANDATORY}")
	@Size(max = 50,  message = "{CONFIG.NAME.LENGTH}")
	String confName;
	
	@NotNull(message = "{CONFIG.SOURCEEXTRACTION.MANDATORY}")
	Integer sourceExtractionTypeCd;
	
	@NotNull(message = "{CONFIG.SOURCETYPE.MANDATORY}")
	Integer sourceTypeCd;
	
	@NotNull(message = "{CONFIG.USERGROUP.MANDATORY}")
	List<String> sourceAllowedUserGroupList;
	
	@NotNull(message = "{CONFIG.DESC.MANDATORY}")
	@NotBlank(message = "{CONFIG.DESC.MANDATORY}")
	@Size(max = 200,  message = "{CONFIG.DESC.LENGTH}")
	String sourceDescription;
	
	@NotNull(message = "{CONFIG.SOURCETAG.MANDATORY}")
	List<String> sourceTagIdList;
	
	@NotNull(message = "{CONFIG.SCHEDULEJSON.MANDATORY}")
	Schedule sourceScheduleJson;
	
	String crtBy;
	
	String modBy;
	
	@NotNull(message = "{CONFIG.SOURCETYPEFIELDS.MANDATORY}")
	List<SourceTypeField> sourceTypeFields;
	
	@NotNull(message = "{CONFIG.FILTER.MANDATORY}")
	List<ConfFilter> filter;

	public String getConfId() {
		return confId;
	}

	public void setConfId(String confId) {
		this.confId = confId;
	}

	public String getConfName() {
		return confName;
	}

	public void setConfName(String confName) {
		this.confName = confName;
	}

	public Integer getSourceExtractionTypeCd() {
		return sourceExtractionTypeCd;
	}

	public void setSourceExtractionTypeCd(Integer sourceExtractionTypeCd) {
		this.sourceExtractionTypeCd = sourceExtractionTypeCd;
	}

	public Integer getSourceTypeCd() {
		return sourceTypeCd;
	}

	public void setSourceTypeCd(Integer sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}

	public List<String> getSourceAllowedUserGroupList() {
		return sourceAllowedUserGroupList;
	}

	public void setSourceAllowedUserGroupList(List<String> sourceAllowedUserGroupList) {
		this.sourceAllowedUserGroupList = sourceAllowedUserGroupList;
	}

	public String getSourceDescription() {
		return sourceDescription;
	}

	public void setSourceDescription(String sourceDescription) {
		this.sourceDescription = sourceDescription;
	}

	public List<String> getSourceTagIdList() {
		return sourceTagIdList;
	}

	public void setSourceTagIdList(List<String> sourceTagIdList) {
		this.sourceTagIdList = sourceTagIdList;
	}

	public Schedule getSourceScheduleJson() {
		return sourceScheduleJson;
	}

	public void setSourceScheduleJson(Schedule sourceScheduleJson) {
		this.sourceScheduleJson = sourceScheduleJson;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public List<SourceTypeField> getSourceTypeFields() {
		return sourceTypeFields;
	}

	public void setSourceTypeFields(List<SourceTypeField> sourceTypeFields) {
		this.sourceTypeFields = sourceTypeFields;
	}

	public List<ConfFilter> getFilter() {
		return filter;
	}

	public void setFilter(List<ConfFilter> filter) {
		this.filter = filter;
	}

}
