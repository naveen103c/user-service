package com.akila.batchjobservices.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.akila.batchjobservices.conf.bean.ConfFilter;

@Entity
@Table(name = "org_batch_job_modules_conf")
public class OrgBatchJobModulesConf {
	
	@EmbeddedId
	OrgBatchJobModulesConfId id;
	
	@Column(name = "conf_id", insertable=false,updatable=false)
	String confId;
	
	/*@Column(name = "module_id")
	Integer moduleId;*/
	
	@Column(name = "sequence")
	Integer sequence;
	
	@Column(name = "is_active")
	Boolean isActive;
	
	@OneToOne
	@JoinColumn(name = "module_id",insertable=false,updatable=false)
	BaseBatchJobModules BaseBatchJobModules;
	
	@Column(name = "module_attribute_json")
	String moduleAttributeJson ;
	
	@Column(name = "action_needed_json")
	String actionNeededJson ;
	
	@Column(name = "mod_ts")
	Date modTs;
	
	@Column(name = "crt_ts")
	Date crtTs;
	
	@Column(name = "crt_by")
	String crtBy;
	
	@Column(name = "mod_by")
	String modBy;
	
	public String getModuleAttributeJson() {
		return moduleAttributeJson;
	}

	public void setModuleAttributeJson(String moduleAttributeJson) {
		this.moduleAttributeJson = moduleAttributeJson;
	}

	public String getActionNeededJson() {
		return actionNeededJson;
	}

	public void setActionNeededJson(String actionNeededJson) {
		this.actionNeededJson = actionNeededJson;
	}

	public OrgBatchJobModulesConfId getId() {
		return id;
	}

	public void setId(OrgBatchJobModulesConfId id) {
		this.id = id;
	}

	public Integer getSequence() {
		return sequence;
	}

	public void setSequence(Integer sequence) {
		this.sequence = sequence;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getConfId() {
		return confId;
	}

	public void setConfId(String confId) {
		this.confId = confId;
	}

	public Date getModTs() {
		return modTs;
	}

	public void setModTs(Date modTs) {
		this.modTs = modTs;
	}

	public Date getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Date crtTs) {
		this.crtTs = crtTs;
	}

	public BaseBatchJobModules getBaseBatchJobModules() {
		return BaseBatchJobModules;
	}

	public void setBaseBatchJobModules(BaseBatchJobModules baseBatchJobModules) {
		BaseBatchJobModules = baseBatchJobModules;
	}

	public boolean isTasklet() {
		if(BaseBatchJobModules != null && BaseBatchJobModules.getJavaTaskLet() != null && BaseBatchJobModules.getJavaTaskLet().length() > 0){
			return true;
		}
		
		return false;
	}
	
	public String getTasklet() {
		if(BaseBatchJobModules != null && BaseBatchJobModules.getModuleTypeCd() == 2){
			return BaseBatchJobModules.getJavaTaskLet();
		}
		
		return null;
	}
	
	public String getJavaModuleClass() {
		if(BaseBatchJobModules != null && BaseBatchJobModules.getModuleTypeCd() == 3){
			return BaseBatchJobModules.getJavaModuleClass();
		}
		
		return null;
	}
	
	public int getModuleTypeCd() {
		return BaseBatchJobModules.getModuleTypeCd();
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}
}
