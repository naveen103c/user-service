package com.akila.batchjobservices.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
@Table(name = "org_job_content_files")
@NamedQuery(name="OrgJobContentFile.findAll", query="SELECT o FROM OrgJobContentFile o")
public class OrgJobContentFile {

    @Id
    @Column(name = "file_id")
    private String fileId;

    @Column(name = "config_id")
    private String confId;
    
    @Column(name = "job_id")
    private String jobId;

    @Column(name = "file_nm")
    private String fileName;
    
    @Column(name = "file_url")
    private String fileUrl;
    
    @Column(name = "updated_step")
    private Integer updatedStep;
    
    @Column(name = "status")
    private Integer status;
    
    @Column(name = "file_crt_ts")
    private Timestamp fileCrtTs;

    @Column(name = "file_mod_ts")
    private Timestamp fileModTs;
    
    @Column(name = "file_size")
    private Integer fileSize;
    
    @Column(name = "description")
    private String description;

    public String getFileId() {
           return fileId;
    }

    public void setFileId(String fileId) {
           this.fileId = fileId;
    }

    public String getConfId() {
           return confId;
    }

    public void setConfId(String confId) {
           this.confId = confId;
    }

    public String getJobId() {
           return jobId;
    }

    public void setJobId(String jobId) {
           this.jobId = jobId;
    }

    public String getFileName() {
           return fileName;
    }

    public void setFileName(String fileName) {
           this.fileName = fileName;
    }

    public Integer getUpdatedStep() {
           return updatedStep;
    }

    public void setUpdatedStep(Integer updatedStep) {
           this.updatedStep = updatedStep;
    }

    public Integer getStatus() {
           return status;
    }

    public void setStatus(Integer status) {
           this.status = status;
    }

    public Timestamp getFileCrtTs() {
           return fileCrtTs;
    }

    public void setFileCrtTs(Timestamp fileCrtTs) {
           this.fileCrtTs = fileCrtTs;
    }

    public Timestamp getFileModTs() {
           return fileModTs;
    }

    public void setFileModTs(Timestamp fileModTs) {
           this.fileModTs = fileModTs;
    }

    public Integer getFileSize() {
           return fileSize;
    }

    public void setFileSize(Integer fileSize) {
           this.fileSize = fileSize;
    }

    public String getFileUrl() {
           return fileUrl;
    }

    public void setFileUrl(String fileUrl) {
           this.fileUrl = fileUrl;
    }

    public String getDescription() {
           return description;
    }

    public void setDescription(String description) {
           this.description = description;
    }
    
}
