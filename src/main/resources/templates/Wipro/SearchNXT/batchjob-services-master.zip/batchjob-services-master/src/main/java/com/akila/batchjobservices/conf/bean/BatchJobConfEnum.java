package com.akila.batchjobservices.conf.bean;

import java.util.HashMap;
import java.util.Map;

public enum BatchJobConfEnum {

	REQUESTED(1), SCHEDULED(2), SUSPENDED(5), DELETED(9);

	private final int value;

	private BatchJobConfEnum(int value) {
		this.value = value;
	}

	private final static Map<Integer, BatchJobConfEnum> REVERSE_MAP = new HashMap<>();

	static {
		for (BatchJobConfEnum status : values()) {
			REVERSE_MAP.put(status.value, status);
		}
	}

	public static BatchJobConfEnum forValue(int value) {
		return REVERSE_MAP.get(value);
	}
	
	public  int getValue() {
		return this.value;
	}

}