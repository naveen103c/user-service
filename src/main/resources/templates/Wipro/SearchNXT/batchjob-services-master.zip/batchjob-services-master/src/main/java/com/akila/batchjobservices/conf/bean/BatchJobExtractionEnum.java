package com.akila.batchjobservices.conf.bean;

import java.util.HashMap;
import java.util.Map;

public enum BatchJobExtractionEnum {

	SCHEDULED_PULL(1), ADHOC_PULL(2), UPLOAD_PULL(3);

	private final int value;

	private BatchJobExtractionEnum(int value) {
		this.value = value;
	}

	private final static Map<Integer, BatchJobExtractionEnum> REVERSE_MAP = new HashMap<>();

	static {
		for (BatchJobExtractionEnum status : values()) {
			REVERSE_MAP.put(status.value, status);
		}
	}

	public static BatchJobExtractionEnum forValue(int value) {
		return REVERSE_MAP.get(value);
	}

}