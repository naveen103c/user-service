package com.akila.batchjobservices.file.storage.bean;

import java.io.InputStream;
import java.util.Map;

public class StorageResponse 
{
	private String versionId;
	private String md5;
	
	
	private InputStream dataStream;
	private Map<String, String> userMetadata;
	private long contentLenght;
	private byte[] content;
	
	public InputStream getDataStream() {
		return dataStream;
	}

	public void setDataStream(InputStream dataStream) {
		this.dataStream = dataStream;
	}

	public String getVersionId() {
		return versionId;
	}

	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}

	public String getMd5() {
		return md5;
	}

	public void setMd5(String md5) {
		this.md5 = md5;
	}

	public Map<String, String> getUserMetadata() {
		return userMetadata;
	}

	public void setUserMetadata(Map<String, String> userMetadata) {
		this.userMetadata = userMetadata;
	}

	public long getContentLenght() {
		return contentLenght;
	}

	public void setContentLenght(long contentLenght) {
		this.contentLenght = contentLenght;
	}

	public byte[] getContent() {
		return content;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}
	
	
	

}
