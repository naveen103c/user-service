package com.akila.batchjobservices.conf;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.batchjobservices.conf.bean.ConfAllResponse;
import com.akila.batchjobservices.conf.bean.ConfFilter;
import com.akila.batchjobservices.conf.bean.ConfRequest;
import com.akila.batchjobservices.conf.bean.ConfResponse;
import com.akila.batchjobservices.conf.bean.ResponseStatus;
import com.akila.batchjobservices.entity.BaseSourceType;
import com.akila.batchjobservices.entity.OrgBatchJobConf;
import com.akila.batchjobservices.util.Constants;
import com.akila.batchjobservices.util.DateUtils;
import com.akila.response.ResponseId;

@RestController
public class ConfController extends AkilaController {

	String defaultUserId = "a9daaf8e-0a5b-46c2-b281-650ab5dda384";

	@Autowired
	private ConfService confService;

	private int STATUS_FAILED = 0;
	private int STATUS_PASS = 1;

	@PostMapping(path = "/confs")
	@ResponseBody
	public ResponseEntity<ResponseStatus> createConf(@Valid @RequestBody ConfRequest confRequest) {
		if (confRequest.getSourceScheduleJson() != null && confRequest.getSourceScheduleJson().getFrequency() != null
				&& !confRequest.getSourceScheduleJson().getFrequency().equals("")) {
			Date nextRunDate = DateUtils.getNextRunDate(confRequest.getSourceScheduleJson(), confRequest.getConfId());
			if (nextRunDate == null) {
				ResponseStatus status = getResponseStatus(STATUS_FAILED, "", "Incorrect Conf Scheduled", 101);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
			confRequest.setSourceExtractionTypeCd(Constants.SCHEDULED_PULL_CD);
		} else {
			confRequest.setSourceExtractionTypeCd(Constants.ADHOC_PULL_CD);
		}

		List<String> nameList = confService.getAllConfNames();
		nameList = nameList.stream().map(String::toLowerCase).map(String::trim).collect(Collectors.toList());
		if (nameList != null && nameList.contains(confRequest.getConfName().toLowerCase().trim())) {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
					("Config Name '" + confRequest.getConfName() + "' Already Exist"), 102);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		} else if (!confService.getSourceExtractionTypeCd().contains(confRequest.getSourceExtractionTypeCd())) {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "", "Incorrect Source Extraction Type Cd", 103);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		} else if (!confService.getSourceTypeCd().contains(confRequest.getSourceTypeCd())) {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "", "Incorrect Source Type Cd", 104);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}

		confRequest.setCrtBy(defaultUserId);
		confRequest.setModBy(defaultUserId);
		ResponseId id = confService.createConf(confRequest);
		ResponseStatus status = getResponseStatus(STATUS_PASS, id.getId(), "Conf successfully created", 0);
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);

	}

	@PutMapping(path = "/confs/{id}")
	public ResponseEntity<ResponseStatus> updateConf(@PathVariable String id,@Valid @RequestBody ConfRequest confRequest) {
		if (confRequest.getSourceScheduleJson() != null && confRequest.getSourceScheduleJson().getFrequency() != null
				&& !confRequest.getSourceScheduleJson().getFrequency().equals("")) {
			Date nextRunDate = DateUtils.getNextRunDate(confRequest.getSourceScheduleJson(), confRequest.getConfId());
			if (nextRunDate == null) {
				ResponseStatus status = getResponseStatus(STATUS_FAILED, "", "Incorrect Conf Scheduled", 101);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
			confRequest.setSourceExtractionTypeCd(Constants.SCHEDULED_PULL_CD);
		} else {
			confRequest.setSourceExtractionTypeCd(Constants.ADHOC_PULL_CD);
		}

		List<String> nameList = confService.getAllConfNames(id);
		nameList = nameList.stream().map(String::toLowerCase).map(String::trim).collect(Collectors.toList());
		if (nameList != null && nameList.contains(confRequest.getConfName().toLowerCase().trim())) {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "",
					("Config Name '" + confRequest.getConfName() + "' Already Exist"), 102);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		} else if (!confService.getSourceExtractionTypeCd().contains(confRequest.getSourceExtractionTypeCd())) {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "", "Incorrect Source Extraction Type Cd", 103);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		} else if (!confService.getSourceTypeCd().contains(confRequest.getSourceTypeCd())) {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, "", "Incorrect Source Type Cd", 104);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}

		confRequest.setCrtBy(defaultUserId);
		confRequest.setModBy(defaultUserId);
		confService.updateConf(id, confRequest);
		ResponseStatus status = getResponseStatus(STATUS_PASS, id, "Conf successfully updated", 0);
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	}
	
	@PutMapping(path = "/confs/user-groups/{id}")
	public ResponseEntity<ResponseStatus> updateConfUserGroups(@PathVariable String id,@RequestBody List<String> userGroups) {
		confService.updateConfUserGroups(id, userGroups);
		ResponseStatus status = getResponseStatus(STATUS_PASS, id, "Conf user groups successfully updated", 0);
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	}

	@GetMapping(path = "/confs/{id}")
	public ConfResponse getConf(@PathVariable String id) {
		ConfResponse confResponse = confService.getConf(id);

		return confResponse;
	}
	
	@GetMapping(path = "/confs/{confName}/{sourceTypeCd}")
	public OrgBatchJobConf getConf(@PathVariable String confName,@PathVariable int sourceTypeCd) {
		return confService.getConfByConfNameAndSourceTypeCd(confName,sourceTypeCd);
	}

	@GetMapping(path = "/confs")
	public List<ConfAllResponse> getAllConfs(@RequestParam(required = false) Integer sourceTypeCd) {
		return confService.getAllConfs(sourceTypeCd);
	}

	@GetMapping(path = "/confs/filters")
	public List<ConfFilter> getFilters() {
		return confService.getFilters();
	}

	@GetMapping(path = "/confs/sourcetypes")
	public List<BaseSourceType> getAllSourceTypes() {
		return confService.getAllSourceTypes();
	}

	@DeleteMapping(path = "/confs/{id}")
	@ResponseBody
	public ResponseEntity<ResponseStatus> deleteConf(@PathVariable String id) {
		String confId = confService.deleteConf(id);

		if (confId != null) {
			ResponseStatus status = getResponseStatus(STATUS_PASS, confId, "Conf Deleted Successfully", 0);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
		} else {
			ResponseStatus status = getResponseStatus(STATUS_FAILED, id, "Conf Id Incorrect", 110);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}

	}

	private ResponseStatus getResponseStatus(int statusCd, String id, String message, int errorCode) {
		ResponseStatus status = new ResponseStatus();
		status.setStatusCode(statusCd);
		status.setId(id);
		status.setMessage(message);
		status.setErrorCode(errorCode);
		return status;
	}
}
