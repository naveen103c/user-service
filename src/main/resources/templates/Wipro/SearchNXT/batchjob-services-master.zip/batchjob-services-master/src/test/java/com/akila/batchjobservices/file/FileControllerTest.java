package com.akila.batchjobservices.file;

import org.springframework.boot.test.context.SpringBootTest;

import com.akila.batchjobservices.BatchJobServicesApplication;

@SpringBootTest(classes = BatchJobServicesApplication.class)

public class FileControllerTest {


}