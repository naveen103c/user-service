package com.akila.batchjobservices.conf.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Module {

	Integer moduleId;
	String moduleName;
	Integer moduleSequence;
	List<String> moduleAttribute = new ArrayList<String>();
	List<String> actionNeeded = new ArrayList<String>();

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public Integer getModuleSequence() {
		return moduleSequence;
	}

	public void setModuleSequence(Integer moduleSequence) {
		this.moduleSequence = moduleSequence;
	}

	public List<String> getModuleAttribute() {
		return moduleAttribute;
	}

	public void setModuleAttribute(List<String> moduleAttribute) {
		this.moduleAttribute = moduleAttribute;
	}
	
	public void addModuleAttribute(String moduleAttribute) {
		this.moduleAttribute.add(moduleAttribute);
	}

	public List<String> getActionNeeded() {
		return actionNeeded;
	}

	public void setActionNeeded(List<String> actionNeeded) {
		this.actionNeeded = actionNeeded;
	}
	
	public void addActionNeeded(String actionNeeded) {
		this.actionNeeded.add(actionNeeded);
	}

	
}
