package com.akila.batchjobservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.batchjobservices.entity.BaseSourceType;

@Repository
public interface BaseSourceTypeRepository extends JpaRepository<BaseSourceType, String> {

	BaseSourceType findBySourceTypeCd(Integer sourceTypeCd);
	
}
