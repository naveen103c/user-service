package com.akila.batchjobservices.conf;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.akila.AES;
import com.akila.AkilaService;
import com.akila.batchjobservices.conf.bean.BatchJobConfEnum;
import com.akila.batchjobservices.conf.bean.BatchJobExecEnum;
import com.akila.batchjobservices.conf.bean.BatchJobExtractionEnum;
import com.akila.batchjobservices.conf.bean.ConfAllResponse;
import com.akila.batchjobservices.conf.bean.ConfFilter;
import com.akila.batchjobservices.conf.bean.ConfRequest;
import com.akila.batchjobservices.conf.bean.ConfResponse;
import com.akila.batchjobservices.conf.bean.Module;
import com.akila.batchjobservices.conf.bean.Schedule;
import com.akila.batchjobservices.conf.bean.SourceTypeField;
import com.akila.batchjobservices.entity.BaseBatchJobModules;
import com.akila.batchjobservices.entity.BaseSourceType;
import com.akila.batchjobservices.entity.OrgBatchJobConf;
import com.akila.batchjobservices.entity.OrgBatchJobModulesConf;
import com.akila.batchjobservices.entity.OrgBatchJobModulesConfId;
import com.akila.batchjobservices.repository.BaseBatchJobModulesRepository;
import com.akila.batchjobservices.repository.BaseSourceTypeRepository;
import com.akila.batchjobservices.repository.OrgBatchJobConfRepository;
import com.akila.batchjobservices.repository.OrgBatchJobModulesConfRepository;
import com.akila.batchjobservices.util.Constants;
import com.akila.batchjobservices.util.DateUtils;
import com.akila.batchjobservices.util.Utils;
import com.akila.commons.AkilaRestTemplate;
import com.akila.response.ResponseId;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ConfService extends AkilaService {
	private static final Logger logger = LogManager.getLogger(ConfService.class);
	@Autowired
	private OrgBatchJobModulesConfRepository orgBatchJobModulesConfRepository;

	@Autowired
	private BaseBatchJobModulesRepository baseBatchJobModulesRepository;

	@Autowired
	private OrgBatchJobConfRepository orgBatchJobConfRepository;

	@Autowired
	private BaseSourceTypeRepository baseSourceTypeRepository;

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate restTemplateloadBalanced;

	@Value("${aes.key}")
	private String aesKey;

	private String PASSWORD = "xxxxxxxxxx";
	
	@Value("${org.service.url}")
	private String orgServiceURL;
	
	@Autowired
	private AkilaRestTemplate akilaRestTemplate;

	@Transactional(isolation = Isolation.SERIALIZABLE)
	public ResponseId createConf(ConfRequest confRequest) {
		OrgBatchJobConf orgBatchJobConf = new OrgBatchJobConf();
		orgBatchJobConf.setConfId(UUID.randomUUID().toString());
		orgBatchJobConf.setConfName(confRequest.getConfName().trim());
		orgBatchJobConf.setBatchJobConfStatusCd(1);
		orgBatchJobConf.setSourceTypeCd(confRequest.getSourceTypeCd());
		orgBatchJobConf.setSourceAllowedUserGroupList(Utils.getString(confRequest.getSourceAllowedUserGroupList()));
		orgBatchJobConf.setSourceExtractionTypeCd(confRequest.getSourceExtractionTypeCd());
		orgBatchJobConf.setSourceTagIdList(Utils.getString(confRequest.getSourceTagIdList()));
		orgBatchJobConf.setSourceDescription(confRequest.getSourceDescription());
		if (confRequest.getSourceExtractionTypeCd() == Constants.SCHEDULED_PULL_CD) {
			orgBatchJobConf.setSourceScheduleJson(Utils.getString(confRequest.getSourceScheduleJson()));
		} else {
			orgBatchJobConf.setSourceScheduleJson("");
		}
		orgBatchJobConf
				.setSourceClassificationJson(AES.encrypt(Utils.getString(confRequest.getSourceTypeFields()), aesKey));
		orgBatchJobConf.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgBatchJobConf.setModTs(new Timestamp(System.currentTimeMillis()));
		orgBatchJobConf.setCrtBy(getUserId());
		orgBatchJobConf.setModBy(getUserId());

		orgBatchJobConf = orgBatchJobConfRepository.save(orgBatchJobConf);

		createFilter(orgBatchJobConf.getConfId(), confRequest.getSourceTypeCd(), confRequest.getFilter(),
				confRequest.getCrtBy(), true);

		return new ResponseId(orgBatchJobConf.getConfId());
	}

	@Transactional(isolation = Isolation.SERIALIZABLE)
	public ResponseId updateConf(String id, ConfRequest confRequest) {
		OrgBatchJobConf orgBatchJobConf = orgBatchJobConfRepository.findById(id).orElse(null);

		if (orgBatchJobConf != null) {
			orgBatchJobConf.setConfName(confRequest.getConfName().trim());
			orgBatchJobConf.setSourceAllowedUserGroupList(Utils.getString(confRequest.getSourceAllowedUserGroupList()));
			orgBatchJobConf.setSourceExtractionTypeCd(confRequest.getSourceExtractionTypeCd());
			orgBatchJobConf.setSourceTagIdList(Utils.getString(confRequest.getSourceTagIdList()));
			orgBatchJobConf.setSourceDescription(confRequest.getSourceDescription());
			if (confRequest.getSourceExtractionTypeCd() == Constants.SCHEDULED_PULL_CD) {
				String schedule = Utils.getString(confRequest.getSourceScheduleJson());
				if (orgBatchJobConf.getNextRunDateTs() != null) {
					orgBatchJobConf.setNextRunDateTs(DateUtils.getNextRunDate(schedule, id));
				}
				//Update Configurations Status to Requested if user reschedule it again 
				if(!orgBatchJobConf.getSourceScheduleJson().equalsIgnoreCase(schedule)) {
					logger.info("ConfService.updateConf : old SourceScheduleJson -"+orgBatchJobConf.getSourceScheduleJson());
					logger.info("ConfService.updateConf : new SourceScheduleJson -"+schedule);
					orgBatchJobConf.setBatchJobConfStatusCd(Constants.SCHEDULED_PULL_CD);
				}
				orgBatchJobConf.setSourceScheduleJson(Utils.getString(confRequest.getSourceScheduleJson()));
			} else {
				orgBatchJobConf.setSourceScheduleJson("");
			}

			if (confRequest.getSourceTypeFields() != null && confRequest.getSourceTypeFields().size() > 0) {
				for (SourceTypeField sourceTypeField : confRequest.getSourceTypeFields()) {
					if (sourceTypeField.getFieldType().equalsIgnoreCase("password")) {
						if (sourceTypeField.getFieldValues() != null && sourceTypeField.getFieldValues().size() > 0) {
							String pass = sourceTypeField.getFieldValues().get(0);
							if (pass.equals(PASSWORD)) {
								String config = orgBatchJobConf.getSourceClassificationJson();
								List<Object> configList = null;
								if (config != null && config.startsWith("[{")) {

									configList = Utils.getSourceTypeFieldstAsArray(config);
								} else if (config != null) {

									configList = Utils.getSourceTypeFieldstAsArray(AES.decrypt(config, aesKey));
								}

								if (configList != null) {
									for (Object obj : configList) {
										SourceTypeField srcField = (SourceTypeField) obj;
										if (srcField.getFieldType().equalsIgnoreCase("password")) {
											sourceTypeField.setFieldValues(srcField.getFieldValues());
										}
									}
								}
							}
							break;
						}

					}
				}
			}

			orgBatchJobConf.setSourceClassificationJson(
					AES.encrypt(Utils.getString(confRequest.getSourceTypeFields()), aesKey));
			orgBatchJobConf.setModTs(new Timestamp(System.currentTimeMillis()));
			orgBatchJobConf.setModBy(getUserId());

			orgBatchJobConf = orgBatchJobConfRepository.save(orgBatchJobConf);

			createFilter(orgBatchJobConf.getConfId(), confRequest.getSourceTypeCd(), confRequest.getFilter(),
					getUserId(), false);

			return new ResponseId(orgBatchJobConf.getConfId());
		} else {
			return null; // todo: return exception id not found
		}
	}
	
	@Transactional(isolation = Isolation.SERIALIZABLE)
	public ResponseId updateConfUserGroups(String id, List<String> userGroups) {
		OrgBatchJobConf orgBatchJobConf = orgBatchJobConfRepository.findById(id).orElse(null);

		if (orgBatchJobConf != null) {
			orgBatchJobConf.setSourceAllowedUserGroupList(Utils.getString(userGroups));
			orgBatchJobConfRepository.save(orgBatchJobConf);
			return new ResponseId(orgBatchJobConf.getConfId());
		} else {
			return null; // todo: return exception id not found
		}
	}


	public ConfResponse getConf(String id) {
		OrgBatchJobConf conf = orgBatchJobConfRepository.findById(id).orElse(null);

		return getConfResponse(conf);
	}
	
	public OrgBatchJobConf getConfByConfNameAndSourceTypeCd(String confName,int sourceTypeCd) {
		return orgBatchJobConfRepository.findByConfNameAndSourceTypeCd(confName,sourceTypeCd);
	}


	public List<ConfAllResponse> getAllConfs(Integer soucetypeCd) {
		List<OrgBatchJobConf> OrgBatchJobConfList = null;
		if (soucetypeCd != null) {
			OrgBatchJobConfList = orgBatchJobConfRepository
					.findBysourceTypeCdAndBatchJobConfStatusCdNotOrderByConfNameAsc(soucetypeCd,
							BatchJobConfEnum.DELETED.getValue());
		} else {
			OrgBatchJobConfList = orgBatchJobConfRepository
					.findByBatchJobConfStatusCdNotAndSourceTypeCdNotOrderByConfNameAsc(BatchJobConfEnum.DELETED.getValue(),Constants.ATTACHMENT_SOURCE_TYPE);
		}

		List<OrgBatchJobConf> updatedList = new ArrayList<OrgBatchJobConf>();
		try {

			HttpEntity<String> entity = new HttpEntity<String>("org-services", getRequestHeader());
			logger.info("ConfService.getAllConfs : entity -"+entity);
			ResponseEntity<?> response = akilaRestTemplate.exchange(restTemplateloadBalanced, orgServiceURL + "/user/groups/"+getUserId(), HttpMethod.GET, entity, List.class);
			//restTemplateloadBalanced.getForEntity("http://org-services/users/"+getUserId(),entity, User .class);


			List<String> gpList = (List<String>) response.getBody();

			if (!gpList.isEmpty()) {
				ObjectMapper objectMapper = new ObjectMapper();
				for (OrgBatchJobConf orgBatchJobConf : OrgBatchJobConfList) {
					String groups = orgBatchJobConf.getSourceAllowedUserGroupList();
					try {
						if (groups != null) {
							List<String> groupList = Arrays.asList(objectMapper.readValue(groups, String[].class));

							List<String> list = groupList.stream().filter(gpList::contains)
									.collect(Collectors.toList());
							// Jira Id AK-407
							if (groupList.isEmpty()) {
								updatedList.add(orgBatchJobConf);

							} else if (!list.isEmpty()) {
								updatedList.add(orgBatchJobConf);
							}

						} /*
							 * else { // Jira Id AK-407 updatedList.add(orgBatchJobConf); }
							 */
					} catch (JsonParseException e) {
						logger.error("getAllConfs : Error while parsing source group json : " + groups, e);
					} catch (Exception e) {
						logger.error("getAllConfs : Error while parsing source group json : " + groups, e);
					}

				}
			}
		} catch (RestClientException e) {
			logger.error(
					"getAllConfs : Error while getting user groups : " + orgServiceURL + "/users/" + getUserId(), e);
		}
		return getConfAllResponse(updatedList);
	}


	public List<ConfFilter> getFilters() {
		List<ConfFilter> filterList = new ArrayList<ConfFilter>();

		List<BaseBatchJobModules> baseBatchJobModules = baseBatchJobModulesRepository.findAllByModuleTypeCd(3);
		int seq = 1;

		for (BaseBatchJobModules module : baseBatchJobModules) {
			ConfFilter filter = new ConfFilter();
			filter.setModuleId(module.getModuleId());
			filter.setModuleName(module.getModuleName().trim());
			filter.setModuleSequence(seq++);
			filter.setModuleAttribute(Utils.getObjectAsArray(module.getModuleAttribute()));
			filter.setActionNeeded(Utils.getObjectAsArray(module.getActionNeeded()));

			filterList.add(filter);
		}

		return filterList;
	}

	public List<BaseSourceType> getAllSourceTypes() {
		List<BaseSourceType> list = baseSourceTypeRepository.findAll();
		for (BaseSourceType baseSourceType : list) {
			baseSourceType
					.setSourceTypeFields(Utils.getSourceTypeFieldstAsArray(baseSourceType.getSourceTypeFieldsJson()));
		}
		return list;
	}

	public List<OrgBatchJobModulesConf> getJobModuleConf(String confId) {
		return orgBatchJobModulesConfRepository.findByConfIdOrderBySequenceAsc(confId);
	}

	public void createFilter(String confId, Integer sourceTypeCode, List<ConfFilter> confFilterList, String userId,
			boolean iscreated) {

		List<BaseBatchJobModules> baseBatchJobModules = baseBatchJobModulesRepository
				.findAllBysourceTypeCd(sourceTypeCode);
		List<OrgBatchJobModulesConf> orgBatchJobModulesConfList = new ArrayList<OrgBatchJobModulesConf>();
		int seq = 0;
		if (baseBatchJobModules != null) {
			for (BaseBatchJobModules baseMod : baseBatchJobModules) {
				OrgBatchJobModulesConf orgBatchJobModulesConf = new OrgBatchJobModulesConf();
				OrgBatchJobModulesConfId id = new OrgBatchJobModulesConfId();
				id.setConfId(confId);
				id.setModuleId(baseMod.getModuleId());
				orgBatchJobModulesConf.setId(id);
				orgBatchJobModulesConf.setSequence(++seq);
				orgBatchJobModulesConf.setIsActive(true);
				orgBatchJobModulesConf.setCrtTs(new Timestamp(System.currentTimeMillis()));
				orgBatchJobModulesConf.setModTs(new Timestamp(System.currentTimeMillis()));
				orgBatchJobModulesConf.setCrtBy(userId);
				orgBatchJobModulesConf.setModBy(userId);
				orgBatchJobModulesConf.setModuleAttributeJson(baseMod.getModuleAttribute());
				orgBatchJobModulesConf.setActionNeededJson(baseMod.getActionNeeded());

				orgBatchJobModulesConfList.add(orgBatchJobModulesConf);
			}
		}
		if (confFilterList != null) {
			for (ConfFilter confFilter : confFilterList) {
				OrgBatchJobModulesConf orgBatchJobModulesConf = new OrgBatchJobModulesConf();
				OrgBatchJobModulesConfId id = new OrgBatchJobModulesConfId();
				id.setConfId(confId);
				id.setModuleId(confFilter.getModuleId());
				orgBatchJobModulesConf.setId(id);
				orgBatchJobModulesConf.setSequence(++seq);
				orgBatchJobModulesConf.setIsActive(true);
				orgBatchJobModulesConf.setCrtTs(new Timestamp(System.currentTimeMillis()));
				orgBatchJobModulesConf.setModTs(new Timestamp(System.currentTimeMillis()));
				orgBatchJobModulesConf.setCrtBy(userId);
				orgBatchJobModulesConf.setModBy(userId);
				orgBatchJobModulesConf.setModuleAttributeJson(Utils.getString(confFilter.getModuleAttribute()));
				orgBatchJobModulesConf.setActionNeededJson(Utils.getString(confFilter.getActionNeeded()));

				orgBatchJobModulesConfList.add(orgBatchJobModulesConf);
			}
		}

		if (!iscreated) {
			List<OrgBatchJobModulesConf> jobModulesConfList = getJobModuleConf(confId);
			orgBatchJobModulesConfRepository.deleteAll(jobModulesConfList);
		}
		orgBatchJobModulesConfRepository.saveAll(orgBatchJobModulesConfList);

	}

	public static List<ConfFilter> getConfFilterList(List<OrgBatchJobModulesConf> orgBatchJobConfList) {
		List<ConfFilter> confFilterList = new ArrayList<ConfFilter>();

		for (OrgBatchJobModulesConf orgBatchJobModulesConf : orgBatchJobConfList) {
			ConfFilter confFilter = new ConfFilter();
			confFilter.setModuleId(orgBatchJobModulesConf.getId().getModuleId());
			confFilter.setModuleName(orgBatchJobModulesConf.getBaseBatchJobModules().getModuleName());

			String actionNeeded = orgBatchJobModulesConf.getModuleAttributeJson();
			List<Object> actionNeededList = Utils.getObjectAsArray(actionNeeded);
			confFilter.setActionNeeded(actionNeededList);

			String moduleAttribute = orgBatchJobModulesConf.getModuleAttributeJson();
			List<Object> moduleAttributeList = Utils.getObjectAsArray(moduleAttribute);
			confFilter.setModuleAttribute(moduleAttributeList);

			confFilter.setModuleSequence(orgBatchJobModulesConf.getSequence());

			confFilterList.add(confFilter);
		}
		return confFilterList;
	}

	public List<ConfAllResponse> getConfAllResponse(List<OrgBatchJobConf> orgBatchJobConfList) {
		List<ConfAllResponse> confAllResponseList = new ArrayList<ConfAllResponse>();
		Map<Integer, String> sourceSystemNameMap = getSourceSystemNameMap();
		for (OrgBatchJobConf orgBatchJobConf : orgBatchJobConfList) {
			ConfAllResponse confAllResponse = new ConfAllResponse();
			confAllResponse.setConfId(orgBatchJobConf.getConfId());
			confAllResponse.setConfName(getValue(orgBatchJobConf.getConfName()));
			confAllResponse.setSourceExtractionTypeCd(orgBatchJobConf.getSourceExtractionTypeCd());

			if (orgBatchJobConf.getConfJobExecStatusCd() != null) {
				confAllResponse.setConfJobStatus(
						getValue(BatchJobExecEnum.forValue(orgBatchJobConf.getConfJobExecStatusCd()).toString()));
			} else {
				confAllResponse.setConfJobStatus(getValue(BatchJobExecEnum.forValue(0).toString()));
			}
			confAllResponse.setSourceAllowedUserGroupList(
					Utils.getObjectAsArray(orgBatchJobConf.getSourceAllowedUserGroupList()));

			confAllResponse.setJobNextRunDate(getValue(getDate(orgBatchJobConf.getNextRunDateTs())));
			if (orgBatchJobConf.getSourceExtractionTypeCd() != null) {
				confAllResponse.setSourceExtractionType(getValue(
						BatchJobExtractionEnum.forValue(orgBatchJobConf.getSourceExtractionTypeCd()).toString()));
			} else {
				confAllResponse.setSourceExtractionType("");
			}
			confAllResponse.setSourceDescription(getValue(orgBatchJobConf.getSourceDescription()));
			confAllResponse.setConfStatus(
					getValue(BatchJobConfEnum.forValue(orgBatchJobConf.getBatchJobConfStatusCd()).toString()));

			confAllResponse.setSourceTypeCd(orgBatchJobConf.getSourceTypeCd());

			if (sourceSystemNameMap.containsKey(orgBatchJobConf.getSourceTypeCd())) {
				confAllResponse.setSourceTypeName(sourceSystemNameMap.get(orgBatchJobConf.getSourceTypeCd()));
			} else {
				confAllResponse.setSourceTypeName("");
			}
			confAllResponseList.add(confAllResponse);
		}

		return confAllResponseList;
	}

	public ConfResponse getConfResponse(OrgBatchJobConf orgBatchJobConf) {

		ConfResponse confResponse = new ConfResponse();
		confResponse.setConfId(getValue(orgBatchJobConf.getConfId()));
		confResponse.setConfName(getValue(orgBatchJobConf.getConfName()));
		String config = orgBatchJobConf.getSourceClassificationJson();
		if (config != null && config.startsWith("[{")) {
			confResponse.setSourceTypeFields(
					Utils.getSourceTypeFieldstAsArray(orgBatchJobConf.getSourceClassificationJson()));
		} else {
			confResponse.setSourceTypeFields(Utils
					.getSourceTypeFieldstAsArray(AES.decrypt(orgBatchJobConf.getSourceClassificationJson(), aesKey)));
		}
		if (confResponse.getSourceTypeFields() != null && confResponse.getSourceTypeFields().size() > 0) {
			for (Object obj : confResponse.getSourceTypeFields()) {
				SourceTypeField sourceTypeField = (SourceTypeField) obj;
				if (sourceTypeField.getFieldType().equalsIgnoreCase("password")) {
					List<String> list = new ArrayList<String>();
					list.add(PASSWORD);
					sourceTypeField.setFieldValues(list);
				}
			}
		}
		confResponse
				.setSourceAllowedUserGroupList(Utils.getObjectAsArray(orgBatchJobConf.getSourceAllowedUserGroupList()));
		confResponse.setSourceDescription(getValue(orgBatchJobConf.getSourceDescription()));
		confResponse.setSourceTagIdList(Utils.getObjectAsArray(orgBatchJobConf.getSourceTagIdList()));
		confResponse.setSourceExtractionTypeCd(orgBatchJobConf.getSourceExtractionTypeCd());
		confResponse.setSourceExtractionType(
				getValue(BatchJobExtractionEnum.forValue(orgBatchJobConf.getSourceExtractionTypeCd()).toString()));
		confResponse.setSourceTypeCd(orgBatchJobConf.getSourceTypeCd());
		if (orgBatchJobConf.getConfJobExecStatusCd() != null) {
			confResponse.setConfJobStatus(
					getValue(BatchJobExecEnum.forValue(orgBatchJobConf.getConfJobExecStatusCd()).toString()));
		} else {
			confResponse.setConfJobStatus(getValue(BatchJobExecEnum.forValue(0).toString()));
		}

		confResponse.setConfStatus(
				getValue(BatchJobConfEnum.forValue(orgBatchJobConf.getBatchJobConfStatusCd()).toString()));
		confResponse.setJobNextRunDate(getValue(getDate(orgBatchJobConf.getNextRunDateTs())));
		confResponse.setCrtBy(getValue(orgBatchJobConf.getCrtBy()));
		confResponse.setSourceScheduleJson(
				(Schedule) Utils.getObject(orgBatchJobConf.getSourceScheduleJson(), Schedule.class));
		BaseSourceType baseSourceType = baseSourceTypeRepository.findBySourceTypeCd(orgBatchJobConf.getSourceTypeCd());

		if (baseSourceType != null) {
			confResponse.setSourceTypeName(baseSourceType.getSourceTypeName());
		} else {
			confResponse.setSourceTypeName("");
		}

		List<OrgBatchJobModulesConf> jobModulesConfList = getJobModuleConf(orgBatchJobConf.getConfId());
		List<Module> moduleList = new ArrayList<Module>();
		for (OrgBatchJobModulesConf orgBatchJobModulesConf : jobModulesConfList) {
			BaseBatchJobModules base = orgBatchJobModulesConf.getBaseBatchJobModules();
			if (base.getModuleTypeCd() == 3) {
				Module module = new Module();
				module.setModuleId(base.getModuleId());
				module.setModuleName(base.getModuleName().trim());
				module.setModuleSequence(orgBatchJobModulesConf.getSequence());

				String orgAttribute = orgBatchJobModulesConf.getModuleAttributeJson();
				List<Object> orgModObj = Utils.getObjectAsArray(orgAttribute);
				if (orgModObj != null) {
					for (Object object : orgModObj) {
						String arr = (String) object;
						module.addModuleAttribute(arr);
					}
				}

				String orgAction = orgBatchJobModulesConf.getActionNeededJson();
				List<Object> orgActObj = Utils.getObjectAsArray(orgAction);
				if (orgActObj != null) {
					for (Object object : orgActObj) {
						String arr = (String) object;
						module.addActionNeeded(arr);
					}
				}
				moduleList.add(module);
			}
		}
		confResponse.setFilter(moduleList);

		return confResponse;
	}

	private static String getDate(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (date != null) {
			return sdf.format(date);
		} else {
			return "";
		}
	}

	private static String getValue(String str) {
		if (str != null) {
			return str;
		} else {
			return "";
		}
	}

	@Transactional(isolation = Isolation.SERIALIZABLE)
	public String deleteConf(String confId) {
		OrgBatchJobConf conf = orgBatchJobConfRepository.findById(confId).orElse(null);
		if (conf != null) {
			List<OrgBatchJobModulesConf> jobModulesConfList = getJobModuleConf(confId);
			for (OrgBatchJobModulesConf orgBatchJobModulesConf : jobModulesConfList) {
				orgBatchJobModulesConf.setIsActive(false);
			}
			conf.setBatchJobConfStatusCd(BatchJobConfEnum.DELETED.getValue());
			conf.setNextRunDateTs(null);
			conf.setConfJobExecStatusCd(BatchJobConfEnum.DELETED.getValue());
			orgBatchJobConfRepository.save(conf);
			orgBatchJobModulesConfRepository.saveAll(jobModulesConfList);

			return conf.getConfId();
		} else {
			return null;
		}

	}

	public List<String> getAllConfNames() {
		return orgBatchJobConfRepository.getAllConfName();
	}

	public List<String> getAllConfNames(String ConfId) {
		return orgBatchJobConfRepository.getAllConfName(ConfId);
	}

	public Map<Integer, String> getSourceSystemNameMap() {
		Map<Integer, String> map = new HashMap<Integer, String>();
		List<BaseSourceType> list = baseSourceTypeRepository.findAll();
		for (BaseSourceType baseSourceType : list) {
			map.put(baseSourceType.getSourceTypeCd(), baseSourceType.getSourceTypeName());
		}

		return map;
	}

	public List<Integer> getSourceExtractionTypeCd() {
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		list.add(3);
		return list;

	}

	public List<Integer> getSourceTypeCd() {
		List<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(3);
		list.add(4);
		list.add(6);
		list.add(7);
		list.add(8);
		list.add(9);
		list.add(10);
		return list;
	}
}
