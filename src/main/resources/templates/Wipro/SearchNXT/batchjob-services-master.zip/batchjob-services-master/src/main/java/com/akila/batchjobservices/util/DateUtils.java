package com.akila.batchjobservices.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.akila.batchjobservices.conf.bean.Schedule;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class DateUtils {

	private static final Logger logger = LogManager.getLogger(DateUtils.class);
	
	public static Date getNextRunDate(String scheduleRunJson, String confId) {
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			Schedule schedule = objectMapper.readValue(scheduleRunJson, Schedule.class);
			return getNextDate(schedule);
		} catch (JsonMappingException  e) {
			logger.error("Error while get next run date -  conf_id : "+confId+ " Error : "+e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Error while get next run date -  conf_id : "+confId+ " Error : "+e.getMessage(), e);
		}

		return null;
	}
	
	public static Date getNextRunDate(Schedule schedule, String confId) {
		try {
			return getNextDate(schedule);
		} catch (ParseException e) {
			logger.error("Error while get next run date -  conf_id : "+confId+ " Error : "+e.getMessage(), e);
		} catch (Exception e) {
			logger.error("Error while get next run date -  conf_id : "+confId+ " Error : "+e.getMessage(), e);
		}

		return null;
	}

	private static Date getNextDate(Schedule scheduleDto) throws ParseException {
		logger.info("DateUtils API getNextDate next run date - " + scheduleDto.getDate()+" "+scheduleDto.getTime());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		try {
			logger.info("DateUtils API getNextDate returned next run date - " + sdf.parse(scheduleDto.getDate()+" "+scheduleDto.getTime()));
			return sdf.parse(scheduleDto.getDate()+" "+scheduleDto.getTime());
		} catch (ParseException e) {
			logger.error("DateUtils => getNextDate : ", e);
		}
		return null;
	}
	
}
