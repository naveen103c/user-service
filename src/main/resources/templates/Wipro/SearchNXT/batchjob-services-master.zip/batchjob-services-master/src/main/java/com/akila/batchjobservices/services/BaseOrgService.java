package com.akila.batchjobservices.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.batchjobservices.entity.BaseOrgs;
import com.akila.batchjobservices.repository.BaseOrgsRepository;

@Service
public class BaseOrgService {

	@Autowired
	BaseOrgsRepository BaseOrgsRepository;
	
	public BaseOrgs getBaseOrgs(String orgId) {
		
		return BaseOrgsRepository.findById(orgId).orElse(null);
		
	}
}
