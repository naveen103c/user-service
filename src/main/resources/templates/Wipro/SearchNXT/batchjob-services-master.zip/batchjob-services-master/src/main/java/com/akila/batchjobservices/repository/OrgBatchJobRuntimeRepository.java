package com.akila.batchjobservices.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.batchjobservices.entity.OrgBatchJobRuntime;

@Repository
public interface OrgBatchJobRuntimeRepository extends JpaRepository<OrgBatchJobRuntime, String>{

	OrgBatchJobRuntime findByConfIdAndJobStatusCd(String confId, int status);

	List<OrgBatchJobRuntime> findByConfIdOrderByLastJobUpdatedTsDesc(String confId);

	OrgBatchJobRuntime findByJobId(String jobId);

	List<OrgBatchJobRuntime> findByOrgBatchJobConfs_SourceTypeCdOrderByLastJobUpdatedTsDesc(int sourcetypes);
	
	List<OrgBatchJobRuntime> findByOrgBatchJobConfsSourceTypeCdNotOrderByLastJobUpdatedTsDesc(int sourceTypeCd, Pageable pageable);

	
}
