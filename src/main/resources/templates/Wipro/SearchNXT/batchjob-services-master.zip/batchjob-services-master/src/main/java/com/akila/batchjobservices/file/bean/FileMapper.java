package com.akila.batchjobservices.file.bean;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface FileMapper {
  FileMapper INSTANCE = Mappers.getMapper(FileMapper.class);
  ;
}
