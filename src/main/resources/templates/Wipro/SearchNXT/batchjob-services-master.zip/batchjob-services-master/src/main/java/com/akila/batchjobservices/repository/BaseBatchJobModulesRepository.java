package com.akila.batchjobservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.batchjobservices.entity.BaseBatchJobModules;

@Repository
public interface BaseBatchJobModulesRepository extends JpaRepository<BaseBatchJobModules, String> {

	List<BaseBatchJobModules> findAllByModuleTypeCd(int i);

	List<BaseBatchJobModules> findAllBysourceTypeCd(Integer sourceTypeCode);

}
