package com.akila.batchjobservices.file.bean;

import com.akila.AkilaResponse;
import java.sql.Timestamp;

public class JobFileResponse extends AkilaResponse {

	String fileId;
	String confId;
	String jobId;
	String fileName;
	String fileUrl;
	Integer updatedStep;
	Integer status;
	Timestamp fileCrtTs;
	Timestamp fileModTs;
	Integer fileSize;
	String description;
	
	public String getFileId() {
		return fileId;
	}
	public void setFileId(String fileId) {
		this.fileId = fileId;
	}
	public String getConfId() {
		return confId;
	}
	public void setConfId(String confId) {
		this.confId = confId;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileUrl() {
		return fileUrl;
	}
	public void setFileUrl(String fileUrl) {
		this.fileUrl = fileUrl;
	}
	public Integer getUpdatedStep() {
		return updatedStep;
	}
	public void setUpdatedStep(Integer updatedStep) {
		this.updatedStep = updatedStep;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Timestamp getFileCrtTs() {
		return fileCrtTs;
	}
	public void setFileCrtTs(Timestamp fileCrtTs) {
		this.fileCrtTs = fileCrtTs;
	}
	public Timestamp getFileModTs() {
		return fileModTs;
	}
	public void setFileModTs(Timestamp fileModTs) {
		this.fileModTs = fileModTs;
	}
	public Integer getFileSize() {
		return fileSize;
	}
	public void setFileSize(Integer fileSize) {
		this.fileSize = fileSize;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}

