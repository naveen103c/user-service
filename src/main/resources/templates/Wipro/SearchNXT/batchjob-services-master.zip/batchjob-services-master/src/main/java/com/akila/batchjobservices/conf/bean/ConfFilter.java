package com.akila.batchjobservices.conf.bean;

import java.util.ArrayList;
import java.util.List;

public class ConfFilter {

	Integer moduleId;
	String moduleName;
	Integer moduleSequence;
	List<Object> moduleAttribute = new ArrayList<Object>();
	List<Object> actionNeeded = new ArrayList<Object>();

	public List<Object> getActionNeeded() {
		return actionNeeded;
	}

	public void setActionNeeded(List<Object> actionNeeded) {
		if (actionNeeded != null) {
			this.actionNeeded = actionNeeded;
		}
	}

	public ConfFilter() {
		// TODO Auto-generated constructor stub
	}

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public Integer getModuleSequence() {
		return moduleSequence;
	}

	public void setModuleSequence(Integer moduleSequence) {
		this.moduleSequence = moduleSequence;
	}

	public List<Object> getModuleAttribute() {
		return moduleAttribute;
	}

	public void setModuleAttribute(List<Object> moduleAttribute) {
		if (moduleAttribute != null) {
			this.moduleAttribute = moduleAttribute;
		}
	}

}
