package com.akila.batchjobservices.file.bean;

import com.akila.AkilaRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * @author RA40030913
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class FileRequest extends AkilaRequest {

	private String fileCrtTs;

	private String fileModTs;

	private String fileNm;

	private String author;
	
	private String sourceFileKey;

	public String getFileNm() {
		return fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getSourceFileKey() {
		return sourceFileKey;
	}

	public void setSourceFileKey(String sourceFileKey) {
		this.sourceFileKey = sourceFileKey;
	}

	public String getFileCrtTs() {
		return fileCrtTs;
	}

	public void setFileCrtTs(String fileCrtTs) {
		this.fileCrtTs = fileCrtTs;
	}

	public String getFileModTs() {
		return fileModTs;
	}

	public void setFileModTs(String fileModTs) {
		this.fileModTs = fileModTs;
	}
}
