package com.akila.batchjobservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.batchjobservices.entity.OrgBatchJobModulesConf;
import com.akila.batchjobservices.entity.OrgBatchJobModulesConfId;

@Repository
public interface OrgBatchJobModulesConfRepository
		extends JpaRepository<OrgBatchJobModulesConf, OrgBatchJobModulesConfId> {

	public List<OrgBatchJobModulesConf> findByConfIdOrderBySequenceAsc(String confId);

}
