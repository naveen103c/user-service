package com.akila.batchjobservices.sns;

import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Scanner;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class SnsController {
	private static final Logger logger = LogManager.getLogger(SnsController.class);

	@PostMapping(path = "/notification")
	public void notification(HttpServletRequest request) {

		Enumeration headerNames = request.getHeaderNames();
		while (headerNames.hasMoreElements()) {
			String headerName = (String) headerNames.nextElement();
			logger.info(headerName + " :  " + request.getHeader(headerName));
		}

		String messagetype = request.getHeader("x-amz-sns-message-type");
		logger.info("x-amz-sns-message-type :  " + messagetype);
		// If message doesn't have the message type header, don't process it.
		if (messagetype == null) {
			return;
		}
		Scanner scan = null;
		try {
			scan = new Scanner(request.getInputStream());
			StringBuilder builder = new StringBuilder();
			while (scan.hasNextLine()) {
				builder.append(scan.nextLine());
			}
			logger.info("Request Body :  " + builder.toString());
			ObjectMapper om = new ObjectMapper();
			Message msg = om.readValue(builder.toString(), Message.class);

			if (msg.getSignatureVersion().equals("1")) {
				logger.info("msg.getSignatureVersion() : " + msg.getSignatureVersion());
			} else {
				logger.info("ELSE msg.getSignatureVersion() : " + msg.getSignatureVersion());
			}

			logger.info("messagetype : " + messagetype);

			if (messagetype.equals("Notification")) {
				String logMsgAndSubject = ">>Notification received from topic " + msg.getTopicArn();
				if (msg.getSubject() != null) {
					logMsgAndSubject += " Subject: " + msg.getSubject();
				}
				logMsgAndSubject += " Message: " + msg.getMessage();
				logger.info(logMsgAndSubject);
			} else if (messagetype.equals("SubscriptionConfirmation")) {
				logger.info("SubscriptionConfirmation : "+msg.getSubscribeURL());
				Scanner sc = new Scanner(new URL(msg.getSubscribeURL()).openStream());
			        StringBuilder sb = new StringBuilder();
			        while (sc.hasNextLine()) {
			            sb.append(sc.nextLine());
			        }
			        logger.info(">>Subscription confirmation (" + msg.getSubscribeURL() + ") Return value: " + sb.toString());
			        
			} else if (messagetype.equals("UnsubscribeConfirmation")) {
				// Handle UnsubscribeConfirmation message.
				// For example, take action if unsubscribing should not have
				// occurred.
				// You can read the SubscribeURL from this message and
				// re-subscribe the endpoint.
				// log.info(">>Unsubscribe confirmation: " + msg.getMessage());
				logger.info("Unsubscribe confirmation: " + msg.getMessage());
			} else {
				logger.info(">>Unknown message type.");
			}

		}
		catch (IOException e) {
			logger.error(">>Error while getting SNS Message",e);
		}finally {
		    if (scan != null) {
		        	scan.close();
		    } 
		}

	}

}
