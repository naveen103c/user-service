package com.akila.batchjobservices.conf.bean;

import java.util.HashMap;
import java.util.Map;

public enum BatchJobExecEnum {

	SUBMITTED(1), SCHEDULED(2), QUEUED(3), RUNNING(4), FAILED(6), COMPLETED(7), COMPLETED_WITH_ERROR(8), NOT_SCHEDULED(0),DELETED(9);

	private final int value;

	private BatchJobExecEnum(int value) {
		this.value = value;
	}

	private final static Map<Integer, BatchJobExecEnum> REVERSE_MAP = new HashMap<>();

	static {
		for (BatchJobExecEnum status : values()) {
			REVERSE_MAP.put(status.value, status);
		}
	}

	public static BatchJobExecEnum forValue(int value) {
		return REVERSE_MAP.get(value);
	}
	
	public  int getValue() {
		return this.value;
	}

}