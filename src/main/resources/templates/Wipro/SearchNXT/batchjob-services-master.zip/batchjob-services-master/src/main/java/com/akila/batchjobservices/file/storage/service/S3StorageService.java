package com.akila.batchjobservices.file.storage.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.NotImplementedException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.akila.batchjobservices.file.storage.bean.StorageRequest;
import com.akila.batchjobservices.file.storage.bean.StorageResponse;
import com.akila.batchjobservices.file.storage.bean.UploadFilePartRequest;
import com.akila.batchjobservices.file.storage.bean.UploadFilePartResponse;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.CompleteMultipartUploadRequest;
import com.amazonaws.services.s3.model.CompleteMultipartUploadResult;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadRequest;
import com.amazonaws.services.s3.model.InitiateMultipartUploadResult;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PartETag;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.model.UploadPartRequest;
import com.amazonaws.services.s3.model.UploadPartResult;
import com.amazonaws.util.IOUtils;

//@Service
//@Scope("prototype")
public class S3StorageService implements IStorageService {
	private static final Logger logger = LogManager.getLogger(S3StorageService.class);
	//@Value("${accessKey}")
	private String accessKey;
	//@Value("${secretKey}")
	private String secretKey;
	//@Value("${s3-region}")
	private String s3Region;

	private AmazonS3 s3Client;

	public S3StorageService() {

	}

	private synchronized AmazonS3 getS3Client(String orgId) {
		if (s3Client != null) {
			return s3Client;
		}
		BasicAWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
		s3Client = AmazonS3ClientBuilder.standard().withRegion(s3Region)
				.withCredentials(new AWSStaticCredentialsProvider(credentials)).build();
		return s3Client;
	}

	private String getObjectURL(StorageRequest request) {
		return request.getContentType() + "/" + request.getFormatType() + "/" + request.getContentId();
	}

	@Override
	public StorageResponse getObject(StorageRequest storageRequest) throws Exception {
		GetObjectRequest request = new GetObjectRequest(storageRequest.getOrgId(), getObjectURL(storageRequest));
		if (storageRequest.getVersionId() != null && !storageRequest.getVersionId().trim().isEmpty()) {
			request.setVersionId(storageRequest.getVersionId().trim());
		}
		S3Object s3Object = getS3Client(storageRequest.getOrgId()).getObject(request);
		StorageResponse response = new StorageResponse();
		response.setDataStream(s3Object.getObjectContent());
		response.setContentLenght(s3Object.getObjectMetadata().getContentLength());
		response.setUserMetadata(s3Object.getObjectMetadata().getUserMetadata());
		response.setContent(IOUtils.toByteArray(s3Object.getObjectContent()));
		response.setVersionId(s3Object.getObjectMetadata().getVersionId());
		s3Object.close();
		return response;
	}

	@Override
	public StorageResponse putObject(StorageRequest storageRequest, Map<String, String> fileDataData) {
		logger.info("putObject : inside putObject");
		PutObjectResult result = null;
		if (storageRequest.getInputStreamType() != null
				&& storageRequest.getInputStreamType().equalsIgnoreCase("string")) {
			logger.info("putObject : inside-1 putObject orgId: " + storageRequest.getOrgId() + ", Path : "
					+ getObjectURL(storageRequest));
			result = getS3Client(storageRequest.getOrgId()).putObject(storageRequest.getOrgId(),
					getObjectURL(storageRequest), (String) storageRequest.getContent());
		} else {
			ObjectMetadata metadata = new ObjectMetadata();
			if (fileDataData != null) {
				metadata.setUserMetadata(fileDataData);
			}
			logger.info("putObject : orgId: " + storageRequest.getOrgId() + ", Path : " + getObjectURL(storageRequest));
			try {
				metadata.setContentLength(((InputStream) storageRequest.getContent()).available());
			} catch (IOException e) {
				logger.error("putObject : Error while getting content lenght : " + e.getMessage(), e);
			}

			if (storageRequest.getFileFormat() != null) {
				metadata.setContentType(storageRequest.getFileFormat());
			}
			logger.info("putObject : putting file into S3 orgId: " + storageRequest.getOrgId() + ", Path : "
					+ getObjectURL(storageRequest));
			PutObjectRequest putObjectRequest = new PutObjectRequest(storageRequest.getOrgId(),
					getObjectURL(storageRequest), (InputStream) storageRequest.getContent(), metadata);
			result = getS3Client(storageRequest.getOrgId()).putObject(putObjectRequest);
			logger.info("putObject : file added to S3 orgId: " + storageRequest.getOrgId() + ", Path : "
					+ getObjectURL(storageRequest) + ", Version ; " + result.getVersionId());
		}
		StorageResponse response = new StorageResponse();
		response.setVersionId(result.getVersionId());
		return response;
	}

	@Override
	public void deleteObject(StorageRequest storageRequest) {
		getS3Client(storageRequest.getOrgId()).deleteObject(storageRequest.getOrgId(), getObjectURL(storageRequest));
	}

	@Override
	public void deleteOrg(String orgId) {
		throw new NotImplementedException("Delete org is not implemented yet");

	}

	@Override
	public List<String> getAllFileNamesInS3Bucket(StorageRequest storageRequest) {
		String folderPah = "";
		if (storageRequest.getContentType() != null) {
			folderPah = storageRequest.getContentType();
		}

		if (storageRequest.getFormatType() != null) {
			folderPah = folderPah + "/" + storageRequest.getFormatType();
		}

		ListObjectsRequest listObjectsRequest = new ListObjectsRequest().withBucketName(storageRequest.getOrgId())
				.withPrefix(folderPah);

		AmazonS3 s3Object = getS3Client(storageRequest.getOrgId());

		ObjectListing objectListing = s3Object.listObjects(listObjectsRequest);

		List<String> fileList = new ArrayList<String>();

		for (S3ObjectSummary summary : objectListing.getObjectSummaries()) {
			String fileName = summary.getKey();
			fileName = fileName.substring(fileName.lastIndexOf("/") + 1);
			if (fileName != null && fileName.length() > 0) {
				fileList.add(fileName);
			}
		}

		return fileList;
	}

	@Override
	public List<String> getAllFileNamesWithSizeInS3Bucket(StorageRequest storageRequest) {
		String folderPah = "";
		if (storageRequest.getContentType() != null) {
			folderPah = storageRequest.getContentType();
		}

		if (storageRequest.getFormatType() != null) {
			folderPah = folderPah + "/" + storageRequest.getFormatType();
		}

		ListObjectsRequest listObjectsRequest = new ListObjectsRequest().withBucketName(storageRequest.getOrgId())
				.withPrefix(folderPah);

		AmazonS3 s3Object = getS3Client(storageRequest.getOrgId());

		ObjectListing objectListing = s3Object.listObjects(listObjectsRequest);

		List<String> fileList = new ArrayList<String>();

		for (S3ObjectSummary summary : objectListing.getObjectSummaries()) {
			String fileName = summary.getKey();
			fileName = fileName.substring(fileName.lastIndexOf("/") + 1);
			if (fileName != null && fileName.length() > 0) {
				fileList.add(fileName + " : " + summary.getSize());
			}
		}

		return fileList;
	}

	public String InitiateMultipartFileUpload(UploadFilePartRequest request) {
		logger.info("Start : InitiateMultipartFileUpload : orgId: " + request.getOrgId() + ", JobId : " + request.getJobId());
		AmazonS3 s3Object = getS3Client(request.getOrgId());
		InitiateMultipartUploadRequest req = new InitiateMultipartUploadRequest(request.getOrgId(),
				getUploadKey(request));
		InitiateMultipartUploadResult result = s3Object.initiateMultipartUpload(req);
		logger.info("End : InitiateMultipartFileUpload : orgId: " + request.getOrgId() + ", JobId : " + request.getJobId()+", UploadId : "+result.getUploadId());
		return result.getUploadId();
	}

	public PartETag uploadFilePart(UploadFilePartRequest request) {
		logger.info("Start : uploadFilePart : orgId: " + request.getOrgId() + ", JobId : " + request.getJobId()+", Key : "+getUploadKey(request)+", UploadId : "+request.getUploadId());
		AmazonS3 s3Object = getS3Client(request.getOrgId());
		
		UploadPartRequest req = new UploadPartRequest();
		
		req.setBucketName(request.getOrgId());
		req.setInputStream(request.getInput());
		req.setKey(getUploadKey(request));
		req.setPartNumber(request.getPartNumber());
		req.setPartSize(request.getPartSize());
		req.setUploadId(request.getUploadId());
		
		UploadPartResult result = s3Object.uploadPart(req);
		
		PartETag tag = result.getPartETag();
		logger.info("End : uploadFilePart : orgId: " + request.getOrgId() + ", JobId : " + request.getJobId() +", UploadId : "+request.getUploadId() +", TagId : "+tag.getETag()+", PartNumber : "+tag.getPartNumber());
		return tag;
	}

	public String completeFilePartUpload(UploadFilePartRequest request) {
		logger.info("Start : completeFilePartUpload : orgId: " + request.getOrgId() + ", JobId : " + request.getJobId()+", Key : "+getUploadKey(request)+", UploadId : "+request.getUploadId());
		AmazonS3 s3Object = getS3Client(request.getOrgId());
		
		CompleteMultipartUploadRequest req = new CompleteMultipartUploadRequest();
		
		req.setUploadId(request.getUploadId());
		req.setKey(getUploadKey(request));
		req.setBucketName(request.getOrgId());
		req.setPartETags(request.getPartETags());

		CompleteMultipartUploadResult result = s3Object.completeMultipartUpload(req);
		logger.info("End : completeFilePartUpload : orgId: " + request.getOrgId() + ", JobId : " + request.getJobId()+", Key : "+getUploadKey(request)+", UploadId : "+request.getUploadId()+", VersionId : "+result.getVersionId());
		
		return result.getVersionId();
	}

	private String getUploadKey(UploadFilePartRequest request) {
		if (request.getJobId() != null) {
			return request.getContentType() + "/" + request.getFormatType() + "/" + request.getJobId() + "/"
					+ request.getContentId();
		} else {
			return request.getContentType() + "/" + request.getFormatType() + "/" + request.getContentId();
		}

	}
}
