package com.akila.batchjobservices.file.bean;

import com.akila.AkilaResponse;

public class FileResponse extends AkilaResponse {
	
	String fileName;
	long fileSize;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public long getFileSize() {
		return fileSize;
	}
	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}
	
	
	
}
