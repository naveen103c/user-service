package com.akila.batchjobservices.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

@Service
public class FileVirusScanService {
	private static final Logger logger = LogManager.getLogger(FileVirusScanService.class);

	@Value("${macfee.host.ip:ip}")
	String serverHost;
	
	@Value("${macfee.host.user:user}")
	String user;
	
	@Value("${macfee.host.password:password}")
	String password;
	
	@Value("${macfee.script.path:path}")
	String mcafeeScript;
	
	@Value("${tmp.file.location:location}")
	String tmpFileStoreLocation;
	
	/**
	 * It will return true if file doesn't contain any malware else it will return false
	 * @param file
	 * @return
	 * @throws IOException
	 */
	public boolean scanFile(MultipartFile file) throws IOException, Exception {
		boolean result;
		File f = null;
		try {
			logger.info("scanFile : " + file.getOriginalFilename());
			String uuid = UUID.randomUUID().toString();
			String fileName = file.getOriginalFilename();
			String extn = fileName.substring(fileName.lastIndexOf(".")+1);
			f = new File(tmpFileStoreLocation+"/"+uuid+"."+extn);
			logger.info("scanFile : downloading file to temp location for virus scan,Temp File : " + f.getAbsolutePath()+", orignal file name : "+file.getOriginalFilename());
			OutputStream out = new FileOutputStream(f);
			logger.info("scanFile : downloading file to temp location for virus scan : " + f.getAbsolutePath()+", orignal file name : "+file.getOriginalFilename());
			IOUtils.copy(file.getInputStream(),out);
			out.close();
			logger.info("scanFile : downloaded file to temp location for virus scan : " + f.getAbsolutePath()+", orignal file name : "+file.getOriginalFilename());
			
			result = scan(f.getAbsolutePath(),uuid);
			
			
		} finally {
			if(f != null) {
				f.delete();
				logger.info("scanFile : Deleted Temp file : "+f.getAbsolutePath());
			}
			
		}
		
		
		return result;
	}

	private boolean scan(String file, String uuid) throws Exception{
		logger.info("Starting virus scanning for file : " + file);
		boolean isFileClean = true;
		try {
			JSch jsch = new JSch();
			Session jschSession = jsch.getSession(user, serverHost, 22);
			jschSession.setPassword(password);
			jschSession.setConfig("StrictHostKeyChecking", "no");
			jschSession.connect(10000);
			ChannelExec channelExec = (ChannelExec) jschSession.openChannel("exec");
			String command = "echo '" + password + "' | sudo -S " + mcafeeScript + " " + file + " " + uuid;
			logger.info("Macfee Command : "+"echo 'xxxxxxxxxxxxx' | sudo -S " + mcafeeScript + " " + file + " " + uuid);
			channelExec.setCommand(command);

			channelExec.setErrStream(System.err);

			InputStream in = channelExec.getInputStream();

			channelExec.connect(5000);

			// read the result from remote server
			byte[] tmp = new byte[1024];
			String lastline = "";
			while (true) {
				StringBuffer sb = new StringBuffer();
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					sb.append(new String(tmp, 0, i));
				}
				logger.info(sb.toString());
				lastline = sb.toString();
				if (channelExec.isClosed()) {
					if (in.available() > 0)
						continue;
					logger.info("Virus Scan ExitStatus : "+channelExec.getExitStatus());
					break;
				}
				try {
					Thread.sleep(1000);
				} catch (Exception ee) {
					logger.error(ee.getMessage(),ee);
				}
			}

			logger.info("Virus Scan Result : "+ lastline);
			String result[] = lastline.substring(lastline.indexOf("root No. of Infections")).split(":");
			if (result[1].trim().equals("0")) {
				logger.info("File is clean : " + file);
				isFileClean = true;
			} else {
				logger.info("File is Infected : " + file);
				isFileClean = false;
			}

			channelExec.disconnect();
			jschSession.disconnect();
			logger.info("Virus Scanning Completed for File : "+file);
		} catch (JSchException | IOException e) {
			logger.error("Error while scanning file : "+file+", Error : "+e.getMessage(),e);
		}catch( Exception e) {
			logger.error("Error while scanning file : "+file+", Error : "+e.getMessage(),e);
			throw new Exception(e);
		}

		return isFileClean;
	}
}
