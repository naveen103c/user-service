package com.akila.batchjobservices.job.bean;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class JobSummary {

	int jobStatusCd = 0;
	int jobFailedCount = 0;
	String jobStatus = "";
	int totalRecord = 0;
	int totalRecordRead;
	int totalProcessCount = 0;
	int totalRecordWrite = 0;
	int totalSkipByFilters = 0;
	int totalAlreadyProcessCountBeforeFailed = 0;
	int fileParsingErrorCount = 0;
	List<String> fileParsingErrorContent = new ArrayList<String>();
	List<String> errors = new ArrayList<String>();
	long contentSize = 0;
	long textContentSyncTime = 0;
	long mediaContentSyncTime = 0;
	int indexingErrorCount = 0;
	
	public int getJobStatusCd() {
		return jobStatusCd;
	}

	public void setJobStatusCd(int jobStatusCd) {
		this.jobStatusCd = jobStatusCd;
	}

	public int getJobFailedCount() {
		return jobFailedCount;
	}

	public void setJobFailedCount(int jobFailedCount) {
		this.jobFailedCount = jobFailedCount;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public int getTotalRecordRead() {
		return totalRecordRead;
	}

	public void setTotalRecordRead(int totalRecordRead) {
		this.totalRecordRead = totalRecordRead;
	}

	public int getTotalRecordWrite() {
		return totalRecordWrite;
	}

	public void setTotalRecordWrite(int totalRecordWrite) {
		this.totalRecordWrite = totalRecordWrite;
	}

	public List<String> getErrors() {
		return errors;
	}

	public void setErrors(List<String> errors) {
		this.errors = errors;
	}

	public void addErrors(String errors) {
		this.errors.add(errors);
	}

	public int getTotalRecord() {
		return totalRecord;
	}

	public void setTotalRecord(int totalRecord) {
		this.totalRecord = totalRecord;
	}

	public int getTotalProcessCount() {
		return totalProcessCount;
	}

	public void setTotalProcessCount(int totalProcessCount) {
		this.totalProcessCount = totalProcessCount;
	}

	public int getTotalSkipByFilters() {
		return totalSkipByFilters;
	}

	public void setTotalSkipByFilters(int totalSkipByFilters) {
		this.totalSkipByFilters = totalSkipByFilters;
	}

	public int getTotalAlreadyProcessCountBeforeFailed() {
		return totalAlreadyProcessCountBeforeFailed;
	}

	public void setTotalAlreadyProcessCountBeforeFailed(int totalAlreadyProcessCountBeforeFailed) {
		this.totalAlreadyProcessCountBeforeFailed = totalAlreadyProcessCountBeforeFailed;
	}

	public int getFileParsingErrorCount() {
		return fileParsingErrorCount;
	}

	public void setFileParsingErrorCount(int fileParsingErrorCount) {
		this.fileParsingErrorCount = fileParsingErrorCount;
	}

	public List<String> getFileParsingErrorContent() {
		return fileParsingErrorContent;
	}

	public void setFileParsingErrorContent(List<String> fileParsingErrorContent) {
		this.fileParsingErrorContent = fileParsingErrorContent;
	}

	public long getContentSize() {
		return contentSize;
	}

	public void setContentSize(long contentSize) {
		this.contentSize = contentSize;
	}

	public long getTextContentSyncTime() {
		return textContentSyncTime;
	}

	public void setTextContentSyncTime(long textContentSyncTime) {
		this.textContentSyncTime = textContentSyncTime;
	}

	public long getMediaContentSyncTime() {
		return mediaContentSyncTime;
	}

	public void setMediaContentSyncTime(long mediaContentSyncTime) {
		this.mediaContentSyncTime = mediaContentSyncTime;
	}

	public int getIndexingErrorCount() {
		return indexingErrorCount;
	}

	public void setIndexingErrorCount(int indexingErrorCount) {
		this.indexingErrorCount = indexingErrorCount;
	}

}
