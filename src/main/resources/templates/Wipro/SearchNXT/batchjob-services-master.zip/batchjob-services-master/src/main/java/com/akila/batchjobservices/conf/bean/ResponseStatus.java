package com.akila.batchjobservices.conf.bean;

public class ResponseStatus {

	int statusCode;
	String id;
	int errorCode;
	String message;

	public ResponseStatus(){}
	
	public ResponseStatus(int statusCd, String id, String message, int errorCode) {
		this.statusCode = statusCd;
		this.id = id;
		this.errorCode = errorCode;
		this.message = message;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
