package com.akila.batchjobservices.util;

public class Constants {
	
	public static int SCHEDULED_PULL_CD = 1;
	public static int ADHOC_PULL_CD = 2;
	public static int UPLOAD_CD = 3;
	
	public static int ATTACHMENT_SOURCE_TYPE = 9;

}
