package com.akila.batchjobservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.batchjobservices.entity.OrgBatchJobConf;

@Repository
public interface OrgBatchJobConfRepository extends JpaRepository<OrgBatchJobConf, String> {

	List<OrgBatchJobConf> findByBatchJobConfStatusCdNotAndSourceTypeCdNotOrderByConfNameAsc(Integer statusCodeNotIn, Integer sourceType);
	
	@Query(value = "SELECT confName from OrgBatchJobConf where batchJobConfStatusCd != 9")
	List<String> getAllConfName();
	
	@Query(value = "SELECT confName from OrgBatchJobConf where batchJobConfStatusCd != 9 and confId <> :confId")
	List<String> getAllConfName(@Param("confId") String confId);

	List<OrgBatchJobConf> findBysourceTypeCdAndBatchJobConfStatusCdNotOrderByConfNameAsc(Integer soucetypeCd, int value);
	
	OrgBatchJobConf findByConfNameAndSourceTypeCd(String confName, int sourceTypeCd);
	
}
