package com.akila.batchjobservices.job.bean;

public enum JobEnum {

	SUBMITTED(1), SCHEDULED(2), QUEUED(3), RUNNING(4), FAILED(6), COMPLETED(7), COMPLETED_WITH_ERROR(8), NOT_SCHEDULED(
			0);

	private final int value;

	private JobEnum(int value) {
		this.value = value;
	}

	public int get() {
		return this.value;
	}

	public static String getNameByCode(int code) {
		for (JobEnum e : JobEnum.values()) {
			if (code == e.value)
				return e.name();
		}
		return null;
	}
}
