package com.akila.batchjobservices.file.bean;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.akila.batchjobservices.entity.OrgJobContentFile;

@Mapper(
	    componentModel = "spring"
	)
	public interface JobFileMapper {
	JobFileMapper INSTANCE = Mappers.getMapper(JobFileMapper.class);
	  ;
	  
	  @Mappings({})
	  List<JobFileResponse> orgJobContentFileToJobResponseList(List<OrgJobContentFile> orgJobContentFile);
	  
	}

