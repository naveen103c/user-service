package com.akila.batchjobservices.file;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpStatusCodeException;

import com.akila.AkilaService;
import com.akila.batchjobservices.entity.BaseOrgs;
import com.akila.batchjobservices.entity.OrgJobContentFile;
import com.akila.batchjobservices.file.bean.FileRequest;
import com.akila.batchjobservices.file.bean.FileResponse;
import com.akila.batchjobservices.file.bean.JobFileMapper;
import com.akila.batchjobservices.file.bean.JobFileResponse;
import com.akila.batchjobservices.repository.OrgJobContentFileRepository;
import com.akila.batchjobservices.services.BaseOrgService;
import com.akila.commons.storage.bean.StorageRequest;
import com.akila.commons.storage.bean.StorageResponse;
import com.akila.commons.storage.bean.UploadFilePartRequest;
import com.akila.commons.storage.service.StorageFactory;
import com.amazonaws.services.s3.model.PartETag;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class FileService extends AkilaService {
	private static final Logger logger = LogManager.getLogger(FileService.class);
	
	@Autowired
	StorageFactory S3StorageService;
	
	@Autowired
	private BaseOrgService baseOrgService;
	
	@Value("${batchjob.upload.file.tikaminetype:application/x-tika-msoffice,application/x-tika-ooxml,application/vnd.ms-excel,application/pdf,application/x-tika-msoffice,video/mp4,text/html,text/plain,video/quicktime,message/rfc822,image/jpeg,image/png,image/bmp,image/tiff}")
	private String tikaMineType;
	
	@Value("${batchjob.upload.file.extns:doc,docx,ppt,pptx,xls,xlsx,pdf,mp4,txt,html,msg,eml,xlsm,jpeg,jpg,png,bmp,tiff,tif}")
	private String fileExtns;
	
	@Autowired
	private OrgJobContentFileRepository orgJobContentFileRepository;

	@Autowired
	private JobFileMapper jobFileMapper;

	public void uploadFilesBatch(String orgId, String jobId, String fileName, InputStream in, String userId, String fileMetaData) throws HttpStatusCodeException, NullPointerException, Exception  {
		StorageRequest request = new StorageRequest();
		request.setOrgId(getStorageFolder());
		request.setContentType("ent-cont");
		request.setFormatType("original/" + jobId);
		request.setContentId(fileName);
		request.setContent(in);
		logger.info("uploadFilesBatch : fileName : "+fileName+", fileMetaData : "+fileMetaData);
		Map<String, String> userMap = new HashMap<String, String>();
		if(fileMetaData != null) {
			ObjectMapper mapper = new ObjectMapper();
			FileRequest fileRequest = mapper.readValue(fileMetaData, FileRequest.class);
			logger.info("uploadFilesBatch : fileName : "+fileName+", getModTs : "+fileRequest.getFileModTs());
			logger.info("uploadFilesBatch : fileName : "+fileName+", getCrtTs : "+fileRequest.getFileCrtTs());
			userMap.put("fileModTs",fileRequest.getFileModTs()+"");
			userMap.put("fileCrtTs",fileRequest.getFileCrtTs()+"");
			userMap.put("sourceFileKey",fileRequest.getSourceFileKey() == null ? null : new String(Base64.getUrlDecoder().decode(fileRequest.getSourceFileKey())));
			logger.info("uploadFilesBatch : fileName : "+fileName+", userMap : "+userMap);
		}
		
		userMap.put("uploadBy",getUserId());
		S3StorageService.putObject(request, userMap);
		
	}
	

	public List<FileResponse> getAllFiles(String orgId, String jobId) {
		StorageRequest request = new StorageRequest();
		request.setOrgId(getStorageFolder());
		request.setContentType("ent-cont");
		request.setFormatType("original/" + jobId);
		List<String> list = S3StorageService.getAllFileNamesWithSizeInS3Bucket(request);
		List<FileResponse> resultList = new ArrayList<FileResponse>();
		for (String string : list) {
			String[] data = string.split(":");
			FileResponse res = new FileResponse();
			res.setFileName(data[0].trim());
			res.setFileSize(Long.parseLong(data[1].trim()));
			resultList.add(res);
		}
		return resultList;
	}
	
	public List<JobFileResponse> getJobAllFiles(String jobId) {
		List<OrgJobContentFile> orgJobContentFileList = orgJobContentFileRepository.findByJobId(jobId);
		return jobFileMapper.orgJobContentFileToJobResponseList(orgJobContentFileList);		
	}


	public void deleteFiles(String orgId, String jobId, String fileName) {
		String[] files = fileName.split(",");
		StorageRequest request;
		for (int i = 0; i < files.length; i++) {
			request = new StorageRequest();
			request.setOrgId(getStorageFolder());
			request.setContentType("ent-cont");
			request.setFormatType("original/" + jobId);
			request.setContentId(files[0]);

			S3StorageService.deleteObject(request);
		}

	}
	
	public String InitiateMultipartFileUpload(String orgId, String jobId, String fileName) {
		UploadFilePartRequest request = new UploadFilePartRequest();
		
		request.setOrgId(getStorageFolder());
		request.setContentType("ent-cont");
		request.setFormatType("original");
		request.setJobId(jobId);
		request.setContentId(fileName);
		
		return S3StorageService.InitiateMultipartFileUpload(request);
	}
	
	public PartETag uploadFilePart(String orgId, String jobId, String fileName, InputStream in, String userId, String uploadId, int partNum) {
		UploadFilePartRequest request = new UploadFilePartRequest();
		
		request.setOrgId(getStorageFolder());
		request.setContentType("ent-cont");
		request.setFormatType("original");
		request.setJobId(jobId);
		request.setContentId(fileName);
		request.setUploadId(uploadId);
		request.setPartNumber(partNum);
		try {
			request.setPartSize(in.available());
		} catch (IOException e) {
			logger.error("uploadFilePart : Error while getting part size : "+e.getMessage());
		}
		request.setInput(in);
		
		return S3StorageService.uploadFilePart(request);
	}
	
	public String completeFilePartUpload(String orgId, String jobId, String fileName, List<PartETag> partETags, String uploadId){
		
		UploadFilePartRequest request = new UploadFilePartRequest();
		
		request.setOrgId(getStorageFolder());
		request.setContentType("ent-cont");
		request.setFormatType("original");
		request.setJobId(jobId);
		request.setContentId(fileName);
		request.setUploadId(uploadId);
		request.setPartETags(partETags);
		
		return S3StorageService.completeFilePartUpload(request);
		
	}
	
	private String getStorageFolder(){
		BaseOrgs org = baseOrgService.getBaseOrgs(getOrgId());
		if(org != null){
			if(org.getStorageFolderNm() != null && org.getStorageFolderNm().trim().length() > 0){
				logger.info("getStorageFolder : StorageFolder : "+org.getStorageFolderNm()+", orgId : "+getOrgId());
				return org.getStorageFolderNm();
			} 
		}
		logger.info("getStorageFolder : StorageFolder : No strorage folder for org, orgId : "+getOrgId());
		return null;
	}
	
	public StorageResponse getVideoInputStream(String fileName){
		StorageRequest request = new StorageRequest();
		request.setOrgId("bu-whrs");
		request.setContentType("static-content");
		request.setFormatType("videos");
		request.setContentId(fileName);
		StorageResponse res = S3StorageService.getObject(request);
		return res;
		
		
	}
	
	public List<String> getExtn() {
		List<String> list = Arrays.asList(fileExtns.split(","));
		logger.info("getExtn : Extn : "+list);	
		return list;
	}
	
	public List<String> getMineType() {
		List<String> list = Arrays.asList(tikaMineType.split(","));
		logger.info("getMineType : Tika Mine Types : "+list);	
		return list;
	}
}
