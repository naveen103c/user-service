package com.akila.batchjobservices.job.bean;

import java.util.ArrayList;
import java.util.List;

import com.akila.AkilaRequest;

public class BatchJobRequest  extends AkilaRequest{
	
	private List<FileMetaDataJsonList> fileMetaDataJsonList = new ArrayList<FileMetaDataJsonList>();
    private String parentContentId;
    private String tags;
    private String rootContentId;
    private String rootContentType;
    private String childContentType;
    
    public List<FileMetaDataJsonList> getFileMetaDataJsonList() {
        return fileMetaDataJsonList;
    }
    public void setFileMetaDataJsonList(List<FileMetaDataJsonList> fileMetaDataJsonList) {
        this.fileMetaDataJsonList = fileMetaDataJsonList;
    }
    public String getParentContentId() {
        return parentContentId;
    }
    public void setParentContentId(String parentContentId) {
        this.parentContentId = parentContentId;
    }
    public String getTags() {
        return tags;
    }
    public void setTags(String tags) {
        this.tags = tags;
    }
	public String getRootContentId() {
		return rootContentId;
	}
	public void setRootContentId(String rootContentId) {
		this.rootContentId = rootContentId;
	}
	public String getRootContentType() {
		return rootContentType;
	}
	public void setRootContentType(String rootContentType) {
		this.rootContentType = rootContentType;
	}
	public String getChildContentType() {
		return childContentType;
	}
	public void setChildContentType(String childContentType) {
		this.childContentType = childContentType;
	}
}
