package com.akila.batchjobservices.job.bean;

import java.util.ArrayList;
import java.util.List;

public class GetJob {
	String jobId;
	String confId;
	int jobStatusId;
	String jobStatus;
	String jobStartTime;
	String jobLastUpdatedTime;
	JobSummary jobSummary;
	List<FileDetail> fileDetails;

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getConfId() {
		return confId;
	}

	public void setConfId(String confId) {
		this.confId = confId;
	}

	public int getJobStatusId() {
		return jobStatusId;
	}

	public void setJobStatusId(int jobStatusId) {
		this.jobStatusId = jobStatusId;
	}

	public String getJobStatus() {
		return jobStatus;
	}

	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}

	public String getJobStartTime() {
		return jobStartTime;
	}

	public void setJobStartTime(String jobStartTime) {
		this.jobStartTime = jobStartTime;
	}

	public String getJobLastUpdatedTime() {
		return jobLastUpdatedTime;
	}

	public void setJobLastUpdatedTime(String jobLastUpdatedTime) {
		this.jobLastUpdatedTime = jobLastUpdatedTime;
	}

	public JobSummary getJobSummary() {
		return jobSummary;
	}

	public void setJobSummary(JobSummary jobSummary) {
		this.jobSummary = jobSummary;
	}

	public List<FileDetail> getFileDetails() {
		if(fileDetails == null) {
			fileDetails = new ArrayList<FileDetail>();
		}
		return fileDetails;
	}

	public void setFileDetails(List<FileDetail> fileDetails) {
		this.fileDetails = fileDetails;
	}

}
