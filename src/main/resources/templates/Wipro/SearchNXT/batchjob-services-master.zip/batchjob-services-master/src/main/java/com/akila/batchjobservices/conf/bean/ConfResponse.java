package com.akila.batchjobservices.conf.bean;

import java.util.ArrayList;
import java.util.List;

import com.akila.AkilaResponse;

public class ConfResponse extends AkilaResponse {
	String confId;
	String confName;
	Integer sourceExtractionTypeCd;
	String sourceExtractionType;
	Integer sourceTypeCd;
	String sourceTypeName;
	String confStatus;
	String confJobStatus;
	List<Object> sourceAllowedUserGroupList = new ArrayList<Object>();
	String sourceDescription;
	List<Object> sourceTagIdList = new ArrayList<Object>();
	Schedule sourceScheduleJson;
	String crtBy;
	String jobNextRunDate;
	List<Object> sourceTypeFields = new ArrayList<Object>();
	List<Module> filter = new ArrayList<Module>();

	public String getConfId() {
		return confId;
	}

	public void setConfId(String confId) {
		this.confId = confId;
	}

	public String getConfStatus() {
		return confStatus;
	}

	public void setConfStatus(String confStatus) {
		this.confStatus = confStatus;
	}

	public String getConfJobStatus() {
		return confJobStatus;
	}

	public void setConfJobStatus(String confJobStatus) {
		this.confJobStatus = confJobStatus;
	}

	public String getJobNextRunDate() {
		return jobNextRunDate;
	}

	public void setJobNextRunDate(String jobNextRunDate) {
		this.jobNextRunDate = jobNextRunDate;
	}

	public String getSourceExtractionType() {
		return sourceExtractionType;
	}

	public void setSourceExtractionType(String sourceExtractionType) {
		this.sourceExtractionType = sourceExtractionType;
	}

	public String getConfName() {
		return confName;
	}

	public void setConfName(String confName) {
		this.confName = confName;
	}

	public Integer getSourceExtractionTypeCd() {
		return sourceExtractionTypeCd;
	}

	public void setSourceExtractionTypeCd(Integer sourceExtractionTypeCd) {
		this.sourceExtractionTypeCd = sourceExtractionTypeCd;
	}

	public Integer getSourceTypeCd() {
		return sourceTypeCd;
	}

	public void setSourceTypeCd(Integer sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}

	public List<Object> getSourceAllowedUserGroupList() {
		return sourceAllowedUserGroupList;
	}

	public void setSourceAllowedUserGroupList(List<Object> sourceAllowedUserGroupList) {
		if (sourceAllowedUserGroupList != null) {

		}
		this.sourceAllowedUserGroupList = sourceAllowedUserGroupList;

	}

	public String getSourceDescription() {
		return sourceDescription;
	}

	public void setSourceDescription(String sourceDescription) {
		this.sourceDescription = sourceDescription;
	}

	public List<Object> getSourceTagIdList() {
		return sourceTagIdList;
	}

	public void setSourceTagIdList(List<Object> sourceTagIdList) {
		if (sourceTagIdList != null) {
			this.sourceTagIdList = sourceTagIdList;
		}
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public List<Object> getSourceTypeFields() {
		return sourceTypeFields;
	}

	public void setSourceTypeFields(List<Object> sourceTypeFields) {
		if (sourceTypeFields != null) {
			this.sourceTypeFields = sourceTypeFields;
		}
	}

	public List<Module> getFilter() {
		return filter;
	}

	public void setFilter(List<Module> ConfFilterList) {
		if (ConfFilterList != null) {
			this.filter = ConfFilterList;
		}
	}

	public String getSourceTypeName() {
		return sourceTypeName;
	}

	public void setSourceTypeName(String sourceTypeName) {
		this.sourceTypeName = sourceTypeName;
	}

	public Schedule getSourceScheduleJson() {
		return sourceScheduleJson;
	}

	public void setSourceScheduleJson(Schedule sourceScheduleJson) {
		if (sourceScheduleJson != null) {
			this.sourceScheduleJson = sourceScheduleJson;
		} else {
			this.sourceScheduleJson = new Schedule();
		}

	}

}
