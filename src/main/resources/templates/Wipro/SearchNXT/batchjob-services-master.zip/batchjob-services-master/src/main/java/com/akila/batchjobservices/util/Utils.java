package com.akila.batchjobservices.util;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.akila.batchjobservices.conf.bean.SourceTypeField;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Utils {
	private static final Logger logger = LogManager.getLogger(Utils.class);
	public static String getDate(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		if (date != null) {
			return sdf.format(date);
		} else {
			return "";
		}
	}

	public static String getValue(String str) {
		if (str != null) {
			return str;
		} else {
			return "";
		}
	}
	
	public static Object getValue(Object str) {
		if (str != null) {
			return str;
		} else {
			return "";
		}
	}

	public static String getString(Object obj) {
		String jobSummaryJson = "";
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			jobSummaryJson = objectMapper.writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			logger.error("Utils.getString: Error while getting string : "+e.getMessage(),e);
		}

		return jobSummaryJson;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static Object getObject(String json, Class cls) {
		Object obj = null;
		ObjectMapper objectMapper = new ObjectMapper();
		if(json == null || json.trim().length() == 0){
			return null;
		}
		try {
			obj = objectMapper.readValue(json, cls);
		} catch (JsonProcessingException e) {
			logger.error("Utils.getObject: Error while getting Object : "+e.getMessage(),e);
		}

		return obj;
	}
	
	public static List<Object> getObjectAsArray(String json) {
		List<Object> obj = null;
		ObjectMapper objectMapper = new ObjectMapper();
		if(json == null || json.trim().length() == 0){
			return null;
		}
		try {
			obj = Arrays.asList(objectMapper.readValue(json, String[].class));
		} catch (JsonProcessingException e) {
			logger.error("Utils.getObjectAsArray: Error while getObjectAsArray : "+e.getMessage(),e);
		}

		return obj;
	}
	
	public static List<Object> getSourceTypeFieldstAsArray(String json) {
		List<Object> obj = null;
		ObjectMapper objectMapper = new ObjectMapper();
		if(json == null || json.trim().length() == 0){
			return null;
		}
		try {
			obj = Arrays.asList(objectMapper.readValue(json, SourceTypeField[].class));
		} catch (JsonProcessingException e) {
			logger.error("Utils.getSourceTypeFieldstAsArray: Error while getSourceTypeFieldstAsArray : "+e.getMessage(),e);
		}

		return obj;
	}

	public static boolean isUUID(String string) {
		try {
			UUID.fromString(string);
			return true;
		} catch (IllegalArgumentException ex) {
			return false;
		} catch (Exception ex) {
			return false;
		}
	}
}
