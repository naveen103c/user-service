package com.akila.batchjobservices.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.akila.batchjobservices.conf.bean.SourceTypeField;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "base_source_type ", schema = "base")
public class BaseSourceType {

	@Id
	@Column(name = "source_type_id ")
	String sourceTypeId ;
	
	@Column(name = "source_type_cd")
	Integer sourceTypeCd;
	
	@Column(name = "source_type_name")
	String sourceTypeName;
	
	@Column(name = "source_type_desc")
	String sourceTypeDesc;
	
	@JsonIgnore
	@Column(name = "is_active")
	Boolean isActive;
	
	@JsonIgnore
	@Column(name = "source_type_fields_json")
	String sourceTypeFieldsJson;
	
	@Transient
	List<Object> sourceTypeFields;

	public String getSourceTypeId() {
		return sourceTypeId;
	}

	public void setSourceTypeId(String sourceTypeId) {
		this.sourceTypeId = sourceTypeId;
	}

	public Integer getSourceTypeCd() {
		return sourceTypeCd;
	}

	public void setSourceTypeCd(Integer sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}

	public String getSourceTypeName() {
		return sourceTypeName;
	}

	public void setSourceTypeName(String sourceTypeName) {
		this.sourceTypeName = sourceTypeName;
	}

	public String getSourceTypeDesc() {
		return sourceTypeDesc;
	}

	public void setSourceTypeDesc(String sourceTypeDesc) {
		this.sourceTypeDesc = sourceTypeDesc;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public String getSourceTypeFieldsJson() {
		return sourceTypeFieldsJson;
	}

	public void setSourceTypeFieldsJson(String sourceTypeFieldsJson) {
		this.sourceTypeFieldsJson = sourceTypeFieldsJson;
	}

	public List<Object> getSourceTypeFields() {
		return sourceTypeFields;
	}

	public void setSourceTypeFields(List<Object> sourceTypeFields) {
		this.sourceTypeFields = sourceTypeFields;
	}
	
}
