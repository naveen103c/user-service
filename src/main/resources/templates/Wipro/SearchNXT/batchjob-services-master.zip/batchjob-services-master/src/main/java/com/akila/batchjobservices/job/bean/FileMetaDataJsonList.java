package com.akila.batchjobservices.job.bean;

public class FileMetaDataJsonList {
	
    private String contentId;
    private String fileName;
    
    public String getContentId() {
        return contentId;
    }
    public void setContentId(String contentId) {
        this.contentId = contentId;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}