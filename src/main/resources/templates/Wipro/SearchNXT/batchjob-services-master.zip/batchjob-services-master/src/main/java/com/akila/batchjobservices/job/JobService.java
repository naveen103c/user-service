package com.akila.batchjobservices.job;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestParam;

import com.akila.AkilaService;
import com.akila.batchjobservices.conf.ConfService;
import com.akila.batchjobservices.conf.bean.BatchJobConfEnum;
import com.akila.batchjobservices.conf.bean.BatchJobExecEnum;
import com.akila.batchjobservices.conf.bean.ConfResponse;
import com.akila.batchjobservices.entity.BaseOrgs;
import com.akila.batchjobservices.entity.OrgBatchJobConf;
import com.akila.batchjobservices.entity.OrgBatchJobRuntime;
import com.akila.batchjobservices.file.FileService;
import com.akila.batchjobservices.file.bean.FileResponse;
import com.akila.batchjobservices.job.bean.BatchJobRequest;
import com.akila.batchjobservices.job.bean.FileDetail;
import com.akila.batchjobservices.job.bean.GetJob;
import com.akila.batchjobservices.job.bean.JobEnum;
import com.akila.batchjobservices.job.bean.JobSummary;
import com.akila.batchjobservices.repository.OrgBatchJobConfRepository;
import com.akila.batchjobservices.repository.OrgBatchJobRuntimeRepository;
import com.akila.batchjobservices.services.BaseOrgService;
import com.akila.batchjobservices.util.Constants;
import com.akila.batchjobservices.util.Utils;
import com.akila.commons.storage.bean.StorageRequest;
import com.akila.commons.storage.service.StorageFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class JobService extends AkilaService {

	@Autowired
	private OrgBatchJobRuntimeRepository orgBatchJobRuntimeRepository;
	
	@Autowired
	private OrgBatchJobConfRepository orgBatchJobConfRepository;
	
	@Autowired
	private ConfService confService;
	
	@Autowired
	FileService fileService;
	
	@Autowired
	private BaseOrgService baseOrgService;
	
	@Autowired
	StorageFactory s3StorageService;
	
	@Value("${file.size.mb:1}")
	int fileSize;

	private static Logger logger = LogManager.getLogger(JobService.class);
	
	public String createJob(String confId, String userId) {

		OrgBatchJobRuntime orgBatchJobRuntime = orgBatchJobRuntimeRepository.findByConfIdAndJobStatusCd(confId, 0);
		if (orgBatchJobRuntime == null) {
			orgBatchJobRuntime = new OrgBatchJobRuntime();
			String jobId = UUID.randomUUID().toString();
			orgBatchJobRuntime.setConfId(confId);
			orgBatchJobRuntime.setJobId(jobId);
			orgBatchJobRuntime.setJobStatusCd(0);
			orgBatchJobRuntime.setCrtBy(getUserId());
			orgBatchJobRuntime.setCrtTs(new Date());
			orgBatchJobRuntime.setModBy(getUserId());
			orgBatchJobRuntime.setModTs(new Date());
			orgBatchJobRuntime.setJobPriority(1);
			orgBatchJobRuntime = orgBatchJobRuntimeRepository.save(orgBatchJobRuntime);
		}

		return orgBatchJobRuntime.getJobId();
	}

	public String createJob(String confId, BatchJobRequest batchJobRequest) throws JsonProcessingException {

		OrgBatchJobRuntime orgBatchJobRuntime = orgBatchJobRuntimeRepository.findByConfIdAndJobStatusCd(confId, 0);
		if (orgBatchJobRuntime == null) {
			orgBatchJobRuntime = new OrgBatchJobRuntime();
			String jobId = UUID.randomUUID().toString();
			orgBatchJobRuntime.setConfId(confId);
			orgBatchJobRuntime.setJobId(jobId);
			orgBatchJobRuntime.setJobStatusCd(0);
			orgBatchJobRuntime.setCrtBy(getUserId());
			orgBatchJobRuntime.setCrtTs(new Date());
			orgBatchJobRuntime.setModBy(getUserId());
			orgBatchJobRuntime.setModTs(new Date());
			orgBatchJobRuntime.setJobPriority(1);
			ObjectMapper mapper = new ObjectMapper();
			orgBatchJobRuntime.setJobMetadataJson(mapper.writeValueAsString(batchJobRequest));
			orgBatchJobRuntime = orgBatchJobRuntimeRepository.save(orgBatchJobRuntime);
		}

		return orgBatchJobRuntime.getJobId();
	}
	
	@Transactional(isolation = Isolation.SERIALIZABLE)
	public String runBatch(@RequestParam String confId, @RequestParam String jobId, String userId) {

		if (confId != null && jobId == null) {
			jobId = createJob(confId, userId);
		}

		if (jobId != null) {
			OrgBatchJobRuntime orgBatchJobRuntime = orgBatchJobRuntimeRepository.findByJobId(jobId);
			OrgBatchJobConf conf = orgBatchJobConfRepository.findById(orgBatchJobRuntime.getConfId()).orElse(null);
			if (conf.getBatchJobConfStatusCd() == BatchJobConfEnum.REQUESTED.getValue()
					||conf.getBatchJobConfStatusCd() == BatchJobConfEnum.SCHEDULED.getValue()) {

				orgBatchJobRuntime.setJobStatusCd(BatchJobExecEnum.SUBMITTED.getValue());
				orgBatchJobRuntime.setModBy(getUserId());
				orgBatchJobRuntime.setModTs(new Date());
				orgBatchJobRuntime.setLastJobUpdatedTs(new Date());
				conf.setBatchJobConfStatusCd(BatchJobConfEnum.SCHEDULED.getValue());
				conf.setConfJobExecStatusCd(BatchJobExecEnum.SUBMITTED.getValue());
				conf.setModTs(new Date());
				orgBatchJobRuntimeRepository.save(orgBatchJobRuntime);
				orgBatchJobConfRepository.save(conf);
				return jobId;
			}
		}

		return null;
	}

	public boolean validateJob(String confId, String jobId) {

		if(confId == null || confId.equalsIgnoreCase("")) {
			OrgBatchJobRuntime orgBatchJobRuntime = orgBatchJobRuntimeRepository.findByJobId(jobId);
			confId = orgBatchJobRuntime.getConfId();
			}
		ConfResponse conf = confService.getConf(confId);
		if (conf == null) {
			return false;
		} else if (conf.getSourceTypeCd() == 4) {

			if (jobId == null) {
				OrgBatchJobRuntime orgBatchJobRuntime = orgBatchJobRuntimeRepository.findByConfIdAndJobStatusCd(confId,
						0);
				if(orgBatchJobRuntime != null ) {
					jobId = orgBatchJobRuntime.getJobId();
				}
			}

			if (jobId != null) {
				List<FileResponse> fileResponseList = fileService.getAllFiles(super.getOrgId(), jobId);
				if (fileResponseList !=null && fileResponseList.size() > 0) {
					return true;
				}
			}
			return false;
		} else {
			return true;
		}

	}

	
	public List<GetJob> getAllJobs(String confId, Integer sourcetypes, Integer jobStatusCd) {
		List<GetJob> jobResult = new ArrayList<GetJob>();
		List<OrgBatchJobRuntime> orgBatchJobRuntime = new ArrayList<>();
		OrgBatchJobRuntime batchJobRuntime ;
		List<FileDetail> fileDetails = new ArrayList<>();
		if(confId != null && jobStatusCd != null) {
			batchJobRuntime = orgBatchJobRuntimeRepository.findByConfIdAndJobStatusCd(confId, 0);
			if(batchJobRuntime != null) {
				orgBatchJobRuntime.add(batchJobRuntime);
				fileDetails = getAllFiles(getOrgId(), batchJobRuntime.getJobId());
			}
		}
		else if(sourcetypes != null){
			orgBatchJobRuntime = orgBatchJobRuntimeRepository.findByOrgBatchJobConfs_SourceTypeCdOrderByLastJobUpdatedTsDesc(sourcetypes);
		}else if(confId != null){
			orgBatchJobRuntime = orgBatchJobRuntimeRepository.findByConfIdOrderByLastJobUpdatedTsDesc(confId);
		} else {
			orgBatchJobRuntime = orgBatchJobRuntimeRepository.findByOrgBatchJobConfsSourceTypeCdNotOrderByLastJobUpdatedTsDesc(Constants.ATTACHMENT_SOURCE_TYPE, PageRequest.of(0,100));
		}
		
		
		for (OrgBatchJobRuntime jobRuntime : orgBatchJobRuntime) {
			GetJob job = new GetJob();
			job.setJobId(jobRuntime.getJobId());
			job.setConfId(jobRuntime.getConfId());
			job.setJobLastUpdatedTime(Utils.getDate(jobRuntime.getLastJobUpdatedTs()));
			job.setJobStartTime(Utils.getDate(jobRuntime.getJobStartTs()));
			job.setJobStatus(JobEnum.getNameByCode(jobRuntime.getJobStatusCd()));
			job.setJobStatusId(jobRuntime.getJobStatusCd());
			Object obj = Utils.getObject(jobRuntime.getJobSummaryJson(), JobSummary.class);
			if (obj != null) {
				job.setJobSummary((JobSummary) obj);
			} else {
				job.setJobSummary(new JobSummary());
			}
			if(fileDetails.size() > 0) {
				job.setFileDetails(fileDetails);
			}

			jobResult.add(job);
		}
		return jobResult;
	}

	public GetJob getJob(String id) {
		OrgBatchJobRuntime jobRuntime = orgBatchJobRuntimeRepository.findById(id).orElse(null);
		GetJob job = new GetJob();
		job.setJobId(jobRuntime.getJobId());
		job.setConfId(jobRuntime.getConfId());
		job.setJobLastUpdatedTime(Utils.getDate(jobRuntime.getLastJobUpdatedTs()));
		job.setJobStartTime(Utils.getDate(jobRuntime.getJobStartTs()));
		job.setJobStatus(JobEnum.getNameByCode(jobRuntime.getJobStatusCd()));
		job.setJobStatusId(jobRuntime.getJobStatusCd());
		Object obj = Utils.getObject(jobRuntime.getJobSummaryJson(), JobSummary.class);
		if (obj != null) {
			job.setJobSummary((JobSummary) obj);
		} else {
			job.setJobSummary(new JobSummary());
		}

		return job;
	}

	public String terminateJob(String id) {
		return null;
	}
	
	public List<FileDetail> getAllFiles(String orgId, String jobId) {
		logger.info("JobService.getAllFiles() starting getting all the files assosiated with JobId");
		StorageRequest request = new StorageRequest();
		request.setOrgId(getStorageFolder());
		request.setContentType("ent-cont");
		request.setFormatType("original/" + jobId);
		List<String> list = s3StorageService.getAllFileNamesWithSizeInS3Bucket(request);
		List<FileDetail> fileDetails = new ArrayList<FileDetail>();
		if (list != null && list.size() > 0) {
			for (String string : list) {
				String[] data = string.split(":");
				FileDetail fileDetail = new FileDetail();
				fileDetail.setFileName(data[0].trim());
				double kilobytes = ((double) Long.parseLong(data[1].trim()) / 1024);
				double megabytes = ((double) kilobytes / 1024);
				if (megabytes >= fileSize) {
					fileDetail.setFileSize(String.format("%.2f", megabytes) + " MB");
				} else {
					fileDetail.setFileSize(String.format("%.2f", (double) kilobytes) + " KB");
				}
				fileDetail.setFileType(StringUtils.getFilenameExtension(fileDetail.getFileName()));
				fileDetails.add(fileDetail);
			}
		}
		return fileDetails;
	}
	
	private String getStorageFolder(){
		BaseOrgs org = baseOrgService.getBaseOrgs(getOrgId());
		if(org != null){
			if(org.getStorageFolderNm() != null && org.getStorageFolderNm().trim().length() > 0){
				logger.info("JobService:getStorageFolder() : StorageFolder : "+org.getStorageFolderNm()+", orgId : "+getOrgId());
				return org.getStorageFolderNm();
			} 
		}
		logger.info("JobService:getStorageFolder() : StorageFolder : No strorage folder for org, orgId : "+getOrgId());
		return null;
	}
}
