package com.akila.batchjobservices.file.storage.service;

import java.util.List;
import java.util.Map;

import com.akila.batchjobservices.file.storage.bean.StorageRequest;
import com.akila.batchjobservices.file.storage.bean.StorageResponse;

public final class StorageFactory implements IStorageService
{

	@Override
	public StorageResponse getObject(StorageRequest storageRequest) throws Exception{
		return getStorageService(storageRequest.getOrgId()).getObject(storageRequest);
	}

	@Override
	public StorageResponse putObject(StorageRequest storageRequest, Map<String, String> fileDataData) {
		return getStorageService(storageRequest.getOrgId()).putObject(storageRequest, fileDataData);
	}

	@Override
	public void deleteObject(StorageRequest storageRequest) {
		getStorageService(storageRequest.getOrgId()).deleteObject(storageRequest);
	}

	@Override
	public void deleteOrg(String orgId) {
		getStorageService(orgId).deleteOrg(orgId);
	}
	
	private IStorageService getStorageService(String orgId)
	{
		return new S3StorageService();
	}

	@Override
	public List<String> getAllFileNamesInS3Bucket(StorageRequest storageRequest) {
		return getStorageService(storageRequest.getOrgId()).getAllFileNamesInS3Bucket(storageRequest);
	}

	@Override
	public List<String> getAllFileNamesWithSizeInS3Bucket(StorageRequest storageRequest) {
		return getStorageService(storageRequest.getOrgId()).getAllFileNamesWithSizeInS3Bucket(storageRequest);
	}
	

}
