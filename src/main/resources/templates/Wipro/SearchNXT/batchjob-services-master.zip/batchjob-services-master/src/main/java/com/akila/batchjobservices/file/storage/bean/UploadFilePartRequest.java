package com.akila.batchjobservices.file.storage.bean;

import java.io.InputStream;
import java.util.List;

import com.amazonaws.services.s3.model.PartETag;

public class UploadFilePartRequest {

	private String orgId; /// wipro/
	private String contentType; // wiki/query/ent-cont
	private String formatType; // stripped/ origional
	private String contentId;
	private String jobId;
	private String fileFormat;
	private InputStream input;
	private int partNumber;
	private int partSize;
	private String uploadId;
	private List<PartETag> partETags;

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getFormatType() {
		return formatType;
	}

	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public InputStream getInput() {
		return input;
	}

	public void setInput(InputStream input) {
		this.input = input;
	}

	public int getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(int partNumber) {
		this.partNumber = partNumber;
	}

	public String getUploadId() {
		return uploadId;
	}

	public void setUploadId(String uploadId) {
		this.uploadId = uploadId;
	}

	public List<PartETag> getPartETags() {
		return partETags;
	}

	public void setPartETags(List<PartETag> partETags) {
		this.partETags = partETags;
	}

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public int getPartSize() {
		return partSize;
	}

	public void setPartSize(int partSize) {
		this.partSize = partSize;
	}

}
