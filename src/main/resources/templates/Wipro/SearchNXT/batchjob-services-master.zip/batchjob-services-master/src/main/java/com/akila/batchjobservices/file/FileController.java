package com.akila.batchjobservices.file;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tika.Tika;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

import com.akila.AkilaController;
import com.akila.batchjobservices.conf.bean.ResponseStatus;
import com.akila.batchjobservices.file.bean.FileResponse;
import com.akila.batchjobservices.file.bean.JobFileResponse;
import com.akila.batchjobservices.util.Utils;
import com.akila.commons.storage.bean.StorageResponse;
import com.amazonaws.services.s3.model.PartETag;

@RestController
public class FileController extends AkilaController {
	private static final Logger logger = LogManager.getLogger(FileController.class);
	
	private static Map<String, List<PartETag>> partETagMap = new HashMap<String, List<PartETag>>();
	private static Map<String, String> jobIdUniqueIdMap = new HashMap<String, String>();
	
	@Autowired
	private FileService fileService;
	
	@Autowired
	private FileVirusScanService fileVirusScanService;
	
	@Value("${virus.scan.enable:false}")
	private boolean odsEnable;

	String defaultUserId = "a9daaf8e-0a5b-46c2-b281-650ab5dda384";
	String defaultOrgId = "84a7c96e-089c-11eb-adc1-0242ac120002";
	
	@Value("${xlsx.file.limit.mb:10}")
	int xlsxFileLimit;

	@PostMapping(path = "/files")
	public ResponseEntity<ResponseStatus> uploadFilesBatch(@RequestParam String jobId,
			@RequestParam("file") MultipartFile file, @RequestParam(required = false) String fileMetdata) throws IOException, Exception  {
		String orgId = defaultOrgId;
		logger.info("uploadFilesBatch : requested Job id : "+jobId+", orgId : "+orgId+", File Name : "+file.getOriginalFilename());
		if (getOrgId() != null && getOrgId().trim().length() > 0) {
			orgId = getOrgId();
		}
		if(!Utils.isUUID(jobId)){
			ResponseStatus status = new ResponseStatus(0, jobId, "Invalid Job Id", 115);
			logger.error("uploadFilesBatch : Job Id is NOT valid, requested Job id : "+jobId+", File Name : "+file.getOriginalFilename());
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		String type = null;
		String extn = null;
		try {
			if(odsEnable && !fileVirusScanService.scanFile(file)) {
				ResponseStatus status = new ResponseStatus(0, jobId, "File contains malware", 120);
				logger.error("uploadFilesBatch : File contains malware, File Name : "+file.getOriginalFilename());
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
			Tika tika = new Tika();
			type = tika.detect(file.getInputStream());
			String fileName = file.getOriginalFilename();
			extn = fileName.substring(fileName.lastIndexOf(".")+1);
			logger.info("uploadFilesBatch : requested Job id : "+jobId+", Name : "+file.getOriginalFilename()+", File Type : "+type+", Extn : "+extn);
		} catch (IOException e) {
			ResponseStatus status = new ResponseStatus(0, jobId, "File format not supported", 116);
			logger.error("uploadFilesBatch : Invalid file, requested Job id : "+jobId+", File Name : "+file.getOriginalFilename(),e);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ResponseStatus status = new ResponseStatus(0, jobId, "Error while validating file", 116);
			logger.error("uploadFilesBatch : Error while validating file : "+jobId+", File Name : "+file.getOriginalFilename(),e);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(type != null && fileService.getMineType().contains(type.toLowerCase())) {
			if(extn != null && fileService.getExtn().contains(extn.toLowerCase()) && file.getOriginalFilename().toLowerCase().indexOf(".exe.") < 0) {
				if(extn.equalsIgnoreCase("XLSX") && file.getSize() / 1048576> xlsxFileLimit) {
					logger.info("xlsx file size is > 10 MB");
					ResponseStatus status = new ResponseStatus(0, jobId, "Max File Upload Size Is 10 MB", 0);
					return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
				}
				fileService.uploadFilesBatch(orgId, jobId, file.getOriginalFilename(), file.getInputStream(),defaultUserId, fileMetdata);
				ResponseStatus status = new ResponseStatus(1, file.getOriginalFilename(), "File uploaded Successfuly", 0);
				logger.info("uploadFilesBatch : Filed successfully uploaded into S3, requested Job id : "+jobId+", File Name : "+file.getOriginalFilename());
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
			} else {
				ResponseStatus status = new ResponseStatus(0, jobId, "File extn not supported", 116);
				logger.error("uploadFilesBatch : Invalid File Extn, requested Job id :: "+jobId+", File Name : "+file.getOriginalFilename()+", File Type : "+type+", Extn : "+extn);
				return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
			}
			
		} else {
			ResponseStatus status = new ResponseStatus(0, jobId, "File format not supported", 116);
			logger.error("uploadFilesBatch : Invalid file, requested Job id : "+jobId+", File Name : "+file.getOriginalFilename()+", File Type : "+type+", Extn : "+extn);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@PostMapping(path = "/filespart")
	public ResponseEntity<ResponseStatus> uploadFilesPart(@RequestParam String jobId,@RequestParam int partNum, @RequestParam boolean isFirst , @RequestParam boolean isLast,
			@RequestParam("file") MultipartFile file) throws Exception {
		String orgId = defaultOrgId;
		logger.info("uploadFilesPart : requested Job id : "+jobId+", orgId : "+orgId+", File Name : "+file.getOriginalFilename()+", partNum : "+partNum+", isLast : "+isLast);
		if (getOrgId() != null && getOrgId().trim().length() > 0) {
			orgId = getOrgId();
		}
		if(!Utils.isUUID(jobId)){
			ResponseStatus status = new ResponseStatus(0, jobId, "Invalid Job Id", 115);
			logger.error("uploadFilesPart : Job Id is NOT valid, requested Job id : "+jobId+", File Name : "+file.getOriginalFilename());
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		String uploadId = null;
		String uniqueKey = jobId+"_"+file.getOriginalFilename();
		
		if(isFirst) {
			// Remove file from map if it uploaded before
			jobIdUniqueIdMap.remove(uniqueKey);
			partETagMap.remove(uniqueKey);
		}
		
		if(jobIdUniqueIdMap.containsKey(uniqueKey)){
			uploadId = jobIdUniqueIdMap.get(uniqueKey);
		} else {
			uploadId = fileService.InitiateMultipartFileUpload(orgId, jobId, file.getOriginalFilename());
			jobIdUniqueIdMap.put(uniqueKey, uploadId);
		}
		
		if(uploadId != null){
			PartETag tag = fileService.uploadFilePart(orgId, jobId, file.getOriginalFilename(), file.getInputStream(), defaultUserId, uploadId, partNum);
			if(partETagMap.containsKey(uniqueKey)){
				partETagMap.get(uniqueKey).add(tag);
			}else {
				List<PartETag> list= new ArrayList<PartETag>();
				list.add(tag);
				partETagMap.put(uniqueKey, list);
			}
			logger.info("uploadFilesPart : File Part successfully uploaded into S3, requested Job id : "+jobId+", File Name : "+file.getOriginalFilename()+",uploadId : "+uploadId);
		}else {
			ResponseStatus status = new ResponseStatus(0, jobId, "Internal Error with Uploading. Try again", 116);
			logger.error("uploadFilesPart : Internal Error with Uploading. Try again Job id : "+jobId+", File Name : "+file.getOriginalFilename());
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		
		if(isLast) {
			String versionNum = fileService.completeFilePartUpload(orgId, jobId, file.getOriginalFilename(),partETagMap.get(uniqueKey), uploadId);
			jobIdUniqueIdMap.remove(uniqueKey);
			partETagMap.remove(uniqueKey);
			
			logger.info("uploadFilesPart : File successfully uploaded into S3, requested Job id : "+jobId+", File Name : "+file.getOriginalFilename()+", versionNum : "+versionNum);
		}
		
		ResponseStatus status = new ResponseStatus(1, file.getOriginalFilename(), "File uploaded Successfuly", 0);
		
		
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	}
	

	@GetMapping(path = "/files")
	public List<FileResponse> getAllFiles(@RequestParam String jobId) {
		String orgId = defaultOrgId;

		if (getOrgId() != null && getOrgId().trim().length() > 0) {
			orgId = getOrgId();
		}
		logger.info("getAllFiles : requested Job id : "+jobId+", orgId : "+orgId);
		return fileService.getAllFiles(orgId, jobId);
	}

	@GetMapping(path = "/jobfiles")
	public List<JobFileResponse> getJobAllFiles(@RequestParam String jobId) {
		
		return fileService.getJobAllFiles(jobId);
	}


	
	@DeleteMapping(path = "/files")
	public ResponseEntity<ResponseStatus> deleteFiles(@RequestParam String jobId, @RequestParam String fileName) {
		String orgId = defaultOrgId;

		if (getOrgId() != null && getOrgId().trim().length() > 0) {
			orgId = getOrgId();
		}
		
		if(!Utils.isUUID(jobId)){
			ResponseStatus status = new ResponseStatus(0, jobId, "Invalid Job Id", 115);

			return new ResponseEntity<ResponseStatus>(status, HttpStatus.BAD_REQUEST);
		}
		logger.info("deleteFiles : requested Job id : "+jobId+", orgId : "+orgId,", fileName: "+fileName);
		fileService.deleteFiles(orgId, jobId, fileName);
		ResponseStatus status = new ResponseStatus(1, fileName, "File/s Successfully Deleted", 0);
		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	}
	
	@GetMapping(path = "/video")
	public ResponseEntity<StreamingResponseBody> getVideo(@RequestParam String videoName,@RequestHeader(value = "Range", required = false) String range) throws IOException{
		long rangeStart = 0;
        long rangeEnd;
        byte[] data;
        Long fileSize;
        
        StorageResponse res = fileService.getVideoInputStream(videoName);
       
		if(res !=null && res.getDataStream() != null){
			 InputStream is = res.getDataStream();
			 if (range == null) {
				StreamingResponseBody responseBody = response -> {
					byte[] buf = new byte[is.available()];
				    int length;
				    while ((length = is.read(buf)) > 0) {
				    	response.write(buf, 0, length);
				    }
				    is.close();
			     };
			     
			     return ResponseEntity.ok()
			           .contentType(MediaType.APPLICATION_OCTET_STREAM)
			           .body(responseBody);
			 } else {
				 	fileSize = res.getContentLenght();
				    String[] ranges = range.split("-");
		            rangeStart = Long.parseLong(ranges[0].substring(6));
		            if (ranges.length > 1) {
		                rangeEnd = Long.parseLong(ranges[1]);
		            } else {
		                rangeEnd = fileSize - 1;
		            }
		            if (fileSize < rangeEnd) {
		                rangeEnd = fileSize - 1;
		            }
		            
		            String contentLength = String.valueOf((rangeEnd - rangeStart) + 1);
		            ByteArrayOutputStream bufferedOutputStream = new ByteArrayOutputStream();
		            data = new byte[1024];
		            int nRead;
		            while ((nRead = is.read(data, 0, data.length)) != -1) {
		                bufferedOutputStream.write(data, 0, nRead);
		            }
		            bufferedOutputStream.flush();
		            is.close();
		            byte[] result = new byte[(int) (rangeEnd - rangeStart) + 1];
		            System.arraycopy(bufferedOutputStream.toByteArray(), (int) rangeStart, result, 0, result.length);
		            StreamingResponseBody responseBody = response -> {
		            	response.write(result);
				     };
				    bufferedOutputStream.close(); 
		            return ResponseEntity.status(HttpStatus.PARTIAL_CONTENT)
		                    .header("Content-Type",MediaType.APPLICATION_OCTET_STREAM.toString())
		                    .header("Accept-Ranges", "bytes")
		                    .header("Content-Length", contentLength)
		                    .header("Content-Range", "bytes" + " " + rangeStart + "-" + rangeEnd + "/" + fileSize)
		                    .body(responseBody);
			 }
		}else {
			return ResponseEntity.notFound().build();
		}
	}
			
}
