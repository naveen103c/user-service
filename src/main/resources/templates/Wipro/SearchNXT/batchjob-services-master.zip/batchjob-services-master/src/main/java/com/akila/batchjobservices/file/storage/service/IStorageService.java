package com.akila.batchjobservices.file.storage.service;

import java.util.List;
import java.util.Map;

import com.akila.batchjobservices.file.storage.bean.StorageRequest;
import com.akila.batchjobservices.file.storage.bean.StorageResponse;
import com.amazonaws.services.s3.model.AmazonS3Exception;

public interface IStorageService 
{
	StorageResponse getObject(StorageRequest storageRequestBean) throws AmazonS3Exception, Exception;;
	StorageResponse putObject(StorageRequest storageRequestBean,Map<String, String> fileDataData);
	void deleteObject(StorageRequest storageRequestBean);
	void deleteOrg(String orgId);
	public List<String> getAllFileNamesInS3Bucket(StorageRequest storageRequest);
	public List<String> getAllFileNamesWithSizeInS3Bucket(StorageRequest storageRequest);
}
