package com.akila.batchjobservices.file.storage.bean;

public class StorageRequest 
{
	private String orgId; /// wipro/
	private String contentType; // wiki/query/ent-cont
	private String formatType; // stripped/ origional
	private String contentId;
	private String fileFormat;
	private String inputStreamType; /// enum
	private Object content;
	private String userId;
	private int version; //0,-1,-2,-3
	private String versionId;
	
	
	
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getFormatType() {
		return formatType;
	}
	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}
	public String getContentId() {
		return contentId;
	}
	public void setContentId(String contentId) {
		this.contentId = contentId;
	}
	public String getFileFormat() {
		return fileFormat;
	}
	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}
	public String getInputStreamType() {
		return inputStreamType;
	}
	public void setInputStreamType(String inputStreamType) {
		this.inputStreamType = inputStreamType;
	}
	public Object getContent() {
		return content;
	}
	public void setContent(Object content) {
		this.content = content;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public String getVersionId() {
		return versionId;
	}
	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}
	
	

}
