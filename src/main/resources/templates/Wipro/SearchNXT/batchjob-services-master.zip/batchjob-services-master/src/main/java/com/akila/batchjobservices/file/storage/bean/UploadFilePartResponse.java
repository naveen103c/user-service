package com.akila.batchjobservices.file.storage.bean;

import com.amazonaws.services.s3.model.PartETag;

public class UploadFilePartResponse {

	private String uploadId;
	private PartETag partETag;

	public String getUploadId() {
		return uploadId;
	}

	public void setUploadId(String uploadId) {
		this.uploadId = uploadId;
	}

	public PartETag getPartETag() {
		return partETag;
	}

	public void setPartETag(PartETag partETag) {
		this.partETag = partETag;
	}

}
