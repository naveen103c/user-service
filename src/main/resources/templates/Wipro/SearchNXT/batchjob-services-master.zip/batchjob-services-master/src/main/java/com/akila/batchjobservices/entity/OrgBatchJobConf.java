package com.akila.batchjobservices.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.akila.batchjobservices.conf.bean.ConfFilter;

/**
 * The persistent class for the org_batch_job_confs database table.
 * 
 */
@Entity
@Table(name = "org_batch_job_confs")
public class OrgBatchJobConf implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "conf_id")
	String confId;

	@Column(name = "conf_name")
	String confName;

	@Column(name = "batch_job_conf_status_cd")
	Integer batchJobConfStatusCd;

	@Column(name = "source_extraction_type_cd")
	Integer sourceExtractionTypeCd;

	@Column(name = "source_type_cd")
	Integer sourceTypeCd;

	@Column(name = "source_allowed_user_group_list")
	String sourceAllowedUserGroupList;

	@Column(name = "source_description")
	String sourceDescription;

	@Column(name = "source_url")
	String sourceUrl;

	@Column(name = "source_user_id")
	String sourceUserId;

	@Column(name = "source_password")
	String sourcePassword;

	@Column(name = "source_tag_id_list")
	String sourceTagIdList;

	@Column(name = "source_schedule_json")
	String sourceScheduleJson;

	@Column(name = "conf_job_exec_status_cd")
	Integer confJobExecStatusCd;

	@Column(name = "last_job_id")
	String lastJobId;

	@Column(name = "next_run_date_ts")
	Date nextRunDateTs;

	@Column(name = "mod_ts")
	Date modTs;

	@Transient
	List<ConfFilter> filterList;

	@Column(name = "crt_ts")
	Date crtTs;

	@Column(name = "crt_By")
	String crtBy;
	
	@Column(name = "mod_By")
	String modBy;

	@Column(name = "source_classification_json")
	String sourceClassificationJson;

	public String getSourceClassificationJson() {
		return sourceClassificationJson;
	}

	public void setSourceClassificationJson(String sourceClassificationJson) {
		this.sourceClassificationJson = sourceClassificationJson;
	}

	public Date getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Date crtTs) {
		this.crtTs = crtTs;
	}

	public List<ConfFilter> getFilterList() {
		return filterList;
	}

	public void setFilterList(List<ConfFilter> filterList) {
		this.filterList = filterList;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public String getConfId() {
		return confId;
	}

	public void setConfId(String confId) {
		this.confId = confId;
	}

	public String getConfName() {
		return confName;
	}

	public void setConfName(String confName) {
		this.confName = confName;
	}

	public Integer getBatchJobConfStatusCd() {
		return batchJobConfStatusCd;
	}

	public void setBatchJobConfStatusCd(Integer batchJobConfStatusCd) {
		this.batchJobConfStatusCd = batchJobConfStatusCd;
	}

	public Integer getSourceExtractionTypeCd() {
		return sourceExtractionTypeCd;
	}

	public void setSourceExtractionTypeCd(Integer sourceExtractionTypeCd) {
		this.sourceExtractionTypeCd = sourceExtractionTypeCd;
	}

	public Integer getSourceTypeCd() {
		return sourceTypeCd;
	}

	public void setSourceTypeCd(Integer sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}

	public String getSourceAllowedUserGroupList() {
		return sourceAllowedUserGroupList;
	}

	public void setSourceAllowedUserGroupList(String sourceAllowedUserGroupList) {
		this.sourceAllowedUserGroupList = sourceAllowedUserGroupList;
	}

	public String getSourceDescription() {
		return sourceDescription;
	}

	public void setSourceDescription(String sourceDescription) {
		this.sourceDescription = sourceDescription;
	}

	public String getSourceUrl() {
		return sourceUrl;
	}

	public void setSourceUrl(String sourceUrl) {
		this.sourceUrl = sourceUrl;
	}

	public String getSourceUserId() {
		return sourceUserId;
	}

	public void setSourceUserId(String sourceUserId) {
		this.sourceUserId = sourceUserId;
	}

	public String getSourcePassword() {
		return sourcePassword;
	}

	public void setSourcePassword(String sourcePassword) {
		this.sourcePassword = sourcePassword;
	}

	public String getSourceTagIdList() {
		return sourceTagIdList;
	}

	public void setSourceTagIdList(String sourceTagIdList) {
		this.sourceTagIdList = sourceTagIdList;
	}

	public String getSourceScheduleJson() {
		return sourceScheduleJson;
	}

	public void setSourceScheduleJson(String sourceScheduleJson) {
		this.sourceScheduleJson = sourceScheduleJson;
	}

	public Integer getConfJobExecStatusCd() {
		return confJobExecStatusCd;
	}

	public void setConfJobExecStatusCd(Integer confJobExecStatusCd) {
		this.confJobExecStatusCd = confJobExecStatusCd;
	}

	public String getLastJobId() {
		return lastJobId;
	}

	public void setLastJobId(String lastJobId) {
		this.lastJobId = lastJobId;
	}

	public Date getNextRunDateTs() {
		return nextRunDateTs;
	}

	public void setNextRunDateTs(Date nextRunDateTs) {
		this.nextRunDateTs = nextRunDateTs;
	}

	public Date getModTs() {
		return modTs;
	}

	public void setModTs(Date modTs) {
		this.modTs = modTs;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

}