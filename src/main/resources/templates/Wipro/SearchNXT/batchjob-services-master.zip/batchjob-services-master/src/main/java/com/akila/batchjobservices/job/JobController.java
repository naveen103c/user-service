package com.akila.batchjobservices.job;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.batchjobservices.conf.bean.ResponseStatus;
import com.akila.batchjobservices.job.bean.BatchJobRequest;
import com.akila.batchjobservices.job.bean.GetJob;
import com.fasterxml.jackson.core.JsonProcessingException;

@RestController
public class JobController extends AkilaController {
	@Autowired
	private JobService jobService;

	String defaultUserId = "a9daaf8e-0a5b-46c2-b281-650ab5dda384";

	@PostMapping(path = "/jobs")
	@ResponseBody
	public ResponseEntity<ResponseStatus> createJob(@RequestParam String confId) {
		String jobId = jobService.createJob(confId, defaultUserId);
		ResponseStatus status = new ResponseStatus(1, jobId, "Job successfully created", 0);

		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	}

	@GetMapping(path = "/jobs/run")
	@ResponseBody
	public ResponseEntity<ResponseStatus> runBatch(@RequestParam(required = false) String confId,
			@RequestParam(required = false) String jobId) {

		if (confId == null && jobId == null) {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

		// Validate upload job file exist or not
		if(!jobService.validateJob(confId,jobId)) {
			ResponseStatus status = new ResponseStatus(0, "", "No file exists for processing",112);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.PRECONDITION_FAILED);
		}

		
		String jId = jobService.runBatch(confId, jobId, defaultUserId);

		if (jId != null) {
			ResponseStatus status = new ResponseStatus(1, jId, "Job successfully Scheduled for Run", 0);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
		} else {
			ResponseStatus status = new ResponseStatus(0, "", "There was some internal error",112);
			return new ResponseEntity<ResponseStatus>(status, HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping(path = "/jobs")
	public ResponseEntity<List<GetJob>> getAllJobs(@RequestParam(required = false) String confId,
			@RequestParam(required = false) Integer sourcetypes, @RequestParam(required = false) Integer jobStatusCd) {
		return new ResponseEntity<List<GetJob>>(jobService.getAllJobs(confId, sourcetypes, jobStatusCd), HttpStatus.OK);
	}

	@GetMapping(path = "/jobs/{id}")
	public GetJob getJob(@PathVariable String id) {

		return jobService.getJob(id);
	}

	@GetMapping(path = "/jobs/{id}/terminate")
	public String terminateJob(@PathVariable String id) {
		return jobService.terminateJob(id);
	}
	
	@PostMapping(path = "/jobs/attachment")
	@ResponseBody
	public ResponseEntity<ResponseStatus> createJob(@RequestParam String confId, @RequestBody BatchJobRequest batchJobRequest) throws JsonProcessingException {
		String jobId = jobService.createJob(confId, batchJobRequest);
		ResponseStatus status = new ResponseStatus(1, jobId, "Job successfully created", 0);

		return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	}
}
