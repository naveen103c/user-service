package com.akila.batchjobservices.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "base_batch_job_modules", schema = "base")
public class BaseBatchJobModules {

	@Id
	@Column(name = "module_id")
	Integer moduleId;

	@Column(name = "module_name")
	String moduleName;

	@Column(name = "java_tasklet")
	String javaTaskLet;

	@Column(name = "java_item_reader")
	String reader;

	@Column(name = "java_item_processor")
	String processor;

	@Column(name = "java_item_writer")
	String writer;

	@Column(name = "chunk_size")
	Integer chunkSize;

	@Column(name = "is_active")
	Boolean isActive;

	@Column(name = "source_type_cd")
	Integer sourceTypeCd;

	@Column(name = "java_module_class")
	String javaModuleClass;

	@Column(name = "module_type_cd")
	Integer moduleTypeCd;

	@Column(name = "module_attribute_json")
	String moduleAttribute;

	@Column(name = "action_needed_json")
	String actionNeeded;

	public Integer getModuleId() {
		return moduleId;
	}

	public void setModuleId(Integer moduleId) {
		this.moduleId = moduleId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getJavaTaskLet() {
		return javaTaskLet;
	}

	public void setJavaTaskLet(String javaTaskLet) {
		this.javaTaskLet = javaTaskLet;
	}

	public String getReader() {
		return reader;
	}

	public void setReader(String reader) {
		this.reader = reader;
	}

	public String getProcessor() {
		return processor;
	}

	public void setProcessor(String processor) {
		this.processor = processor;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public Integer getChunkSize() {
		return chunkSize;
	}

	public void setChunkSize(Integer chunkSize) {
		this.chunkSize = chunkSize;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Integer getSourceTypeCd() {
		return sourceTypeCd;
	}

	public void setSourceTypeCd(Integer sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}

	public String getJavaModuleClass() {
		return javaModuleClass;
	}

	public void setJavaModuleClass(String javaModuleClass) {
		this.javaModuleClass = javaModuleClass;
	}

	public Integer getModuleTypeCd() {
		return moduleTypeCd;
	}

	public void setModuleTypeCd(Integer moduleTypeCd) {
		this.moduleTypeCd = moduleTypeCd;
	}

	public String getModuleAttribute() {
		return moduleAttribute;
	}

	public void setModuleAttribute(String moduleAttribute) {
		this.moduleAttribute = moduleAttribute;
	}

	public String getActionNeeded() {
		return actionNeeded;
	}

	public void setActionNeeded(String actionNeeded) {
		this.actionNeeded = actionNeeded;
	}

}
