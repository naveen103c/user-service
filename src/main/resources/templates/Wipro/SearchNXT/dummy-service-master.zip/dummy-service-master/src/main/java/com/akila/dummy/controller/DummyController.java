package com.akila.dummy.controller;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DummyController {

	@GetMapping(path = "/dummy/dummyData")
	public String getDummyData(@RequestParam Integer periodCd) {
		return "success";
	}

	@PutMapping(path = "/dummy/dummyData/{id}")
	public String updateDummy(@PathVariable String id, @RequestParam Integer count) {
		return "successfully updated";
	}

	@PostMapping(path = "/dummy/dummyData/{id}")
	public String createDummy(@PathVariable String id) {
		return "successfully created";
	}

	@DeleteMapping(path = "/dummy/dummyData/{id}")
	public String deleteDummy(@PathVariable String id) {
		return "deleted";
	}

}
