package com.akila.expertconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.expertconnect.entity.OrgUser;

@Repository
public interface OrgUserRepository extends JpaRepository<OrgUser, String> {
	
	@Query(value = "SELECT o.userId ,o.userFirstNm,o.userLastNm ,o.usrEmail from OrgUser o where o.userId in (:userIds)")
	List<Object[]> getUserEmail(@Param("userIds") List<String> userIds);
	
	@Query(value = "SELECT o.userId ,o.userFirstNm,o.userLastNm ,o.usrEmail from OrgUser o where o.usrEmail in (:usrEmails)")
	List<Object[]> getUserEmailById(@Param("usrEmails") List<String> usrEmails);
}
