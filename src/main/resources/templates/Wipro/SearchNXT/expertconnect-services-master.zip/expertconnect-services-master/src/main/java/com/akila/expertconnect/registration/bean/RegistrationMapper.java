package com.akila.expertconnect.registration.bean;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.akila.expertconnect.entity.OrgCommunitySme;
import com.akila.expertconnect.entity.OrgCommunitySmeRequest;
import com.akila.expertconnect.entity.OrgSmeAvailability;

@Mapper(
    componentModel = "spring"
)
public interface RegistrationMapper {
  RegistrationMapper INSTANCE = Mappers.getMapper(RegistrationMapper.class);
  ;

//  @Mappings({})
//  RegistrationResponse orgSmeAvailabilityToRegistrationResponse(
//      OrgSmeAvailability orgSmeAvailability);

//  @Mappings({})
//  List<RegistrationResponse> orgSmeAvailabilityToRegistrationResponseList(
//      List<OrgSmeAvailability> orgSmeAvailability);

  @Mappings({})
  List<RegistrationResponse> OrgCommunitySmeRequestListToRegistrationResponseList(
      List<OrgCommunitySmeRequest> OrgCommunitySmeRequest);
  
  @Mappings({})
  RegistrationResponse OrgCommunitySmeRequestToRegistrationResponse(
      OrgCommunitySmeRequest OrgCommunitySmeRequest);
  
  @Mappings({@Mapping(source = "id.communityId" , target = "communityId"),@Mapping(source = "id.userId" , target = "userId")})
  RegistrationResponse OrgCommunitySmeToRegistrationResponse(
		  OrgCommunitySme orgCommunitySme);
  
  @Mappings({@Mapping(source = "requestId" , target = "availabilityId")})
  OrgSmeAvailability registrationRequestToOrgSmeAvailability(
		  OrgCommunitySmeRequest registrationRequest);
  
  @Mappings({})
  OrgCommunitySmeRequest registrationRequestToOrgCommunitySmeRequest(
      RegistrationRequest registrationRequest);
  
}



