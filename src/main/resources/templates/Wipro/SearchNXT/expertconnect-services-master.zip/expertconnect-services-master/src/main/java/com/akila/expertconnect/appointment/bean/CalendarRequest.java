package com.akila.expertconnect.appointment.bean;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.UUID;

public class CalendarRequest {
    private String uid;
    private String toEmail;
    private String ccEmail;
    private String subject;
    private String body;
    private String htmlBody;
    private Timestamp meetingStartTime;
    private Timestamp meetingEndTime;
    private String smeName = "";
	private String senderName = "";
	
    private CalendarRequest(Builder builder) {
        toEmail = builder.toEmail;
        subject = builder.subject;
        body = builder.body;
        htmlBody = builder.htmlBody;
        meetingStartTime = builder.meetingStartTime;
        meetingEndTime = builder.meetingEndTime;
    }
 
 
    public String getUid() {
        return uid;
    }
 
    public String getToEmail() {
        return toEmail;
    }
 
    public String getSubject() {
        return subject;
    }
 
    public String getBody() {
        return body;
    }
    
    public String getHtmlBody() {
        return htmlBody;
    }
 
    public Timestamp getMeetingStartTime() {
        return meetingStartTime;
    }
 
    public Timestamp getMeetingEndTime() {
        return meetingEndTime;
    }
 
    public static final class Builder {
        private String toEmail;
        private String subject;
        private String body;
        private String htmlBody;
        private Timestamp meetingStartTime;
        private Timestamp meetingEndTime;
 
        public Builder() {
        }
 
        public Builder withToEmail(String val) {
            toEmail = val;
            return this;
        }
 
        public Builder withSubject(String val) {
            subject = val;
            return this;
        }
 
        public Builder withBody(String val) {
            body = val;
            return this;
        }
        
        public Builder withHtmlBody(String val) {
            htmlBody = val;
            return this;
        }
 
        public Builder withMeetingStartTime(Timestamp val) {
            meetingStartTime = val;
            return this;
        }
 
        public Builder withMeetingEndTime(Timestamp val) {
            meetingEndTime = val;
            return this;
        }
 
        public CalendarRequest build() {
            return new CalendarRequest(this);
        }
    }

	public String getCcEmail() {
		return ccEmail;
	}


	public void setCcEmail(String ccEmail) {
		this.ccEmail = ccEmail;
	}


	public void setUid(String uid) {
		this.uid = uid;
	}


	public String getSmeName() {
		return smeName;
	}


	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}


	public String getSenderName() {
		return senderName;
	}


	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
}