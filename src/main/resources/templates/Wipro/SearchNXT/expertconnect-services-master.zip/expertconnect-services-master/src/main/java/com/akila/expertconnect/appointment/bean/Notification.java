package com.akila.expertconnect.appointment.bean;

import java.math.BigDecimal;

public class Notification {

	String userId;
	String tenant;
	String requestUri;
	String queryString;
	String httpMethod;
	String orgId;
	String serviceName;
	String metricName;
	BigDecimal value;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTenant() {
		return tenant;
	}

	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

	public String getRequestUri() {
		return requestUri;
	}

	public void setRequestUri(String requestUri) {
		this.requestUri = requestUri;
	}

	public String getQueryString() {
		return queryString;
	}

	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getMetricName() {
		return metricName;
	}

	public void setMetricName(String metricName) {
		this.metricName = metricName;
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "Notification [userId=" + userId + ", tenant=" + tenant + ", requestUri=" + requestUri + ", queryString="
				+ queryString + ", httpMethod=" + httpMethod + ", orgId=" + orgId + ", serviceName=" + serviceName
				+ ", metricName=" + metricName + ", value=" + value + "]";
	}
	
	
	
	

}
