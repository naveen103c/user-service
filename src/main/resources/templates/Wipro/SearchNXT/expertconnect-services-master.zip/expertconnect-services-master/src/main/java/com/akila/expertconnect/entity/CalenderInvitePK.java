package com.akila.expertconnect.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the org_community_smes database table.
 * 
 */
@Embeddable
public class CalenderInvitePK implements Serializable {
	// default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name = "meeting_id", insertable = false, updatable = false)
	private String meetingId;

	@Column(name = "appointment_id", insertable = false, updatable = false)
	private String appointmentId;

	public CalenderInvitePK() {
	}

	public String getMeetingId() {
		return meetingId;
	}

	public void setMeetingId(String meetingId) {
		this.meetingId = meetingId;
	}

	public String getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(String appointmentId) {
		this.appointmentId = appointmentId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof CalenderInvitePK)) {
			return false;
		}
		CalenderInvitePK castOther = (CalenderInvitePK) other;
		return this.appointmentId.equals(castOther.appointmentId) && this.meetingId.equals(castOther.meetingId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.appointmentId.hashCode();
		hash = hash * prime + this.meetingId.hashCode();

		return hash;
	}
}