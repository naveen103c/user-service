package com.akila.expertconnect.appointment.trends;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.functors.ConstantFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.expertconnect.appointment.bean.Constant;
import com.akila.expertconnect.appointment.trends.bean.TrendResponse;
import com.akila.expertconnect.repository.OrgAppointmentRepository;
import com.akila.expertconnect.repository.OrgSkillRepository;

@Service
public class AppointmentTrendService extends AkilaService {

	@Autowired
	protected OrgAppointmentRepository orgAppointmentRepository;

	@Autowired
	protected OrgSkillRepository orgSkillRepository;

	LocalDate currentdate = LocalDate.now();
	protected int month = currentdate.getMonthValue();
	protected int year = currentdate.getYear();

	public List<TrendResponse> getTrendingSkill() {
		List<TrendResponse> responseList = new ArrayList<TrendResponse>();
		List<Object[]> response = orgAppointmentRepository.getTrendingSkill(year, month);
		Map<String, Integer> map = new HashMap<String, Integer>();
		int count;
		for (Object[] object : response) {
			if (map.containsKey(object[0].toString())) {
				count = map.get(object[0].toString());
				count += ((Number)object[1]).intValue();
				map.put(object[0].toString(), count);
			} else {
				map.put(object[0].toString(), ((Number)object[1]).intValue());
			}
		}
		  
		for (Map.Entry<String, Integer> value : map.entrySet()) {
			TrendResponse trendResponse = new TrendResponse();
			trendResponse.setName(value.getKey());
			trendResponse.setValue(value.getValue());
			responseList.add(trendResponse);
		}

		Collections.sort(responseList, new Comparator<TrendResponse>(){

			  public int compare(TrendResponse o1, TrendResponse o2)
			  {
			     return o2.getValue().compareTo(o1.getValue());
			  }
			});
		if(responseList.size()>Constant.MATRIC_RESULT_LIMIT)
			responseList.subList(Constant.MATRIC_RESULT_LIMIT, responseList.size()).clear();
		
		return responseList;
	}

	public List<TrendResponse> getTrendingSME() {
		List<TrendResponse> responseList = new ArrayList<TrendResponse>();
		List<Object[]> response = orgAppointmentRepository.getTrendingSME(year, month);
		Map<String, Integer> map = new HashMap<String, Integer>();
		int count;
		for (Object[] object : response) {
			if (map.containsKey(object[0].toString())) {
				count = map.get(object[0].toString());
				count += ((Number)object[1]).intValue();
				map.put(object[0].toString(), count);
			} else {
				map.put(object[0].toString(), ((Number)object[1]).intValue());
			}
		}
		for (Map.Entry<String, Integer> value : map.entrySet()) {
			TrendResponse trendResponse = new TrendResponse();
			trendResponse.setName(value.getKey());
			trendResponse.setValue(value.getValue());
			responseList.add(trendResponse);
		}
		Collections.sort(responseList, new Comparator<TrendResponse>(){

			  public int compare(TrendResponse o1, TrendResponse o2)
			  {
			     return o2.getValue().compareTo(o1.getValue());
			  }
			});
		
		if(responseList.size()>Constant.MATRIC_RESULT_LIMIT)
			responseList.subList(Constant.MATRIC_RESULT_LIMIT, responseList.size()).clear();
		
		return responseList;
	}
	
	public List<TrendResponse> getAppointmentStatusTrend() {
		List<TrendResponse> responseList = new ArrayList<TrendResponse>();
		List<Object[]> response = orgAppointmentRepository.getAppointmentStatusTrend(year, month);
		Map<String, Integer> map = new HashMap<String, Integer>();
		int count;
		for (Object[] object : response) {
			if (map.containsKey(object[0].toString())) {
				count = map.get(object[0].toString());
				count += ((Number)object[1]).intValue();
				map.put(object[0].toString(), count);
			} else {
				map.put(object[0].toString(), ((Number)object[1]).intValue());
			}
		}
		for (Map.Entry<String, Integer> value : map.entrySet()) {
			TrendResponse trendResponse = new TrendResponse();
			String status = null;
			if(value.getKey().equals("1")) {
				status = "Scheduled";
			}else if (value.getKey().equals("2")) {
				status = "Canceled";
			}else if (value.getKey().equals("3")) {
				status = "Rescheduled";
			}else {
				status = "Completed";
			}
			trendResponse.setName(status);
			trendResponse.setValue(value.getValue());
			responseList.add(trendResponse);
		}
		return responseList;
	}
}