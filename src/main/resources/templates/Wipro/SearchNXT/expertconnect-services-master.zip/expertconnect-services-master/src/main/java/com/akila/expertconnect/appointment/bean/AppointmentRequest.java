package com.akila.expertconnect.appointment.bean;

import java.sql.Timestamp;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.akila.AkilaRequest;

public class AppointmentRequest extends AkilaRequest {

	@NotNull(message = "{APPOINTMENT.LOCATION.MANDATORY}")
	private Integer locationCd;

	@NotNull(message = "{APPOINTMENT.BOOKINGTS.MANDATORY}")
	private Timestamp bookingTs;
	
	@NotNull(message = "{APPOINTMENT.APPOINTMENTTS.MANDATORY}")
	@NotEmpty(message = "{APPOINTMENT.APPOINTMENTTS.MANDATORY}")
	private String appointmentTs;

	private String bookedBy;

	@NotNull(message = "{APPOINTMENT.SMEUSERID.MANDATORY}")
	@NotEmpty(message = "{APPOINTMENT.SMEUSERID.MANDATORY}")
	private String smeUserId;

	@NotNull(message = "{APPOINTMENT.SKILLID.MANDATORY}")
	@NotEmpty(message = "{APPOINTMENT.SKILLID.MANDATORY}")
	private String skillId;

	@NotNull(message = "{APPOINTMENT.DESC.MANDATORY}")
	@NotEmpty(message = "{APPOINTMENT.DESC.MANDATORY}")
	private String description;

	private String cancelledReason;

	private String feedback;
	
	private Integer appointmentStatusCd;
	
	@NotNull(message = "{APPOINTMENT.DURATION.MANDATORY}")
	private Integer appointmentDuration;
	
	public Integer getAppointmentStatusCd() {
		return appointmentStatusCd;
	}

	public void setAppointmentStatusCd(Integer appointmentStatusCd) {
		this.appointmentStatusCd = appointmentStatusCd;
	}

	public String getBookedBy() {
		return bookedBy;
	}

	public void setBookedBy(String bookedBy) {
		this.bookedBy = bookedBy;
	}

	public Integer getLocationCd() {
		return locationCd;
	}

	public void setLocationCd(Integer locationCd) {
		this.locationCd = locationCd;
	}

	public String getAppointmentTs() {
		return appointmentTs;
	}

	public void setAppointmentTs(String appointmentTs) {
		this.appointmentTs = appointmentTs;
	}

	public Timestamp getBookingTs() {
		return bookingTs;
	}

	public void setBookingTs(Timestamp bookingTs) {
		this.bookingTs = bookingTs;
	}

	public String getSmeUserId() {
		return smeUserId;
	}

	public void setSmeUserId(String smeUserId) {
		this.smeUserId = smeUserId;
	}

	public String getSkillId() {
		return skillId;
	}

	public void setSkillId(String skillId) {
		this.skillId = skillId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCancelledReason() {
		return cancelledReason;
	}

	public void setCancelledReason(String cancelledReason) {
		this.cancelledReason = cancelledReason;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public Integer getAppointmentDuration() {
		return appointmentDuration;
	}

	public void setAppointmentDuration(Integer appointmentDuration) {
		this.appointmentDuration = appointmentDuration;
	}

	@Override
	public String toString() {
		return "AppointmentRequest [locationCd=" + locationCd + ", bookingTs=" + bookingTs + ", appointmentTs="
				+ appointmentTs + ", bookedBy=" + bookedBy + ", smeUserId=" + smeUserId + ", skillId=" + skillId
				+ ", description=" + description + ", cancelledReason=" + cancelledReason + ", feedback=" + feedback
				+ ", appointmentStatusCd=" + appointmentStatusCd + ", appointmentDuration=" + appointmentDuration + "]";
	}
}
