package com.akila.expertconnect.appointment;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.mail.MessagingException;
import javax.transaction.Transactional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.expertconnect.appointment.bean.AppointmentMapper;
import com.akila.expertconnect.appointment.bean.AppointmentRequest;
import com.akila.expertconnect.appointment.bean.AppointmentResponse;
import com.akila.expertconnect.appointment.bean.CalendarRequest;
import com.akila.expertconnect.appointment.bean.CalendarService;
import com.akila.expertconnect.appointment.bean.Constant;
import com.akila.expertconnect.appointment.bean.MeetingRequest;
import com.akila.expertconnect.appointment.bean.Notification;
import com.akila.expertconnect.entity.BaseEmailTemplate;
import com.akila.expertconnect.entity.CalenderInvite;
import com.akila.expertconnect.entity.CalenderInvitePK;
import com.akila.expertconnect.entity.OrgAppointment;
import com.akila.expertconnect.entity.OrgAppointmentsHistory;
import com.akila.expertconnect.entity.OrgEmailTemplate;
import com.akila.expertconnect.entity.OrgSkill;
import com.akila.expertconnect.entity.OrgUser;
import com.akila.expertconnect.entity.OrgUserActivity;
import com.akila.expertconnect.repository.BaseEmailTemplateRepository;
import com.akila.expertconnect.repository.CalenderInviteRepository;
import com.akila.expertconnect.repository.OrgAppointmentRepository;
import com.akila.expertconnect.repository.OrgAppointmentsHistoryRepository;
import com.akila.expertconnect.repository.OrgEmailTemplateRepository;
import com.akila.expertconnect.repository.OrgSkillRepository;
import com.akila.expertconnect.repository.OrgUserActivityRepository;
import com.akila.expertconnect.repository.OrgUserRepository;
import com.akila.response.ResponseId;

@Service
public class AppointmentService extends AkilaService {

	private static Logger log = LogManager.getLogger(AppointmentService.class);

	@Autowired
	private OrgAppointmentRepository orgAppointmentRepository;

	@Autowired
	private OrgEmailTemplateRepository orgEmailTemplateRepository;

	@Autowired
	private BaseEmailTemplateRepository baseEmailTemplateRepository;

	@Autowired
	private AppointmentMapper appointmentMapper;

	@Autowired
	private OrgAppointmentsHistoryRepository orgAppointmentsHistoryRepository;

	@Autowired
	private OrgUserActivityRepository orgUserActivityRepository;

	@Autowired
	protected OrgUserRepository orgUserRepository;

	@Autowired
	protected CalenderInviteRepository calenderInviteRepository;

	@Autowired
	protected OrgSkillRepository orgSkillRepository;

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate restTemplateloadBalanced;

	@Value("${mail_username}")
	private String username;

	@Value("${mail_password}")
	private String password;

	@Value("${mail.smtp.auth}")
	private String mailSmtpAuth;

	@Value("${mail.smtp.starttls.enable}")
	private String mailSmtpStarttlsEnable;

	@Value("${mail.smtp.host}")
	private String mailSmtpHost;

	@Value("${mail.smtp.port}")
	private String mailSmtpPort;

	@Value("${organizer_cn}")
	private String organizerCn;

	@Value("${incentive.service.url}")
	private String incentiveServiceURL;
	
	@Autowired
	CalendarService calendarService;
	
	@Autowired
	private AkilaRestTemplate akilaRestTemplate;
	
	public ResponseId createAppointment(AppointmentRequest appointmentRequest) {

		log.info("Create Appointment Request -- " + appointmentRequest.toString());
		OrgAppointment orgAppointment = appointmentMapper.orgAppointmentToAppointmentRequest(appointmentRequest);
		// OrgAppointment orgAppointment = new OrgAppointment();
		orgAppointment.setDescription(appointmentRequest.getDescription());
		orgAppointment.setLocationCd(appointmentRequest.getLocationCd());
		orgAppointment.setSkillId(appointmentRequest.getSkillId());
		orgAppointment.setSmeUserId(appointmentRequest.getSmeUserId());
		orgAppointment.setBookingTs(appointmentRequest.getBookingTs());
		// orgAppointment.setBookingTs(Timestamp.valueOf(appointmentRequest.getAppointmentTs()));
		orgAppointment.setAppointmentId(UUID.randomUUID());
		orgAppointment.setModTs(new Timestamp(System.currentTimeMillis()));
		orgAppointment.setModBy(super.getUserId());
		orgAppointment.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgAppointment.setCrtBy(super.getUserId());
		orgAppointment.setBookedBy(super.getUserId());
		orgAppointment.setDuration(appointmentRequest.getAppointmentDuration());
		orgAppointment.setAppointmentStatusCd(1);
		orgAppointment.setBookingEndTs(Timestamp.valueOf(Timestamp.valueOf(appointmentRequest.getBookingTs() + "")
				.toLocalDateTime().plusMinutes(orgAppointment.getDuration())));
		if ((orgAppointmentRepository.findByBookedByOrSmeUserIdAndBookingTsGreaterThanEqualAndBookingEndTsLessThanEqual(
				Timestamp.valueOf(orgAppointment.getBookingTs().toLocalDateTime().plusSeconds(1)), Timestamp.valueOf(orgAppointment.getBookingEndTs().toLocalDateTime().minusSeconds(1)), super.getUserId(),
				orgAppointment.getSmeUserId()).size() == 0)) {
			orgAppointmentRepository.save(orgAppointment);
			this.createActivity(Constant.ACTIVITY_APPOINTMENT_BOOK);

			// Create Appointment Mail.
			ExecutorService executorService = Executors.newSingleThreadExecutor();
			executorService.execute(new Runnable() {
				@Override
				public void run() {
					// sendInvite(meetingRequest, "REQUEST", null,null,0);
					sendMeetingInvite(orgAppointment.getAppointmentId().toString(), "REQUEST",
							appointmentRequest.getAppointmentTs(), null,"");
				}
			});
			return new ResponseId(orgAppointment.getAppointmentId().toString());
		} else {
			return new ResponseId("");
		}

	}

	public List<AppointmentResponse> getAllAppointment(@RequestParam String communityId, @RequestParam String userId,
			@RequestParam Integer appStatusCd, Integer fetchHistory) {
		appStatusCd = appStatusCd == null ? 0 : appStatusCd;
		if (fetchHistory == null || fetchHistory == 0) {
			List<OrgAppointment> resultList = orgAppointmentRepository.findAllSMEByFilter(userId, appStatusCd);
			return appointmentMapper.orgSmeAvailabilityListToAppointmentResponseList(resultList);
		} else {
			List<OrgAppointmentsHistory> resultList = orgAppointmentsHistoryRepository
					.orgAppointmentsHistoryRepository(userId, appStatusCd);
			return appointmentMapper.orgSmeAvailabilityHistoryListToAppointmentResponseList(resultList);
		}

	}

	public AppointmentResponse getAppointment(UUID id) {
		OrgAppointment orgAppointment = orgAppointmentRepository.findById(id).orElse(null);
		return appointmentMapper.orgSmeAvailabilityToAppointmentResponse(orgAppointment);
	}

	@Transactional
	public ResponseId updateAppointment(UUID id, AppointmentRequest appointmentRequest) {
		log.info("updateAppointment : Inside updateAppointment method ");
		OrgAppointment orgAppointmentOld = orgAppointmentRepository.findById(id).orElse(null);
		if (orgAppointmentOld != null) {

			// Save In History
			OrgAppointmentsHistory orgAppointmentsHistory = new OrgAppointmentsHistory();
			orgAppointmentsHistory = appointmentMapper.orgAppointmentToAppointmentsHistory(orgAppointmentOld);
			orgAppointmentsHistory.setHistoryId(UUID.randomUUID());
			orgAppointmentsHistory.setModBy(super.getUserId());
			orgAppointmentsHistory.setModTs(new Timestamp(System.currentTimeMillis()));
			orgAppointmentsHistory.setAppointmentStatusCd(appointmentRequest.getAppointmentStatusCd());
			orgAppointmentsHistory.setCancelledReason(appointmentRequest.getCancelledReason());
			orgAppointmentsHistory.setBookingEndTs(Timestamp.valueOf(Timestamp.valueOf(appointmentRequest.getBookingTs() + "")
					.toLocalDateTime().plusMinutes(orgAppointmentOld.getDuration())));
			orgAppointmentsHistoryRepository.save(orgAppointmentsHistory);

			if (appointmentRequest.getAppointmentStatusCd() == Constant.APPOINTMENT_COMPLETE) {
				orgAppointmentRepository.deleteById(id);
				this.createActivity(Constant.ACTIVITY_APPOINTMENT_COMPLETE);
				postToIncentive(orgAppointmentOld.getSmeUserId(), orgAppointmentOld.getAppointmentId().toString(),
						appointmentRequest.getAppointmentStatusCd());
				log.info("Appointment Complete postToIncentive(); Triggred ");

			} else if (appointmentRequest.getAppointmentStatusCd() == Constant.APPOINTMENT_CANCELED) {
				sendMeetingInvite(id.toString(), "CANCEL", null, null,"");
				orgAppointmentRepository.deleteById(id);
				this.createActivity(Constant.ACTIVITY_APPOINTMENT_CANCEL);
				/*
				 * postToIncentive(orgAppointmentOld.getBookedBy(),
				 * orgAppointmentOld.getAppointmentId().toString(),
				 * appointmentRequest.getAppointmentStatusCd());
				 * log.info("Appointment Cancel postToIncentive(); Triggred ");
				 */

			} else {

				OrgAppointment orgAppointment = appointmentMapper
						.orgAppointmentToAppointmentRequest(appointmentRequest);
				orgAppointment.setAppointmentId(id);
				orgAppointment.setModTs(new Timestamp(System.currentTimeMillis()));
				orgAppointment.setModBy(super.getUserId());
				orgAppointment.setCrtTs(orgAppointmentOld.getCrtTs());
				orgAppointment.setCrtBy(orgAppointmentOld.getCrtBy());
				orgAppointment.setBookedBy(orgAppointmentOld.getBookedBy());
				orgAppointment.setBookingTs(appointmentRequest.getBookingTs());
				orgAppointment.setDuration(orgAppointmentOld.getDuration());
				orgAppointment
						.setBookingEndTs(Timestamp.valueOf(Timestamp.valueOf(appointmentRequest.getBookingTs() + "")
								.toLocalDateTime().plusMinutes(orgAppointment.getDuration())));
				log.info("Update Appointment Booking getBookingTs --> " + orgAppointment.getBookingTs());
				log.info("Update Appointment Booking getBookingEndTs --> " + orgAppointment.getBookingEndTs());
				log.info("Update Appointment Booking getAppointmentTs --> "
						+ Timestamp.valueOf(appointmentRequest.getAppointmentTs()));
				orgAppointment.setAppointmentStatusCd(1);
				orgAppointmentRepository.save(orgAppointment);
				this.createActivity(Constant.ACTIVITY_APPOINTMENT_RESCHEDUE);
				String currentUserId = super.getUserId();
				log.info("currentUserId -> "+currentUserId);
				ExecutorService executorService = Executors.newSingleThreadExecutor();
				executorService.execute(new Runnable() {
					@Override
					public void run() {
						// sendInvite(meetingRequest, "REQUEST", null,null,0);
						sendMeetingInvite(orgAppointment.getAppointmentId().toString(), "UPDATE",
								appointmentRequest.getAppointmentTs(), appointmentRequest.getDescription(), currentUserId);
					}
				});
			}

		}

		return new ResponseId(id.toString());
	}

	public void deleteAppointment(UUID id) {
		log.info("Inside deleteAppointment UUID : " + id);
		OrgAppointment orgAppointment = orgAppointmentRepository.findById(id).orElse(null);
		OrgAppointmentsHistory orgAppointmentsHistory = new OrgAppointmentsHistory();
		orgAppointmentsHistory = appointmentMapper.orgAppointmentToAppointmentsHistory(orgAppointment);
		orgAppointmentsHistory.setAppointmentStatusCd(2);
		orgAppointmentsHistory.setHistoryId(UUID.randomUUID());
		orgAppointmentsHistory.setModBy(super.getUserId());
		orgAppointmentsHistory.setModTs(new Timestamp(System.currentTimeMillis()));
		orgAppointmentsHistoryRepository.save(orgAppointmentsHistory);
		sendMeetingInvite(id.toString(), "CANCEL", null, null,"");
		orgAppointmentRepository.deleteById(id);

		this.createActivity(Constant.ACTIVITY_APPOINTMENT_DELETE);
	}

	public void createActivity(int statusCode) {
		OrgUserActivity orgUserActivity = new OrgUserActivity();
		orgUserActivity.setActivityId(UUID.randomUUID());
		orgUserActivity.setUserId(UUID.fromString(super.getUserId()));
		orgUserActivity.setModTs(new Timestamp(System.currentTimeMillis()));
		orgUserActivity.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgUserActivity.setCrtBy(super.getUserId());
		orgUserActivity.setModBy(super.getUserId());
		orgUserActivity.setActivityCd(statusCode);
		orgUserActivityRepository.save(orgUserActivity);
	}

	public ResponseId saveUpdateCalenderInvite(CalendarRequest calendarRequest, String inviteId, String appointmentId,
			Integer category, String method, String senderId) {
		CalenderInvite calenderInvite = new CalenderInvite();
		CalenderInvitePK calenderInvitePK = getCalenderInvitePK(inviteId, appointmentId);
		if (calenderInviteRepository.existsById(calenderInvitePK)) {
			calenderInvite = calenderInviteRepository.getOne(calenderInvitePK);
			calenderInvite.setSentToEmail(calendarRequest.getToEmail());
			calenderInvite.setSubject(calendarRequest.getSubject());
			calenderInvite.setBody(calendarRequest.getBody());
			calenderInvite.setMeetingEndTime(calendarRequest.getMeetingEndTime());
			calenderInvite.setMeetingStartTime(calendarRequest.getMeetingStartTime());
			calenderInvite.setCrtBy(senderId);
			calenderInvite.setModTs(new Timestamp(System.currentTimeMillis()));
			if (method.equals("CANCEL")) {
				calenderInvite.setStatus(Constant.CANCELED);
			} else {
				calenderInvite.setStatus(Constant.RESCHEDULED);
			}
			calenderInvite.setCategory(category);
		} else {
			calenderInvite.setId(calenderInvitePK);
			calenderInvite.setSentToEmail(calendarRequest.getToEmail());
			calenderInvite.setSubject(calendarRequest.getSubject());
			calenderInvite.setBody(calendarRequest.getBody());
			calenderInvite.setMeetingEndTime(calendarRequest.getMeetingEndTime());
			calenderInvite.setMeetingStartTime(calendarRequest.getMeetingStartTime());
			calenderInvite.setCrtBy(senderId);
			calenderInvite.setCrtTs(new Timestamp(System.currentTimeMillis()));
			calenderInvite.setModTs(new Timestamp(System.currentTimeMillis()));
			calenderInvite.setStatus(Constant.SCHEDULED);
			calenderInvite.setCategory(category);
		}
		calenderInvite = calenderInviteRepository.save(calenderInvite);
		return new ResponseId(calenderInvite.getId().getMeetingId());
	}

	private CalenderInvitePK getCalenderInvitePK(String inviteId, String appointmentId) {
		CalenderInvitePK pk = new CalenderInvitePK();
		pk.setAppointmentId(appointmentId);
		pk.setMeetingId(inviteId);

		return pk;
	}

	private OrgEmailTemplate getAppointmentTemplate(String templateName) {
		List<OrgEmailTemplate> temp = orgEmailTemplateRepository.findByName(templateName);
		if (temp != null && temp.size() > 0) {
			return temp.get(0);
		} else {
			BaseEmailTemplate template = getBaseAppointmentTemplate(templateName);
			if (template != null) {
				OrgEmailTemplate orgTemp = new OrgEmailTemplate();
				orgTemp.setSubject(template.getSubject());
				orgTemp.setTemplate(template.getTemplate());
				return orgTemp;
			} else {
				return null;
			}
		}
	}

	private BaseEmailTemplate getBaseAppointmentTemplate(String templateName) {
		List<BaseEmailTemplate> temp = baseEmailTemplateRepository.findByName(templateName);
		if (temp != null && temp.size() > 0) {
			return temp.get(0);
		}

		return null;
	}

	private void sendMeetingInvite(String appointmentId, String method, String appointmentTs, String description, String currentUserId) {
		try {
			OrgAppointment orgAppointment = orgAppointmentRepository.findById(UUID.fromString(appointmentId))
					.orElse(null);
			if (orgAppointment != null) {
				OrgUser sme = orgUserRepository.getOne(orgAppointment.getSmeUserId());
				OrgUser bookedBy = orgUserRepository.getOne(orgAppointment.getBookedBy());
				OrgSkill orgSkill = orgSkillRepository.getOne(orgAppointment.getSkillId());

				if (method.equals("REQUEST") || method.equals("UPDATE")) {
					method = "REQUEST";
				}
				log.info("sendMeetingInvite : method : " + method);
				String meetingDescription = description!=null && !description.isEmpty() ? description : orgAppointment.getDescription();
				String body = "", subject = "", htmlBody = "";
				if (orgAppointment.getSmeUserId().equals(currentUserId)) {
					OrgEmailTemplate requesterTemplate = getAppointmentTemplate(Constant.APPOINTMENT_REQUESTOR);
					body = getTempplate(requesterTemplate, sme, bookedBy, orgSkill.getSkillMnemonic(),
							meetingDescription, Constant.TEXT);
					subject = getSUbject(requesterTemplate, sme, bookedBy, orgSkill.getSkillMnemonic(),
							orgAppointment.getDescription());
					htmlBody = getTempplate(requesterTemplate, sme, bookedBy, orgSkill.getSkillMnemonic(),
							meetingDescription, Constant.HTML);
				} else {
					OrgEmailTemplate smeTemplate = getAppointmentTemplate(Constant.APPOINTMENT_SME);
					OrgEmailTemplate smeHtmlTemplate = getAppointmentTemplate(Constant.APPOINTMENT_SME_HTML);
					body = getTempplate(smeTemplate, sme, bookedBy, orgSkill.getSkillMnemonic(), meetingDescription,
							Constant.TEXT);
					subject = getSUbject(smeTemplate, sme, bookedBy, orgSkill.getSkillMnemonic(),
							orgAppointment.getDescription());
					htmlBody = getTempplate(smeHtmlTemplate, sme, bookedBy, orgSkill.getSkillMnemonic(),
							meetingDescription, Constant.HTML);
				}

				MeetingRequest meetingRequest = new MeetingRequest();
				if (appointmentTs != null) {
					meetingRequest.setMeetingStartTime(Timestamp.valueOf(appointmentTs));
					LocalDateTime meetingEndTime = Timestamp.valueOf(appointmentTs).toLocalDateTime()
							.plusMinutes(orgAppointment.getDuration());
					meetingRequest.setMeetingEndTime(Timestamp.valueOf(meetingEndTime));
				} else {
					meetingRequest.setMeetingStartTime(Timestamp.valueOf(orgAppointment.getBookingTs() + ""));
					LocalDateTime meetingEndTime = orgAppointment.getBookingTs().toLocalDateTime()
							.plusMinutes(orgAppointment.getDuration());
					meetingRequest.setMeetingEndTime(Timestamp.valueOf(meetingEndTime));
				}
				meetingRequest.setSkill(orgSkill.getSkillMnemonic());
				meetingRequest.setLocation(orgAppointment.getLocationCd());
				meetingRequest.setBody(body);
				meetingRequest.setHtmlBody(htmlBody);
				meetingRequest.setSubject(subject);
				meetingRequest.setAppointmentId(orgAppointment.getAppointmentId().toString());
				meetingRequest.setDescription(orgAppointment.getDescription());
				meetingRequest.setFacilitatorId(sme.getUserId());
				meetingRequest.setSenderId(bookedBy.getUserId());
				if (orgAppointment.getSmeUserId().equals(currentUserId)) {
					meetingRequest.setFacilitatorEmail(bookedBy.getUsrEmail());
					meetingRequest.setSenderEmail(sme.getUsrEmail());
				} else {
					meetingRequest.setFacilitatorEmail(sme.getUsrEmail());
					meetingRequest.setSenderEmail(bookedBy.getUsrEmail());
				}
				meetingRequest.setSmeName(sme.getUserFirstNm() + " " + sme.getUserLastNm());
				meetingRequest.setSenderName(bookedBy.getUserFirstNm() + " " + bookedBy.getUserLastNm());

				if (method.equalsIgnoreCase("REQUEST")) {
					meetingRequest.setStatus(Constant.SCHEDULED);
				} else if (method.equalsIgnoreCase("UPDATE")) {
					meetingRequest.setStatus(Constant.RESCHEDULED);
				} else {
					meetingRequest.setStatus(Constant.CANCELED);
					List<CalenderInvite> calenderInviteList = calenderInviteRepository
							.findByIdAppointmentIdOrderByCrtTsDesc(orgAppointment.getAppointmentId().toString());
					if (calenderInviteList != null && calenderInviteList.size() > 0) {
						CalenderInvite calenderInvite = calenderInviteList.get(0);
						meetingRequest.setMeetingStartTime(calenderInvite.getMeetingStartTime());
						meetingRequest.setMeetingEndTime(calenderInvite.getMeetingEndTime());
					}
				}
				meetingRequest.setCategory(0);
				sendMail(meetingRequest, method);
				log.info("Sendmail- mail sent successfully for appointmentId : " + appointmentId + ", method : "
						+ method);
			}
		} catch (Exception e) {
			log.error("Error in sending meeting inviate" + e.getMessage(), e);
		}
	}

	private void sendMail(MeetingRequest request, String method) throws MessagingException, IOException {
		CalendarRequest calendarRequest;
		calendarRequest = new CalendarRequest.Builder().withSubject(request.getSubject()).withBody(request.getBody())
				.withHtmlBody(request.getHtmlBody()).withToEmail(request.getFacilitatorEmail())
				.withMeetingStartTime(request.getMeetingStartTime()).withMeetingEndTime(request.getMeetingEndTime())
				.build();
		calendarRequest.setCcEmail(request.getSenderEmail());
		calendarRequest.setUid(request.getAppointmentId());
		calendarRequest.setSmeName(request.getSmeName());
		calendarRequest.setSenderName(request.getSenderName());
		calendarService.sendCalendarInvite(username, calendarRequest, method, request.getAppointmentId(),
				request.getAppointmentId(), request.getLocation(), organizerCn, request.getSubject());
		String meetingid = UUID.randomUUID().toString();
		saveUpdateCalenderInvite(calendarRequest, meetingid, request.getAppointmentId(), request.getCategory(), method,
				request.getSenderId());

	}

	private String getTempplate(OrgEmailTemplate orgTemp, OrgUser smeObj, OrgUser reqObj, String skill, String desc,
			String type) {
		String template = "";
		if (type.equalsIgnoreCase(Constant.TEXT)) {
			if (orgTemp != null && orgTemp.getTemplate() != null && orgTemp.getTemplate().length() > 0) {
				template = orgTemp.getTemplate();
			} else {
				template = "Hi &SME&, \n\n We have scheduled this meeting on &SENDER& request to have discussion on &SKILL&.\n\n  Comments from &SENDER& \n\n &COMMENTS& \n\n  Thanks \n\n SearchNxt Team";
			}
		} else {
			if (orgTemp != null && orgTemp.getTemplate() != null && orgTemp.getTemplate().length() > 0) {
				template = orgTemp.getTemplate();
			} else {
				template = "Hi &SME&, <br><br> We have scheduled this meeting on &SENDER& request to have discussion on &SKILL&.<br><br>  Comments from &SENDER& <br> &COMMENTS& <br><br>  Thanks <br> SearchNxt Team";
			}
		}
		template = template.replaceAll("&SME&", smeObj.getUserFirstNm() + " " + smeObj.getUserLastNm());
		template = template.replaceAll("&SENDER&", reqObj.getUserFirstNm() + " " + reqObj.getUserLastNm());
		template = template.replaceAll("&SKILL&", skill);
		template = template.replaceAll("&COMMENTS&", desc);

		return template;
	}

	private String getSUbject(OrgEmailTemplate orgTemp, OrgUser smeObj, OrgUser reqObj, String skill, String desc) {
		String template = "";
		if (orgTemp != null && orgTemp.getSubject() != null && orgTemp.getSubject().length() > 0) {
			template = orgTemp.getSubject();
		} else {
			template = "SearchNxt > Expert Connect > Meeting Request for &SKILL&";
		}
		template = template.replaceAll("&SME&", smeObj.getUserFirstNm() + " " + smeObj.getUserLastNm());
		template = template.replaceAll("&SENDER&", reqObj.getUserFirstNm() + " " + reqObj.getUserLastNm());
		template = template.replaceAll("&SKILL&", skill);
		template = template.replaceAll("&COMMENTS&", desc);

		return template;
	}

//	private CalendarService getCalendarServiceInstance() {
//		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
//		mailSender.setUsername(username);
//		mailSender.setPassword(password);
//		Properties properties = new Properties();
//		properties.put("mail.smtp.auth", mailSmtpAuth);
//		properties.put("mail.smtp.starttls.enable", mailSmtpStarttlsEnable);
//		properties.put("mail.smtp.host", mailSmtpHost);
//		properties.put("mail.smtp.port", mailSmtpPort);
//		mailSender.setJavaMailProperties(properties);
//		CalendarService calendarService = new CalendarService();
//
//		return calendarService;
//	}

	private void postToIncentive(String userId, String appntId, int status) {

		Notification notification;
		try {
			notification = new Notification();
			notification.setHttpMethod("PUT");
			notification.setRequestUri("/expertconnect-services/appointments/" + appntId);
			notification.setTenant(request.getHeader("tenant"));
			notification.setServiceName("/expertconnect-services");
			notification.setQueryString("appointmentStatusCode=" + status);
			notification.setUserId(userId);
			callExecutor(notification);
		} catch (Exception e) {
			log.error("Error in postToIncentive : " + e.getMessage(), e);
		}

	}

	private void callExecutor(Notification notification) {

		ExecutorService executorService = Executors.newSingleThreadExecutor();

		executorService.execute(new Runnable() {

			@Override
			public void run() {

				try {
					log.info("Event Will push in queue in Run--" + notification.toString());
					HttpHeaders headers = new HttpHeaders();
					headers.setContentType(MediaType.APPLICATION_JSON);
					headers.set("tenant", notification.getTenant());
					headers.set("userId", notification.getUserId());
					HttpEntity<Notification> entity = new HttpEntity<Notification>(notification, headers);
					akilaRestTemplate.exchange(restTemplateloadBalanced, incentiveServiceURL + "/publishevent", HttpMethod.POST, entity,
							Void.class);
					log.info("Event pushed in queue");
				} catch (Exception e) {
					log.error("Error in publishevent : " + e.getMessage(), e);
				}

			}
		});

	}

}
