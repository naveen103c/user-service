package com.akila.expertconnect.registration.bean;

import java.sql.Time;
import java.sql.Timestamp;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.akila.AkilaRequest;

public class RegistrationRequest extends AkilaRequest {

    @NotNull(message = "{SME.APPOINTMENT.STARTTS.MANDATORY}")
	private Time appointmentStartTs;
    
    @NotNull(message = "{SME.APPOINTMENT.ENDTS.MANDATORY}")
	private Time appointmentEndTs;

    @NotNull(message = "{SME.COMMUNITY.MANDATORY}")
    @NotEmpty(message = "{SME.COMMUNITY.MANDATORY}")
	private String communityId;

    @NotNull(message = "{SME.ENDDATE.MANDATORY}")
	private Timestamp endTs;

    @NotNull(message = "{SME.LOCATIONCD.MANDATORY}")
	private Integer locationCd;

    @NotNull(message = "{SME.SCHEDULETYPE.MANDATORY}")
	private Integer scheduleTypeCd;

    @NotNull(message = "{SME.STARTDATE.MANDATORY}")
	private Timestamp startTs;
	
    @NotNull(message = "{SME.SKILL.MANDATORY}")
    @NotEmpty(message = "{SME.SKILL.MANDATORY}")
	private String skillList;
	
   /* @Pattern(regexp="^(0[1-9|][0-9|]*)$",message = "{SME.SCHEDULECD.FORMAT}")*/
    @Pattern(regexp="^[0-9,]*$",message = "{SME.SCHEDULECD.FORMAT}")
	private String scheduleCd;
	
	@NotNull(message = "{SME.USER.NOTNULL}")
	@NotEmpty(message = "{SME.USER.NOTNULL}")
	private String userId;
	
	@NotNull(message = "{APPOINTMENT.DURATION.MANDATORY}")
	private String appointmentDuration;
	
	public String getScheduleCd() {
		return scheduleCd;
	}

	public void setScheduleCd(String scheduleCd) {
		this.scheduleCd = scheduleCd;
	}

	public Time getAppointmentStartTs() {
		return appointmentStartTs;
	}

	public void setAppointmentStartTs(Time appointmentStartTs) {
		this.appointmentStartTs = appointmentStartTs;
	}

	public Time getAppointmentEndTs() {
		return appointmentEndTs;
	}

	public void setAppointmentEndTs(Time appointmentEndTs) {
		this.appointmentEndTs = appointmentEndTs;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public void setEndTs(Timestamp endTs) {
		this.endTs = endTs;
	}

	public String getSkillList() {
		return skillList;
	}

	public void setSkillList(String skillList) {
		this.skillList = skillList;
	}

	public void setLocationCd(Integer locationCd) {
		this.locationCd = locationCd;
	}

	public void setScheduleTypeCd(Integer scheduleTypeCd) {
		this.scheduleTypeCd = scheduleTypeCd;
	}

	public void setStartTs(Timestamp startTs) {
		this.startTs = startTs;
	}

	public String getCommunityId() {
		return communityId;
	}

	public Timestamp getEndTs() {
		return endTs;
	}

	public Integer getLocationCd() {
		return locationCd;
	}

	public Integer getScheduleTypeCd() {
		return scheduleTypeCd;
	}

	public Timestamp getStartTs() {
		return startTs;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getAppointmentDuration() {
		return appointmentDuration;
	}

	public void setAppointmentDuration(String appointmentDuration) {
		this.appointmentDuration = appointmentDuration;
	}

}
