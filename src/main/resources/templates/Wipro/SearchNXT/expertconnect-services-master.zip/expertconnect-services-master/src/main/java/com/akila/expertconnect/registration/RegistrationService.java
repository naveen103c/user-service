package com.akila.expertconnect.registration;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.akila.AkilaService;
import com.akila.expertconnect.entity.OrgCommunitySme;
import com.akila.expertconnect.entity.OrgCommunitySmeRequest;
import com.akila.expertconnect.entity.OrgSmeAvailability;
import com.akila.expertconnect.entity.OrgUserActivity;
import com.akila.expertconnect.registration.bean.RegistrationMapper;
import com.akila.expertconnect.registration.bean.RegistrationRequest;
import com.akila.expertconnect.registration.bean.RegistrationResponse;
import com.akila.expertconnect.repository.OrgCommunitySmeRepository;
import com.akila.expertconnect.repository.OrgCommunitySmeRequestRepository;
import com.akila.expertconnect.repository.OrgSmeAvailabilityRepository;
import com.akila.expertconnect.repository.OrgUserActivityRepository;
import com.akila.response.ResponseId;

@Service
public class RegistrationService extends AkilaService {
	@Autowired
	private OrgSmeAvailabilityRepository orgSmeAvailabilityRepository;

	@Autowired
	private OrgCommunitySmeRequestRepository orgCommunitySmeRequestRepository;
	
	@Autowired
	private OrgCommunitySmeRepository orgCommunitySmeRepository;

	@Autowired
	private RegistrationMapper registrationMapper;
	
	@Autowired
	private OrgUserActivityRepository orgUserActivityRepository;

	public List<RegistrationResponse> getAllRegistration(@RequestParam String communityId,String requestStatusCd) {

		List<OrgCommunitySmeRequest> orgRegistrationList = null;
		if(communityId == null && requestStatusCd == null) {
			orgRegistrationList = orgCommunitySmeRequestRepository.findAll();
		}else if(communityId != null && requestStatusCd != null){
			orgRegistrationList = orgCommunitySmeRequestRepository.findAllSMERequestByCommunityIdAndRequestStatus(communityId,requestStatusCd);
		}
		else if(communityId != null){
			orgRegistrationList = orgCommunitySmeRequestRepository.findAllSMERequestByCommunityId(communityId);
		}
		else {
			orgRegistrationList = orgCommunitySmeRequestRepository.findAllSMERequestByRequestStatusCd(requestStatusCd);
		}

		return this.convertRegistrationListToResponseList(orgRegistrationList);
		
	}
	
	public RegistrationResponse getRegistrationByUserId(String userId) {
		
		List<OrgCommunitySme>  smeList= orgCommunitySmeRepository.findSMEByIdUserId(userId);
		RegistrationResponse registrationResponse = registrationMapper.OrgCommunitySmeToRegistrationResponse(smeList.get(0));
		return registrationResponse;
	}

	public RegistrationResponse getRegistration(String id) {
		OrgCommunitySmeRequest orgRegistration = orgCommunitySmeRequestRepository.findById(id).orElse(null);
		return registrationMapper.OrgCommunitySmeRequestToRegistrationResponse(orgRegistration);
	}

	@Transactional
	public ResponseId updateRegistration(String id, RegistrationRequest registrationRequest) {

		OrgCommunitySme orgCommunitySme = new OrgCommunitySme();
		orgCommunitySme.setId(this.getOrgCommunitySmePK(registrationRequest.getCommunityId(),registrationRequest.getUserId()));
		orgCommunitySme = orgCommunitySmeRepository.findById(orgCommunitySme.getId()).orElse(null);
		
		orgCommunitySme.setSkillList(registrationRequest.getSkillList());
		orgCommunitySme.setAppointmentStartTs(registrationRequest.getAppointmentStartTs());
		orgCommunitySme.setAppointmentEndTs(registrationRequest.getAppointmentEndTs());
		orgCommunitySme.setLocationCd(registrationRequest.getLocationCd());
		orgCommunitySme.setEndTs(registrationRequest.getEndTs());
		orgCommunitySme.setScheduleTypeCd(registrationRequest.getScheduleTypeCd());
		orgCommunitySme.setStartTs(registrationRequest.getStartTs());
		orgCommunitySme.setSkillList(registrationRequest.getSkillList());
		orgCommunitySme.setScheduleCd(registrationRequest.getScheduleCd().replace(",", "|"));
		orgCommunitySme.setSmeStatusCd(6);
		orgCommunitySme.setAppointmentDuration(registrationRequest.getAppointmentDuration());
		
		orgCommunitySme.setModTs(new Timestamp(System.currentTimeMillis()));
		orgCommunitySme.setModBy(super.getUserId());
		orgCommunitySmeRepository.save(orgCommunitySme);

		this.createActivity(4);
		return new ResponseId(id);
	}

	public ResponseId approveRegistration(String id) {
		OrgCommunitySmeRequest request = orgCommunitySmeRequestRepository.findById(id).orElse(null);
		if (request != null && request.getRequestStatusCd() == 6) {
			
			OrgCommunitySme orgCommunitySme = new OrgCommunitySme();
			orgCommunitySme.setId(this.getOrgCommunitySmePK(request.getCommunityId(),super.getUserId()));
			orgCommunitySme.setSkillList(request.getSkillList());
			orgCommunitySme.setSmeStatusCd(6);
			orgCommunitySme.setModTs(new Timestamp(System.currentTimeMillis()));
			orgCommunitySme.setCrtTs(new Timestamp(System.currentTimeMillis()));
			orgCommunitySme.setCrtBy(super.getUserId());
			orgCommunitySme.setModBy(super.getUserId());
			orgCommunitySmeRepository.save(orgCommunitySme);
			
			OrgSmeAvailability availableSme = registrationMapper.registrationRequestToOrgSmeAvailability(request);
			availableSme.setModTs(new Timestamp(System.currentTimeMillis()));
			availableSme.setModBy(super.getUserId());			
			orgSmeAvailabilityRepository.save(availableSme);
			request.setRequestStatusCd(7);
			//orgCommunitySmeRequestRepository.save(request);
		}
		this.createActivity(2);
		return new ResponseId((request.getRequestId()!=null)?request.getRequestId():"0");
	}

	public ResponseId declineRegistration(String id) {
		OrgCommunitySmeRequest request = orgCommunitySmeRequestRepository.getOne(id);
		request.setRequestStatusCd(8);
		request.setModTs(new Timestamp(System.currentTimeMillis()));
		request.setModBy(super.getUserId());
		orgCommunitySmeRequestRepository.save(request);
		this.createActivity(3);
		return new ResponseId(request.getRequestId());
	}
	
	public ResponseId deleteRegistration(String communityId,String userId) {
		OrgCommunitySme orgCommunitySme = orgCommunitySmeRepository.findById(this.getOrgCommunitySmePK(communityId,userId)).orElse(null);
		if(orgCommunitySme != null) {
			orgCommunitySmeRepository.deleteById(this.getOrgCommunitySmePK(communityId,userId));
		}
		return new ResponseId(userId);
	}

	public ResponseId addRegistration(RegistrationRequest registrationRequest) {

		OrgCommunitySme orgCommunitySme = new OrgCommunitySme();
		orgCommunitySme.setId(this.getOrgCommunitySmePK(registrationRequest.getCommunityId(),registrationRequest.getUserId()));
		orgCommunitySme.setSkillList(registrationRequest.getSkillList());
		orgCommunitySme.setAppointmentStartTs(registrationRequest.getAppointmentStartTs());
		orgCommunitySme.setAppointmentEndTs(registrationRequest.getAppointmentEndTs());
		orgCommunitySme.setLocationCd(registrationRequest.getLocationCd());
		orgCommunitySme.setEndTs(registrationRequest.getEndTs());
		orgCommunitySme.setScheduleTypeCd(registrationRequest.getScheduleTypeCd());
		orgCommunitySme.setStartTs(registrationRequest.getStartTs());
		orgCommunitySme.setSkillList(registrationRequest.getSkillList());
		orgCommunitySme.setScheduleCd(registrationRequest.getScheduleCd().replace(",", "|"));
		orgCommunitySme.setSmeStatusCd(6);
		orgCommunitySme.setAppointmentDuration(registrationRequest.getAppointmentDuration());
		orgCommunitySme.setModTs(new Timestamp(System.currentTimeMillis()));
		orgCommunitySme.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgCommunitySme.setCrtBy(super.getUserId());
		orgCommunitySme.setModBy(super.getUserId());
		orgCommunitySmeRepository.save(orgCommunitySme);

		this.createActivity(1);
		return new ResponseId(registrationRequest.getUserId());
	}
	
	
	public List<RegistrationResponse> convertRegistrationListToResponseList(
			List<OrgCommunitySmeRequest> requestList) {

		List<RegistrationResponse> requestResponseList = new ArrayList<RegistrationResponse>();
		for (OrgCommunitySmeRequest request : requestList) {
			RegistrationResponse registrationResponse = registrationMapper.OrgCommunitySmeRequestToRegistrationResponse(request);
			registrationResponse.setUserName(request.getUser().getUserFirstNm());

			requestResponseList.add(registrationResponse);
		}

		return requestResponseList;
	}

	public void createActivity(int statusCode) {
		OrgUserActivity orgUserActivity = new OrgUserActivity();
		orgUserActivity.setActivityId(UUID.randomUUID());
		orgUserActivity.setUserId(UUID.fromString(super.getUserId()));
		orgUserActivity.setModTs(new Timestamp(System.currentTimeMillis()));
		orgUserActivity.setCrtTs(new Timestamp(System.currentTimeMillis()));
		orgUserActivity.setCrtBy(super.getUserId());
		orgUserActivity.setModBy(super.getUserId());
		orgUserActivity.setActivityCd(statusCode);
		orgUserActivityRepository.save(orgUserActivity);
		
	}
	
	public com.akila.expertconnect.entity.OrgCommunitySmePK getOrgCommunitySmePK(String communityId,String userId) {
		com.akila.expertconnect.entity.OrgCommunitySmePK orgCommunitySmePK = new com.akila.expertconnect.entity.OrgCommunitySmePK();
		orgCommunitySmePK.setUserId(userId);
		orgCommunitySmePK.setCommunityId(communityId);
		return orgCommunitySmePK;
	}
		
}
