package com.akila.expertconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.expertconnect.entity.CalenderInvite;
import com.akila.expertconnect.entity.CalenderInvitePK;

@Repository
public interface CalenderInviteRepository extends JpaRepository<CalenderInvite, CalenderInvitePK> {

	List<CalenderInvite> getCalenderInviteByIdAppointmentId(@Param("appointmentId") String appointmentId);
	
	List<CalenderInvite> findByIdAppointmentIdOrderByCrtTsDesc(String appointmentId);

}
