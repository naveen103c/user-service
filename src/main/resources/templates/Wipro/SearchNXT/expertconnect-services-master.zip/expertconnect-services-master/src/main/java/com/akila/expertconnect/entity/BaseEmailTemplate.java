package com.akila.expertconnect.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.akila.AkilaEntity;

@Entity
@Table(name="base_email_template", schema = "base")
public class BaseEmailTemplate extends AkilaEntity implements Serializable{

	@Id
	@Column(name="template_id")
	String templateId;
	
	@Column(name="name")
	String name;
	
	@Column(name="description")
	String description;
	
	@Column(name="subject")
	String subject;
	
	@Column(name="template")
	String template;
	
	@Column(name="defaultto")
	String defaultto;
	
	@Column(name="defaultcc")
	String defaultcc;
	
	@Column(name="status")
	Integer status;

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}

	public String getDefaultto() {
		return defaultto;
	}

	public void setDefaultto(String defaultto) {
		this.defaultto = defaultto;
	}

	public String getDefaultcc() {
		return defaultcc;
	}

	public void setDefaultcc(String defaultcc) {
		this.defaultcc = defaultcc;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	
	
}
