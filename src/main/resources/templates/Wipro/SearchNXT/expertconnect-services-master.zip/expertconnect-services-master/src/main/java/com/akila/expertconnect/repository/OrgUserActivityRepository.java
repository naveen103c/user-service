package com.akila.expertconnect.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.expertconnect.entity.OrgUserActivity;

@Repository
public interface OrgUserActivityRepository extends JpaRepository<OrgUserActivity, UUID> {
	
	@Query("select o from OrgUserActivity o where  (cast(:userId as org.hibernate.type.UUIDCharType) is null or o.userId = :userId) "
			+ " and (:activityCd = 0 or  o.activityCd = (:activityCd)) " )
	public List<OrgUserActivity> findAllSMEByFilter(UUID userId,Integer activityCd);
}
