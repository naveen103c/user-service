package com.akila.expertconnect.entity;

import com.akila.AkilaEntity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the org_skills database table.
 * 
 */
@Entity
@Table(name="org_skills")
@NamedQuery(name="OrgSkill.findAll", query="SELECT o FROM OrgSkill o")
public class OrgSkill extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="skill_id")
	private String skillId;

	@Column(name="crt_by")
	private String crtBy;

	@Column(name="crt_ts")
	private Timestamp crtTs;

	private String description;

	@Column(name="mod_by")
	private String modBy;

	@Column(name="mod_ts")
	private Timestamp modTs;

	@Column(name="skill_mnemonic")
	private String skillMnemonic;

	public OrgSkill() {
	}

	public String getSkillId() {
		return this.skillId;
	}

	public void setSkillId(String skillId) {
		this.skillId = skillId;
	}

	public String getCrtBy() {
		return this.crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getModBy() {
		return this.modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Timestamp getModTs() {
		return this.modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public String getSkillMnemonic() {
		return this.skillMnemonic;
	}

	public void setSkillMnemonic(String skillMnemonic) {
		this.skillMnemonic = skillMnemonic;
	}

}