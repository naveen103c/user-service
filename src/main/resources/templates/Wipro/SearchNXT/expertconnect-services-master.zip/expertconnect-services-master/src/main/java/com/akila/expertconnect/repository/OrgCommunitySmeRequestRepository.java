package com.akila.expertconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.expertconnect.entity.OrgCommunitySmeRequest;

@Repository
public interface OrgCommunitySmeRequestRepository extends JpaRepository<OrgCommunitySmeRequest, String> {
	
	@Query("select o from OrgCommunitySmeRequest o where o.communityId = (:communityId)")
	public List<OrgCommunitySmeRequest> findAllSMERequestByCommunityId(String communityId);
	
	@Query("select o from OrgCommunitySmeRequest o where o.userId = (:userId)")
	public OrgCommunitySmeRequest findByUserId(String userId);
	
	@Query("select o from OrgCommunitySmeRequest o where o.requestStatusCd = (:requestStatusCd)")
	public List<OrgCommunitySmeRequest> findAllSMERequestByRequestStatusCd(String requestStatusCd);
	
	@Query("select o from OrgCommunitySmeRequest o where o.communityId = (:communityId) and o.requestStatusCd = (:requestStatusCd)")
	public List<OrgCommunitySmeRequest> findAllSMERequestByCommunityIdAndRequestStatus(String communityId,String requestStatusCd);
	
	
}
