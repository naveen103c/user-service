package com.akila.expertconnect.appointment.bean;

import java.sql.Timestamp;
import java.util.UUID;

import com.akila.AkilaResponse;

public class AppointmentResponse extends AkilaResponse {

	private UUID appointmentId;

	private Integer appointmentStatusCd;

	private String bookedBy;

	private Timestamp bookingTs;

	private String cancelledReason;

	private String description;

	private Integer duration;

	private String feedback;

	private Integer locationCd;

	private String skillId;

	private String smeUserId;

	public UUID getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(UUID appointmentId) {
		this.appointmentId = appointmentId;
	}

	public Integer getAppointmentStatusCd() {
		return appointmentStatusCd;
	}

	public void setAppointmentStatusCd(Integer appointmentStatusCd) {
		this.appointmentStatusCd = appointmentStatusCd;
	}

	public String getBookedBy() {
		return bookedBy;
	}

	public void setBookedBy(String bookedBy) {
		this.bookedBy = bookedBy;
	}

	public Timestamp getBookingTs() {
		return bookingTs;
	}

	public void setBookingTs(Timestamp bookingTs) {
		this.bookingTs = bookingTs;
	}

	public String getCancelledReason() {
		return cancelledReason;
	}

	public void setCancelledReason(String cancelledReason) {
		this.cancelledReason = cancelledReason;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public Integer getLocationCd() {
		return locationCd;
	}

	public void setLocationCd(Integer locationCd) {
		this.locationCd = locationCd;
	}

	public String getSkillId() {
		return skillId;
	}

	public void setSkillId(String skillId) {
		this.skillId = skillId;
	}

	public String getSmeUserId() {
		return smeUserId;
	}

	public void setSmeUserId(String smeUserId) {
		this.smeUserId = smeUserId;
	}

}
