package com.akila.expertconnect.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.expertconnect.entity.OrgSmeAvailability;

@Repository
public interface OrgSmeAvailabilityRepository extends JpaRepository<OrgSmeAvailability, String> {
	
	@Query("select o from OrgSmeAvailability o where o.userId = (:userId)")
	public OrgSmeAvailability findByUserId(String userId);
	
	public OrgSmeAvailability findByAvailabilityId(String availableId);
	
	
}
