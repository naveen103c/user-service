package com.akila.expertconnect.appointment.bean;

public final class Constant {

	public static final String SENDER_BODY = "Hi sender, \n"
											+ "Meeting invite has been sent to facilitator for skill \n";
	public static final String FACILITATOR_BODY = "Hi facilitator, \n"
												+ "sender has scheduled a meeting for skill \n";
	public static final String SUBJECT = "Meeting schedule for skill";
	public static final int SCHEDULED = 1;
	public static final int RESCHEDULED = 2;
	public static final int CANCELED = 3;
	
	public static final int SENDER = 1;
	public static final int FACILITATOR = 2;
	
	public static final int APPOINTMENT_SCHEDULED = 1;
	public static final int APPOINTMENT_RESCHEDULED = 4;
	public static final int APPOINTMENT_CANCELED = 2;
	public static final int APPOINTMENT_COMPLETE = 3;
	
	
	public static final int ACTIVITY_SME_APPLIED = 1;
	public static final int ACTIVITY_SME_APPROVED = 2;
	public static final int ACTIVITY_SME_DECLINE = 3;
	public static final int ACTIVITY_SME_UPDATED = 4;
	public static final int ACTIVITY_APPOINTMENT_BOOK = 5;
	public static final int ACTIVITY_APPOINTMENT_CANCEL = 6;
	public static final int ACTIVITY_APPOINTMENT_RESCHEDUE = 7;
	public static final int ACTIVITY_APPOINTMENT_DELETE = 8;
	public static final int ACTIVITY_APPOINTMENT_COMPLETE = 9;
	
	public static final int MATRIC_RESULT_LIMIT = 10;
	
	public static final String APPOINTMENT_REQUESTOR="APPOINTMENT_REQUESTOR";
	public static final String APPOINTMENT_SME="APPOINTMENT_SME";
	public static final String APPOINTMENT_SME_HTML="APPOINTMENT_SME_HTML";
	
	public static final String TEXT="text";
	public static final String HTML="html";
	
	
}
