package com.akila.expertconnect.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.expertconnect.entity.OrgAppointmentsHistory;

@Repository
public interface OrgAppointmentsHistoryRepository extends JpaRepository<OrgAppointmentsHistory, String> {
	
	@Query("select o from OrgAppointmentsHistory o where  (cast(:bookedBy as org.hibernate.type.UUIDCharType) is null or o.smeUserId = :bookedBy or o.bookedBy = :bookedBy) "
			+ " and ((:appStatusCd) = 0 or  o.appointmentStatusCd = (:appStatusCd)) " )
	public List<OrgAppointmentsHistory> orgAppointmentsHistoryRepository(@Param("bookedBy") String bookedBy,Integer appStatusCd);

}
