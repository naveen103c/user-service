package com.akila.expertconnect.activity;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.akila.AkilaService;
import com.akila.expertconnect.activity.bean.ActivityMapper;
import com.akila.expertconnect.activity.bean.ActivityResponse;
import com.akila.expertconnect.entity.OrgUserActivity;
import com.akila.expertconnect.repository.OrgUserActivityRepository;

@Service
public class ActivityService extends AkilaService {

	@Autowired
	private OrgUserActivityRepository orgUserActivityRepository;

	@Autowired
	private ActivityMapper activityMapper;

	public List<ActivityResponse> getAllActivity(@RequestParam UUID communityId, @RequestParam UUID userId,
			@RequestParam Integer activityCd) {

		List<OrgUserActivity> list = orgUserActivityRepository.findAllSMEByFilter(userId, activityCd);
		return activityMapper.orgUserActivityToActivityResponseList(list);
	}

	public ActivityResponse getActivity(UUID id) {
		OrgUserActivity orgUserActivity = orgUserActivityRepository.getOne(id);
		return activityMapper.orgUserActivityToActivityResponse(orgUserActivity);
	}
}
