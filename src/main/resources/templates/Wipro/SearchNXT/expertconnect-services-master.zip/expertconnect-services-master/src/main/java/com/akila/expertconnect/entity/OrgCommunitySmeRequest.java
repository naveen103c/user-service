package com.akila.expertconnect.entity;

import com.akila.AkilaEntity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Time;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the org_community_sme_requests database table.
 * 
 */
@Entity
@Table(name="org_community_sme_requests")
@NamedQuery(name="OrgCommunitySmeRequest.findAll", query="SELECT o FROM OrgCommunitySmeRequest o")
public class OrgCommunitySmeRequest extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="request_id")
	private String requestId;

	@Column(name="available_time")
	private Time availableTime;

	@Column(name="community_id")
	private String communityId;

	@Column(name="crt_by")
	private String crtBy;

	@Column(name="crt_ts")
	private Timestamp crtTs;

	@Temporal(TemporalType.DATE)
	@Column(name="end_ts")
	private Date endTs;

	@Column(name="location_cd")
	private Integer locationCd;

	@Column(name="mod_by")
	private String modBy;

	@Column(name="mod_ts")
	private Timestamp modTs;

	@Column(name="request_status_cd")
	private Integer requestStatusCd;

	@Column(name="schedule_type_cd")
	private Integer scheduleTypeCd;

	@Column(name="skill_list")
	private String skillList;

	@Temporal(TemporalType.DATE)
	@Column(name="start_ts")
	private Date startTs;

	@Column(name="user_id")
	private String userId;

	@Column(name="schedule_cd")
	private String scheduleCd;

	

    @OneToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "user_id",insertable = false,updatable = false, nullable = false)
	OrgUser user;
	
	
	public OrgUser getUser() {
		return user;
	}

	public void setUser(OrgUser user) {
		this.user = user;
	}

	public OrgCommunitySmeRequest() {
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public Time getAvailableTime() {
		return this.availableTime;
	}

	public void setAvailableTime(Time availableTime) {
		this.availableTime = availableTime;
	}

	public String getCommunityId() {
		return this.communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public String getCrtBy() {
		return this.crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public Date getEndTs() {
		return this.endTs;
	}

	public void setEndTs(Date endTs) {
		this.endTs = endTs;
	}

	public Integer getLocationCd() {
		return this.locationCd;
	}

	public void setLocationCd(Integer locationCd) {
		this.locationCd = locationCd;
	}

	public String getModBy() {
		return this.modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Timestamp getModTs() {
		return this.modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public Integer getRequestStatusCd() {
		return this.requestStatusCd;
	}

	public void setRequestStatusCd(Integer requestStatusCd) {
		this.requestStatusCd = requestStatusCd;
	}

	public Integer getScheduleTypeCd() {
		return this.scheduleTypeCd;
	}

	public void setScheduleTypeCd(Integer scheduleTypeCd) {
		this.scheduleTypeCd = scheduleTypeCd;
	}

	public String getSkillList() {
		return this.skillList;
	}

	public void setSkillList(String skillList) {
		this.skillList = skillList;
	}

	public Date getStartTs() {
		return this.startTs;
	}

	public void setStartTs(Date startTs) {
		this.startTs = startTs;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getScheduleCd() {
		return scheduleCd;
	}

	public void setScheduleCd(String scheduleCd) {
		this.scheduleCd = scheduleCd;
	}

}