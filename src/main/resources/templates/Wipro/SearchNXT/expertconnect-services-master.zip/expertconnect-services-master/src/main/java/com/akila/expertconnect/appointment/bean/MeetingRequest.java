package com.akila.expertconnect.appointment.bean;

import java.sql.Timestamp;

public class MeetingRequest {
	private String appointmentId;
	private String senderId;
	private String senderEmail;
	private String facilitatorId;
	private String facilitatorEmail;
	private String subject;
	private String body;
	private String htmlBody;
	private Timestamp meetingStartTime;
	private Timestamp meetingEndTime;
	private int status;
	private int category;
	private String skill;
	private int location;
	private String description;
	private String smeName;
	private String senderName;

	public int getLocation() {
		return location;
	}

	public void setLocation(int location) {
		this.location = location;
	}

	public String getSkill() {
		return skill;
	}

	public void setSkill(String skill) {
		this.skill = skill;
	}

	public int getCategory() {
		return category;
	}

	public void setCategory(int category) {
		this.category = category;
	}

	public String getSubject() {
		return subject;
	}

	public String getAppointmentId() {
		return appointmentId;
	}

	public void setAppointmentId(String appointmentId) {
		this.appointmentId = appointmentId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getSenderId() {
		return senderId;
	}

	public void setSenderId(String senderId) {
		this.senderId = senderId;
	}

	public String getFacilitatorId() {
		return facilitatorId;
	}

	public void setFacilitatorId(String facilitatorId) {
		this.facilitatorId = facilitatorId;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}
	
	public String getHtmlBody() {
		return htmlBody;
	}

	public void setHtmlBody(String htmlBody) {
		this.htmlBody = htmlBody;
	}

	public Timestamp getMeetingStartTime() {
		return meetingStartTime;
	}

	public void setMeetingStartTime(Timestamp meetingStartTime) {
		this.meetingStartTime = meetingStartTime;
	}

	public Timestamp getMeetingEndTime() {
		return meetingEndTime;
	}

	public void setMeetingEndTime(Timestamp meetingEndTime) {
		this.meetingEndTime = meetingEndTime;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSenderEmail() {
		return senderEmail;
	}

	public void setSenderEmail(String senderEmail) {
		this.senderEmail = senderEmail;
	}

	public String getFacilitatorEmail() {
		return facilitatorEmail;
	}

	public void setFacilitatorEmail(String facilitatorEmail) {
		this.facilitatorEmail = facilitatorEmail;
	}

	public String getSmeName() {
		return smeName;
	}

	public void setSmeName(String smeName) {
		this.smeName = smeName;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	@Override
	public String toString() {
		return "MeetingRequest [appointmentId=" + appointmentId + ", senderId=" + senderId + ", senderEmail="
				+ senderEmail + ", facilitatorId=" + facilitatorId + ", facilitatorEmail=" + facilitatorEmail
				+ ", subject=" + subject + ", body=" + body + ", htmlBody=" + htmlBody + ", meetingStartTime="
				+ meetingStartTime + ", meetingEndTime=" + meetingEndTime + ", status=" + status + ", category="
				+ category + ", skill=" + skill + ", location=" + location + ", description=" + description
				+ ", smeName=" + smeName + ", senderName=" + senderName + "]";
	}
}