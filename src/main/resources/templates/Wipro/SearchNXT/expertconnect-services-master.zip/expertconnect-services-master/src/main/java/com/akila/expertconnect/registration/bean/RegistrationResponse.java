package com.akila.expertconnect.registration.bean;

import com.akila.AkilaResponse;
import java.lang.Integer;
import java.lang.String;
import java.sql.Time;
import java.sql.Timestamp;

/**
 * @author CORP\wiga-dev
 *
 */
public class RegistrationResponse extends AkilaResponse {

	private String requestId;

	private String communityId;

	private Timestamp endTs;

	private Integer locationCd;

	private Integer scheduleTypeCd;

	private Timestamp startTs;
	
	private String skillList;
	
	private String userId;
	
	private Time appointmentStartTs;
	
    private Time appointmentEndTs;
	
	private Integer appointmentDuration;
	
	private String userName;
	
	private String scheduleCd;
	
	private Integer requestStatusCd;
	
	public String getScheduleCd() {
		return scheduleCd;
	}

	public void setScheduleCd(String scheduleCd) {
		this.scheduleCd = scheduleCd;
	}
	
	public Integer getRequestStatusCd() {
		return requestStatusCd;
	}

	public void setRequestStatusCd(Integer requestStatusCd) {
		this.requestStatusCd = requestStatusCd;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getSkillList() {
		return skillList;
	}

	public Time getAppointmentStartTs() {
		return appointmentStartTs;
	}

	public void setAppointmentStartTs(Time appointmentStartTs) {
		this.appointmentStartTs = appointmentStartTs;
	}

	public Time getAppointmentEndTs() {
		return appointmentEndTs;
	}

	public void setAppointmentEndTs(Time appointmentEndTs) {
		this.appointmentEndTs = appointmentEndTs;
	}

	public Integer getAppointmentDuration() {
		return appointmentDuration;
	}

	public void setAppointmentDuration(Integer appointmentDuration) {
		this.appointmentDuration = appointmentDuration;
	}

	public void setSkillList(String skillList) {
		this.skillList = skillList;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public void setEndTs(Timestamp endTs) {
		this.endTs = endTs;
	}

	public void setLocationCd(Integer locationCd) {
		this.locationCd = locationCd;
	}

	public void setScheduleTypeCd(Integer scheduleTypeCd) {
		this.scheduleTypeCd = scheduleTypeCd;
	}

	public void setStartTs(Timestamp startTs) {
		this.startTs = startTs;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCommunityId() {
		return communityId;
	}

	public Timestamp getEndTs() {
		return endTs;
	}

	public Integer getLocationCd() {
		return locationCd;
	}

	public Integer getScheduleTypeCd() {
		return scheduleTypeCd;
	}

	public Timestamp getStartTs() {
		return startTs;
	}

	public String getUserId() {
		return userId;
	}
}
