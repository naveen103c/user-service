package com.akila.expertconnect.helper.bean;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.akila.expertconnect.entity.OrgCommunitySme;


@Mapper(
    componentModel = "spring"
)
public interface HelperMapper {
  HelperMapper INSTANCE = Mappers.getMapper(HelperMapper.class);

  @Mappings({
	  @Mapping(source = "id.communityId" , target = "communityId"),
	  @Mapping(source = "id.userId" , target = "userId")
  })  
 OrgCommunitySmeResponse communitySmeToResponse(
      OrgCommunitySme baseRegistration);

}
