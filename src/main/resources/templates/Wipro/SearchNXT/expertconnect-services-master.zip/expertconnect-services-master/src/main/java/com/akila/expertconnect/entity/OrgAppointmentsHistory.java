package com.akila.expertconnect.entity;

import com.akila.AkilaEntity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.UUID;


/**
 * The persistent class for the org_appointments_history database table.
 * 
 */
@Entity
@Table(name="org_appointments_history")
@NamedQuery(name="OrgAppointmentsHistory.findAll", query="SELECT o FROM OrgAppointmentsHistory o")
public class OrgAppointmentsHistory extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="history_id")
	private UUID historyId;

	@Column(name="appointment_id")
	private UUID appointmentId;

	@Column(name="appointment_status_cd")
	private Integer appointmentStatusCd;

	@Column(name="booked_by")
	private String bookedBy;

	@Column(name="booking_ts")
	private Timestamp bookingTs;

	@Column(name="cancelled_reason")
	private String cancelledReason;

	@Column(name="crt_by")
	private String crtBy;

	@Column(name="crt_ts")
	private Timestamp crtTs;

	private String description;

	private Integer duration;

	private String feedback;

	@Column(name="location_cd")
	private Integer locationCd;

	@Column(name="mod_by")
	private String modBy;

	@Column(name="mod_ts")
	private Timestamp modTs;

	@Column(name="skill_id")
	private String skillId;

	@Column(name="sme_user_id")
	private String smeUserId;

	@Column(name="booking_end_ts")
	private Timestamp bookingEndTs;
	
	public OrgAppointmentsHistory() {
	}

	public UUID getHistoryId() {
		return this.historyId;
	}

	public void setHistoryId(UUID historyId) {
		this.historyId = historyId;
	}

	public UUID getAppointmentId() {
		return this.appointmentId;
	}

	public void setAppointmentId(UUID appointmentId) {
		this.appointmentId = appointmentId;
	}

	public Integer getAppointmentStatusCd() {
		return this.appointmentStatusCd;
	}

	public void setAppointmentStatusCd(Integer appointmentStatusCd) {
		this.appointmentStatusCd = appointmentStatusCd;
	}

	public String getBookedBy() {
		return this.bookedBy;
	}

	public void setBookedBy(String bookedBy) {
		this.bookedBy = bookedBy;
	}

	public Timestamp getBookingTs() {
		return this.bookingTs;
	}

	public void setBookingTs(Timestamp bookingTs) {
		this.bookingTs = bookingTs;
	}

	public String getCancelledReason() {
		return this.cancelledReason;
	}

	public void setCancelledReason(String cancelledReason) {
		this.cancelledReason = cancelledReason;
	}

	public String getCrtBy() {
		return this.crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getDuration() {
		return this.duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getFeedback() {
		return this.feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public Integer getLocationCd() {
		return this.locationCd;
	}

	public void setLocationCd(Integer locationCd) {
		this.locationCd = locationCd;
	}

	public String getModBy() {
		return this.modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Timestamp getModTs() {
		return this.modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public String getSkillId() {
		return this.skillId;
	}

	public void setSkillId(String skillId) {
		this.skillId = skillId;
	}

	public String getSmeUserId() {
		return this.smeUserId;
	}

	public void setSmeUserId(String smeUserId) {
		this.smeUserId = smeUserId;
	}

	public Timestamp getBookingEndTs() {
		return bookingEndTs;
	}

	public void setBookingEndTs(Timestamp bookingEndTs) {
		this.bookingEndTs = bookingEndTs;
	}

}