package com.akila.expertconnect.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;

/**
 * The persistent class for the calender_invite_audit database table.
 */

@Entity

@Table(name = "calender_invite")

@NamedQuery(name = "CalenderInvite.findAll", query = "SELECT o FROM CalenderInvite o")

public class CalenderInvite extends AkilaEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private CalenderInvitePK id;

	@Column(name = "sent_to_email")
	private String sentToEmail;

	@Column(name = "subject")
	private String subject;

	@Column(name = "body")
	private String body;

	@Column(name = "meeting_start_time")
	private Timestamp meetingStartTime;

	@Column(name = "meeting_end_time")
	private Timestamp meetingEndTime;

	@Column(name = "status")
	private Integer status;
	
	@Column(name = "category")
	private Integer category;

	public CalenderInvite() {

	}

	public Integer getCategory() {
		return category;
	}

	public void setCategory(Integer category) {
		this.category = category;
	}

	public CalenderInvitePK getId() {
		return id;
	}

	public void setId(CalenderInvitePK id) {
		this.id = id;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getSentToEmail() {
		return sentToEmail;
	}

	public void setSentToEmail(String sentToEmail) {
		this.sentToEmail = sentToEmail;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public Timestamp getMeetingStartTime() {
		return meetingStartTime;
	}

	public void setMeetingStartTime(Timestamp meetingStartTime) {
		this.meetingStartTime = meetingStartTime;
	}

	public Timestamp getMeetingEndTime() {
		return meetingEndTime;
	}

	public void setMeetingEndTime(Timestamp meetingEndTime) {
		this.meetingEndTime = meetingEndTime;
	}

}