package com.akila.expertconnect.entity;

import com.akila.AkilaEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Time;
import java.sql.Timestamp;


/**
 * The persistent class for the org_sme_availability database table.
 * 
 */
@Entity
@Table(name="org_sme_availability")
@NamedQuery(name="OrgSmeAvailability.findAll", query="SELECT o FROM OrgSmeAvailability o")
public class OrgSmeAvailability extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="availability_id")
	private String availabilityId;

	@Column(name="community_id")
	private String communityId;

	@Column(name="available_time")
	private Time availableTime;
	
	@JsonIgnore
	@Column(name="crt_by")
	private String crtBy;
	@JsonIgnore
	@Column(name="crt_ts")
	private Timestamp crtTs;

	@Column(name="end_ts")
	private Timestamp endTs;

	@Column(name="location_cd")
	private Integer locationCd;

	@JsonIgnore
	@Column(name="mod_by")
	private String modBy;
	
	@JsonIgnore
	@Column(name="mod_ts")
	private Timestamp modTs;

	@Column(name="schedule_type_cd")
	private Integer scheduleTypeCd;

	@Column(name="start_ts")
	private Timestamp startTs;

	@Column(name="user_id")
	private String userId;

	@Column(name="schedule_cd")
	private String scheduleCd;


    @OneToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "user_id",insertable = false,updatable = false, nullable = false)
	OrgUser user;
    
	public OrgSmeAvailability() {
	}

	public String getAvailabilityId() {
		return this.availabilityId;
	}

	public void setAvailabilityId(String availabilityId) {
		this.availabilityId = availabilityId;
	}

	public String getCommunityId() {
		return this.communityId;
	}

	public String getScheduleCd() {
		return scheduleCd;
	}

	public void setScheduleCd(String scheduleCd) {
		this.scheduleCd = scheduleCd;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public String getCrtBy() {
		return this.crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public Timestamp getEndTs() {
		return this.endTs;
	}

	public void setEndTs(Timestamp endTs) {
		this.endTs = endTs;
	}

	public Integer getLocationCd() {
		return this.locationCd;
	}

	public void setLocationCd(Integer locationCd) {
		this.locationCd = locationCd;
	}

	public String getModBy() {
		return this.modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Time getAvailableTime() {
		return availableTime;
	}

	public void setAvailableTime(Time availableTime) {
		this.availableTime = availableTime;
	}

	public Timestamp getModTs() {
		return this.modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public Integer getScheduleTypeCd() {
		return this.scheduleTypeCd;
	}

	public void setScheduleTypeCd(Integer scheduleTypeCd) {
		this.scheduleTypeCd = scheduleTypeCd;
	}

	public Timestamp getStartTs() {
		return this.startTs;
	}

	public void setStartTs(Timestamp startTs) {
		this.startTs = startTs;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public OrgUser getUser() {
		return user;
	}

	public void setUser(OrgUser user) {
		this.user = user;
	}

}