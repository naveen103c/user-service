package com.akila.expertconnect.appointment.bean;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.akila.expertconnect.entity.OrgAppointment;
import com.akila.expertconnect.entity.OrgAppointmentsHistory;

@Mapper(componentModel = "spring")
public interface AppointmentMapper {
	AppointmentMapper INSTANCE = Mappers.getMapper(AppointmentMapper.class);;

	@Mappings({})
	List<AppointmentResponse> orgSmeAvailabilityListToAppointmentResponseList(List<OrgAppointment> orgSmeAvailability);

	@Mappings({})
	AppointmentResponse orgSmeAvailabilityToAppointmentResponse(OrgAppointment orgSmeAvailability);

	@Mappings({})
	OrgAppointment orgAppointmentToAppointmentRequest(AppointmentRequest appointmentRequest);
	
	@Mappings({})
	OrgAppointmentsHistory orgAppointmentToAppointmentsHistory(OrgAppointment appointment);
	

	@Mappings({})
	List<AppointmentResponse> orgSmeAvailabilityHistoryListToAppointmentResponseList(List<OrgAppointmentsHistory> orgAppointmentsHistoryList);

}
