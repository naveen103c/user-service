package com.akila.expertconnect.activity.bean;

import com.akila.AkilaResponse;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.lang.Integer;
import java.lang.String;
import java.sql.Timestamp;
import java.util.UUID;

public class ActivityResponse extends AkilaResponse {
  private UUID activityId;

  private Integer activityCd;

  @JsonIgnore
  private String crtBy;

  private Timestamp crtTs;

  @JsonIgnore
  private String modBy;

  @JsonIgnore
  private Timestamp modTs;

  private UUID userId;

  public void setActivityId(UUID activityId) {
    this.activityId = activityId;
  }

  public void setActivityCd(Integer activityCd) {
    this.activityCd = activityCd;
  }

  public void setCrtBy(String crtBy) {
    this.crtBy = crtBy;
  }

  public void setCrtTs(Timestamp crtTs) {
    this.crtTs = crtTs;
  }

  public void setModBy(String modBy) {
    this.modBy = modBy;
  }

  public void setModTs(Timestamp modTs) {
    this.modTs = modTs;
  }

  public void setUserId(UUID userId) {
    this.userId = userId;
  }

  public UUID getActivityId() {
    return activityId;
  }

  public Integer getActivityCd() {
    return activityCd;
  }

  public String getCrtBy() {
    return crtBy;
  }

  public Timestamp getCrtTs() {
    return crtTs;
  }

  public String getModBy() {
    return modBy;
  }

  public Timestamp getModTs() {
    return modTs;
  }

  public UUID getUserId() {
    return userId;
  }
}
