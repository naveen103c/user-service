package com.akila.expertconnect.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.expertconnect.entity.OrgSkill;

@Repository
public interface OrgSkillRepository extends JpaRepository<OrgSkill, String> {
}