package com.akila.expertconnect.activity.bean;

import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.akila.expertconnect.entity.OrgUserActivity;

@Mapper(
    componentModel = "spring"
)
public interface ActivityMapper {
  ActivityMapper INSTANCE = Mappers.getMapper(ActivityMapper.class);
  ;

  @Mappings({})
  ActivityResponse orgUserActivityToActivityResponse(OrgUserActivity orgUserActivity);

  @Mappings({})
  List<ActivityResponse> orgUserActivityToActivityResponseList(
      List<OrgUserActivity> orgUserActivity);

  @Mappings({})
  OrgUserActivity activityRequestToOrgUserActivity(ActivityRequest activityRequest);
}
