package com.akila.expertconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.expertconnect.entity.OrgCommunitySme;
import com.akila.expertconnect.entity.OrgCommunitySmePK;

@Repository
public interface OrgCommunitySmeRepository extends JpaRepository<OrgCommunitySme, OrgCommunitySmePK> {
	
	@Query("select o from OrgCommunitySme o inner join OrgUser ou on ou.userId = o.id.userId where ou.active = true")
	public List<OrgCommunitySme> findAll();
	
	@Query("select o from OrgCommunitySme o inner join OrgUser ou on ou.userId = o.id.userId where o.id.communityId = (:communityId)"
			+ " and ou.active = true")
	public List<OrgCommunitySme> findAllSMEByCommunityId(String communityId);
	
	@Query("select o from OrgCommunitySme o inner join OrgUser ou on ou.userId = o.id.userId where o.skillList LIKE CONCAT('%',:skillId,'%')"
			+ " and ou.active = true")
	public List<OrgCommunitySme> findAllSMEBySkillId(String skillId);
	
	public List<OrgCommunitySme> findSMEByIdUserId(String skillId);
	
}
