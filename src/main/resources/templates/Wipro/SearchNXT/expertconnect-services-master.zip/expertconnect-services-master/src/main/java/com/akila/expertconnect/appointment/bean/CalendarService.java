package com.akila.expertconnect.appointment.bean;

import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.mail.MessagingException;

import org.springframework.stereotype.Service;

import com.akila.commons.email.sender.EmailGraphClient;
 
@Service
public class CalendarService extends EmailGraphClient {
	
    public void sendCalendarInvite(String fromEmail, CalendarRequest calendarRequest, String method, String uuid, String appointmentId, int locationCd, String organizerCn, String subject) throws MessagingException, IOException {
    	String uid = (uuid != null)? uuid : calendarRequest.getUid();
		String location = (locationCd == 1) ? "Microsoft Teams Meeting" : "Cisco webex meeting";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd HHmmss");
        StringBuilder builder = new StringBuilder();
        builder.append("BEGIN:VCALENDAR\n" +
                "METHOD:"+method+"\n" +
                "PRODID::-//Microsoft Corporation//Outlook 11.0 MIMEDIR//EN\n" +
                "VERSION:2.0\n" +
                "BEGIN:VTIMEZONE\n" +
                "TZID:Asia/Kolkata\n" +
                "END:VTIMEZONE\n" +
                "BEGIN:VEVENT\n" +
                "ATTENDEE;CN="+calendarRequest.getSmeName()+";ROLE=REQ-PARTICIPANT;RSVP=TRUE:MAILTO:" + calendarRequest.getToEmail() + "\n" +
                "ATTENDEE;CN="+calendarRequest.getSenderName()+";CUTYPE=INDIVIDUAL;PARTSTAT=NEEDS-ACTION;ROLE=REQ-PARTICIPANT;RSVP=TRUE:mailto:"+calendarRequest.getCcEmail() +"\n" +
                "ORGANIZER;CN="+organizerCn+":MAILTO:" + fromEmail + "\n" +
                "DESCRIPTION;LANGUAGE=en-US:" + calendarRequest.getBody() + "\n" +
                "X-ALT-DESC;FMTTYPE=text/html:"+ calendarRequest.getHtmlBody() + "\n" +
                "UID:"+uid+"\n" +
                "SUMMARY;LANGUAGE=en-US:"+subject+"\n" +
                "DTSTART:" + formatter.format(calendarRequest.getMeetingStartTime().toLocalDateTime()).replace(" ", "T") + "\n" +
                "DTEND:" + formatter.format(calendarRequest.getMeetingEndTime().toLocalDateTime()).replace(" ", "T") + "\n" +
                "CLASS:PUBLIC\n" +
                "PRIORITY:5\n" +
                "DTSTAMP:" + formatter.format(calendarRequest.getMeetingStartTime().toLocalDateTime()).replace(" ", "T") + "\n" +
                "TRANSP:OPAQUE\n" +
                "STATUS:CONFIRMED\n" +
                "SEQUENCE:$sequenceNumber\n" +
                "LOCATION;LANGUAGE=en-US:"+location+"\n" +
                "BEGIN:VALARM\n" +
                "DESCRIPTION:REMINDER\n" +
                "TRIGGER;RELATED=START:-PT15M\n" +
                "ACTION:DISPLAY\n" +
                "END:VALARM\n" +
                "END:VEVENT\n" +
                "END:VCALENDAR");
 
		List<String> toEmailList = new ArrayList<String>();
		toEmailList.add(calendarRequest.getToEmail());
		
		List<String> fromEmailList = new ArrayList<String>();
		fromEmailList.add(calendarRequest.getCcEmail());
        
		sendCalenderInviteByICS(calendarRequest.getHtmlBody(),subject,toEmailList,
        		fromEmailList,null,builder);
    }
    
}
