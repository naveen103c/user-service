package com.akila.expertconnect.entity;

import com.akila.AkilaEntity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.UUID;


/**
 * The persistent class for the org_user_activity database table.
 * 
 */
@Entity
@Table(name="org_user_activity")
@NamedQuery(name="OrgUserActivity.findAll", query="SELECT o FROM OrgUserActivity o")
public class OrgUserActivity extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="activity_id")
	private UUID activityId;

	@Column(name="activity_cd")
	private Integer activityCd;

	@Column(name="crt_by")
	private String crtBy;

	@Column(name="crt_ts")
	private Timestamp crtTs;

	@Column(name="mod_by")
	private String modBy;

	@Column(name="mod_ts")
	private Timestamp modTs;

	@Column(name="user_id")
	private UUID userId;

	public OrgUserActivity() {
	}

	public UUID getActivityId() {
		return this.activityId;
	}

	public void setActivityId(UUID activityId) {
		this.activityId = activityId;
	}

	public Integer getActivityCd() {
		return this.activityCd;
	}

	public void setActivityCd(Integer activityCd) {
		this.activityCd = activityCd;
	}

	public String getCrtBy() {
		return this.crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getModBy() {
		return this.modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Timestamp getModTs() {
		return this.modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public UUID getUserId() {
		return this.userId;
	}

	public void setUserId(UUID userId) {
		this.userId = userId;
	}

}