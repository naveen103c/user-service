package com.akila.expertconnect.appointment.trends;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.expertconnect.appointment.trends.bean.TrendResponse;

@RestController
public class AppointmentTrendController extends AkilaController {
	@Autowired
	private AppointmentTrendService appointmentTrendService;

	@GetMapping(path = "/appointmentTrends/skill")
	public List<TrendResponse> getTrendingSkill() {
		return appointmentTrendService.getTrendingSkill();
	}

	@GetMapping(path = "/appointmentTrends/sme")
	public List<TrendResponse> getTrendingSME() {
		return appointmentTrendService.getTrendingSME();
	}

	@GetMapping(path = "/appointmentTrends/status")
	public List<TrendResponse> getAppointmentStatusTrend() {
		return appointmentTrendService.getAppointmentStatusTrend();
	}

}
