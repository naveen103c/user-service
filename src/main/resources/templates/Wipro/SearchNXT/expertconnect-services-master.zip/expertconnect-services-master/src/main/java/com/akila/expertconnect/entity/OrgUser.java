package com.akila.expertconnect.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the org_users database table.
 * 
 */
@Entity
@Table(name="org_users")
@NamedQuery(name="OrgUser.findAll", query="SELECT o FROM OrgUser o")
public class OrgUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="user_id")
	private String userId;

	@Column(name="user_first_nm")
	private String userFirstNm;

	@Column(name="user_last_nm")
	private String userLastNm;

	@Column(name="user_mid_nm")
	private String userMidNm;

	@Column(name="usr_email")
	private String usrEmail;
	
	@JsonIgnore
	@Column(name="crt_by")
	protected String crtBy;

	@JsonIgnore
	@Column(name="crt_ts")
	protected Timestamp crtTs;

	@JsonIgnore
	@Column(name="mod_by")
	protected String modBy;

	@JsonIgnore
	@Column(name="mod_ts")
	protected Timestamp modTs;
	
    @OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
    OrgCommunitySmeRequest request;
    
    @Column(name= "is_active")
    private boolean active;
    
//    @OneToOne(mappedBy = "user", fetch = FetchType.LAZY)
//    OrgCommunitySme orgCommunitySme;
    
	public OrgUser() {
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getUserFirstNm() {
		return this.userFirstNm;
	}

	public void setUserFirstNm(String userFirstNm) {
		this.userFirstNm = userFirstNm;
	}

	public String getUserLastNm() {
		return this.userLastNm;
	}

	public void setUserLastNm(String userLastNm) {
		this.userLastNm = userLastNm;
	}

	public String getUserMidNm() {
		return this.userMidNm;
	}

	public void setUserMidNm(String userMidNm) {
		this.userMidNm = userMidNm;
	}

	public String getUsrEmail() {
		return this.usrEmail;
	}

	public void setUsrEmail(String usrEmail) {
		this.usrEmail = usrEmail;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Timestamp getModTs() {
		return modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}
	
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		return "OrgUser [userId=" + userId + ", userFirstNm=" + userFirstNm + ", userLastNm=" + userLastNm
				+ ", userMidNm=" + userMidNm + ", usrEmail=" + usrEmail + ", crtBy=" + crtBy + ", crtTs=" + crtTs
				+ ", modBy=" + modBy + ", modTs=" + modTs + ", request=" + request + ", active=" + active + "]";
	}

}