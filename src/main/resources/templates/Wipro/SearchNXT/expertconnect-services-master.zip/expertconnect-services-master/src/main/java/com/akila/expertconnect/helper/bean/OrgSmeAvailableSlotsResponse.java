package com.akila.expertconnect.helper.bean;

import java.sql.Timestamp;
import java.util.List;

import com.akila.AkilaResponse;
import com.akila.expertconnect.entity.OrgSmeAvailability;
import com.akila.expertconnect.entity.OrgUser;
import com.fasterxml.jackson.annotation.JsonIgnore;

public class OrgSmeAvailableSlotsResponse extends AkilaResponse {

	private OrgCommunitySmeResponse orgSmeAvailability;
	
	//private OrgSmeAvailability orgSmeAvailability;
	
	private OrgUser user;
	
	private List<Timestamp> bookedAppointment;;
	

	public List<Timestamp> getBookedAppointment() {
		return bookedAppointment;
	}


	public void setBookedAppointment(List<Timestamp> bookedAppointment) {
		this.bookedAppointment = bookedAppointment;
	}


	public OrgUser getUser() {
		return user;
	}

	public void setUser(OrgUser user) {
		this.user = user;
	}


	public OrgCommunitySmeResponse getOrgSmeAvailability() {
		return orgSmeAvailability;
	}


	public void setOrgSmeAvailability(OrgCommunitySmeResponse orgSmeAvailability) {
		this.orgSmeAvailability = orgSmeAvailability;
	}


}
