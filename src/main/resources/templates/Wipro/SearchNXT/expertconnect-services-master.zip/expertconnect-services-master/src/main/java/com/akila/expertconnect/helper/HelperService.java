package com.akila.expertconnect.helper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.akila.AkilaService;
import com.akila.expertconnect.entity.OrgAppointment;
import com.akila.expertconnect.entity.OrgCommunitySme;
import com.akila.expertconnect.entity.OrgSmeAvailability;
import com.akila.expertconnect.entity.OrgUser;
import com.akila.expertconnect.helper.bean.HelperMapper;
import com.akila.expertconnect.helper.bean.OrgCommunitySmeResponse;
import com.akila.expertconnect.helper.bean.OrgSmeAvailableSlotsResponse;
import com.akila.expertconnect.repository.OrgAppointmentRepository;
import com.akila.expertconnect.repository.OrgCommunitySmeRepository;
import com.akila.expertconnect.repository.OrgSmeAvailabilityRepository;
import com.akila.expertconnect.repository.OrgUserRepository;

@Service
public class HelperService extends AkilaService {

	@Autowired
	private OrgCommunitySmeRepository orgCommunitySmeRepository;

	/*
	 * @Autowired private OrgSmeAvailabilityRepository orgSmeAvailabilityRepository;
	 */
	
	@Autowired 
	private OrgAppointmentRepository orgAppointmentRepository;
	
	@Autowired
	private HelperMapper helperMapper;
	
	@Autowired
	private OrgUserRepository orgUserRepository;
	

	public List<OrgCommunitySmeResponse> getAllSME(@RequestParam String communityId,
      @RequestParam String skillId) {
	  
	  List <OrgCommunitySme> resultList =new ArrayList<OrgCommunitySme>();
	  if(communityId == null && skillId == null) {
		  resultList =  orgCommunitySmeRepository.findAll();
	  }
	  else if(communityId != null) {
		  resultList =  orgCommunitySmeRepository.findAllSMEByCommunityId(communityId);
	  }
	  else if(skillId != null) {
		  resultList =  orgCommunitySmeRepository.findAllSMEBySkillId(skillId);
	  }
	  
    return communitySmeToResponse(resultList);
  }
	
	
	
	public List<OrgSmeAvailableSlotsResponse> getAllAppointmentSlot(
		      @RequestParam String skillId) {
			  
			  List <OrgCommunitySme> resultList =new ArrayList<OrgCommunitySme>();
			  resultList =  orgCommunitySmeRepository.findAllSMEBySkillId(skillId);
			  
			  List <OrgSmeAvailableSlotsResponse> orgSmeAvailableSlotsResponseList = new ArrayList<OrgSmeAvailableSlotsResponse>();
			  
			  for (OrgCommunitySme orgCommunitySme : resultList) {
				 
				  OrgSmeAvailableSlotsResponse orgSmeAvailableSlotsResponse = new OrgSmeAvailableSlotsResponse();
				  
				  orgSmeAvailableSlotsResponse.setUser(orgUserRepository.findById(orgCommunitySme.getId().getUserId()).orElse(null));
				  
				  orgSmeAvailableSlotsResponse.setOrgSmeAvailability(helperMapper.communitySmeToResponse(orgCommunitySme));
				  
//				  OrgSmeAvailability orgSmeAvailability  = orgSmeAvailabilityRepository.findByUserId(orgCommunitySme.getId().getUserId());
//				  orgSmeAvailableSlotsResponse.setOrgSmeAvailability(orgSmeAvailability);
				  
				  
				  List<OrgAppointment> orgAppointment = orgAppointmentRepository.findByUserId(orgCommunitySme.getId().getUserId());
				  List<Timestamp> appointments = new ArrayList<Timestamp>(); 
				  for (OrgAppointment appointment : orgAppointment) {
					  appointments.add(appointment.getBookingTs());
					
				}
				  
				  orgSmeAvailableSlotsResponse.setBookedAppointment(appointments);

				  orgSmeAvailableSlotsResponseList.add(orgSmeAvailableSlotsResponse);
			}
			  
			  
		    return orgSmeAvailableSlotsResponseList;
		  }

	List<OrgCommunitySmeResponse> communitySmeToResponse(List<OrgCommunitySme> orgCommunitySmeList) {

		List<OrgCommunitySmeResponse> list = new ArrayList<OrgCommunitySmeResponse>();

		for (OrgCommunitySme orgCommunitySme : orgCommunitySmeList) {
			OrgCommunitySmeResponse orgCommunitySmeResponse = helperMapper.communitySmeToResponse(orgCommunitySme);
			list.add(orgCommunitySmeResponse);
		}
		return list;
	}

}
