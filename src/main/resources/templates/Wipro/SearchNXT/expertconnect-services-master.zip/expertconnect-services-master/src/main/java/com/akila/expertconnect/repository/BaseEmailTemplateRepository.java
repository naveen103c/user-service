package com.akila.expertconnect.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.expertconnect.entity.BaseEmailTemplate;

@Repository
public interface BaseEmailTemplateRepository extends JpaRepository<BaseEmailTemplate, String> {

	List<BaseEmailTemplate> findByName(String templateName);

}
