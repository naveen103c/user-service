package com.akila.expertconnect.helper.bean;

import java.sql.Time;
import java.sql.Timestamp;

import javax.persistence.Column;

import com.akila.AkilaResponse;

public class OrgCommunitySmeResponse extends AkilaResponse {

	private String communityId;

	private String userId;

	private String skillList;

	private Integer smeStatusCd;
	
	private Time appointmentStartTs;
	
	private Time appointmentEndTs;
	
	private Integer appointmentDuration;
	
	private Integer locationCd;
	
	private Integer scheduleTypeCd;

	private Timestamp startTs;

	private String scheduleCd;
	
	@Column(name="end_ts")
	private Timestamp endTs;
	
	//private OrgUser user;

	public String getCommunityId() {
		return communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSkillList() {
		return skillList;
	}

	public void setSkillList(String skillList) {
		this.skillList = skillList;
	}

	public Integer getSmeStatusCd() {
		return smeStatusCd;
	}

	public void setSmeStatusCd(Integer smeStatusCd) {
		this.smeStatusCd = smeStatusCd;
	}
	
	public Time getAppointmentStartTs() {
		return appointmentStartTs;
	}

	public void setAppointmentStartTs(Time appointmentStartTs) {
		this.appointmentStartTs = appointmentStartTs;
	}

	public Time getAppointmentEndTs() {
		return appointmentEndTs;
	}

	public void setAppointmentEndTs(Time appointmentEndTs) {
		this.appointmentEndTs = appointmentEndTs;
	}

	public Integer getAppointmentDuration() {
		return appointmentDuration;
	}

	public void setAppointmentDuration(Integer appointmentDuration) {
		this.appointmentDuration = appointmentDuration;
	}

	public Integer getLocationCd() {
		return locationCd;
	}

	public void setLocationCd(Integer locationCd) {
		this.locationCd = locationCd;
	}

	public Integer getScheduleTypeCd() {
		return scheduleTypeCd;
	}

	public void setScheduleTypeCd(Integer scheduleTypeCd) {
		this.scheduleTypeCd = scheduleTypeCd;
	}

	public Timestamp getStartTs() {
		return startTs;
	}

	public void setStartTs(Timestamp startTs) {
		this.startTs = startTs;
	}

	public String getScheduleCd() {
		return scheduleCd;
	}

	public void setScheduleCd(String scheduleCd) {
		this.scheduleCd = scheduleCd;
	}

	public Timestamp getEndTs() {
		return endTs;
	}

	public void setEndTs(Timestamp endTs) {
		this.endTs = endTs;
	}

}
