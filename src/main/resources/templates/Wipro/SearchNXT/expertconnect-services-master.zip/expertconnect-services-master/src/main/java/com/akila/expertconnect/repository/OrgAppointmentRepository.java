package com.akila.expertconnect.repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.akila.expertconnect.entity.OrgAppointment;

@Repository
public interface OrgAppointmentRepository extends JpaRepository<OrgAppointment, UUID> {

	@Query("select o from OrgAppointment o where  (cast(:bookedBy as org.hibernate.type.UUIDCharType) is null or o.bookedBy = :bookedBy  or o.smeUserId = :bookedBy  or o.smeUserId = :bookedBy) "
			+ " and ((:appStatusCd) = 0 or  o.appointmentStatusCd = (:appStatusCd)) and booking_ts >= NOW()")
	public List<OrgAppointment> findAllSMEByFilter(@Param("bookedBy") String bookedBy, Integer appStatusCd);

	@Query("select o from OrgAppointment o where  smeUserId = (:userId)")
	public List<OrgAppointment> findByUserId(String userId);

	@Query("select o from OrgAppointment o where  smeUserId = (:userId) and bookingTs = (:bookingTS)")
	public List<OrgAppointment> findBySmeIdAndTime(String userId, Timestamp bookingTS);

	@Query(value = "select os.skill_mnemonic, count(oa.appointment_id) from org_appointments oa, \n"
			+ "org_skills os\n" + "where oa.skill_id = os.skill_id and\n"
			+ "date_part('month', oa.booking_ts) = :month\n" + "and date_part('year', oa.booking_ts) = :year\n"
			+ "group by os.skill_mnemonic\n" + "union\n"
			+ "select os.skill_mnemonic, count(DISTINCT oa.appointment_id) from org_appointments_history oa, \n"
			+ "org_skills os\n" + "where oa.skill_id = os.skill_id and oa.appointment_status_cd not in (2,3) and\n"
			+ "date_part('month', oa.booking_ts) = :month\n" + "and date_part('year', oa.booking_ts) = :year\n"
			+ "group by os.skill_mnemonic", nativeQuery = true)
	List<Object[]> getTrendingSkill(@Param("year") int year, @Param("month") int month);
	
	@Query(value = "select concat_ws(' ', ou.user_first_nm, ou.user_last_nm) AS name , count(oa.appointment_id)\n" + 
			"from org_appointments_history oa,org_users ou\n" + 
			"where oa.sme_user_id = ou.user_id and oa.appointment_status_cd !=2 and\n" + 
			"date_part('month', oa.booking_ts) = :month\n" + 
			"and date_part('year', oa.booking_ts) = :year\n" + 
			"group by name\n" + 
			"union\n" + 
			"select concat_ws(' ', ou.user_first_nm, ou.user_last_nm) AS name , count(oa.appointment_id)\n" + 
			"from org_appointments oa,org_users ou\n" + 
			"where oa.sme_user_id = ou.user_id and\n" + 
			"date_part('month', oa.booking_ts) = :month\n" + 
			"and date_part('year', oa.booking_ts) = :year\n" + 
			"group by name", nativeQuery = true)
	List<Object[]> getTrendingSME(@Param("year") int year, @Param("month") int month);
	
	@Query(value = "select oa.appointment_status_cd AS appointmentStatus , count(oa.appointment_id)\n" + 
			"from org_appointments_history oa\n" + 
			"where date_part('month', oa.booking_ts) = :month\n" + 
			"and date_part('year', oa.booking_ts) = :year\n" + 
			"group by appointmentStatus\n" + 
			"union\n" + 
			"select oa.appointment_status_cd AS appointmentStatus , count(oa.appointment_id)\n" + 
			"from org_appointments oa\n" + 
			"where date_part('month', oa.booking_ts) = :month\n" + 
			"and date_part('year', oa.booking_ts) = :year\n" + 
			"group by appointmentStatus", nativeQuery = true)
	List<Object[]> getAppointmentStatusTrend(@Param("year") int year, @Param("month") int month);
	
	@Query("select o from OrgAppointment o where (bookedBy = :userId or smeUserId = :userId or bookedBy = :smeUserId or smeUserId = :smeUserId) and ((:bookingStartTS between bookingTs  and bookingEndTs) or (:bookingEndTS between bookingTs  and bookingEndTs ))")
	public List<OrgAppointment> findByBookedByOrSmeUserIdAndBookingTsGreaterThanEqualAndBookingEndTsLessThanEqual(Timestamp bookingStartTS,Timestamp bookingEndTS,String userId,String smeUserId);

}
