package com.akila.expertconnect.entity;

import java.io.Serializable;
import java.sql.Time;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;


/**
 * The persistent class for the org_community_smes database table.
 * 
 */
@Entity
@Table(name="org_community_smes")
@NamedQuery(name="OrgCommunitySme.findAll", query="SELECT o FROM OrgCommunitySme o")
public class OrgCommunitySme extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgCommunitySmePK id;

	@Column(name="appointment_start_ts")
	private Time appointmentStartTs;
	
	@Column(name="appointment_end_ts")
	private Time appointmentEndTs;
	
	@Column(name="location_cd")
	private Integer locationCd;
	
	@Column(name="schedule_type_cd")
	private Integer scheduleTypeCd;

	@Column(name="start_ts")
	private Timestamp startTs;

	@Column(name="schedule_cd")
	private String scheduleCd;
	
	@Column(name = "skill_list")
	private String skillList;
	
	@Column(name = "sme_status_cd")
	private Integer smeStatusCd; 
	
	@Column(name="end_ts")
	private Timestamp endTs;
	
	@Column(name="appointment_duration")
	private String appointmentDuration;

//    @OneToOne(fetch = FetchType.EAGER, optional = false)
//    @JoinColumn(name = "user_id",insertable = false,updatable = false, nullable = false)
//	OrgUser user;

//	public OrgUser getUser() {
//		return user;
//	}
//
//	public void setUser(OrgUser user) {
//		this.user = user;
//	}

	public OrgCommunitySme() {
	}

	public OrgCommunitySmePK getId() {
		return this.id;
	}

	public void setId(OrgCommunitySmePK id) {
		this.id = id;
	}

	public String getSkillList() {
		return skillList == null ? "" : skillList;
	}

	public Integer getSmeStatusCd() {
		return smeStatusCd == null ? 6 : smeStatusCd;
	}

	public void setSmeStatusCd(Integer smeStatusCd) {
		this.smeStatusCd = smeStatusCd;
	}

	public Timestamp getEndTs() {
		return endTs == null ? new Timestamp(System.currentTimeMillis()) : endTs;
	}

	public void setEndTs(Timestamp endTs) {
		this.endTs = endTs;
	}
	
	public Time getAppointmentStartTs() {
		return appointmentStartTs;
	}

	public void setAppointmentStartTs(Time appointmentStartTs) {
		this.appointmentStartTs = appointmentStartTs;
	}

	public Time getAppointmentEndTs() {
		return appointmentEndTs;
	}

	public void setAppointmentEndTs(Time appointmentEndTs) {
		this.appointmentEndTs = appointmentEndTs;
	}

	public Integer getLocationCd() {
		return locationCd == null ? 0 : locationCd;
	}

	public void setLocationCd(Integer locationCd) {
		this.locationCd = locationCd;
	}

	public Integer getScheduleTypeCd() {
		return scheduleTypeCd == null ? 0 : scheduleTypeCd;
	}

	public void setScheduleTypeCd(Integer scheduleTypeCd) {
		this.scheduleTypeCd = scheduleTypeCd;
	}

	public Timestamp getStartTs() {
		return startTs == null ? new Timestamp(System.currentTimeMillis()) : startTs;
	}

	public void setStartTs(Timestamp startTs) {
		this.startTs = startTs;
	}

	public String getScheduleCd() {
		return scheduleCd == null ? "" : scheduleCd;
	}

	public void setScheduleCd(String scheduleCd) {
		this.scheduleCd = scheduleCd;
	}

	public void setSkillList(String skillList) {
		this.skillList = skillList;
	}

	public String getAppointmentDuration() {
		return appointmentDuration;
	}

	public void setAppointmentDuration(String appointmentDuration) {
		this.appointmentDuration = appointmentDuration;
	}
	
}