package com.akila.expertconnect.activity;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.expertconnect.activity.bean.ActivityResponse;

@RestController
public class ActivityController extends AkilaController {
  @Autowired
  private ActivityService activityService;

  @GetMapping(
      path = "/activities"
  )
  public List<ActivityResponse> getAllActivity(@RequestParam(required = false) UUID communityId,
      @RequestParam(required = false) UUID userId, @RequestParam (required = false ,defaultValue = "0") Integer activityCd) {
    return activityService.getAllActivity(communityId, userId, activityCd);
  }

  @GetMapping(
      path = "/activities/{id}"
  )
  public ActivityResponse getActivity(@PathVariable UUID id) {
    return activityService.getActivity(id);
  }
}
