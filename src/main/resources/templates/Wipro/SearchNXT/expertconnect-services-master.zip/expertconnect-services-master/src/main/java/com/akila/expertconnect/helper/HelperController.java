package com.akila.expertconnect.helper;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.expertconnect.helper.bean.OrgCommunitySmeResponse;
import com.akila.expertconnect.helper.bean.OrgSmeAvailableSlotsResponse;

@RestController
public class HelperController extends AkilaController {
  @Autowired
  private HelperService helperService;

  @GetMapping(
      path = "/helpers/available-smes"
  )
  public List<OrgCommunitySmeResponse> getAllSME(@RequestParam(required = false) String communityId,
      @RequestParam(required = false) String skillId) {
    return helperService.getAllSME(communityId, skillId);
  }

  @GetMapping(
	      path = "/helpers/available-slots/{skillId}"
	  )
  public List<OrgSmeAvailableSlotsResponse> getAllAppointmentSlot(
	      @PathVariable String skillId) {
	    return helperService.getAllAppointmentSlot(skillId);
	  }
  
}
