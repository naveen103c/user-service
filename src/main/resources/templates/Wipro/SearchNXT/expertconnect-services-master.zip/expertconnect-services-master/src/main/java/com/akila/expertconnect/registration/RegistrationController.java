package com.akila.expertconnect.registration;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.expertconnect.registration.bean.RegistrationRequest;
import com.akila.expertconnect.registration.bean.RegistrationResponse;
import com.akila.response.ResponseId;

@RestController
public class RegistrationController extends AkilaController {
  @Autowired
  private RegistrationService registrationService;

  @GetMapping(
      path = "/registrations"
  )
  public List<RegistrationResponse> getAllRegistration(@RequestParam(required = false) String communityId,@RequestParam(required = false) String requestStatusCd) {
    return registrationService.getAllRegistration(communityId,requestStatusCd);
  }

  @GetMapping(
      path = "/registrations/{id}"
  )
  public RegistrationResponse getRegistration(@PathVariable String id) {
    return registrationService.getRegistration(id);
  }
  
  @GetMapping(
	      path = "/registrations/user-details/{userId}"
	  )
	  public RegistrationResponse getRegistrationByUserId(@PathVariable String userId) {
	    return registrationService.getRegistrationByUserId(userId);
	  }

  @PutMapping(
      path = "/registrations/{id}"
  )
  public ResponseId updateRegistration(@PathVariable String id,
		  @Valid  @RequestBody RegistrationRequest registrationRequest) {
    return registrationService.updateRegistration(id, registrationRequest);
  }

  @PutMapping(
      path = "/registrations/{id}/approve"
  )
  public ResponseId approveRegistration(@PathVariable String id) {
    return registrationService.approveRegistration(id);
  }

  @PutMapping(
      path = "/registrations/{id}/decline"
  )
  public ResponseId declineRegistration(@PathVariable String id) {
    return registrationService.declineRegistration(id);
  }
  
  @DeleteMapping(
	      path = "/registrations/{communityId}/{userId}"
	  )
	  public ResponseId deleteRegistration(@PathVariable String communityId,@PathVariable String userId) {
	    return registrationService.deleteRegistration(communityId,userId);
	  }

  @PostMapping(
      path = "/registrations"
  )
  public ResponseId addRegistration(@Valid @RequestBody RegistrationRequest registrationRequest) {
    return registrationService.addRegistration(registrationRequest);
  }
}
