package com.akila.expertconnect.appointment;

import java.util.List;
import java.util.UUID;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.expertconnect.appointment.bean.AppointmentRequest;
import com.akila.expertconnect.appointment.bean.AppointmentResponse;
import com.akila.expertconnect.appointment.bean.ResponseStatus;
import com.akila.response.ResponseId;

@RestController
public class AppointmentController extends AkilaController {
  @Autowired
  private AppointmentService appointmentService;

  private int STATUS_FAILED = 0;
  private int STATUS_PASS = 1;
  
  @PostMapping(
      path = "/appointments"
  )
  public ResponseEntity<ResponseStatus> createAppointment(@Valid @RequestBody AppointmentRequest appointmentRequest) {
	  ResponseId response =  appointmentService.createAppointment(appointmentRequest);
	  if(response.getId().equals(""))
	  {
		  ResponseStatus status = getResponseStatus(STATUS_FAILED, "", ("User time slot already booked"), 429);
		  return new ResponseEntity<ResponseStatus>(status, HttpStatus.TOO_MANY_REQUESTS);
	  }else {
		  ResponseStatus status = getResponseStatus(STATUS_PASS, "", ("Appointment successfully created"), 101);
		  return new ResponseEntity<ResponseStatus>(status, HttpStatus.OK);
	  }
  }

  @GetMapping(
      path = "/appointments"
  )
  public List<AppointmentResponse> getAllAppointment(@RequestParam(required = false) String communityId,
      @RequestParam(required = false) String userId, @RequestParam(required = false) Integer appStatusCd, @RequestParam(required = false) Integer fetchHistory) {
    return appointmentService.getAllAppointment(communityId, userId, appStatusCd,fetchHistory);
  }

  @GetMapping(
      path = "/appointments/{id}"
  )
  public AppointmentResponse getAppointment(@PathVariable UUID id) {
    return appointmentService.getAppointment(id);
  }

  @PutMapping(
      path = "/appointments/{id}"
  )
	public ResponseId updateAppointment(@PathVariable UUID id,
			@Valid @RequestBody AppointmentRequest appointmentRequest,
			@RequestParam("appointmentStatusCd") String appointmentStatusCd) {
		return appointmentService.updateAppointment(id, appointmentRequest);
	}

  @DeleteMapping(
      path = "/appointments/{id}"
  )
  public void deleteAppointment(@PathVariable UUID id) {
    appointmentService.deleteAppointment(id);
  }
  
  private ResponseStatus getResponseStatus(int statusCd, String id, String message, int errorCode) {
		ResponseStatus status = new ResponseStatus();
		status.setStatusCode(statusCd);
		status.setId(id);
		status.setMessage(message);
		status.setErrorCode(errorCode);
		return status;
	}

}
