package com.akila.health.controller;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.akila.health.entity.AkilaServices;
import com.akila.health.entity.AkilaServicesLogs;
import com.akila.health.entity.AkilaServicesLogsRepository;
import com.akila.health.entity.AkilaServicesRepository;

@Service
public class MonitoringService {
	private static Logger log = LogManager.getLogger(MonitoringService.class);
	
	@Autowired
	AkilaServicesRepository akilaServicesRepository;
	
	@Autowired
	AkilaServicesLogsRepository akilaServicesLogsRepository;
	
	@Autowired
	RestartServices restartServices;
	
	@Autowired
	MailServices mailServices;

	@Bean("restTemplate")
	public RestTemplate restTemplate(
	        RestTemplateBuilder restTemplateBuilder) {

	    return restTemplateBuilder
	            .setConnectTimeout(Duration.ofSeconds(5))
	            .setReadTimeout(Duration.ofSeconds(10))
	            .build();
	}
	
	@Autowired
	@Qualifier("restTemplate")
	RestTemplate restTemplate;
	
	@Scheduled(cron = "${health.check.cron}")
	public void checkServiceHealth() {
		//System.out.println("Starting Health Services....................");
		log.info("Starting Health Services....................");
		List<AkilaServices> unhealthyServices = new ArrayList<AkilaServices>();
		List<AkilaServices> healthyServices = new ArrayList<AkilaServices>();
		List<AkilaServices> services = getAllService();
		for (AkilaServices akilaServices : services) {
			try {
				log.info(akilaServices.getServiceName()+", EndPoint : "+akilaServices.getEndPoint());
				ResponseEntity<String> response  = restTemplate.getForEntity(akilaServices.getEndPoint(), String.class);
				HttpStatus status = response.getStatusCode();
				log.info(akilaServices.getServiceName()+", HttpStatus : "+status.value());
				String responseBody = response.getBody();
				//log.info(akilaServices.getServiceName()+", Response Body : "+responseBody);
				//System.out.println(akilaServices.getServiceName()+", responseBody : "+responseBody);
				 akilaServices.setLastUpdatedTs(new Date());
				 if(status.value() == 200) {
					 log.info(akilaServices.getServiceName()+": Last status : "+akilaServices.getStatusStr()+", Current Status : UP");
					 akilaServices.setStatus(1);
					 akilaServices.setErrorCount(0);
					 healthyServices.add(akilaServices);
				} else {
					 log.info(akilaServices.getServiceName()+": Last status : "+akilaServices.getStatusStr()+", Current Status : Down");
					 akilaServices.setStatus(0);
					 akilaServices.setErrorCount(akilaServices.getErrorCount() + 1);
				     unhealthyServices.add(akilaServices);
				}
			} catch (RestClientException e) {
				 log.error("Connection error with service : "+akilaServices.getServiceName(), e);
				 log.info(akilaServices.getServiceName()+": Last status : "+akilaServices.getStatusStr()+", Current Status : Down");
				 akilaServices.setLastUpdatedTs(new Date());
				 akilaServices.setStatus(0);
				 akilaServices.setErrorCount(akilaServices.getErrorCount() + 1);
			     unhealthyServices.add(akilaServices);
			}
			
		}
		
		updateStatus(healthyServices,unhealthyServices);
		String errors = restartServices(unhealthyServices);
		
		notify(unhealthyServices,errors);
	}
	
    private void notify(List<AkilaServices> unhealthyServices, String errors) {
		StringBuffer sb  = new StringBuffer();
    	if(unhealthyServices.size() > 0) {
    		for (AkilaServices akilaServices : unhealthyServices) {
				sb.append(akilaServices.getServiceName()+" was down. Service restart command executed. Error Count : "+akilaServices.getErrorCount());
				sb.append("\n\n");
			}
		}
    	
    	if(errors.length() > 0) {
    		sb.append("\n\n");
    		sb.append("Error Summary while restarting services:-");
    		sb.append("\n\n");
    		sb.append(errors);
    	}
		
    	try {
    		if(sb.toString().length() > 0) {
	    		log.info("Mail Body : "+sb.toString()); 
	    		//System.out.println("Mail Body : "+sb.toString());
				mailServices.sendMail(sb.toString());
    		}
		} catch (Exception e) {
			log.error("Error while sending mails : "+e.getMessage(), e); 
		}
	}

	private String restartServices(List<AkilaServices> unhealthyServices) {
		StringBuffer sb  = new StringBuffer();
		for (AkilaServices akilaServices : unhealthyServices) {
			try {
				log.info("Restarting Service : "+akilaServices.getServiceName());
				restartServices.restart(akilaServices);
				log.info("Restarted Service : "+akilaServices.getServiceName());
			} catch (Exception e) {
				sb.append(akilaServices.getServiceName()+", Error while restarting service : "+e.getMessage());
				sb.append("\n\n");
				log.error("Error while restarting Service : "+akilaServices.getServiceName()+", Error : "+e.getMessage(),e);
			}
		}
		return sb.toString();
	}

	private void updateStatus(List<AkilaServices> healthyServices, List<AkilaServices> unhealthyServices) {
		try {
			akilaServicesRepository.saveAll(healthyServices);
			akilaServicesRepository.saveAll(unhealthyServices);
			
			List<AkilaServicesLogs> logs = new ArrayList<AkilaServicesLogs>();
			for (AkilaServices akilaServices : unhealthyServices) {
				AkilaServicesLogs log = new AkilaServicesLogs();
				log.setLogId(UUID.randomUUID().toString());
				log.setServiceId(akilaServices.getServiceId());
				log.setServiceStatus(akilaServices.getStatus());
				log.setLastUpdateTs(akilaServices.getLastUpdatedTs());
				logs.add(log);
			}
			for (AkilaServices akilaServices : healthyServices) {
				AkilaServicesLogs log = new AkilaServicesLogs();
				log.setLogId(UUID.randomUUID().toString());
				log.setServiceId(akilaServices.getServiceId());
				log.setServiceStatus(akilaServices.getStatus());
				log.setLastUpdateTs(akilaServices.getLastUpdatedTs());
				logs.add(log);
			}
			
			akilaServicesLogsRepository.saveAll(logs);
		} catch (Exception e) {
			log.error("updateStatus : "+e.getMessage());
		}
	}
	
	public List<AkilaServices> getAllService() {
		
		return akilaServicesRepository.findByActiveCd(true);
	}

	public void deleteService(String id) {
		AkilaServices service = akilaServicesRepository.getOne(id);
		service.setActiveCd(false);
		akilaServicesRepository.save(service);
	}

	public void updateService(String id, ServicesBean servicesBean) {
		AkilaServices service = akilaServicesRepository.getOne(id);
		service.setServiceName(servicesBean.getServiceName());
		service.setServerIp(servicesBean.getServerIp());
		service.setServiceDesc(servicesBean.getServiceDesc());
		service.setDockerContainerNm(servicesBean.getDockerContainerNm());
		service.setEndPoint(servicesBean.getEndPoint());
		service.setActiveCd(true);
		akilaServicesRepository.save(service);
	}

	public String addService(ServicesBean servicesBean) {
		String uuid = UUID.randomUUID().toString();
		AkilaServices service = new AkilaServices();
		service.setServiceId(uuid);
		service.setServiceName(servicesBean.getServiceName());
		service.setServerIp(servicesBean.getServerIp());
		service.setDockerContainerNm(servicesBean.getDockerContainerNm());
		service.setEndPoint(servicesBean.getEndPoint());
		service.setActiveCd(true);
		service.setErrorCount(0);
		service.setStatus(1);
		service.setServiceDesc(servicesBean.getServiceDesc());
		
		akilaServicesRepository.save(service);
		
		return uuid;
	}
	
	

}
