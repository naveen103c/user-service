package com.akila.health.entity;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AkilaServicesRepository  extends JpaRepository<AkilaServices, String>{

	List<AkilaServices> findByActiveCd(boolean b);

}
