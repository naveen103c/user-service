package com.akila.health.controller;

import java.io.IOException;
import java.io.InputStream;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.akila.health.entity.AkilaServices;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

@Service
public class RestartServices {
	private static Logger log = LogManager.getLogger(RestartServices.class);
			
	@Value("${private.key.path}")
	String privateKey;
	
	@Value("${user.name}")
	String userName;
	
	@Value("${ssh.port}")
	int sshPort;
	
	@Value("${known.hosts.path}")
	String knownHostsPath;
	
	 private static final String REMOTE_HOST = "10.0.4.6";
	    private static final String USERNAME = "ubuntu";
	    private static final int REMOTE_PORT = 22;
	    private static final int SESSION_TIMEOUT = 10000;
	    private static final int CHANNEL_TIMEOUT = 5000;

	    public void restart(AkilaServices akilaServices) throws Exception {

	        Session jschSession = null;

	        try {

	            JSch jsch = new JSch();
	            jsch.setKnownHosts(knownHostsPath);
	            log.info(akilaServices.getServiceName()+", userName : "+USERNAME);
	            jschSession = jsch.getSession(USERNAME, akilaServices.getServerIp(), sshPort);

	            // not recommend, uses jsch.setKnownHosts
	            jschSession.setConfig("StrictHostKeyChecking", "no");

	            // authenticate using private key
	            jsch.addIdentity(privateKey);

	            // 10 seconds timeout session
	            jschSession.connect(SESSION_TIMEOUT);

	            ChannelExec channelExec = (ChannelExec) jschSession.openChannel("exec");

	            // Run a commanddd
	            //channelExec.setCommand("ls -lsah");
	            String command = "sudo docker restart "+akilaServices.getDockerContainerNm();
	            channelExec.setCommand(command);
	            log.info(akilaServices.getServiceName()+" : "+command);
	            // display errors to System.err
	            channelExec.setErrStream(System.err);

	            InputStream in = channelExec.getInputStream();

	            // 5 seconds timeout channel
	            channelExec.connect(CHANNEL_TIMEOUT);

	            // read the result from remote server
	            byte[] tmp = new byte[1024];
	            while (true) {
	            	StringBuffer sb =  new StringBuffer();
	                while (in.available() > 0) {
	                    int i = in.read(tmp, 0, 1024);
	                    if (i < 0) break;
	                    sb.append(new String(tmp, 0, i));
	                }
	                log.info(akilaServices.getServiceName()+" : "+sb.toString());
	                if (channelExec.isClosed()) {
	                    if (in.available() > 0) continue;
	                    log.info(akilaServices.getServiceName()+" : exit-status: "
	                        + channelExec.getExitStatus());
	                    break;
	                }
	                try {
	                    Thread.sleep(1000);
	                } catch (Exception ee) {
	                }
	            }

	            channelExec.disconnect();

	        } catch (JSchException | IOException e) {

	           throw new Exception(e);

	        } finally {
	            if (jschSession != null) {
	                jschSession.disconnect();
	            }
	        }

	    }

}

