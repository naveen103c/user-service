package com.akila.health.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.health.entity.AkilaServices;


@RestController
public class MonitoringController {
	
	@Autowired
	MonitoringService monitoringService;
	
	@GetMapping(path = "/status")
	public List<ServicesBean> get() {
		return getServices();
	}
	
	@PostMapping(path = "/services")
	public String addService(@RequestBody ServicesBean servicesBean) {
		return monitoringService.addService(servicesBean);
	}
	
	@PutMapping(path = "/services/{id}")
	public String updateService(@PathVariable String id, @RequestBody ServicesBean ServicesBean) {
		monitoringService.updateService(id,ServicesBean);
		return id;
	} 
	
	@DeleteMapping(path = "/services/{id}")
	public void deleteService(@PathVariable String id) {
		monitoringService.deleteService(id);
	}
	
	
	private List<ServicesBean> getServices(){
		List<ServicesBean> resultList = new ArrayList<ServicesBean>();
		List<AkilaServices> list = monitoringService.getAllService();
		for (AkilaServices akilaServices : list) {
			ServicesBean bean = new ServicesBean();
			bean.setServiceName(akilaServices.getServiceName());
			bean.setServiceId(akilaServices.getServiceId());
			bean.setEndPoint(akilaServices.getEndPoint());
			bean.setLastUpdatedTs(akilaServices.getLastUpdatedTs());
			bean.setServerIp(akilaServices.getServerIp());
			bean.setStatus(akilaServices.getStatusStr());
			bean.setDockerContainerNm(akilaServices.getDockerContainerNm());
			bean.setErrorCount(akilaServices.getErrorCount());
			bean.setServiceDesc(akilaServices.getServiceDesc());
			resultList.add(bean);
		}
		
		return resultList;
	}
	
}
