package com.akila.health.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "akila_services", schema = "base")
public class AkilaServices {

	@Id
	@Column(name = "service_id")
	String serviceId;
	@Column(name = "service_nm")
	String serviceName;
	@Column(name = "service_desc")
	String serviceDesc;
	@Column(name = "server_ip")
	String serverIp;
	@Column(name = "docker_container_nm")
	String dockerContainerNm;
	@Column(name = "service_endpoint")
	String endPoint;
	@Column(name = "last_status")
	Integer status;
	@Column(name = "last_update_ts")
	Date lastUpdatedTs;
	@Column(name = "error_count")
	Integer errorCount;
	@Column(name = "active_cd")
	Boolean activeCd;
	
	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getEndPoint() {
		return endPoint;
	}

	public void setEndPoint(String endPoint) {
		this.endPoint = endPoint;
	}

	public int getStatus() {
		if(this.status == null) {
			return 0;
		}
		return status.intValue();
	}

	public String getStatusStr() {
		if(this.status == null) {
			return "";
		}
		if (status.intValue() == 1) {
			return "UP";
		} else {
			return "Down";
		}

	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getLastUpdatedTs() {
		return lastUpdatedTs;
	}

	public void setLastUpdatedTs(Date lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}

	public String getServiceDesc() {
		return serviceDesc;
	}

	public void setServiceDesc(String serviceDesc) {
		this.serviceDesc = serviceDesc;
	}

	public String getServerIp() {
		return serverIp;
	}

	public void setServerIp(String serverIp) {
		this.serverIp = serverIp;
	}

	public String getDockerContainerNm() {
		return dockerContainerNm;
	}

	public void setDockerContainerNm(String dockerContainerNm) {
		this.dockerContainerNm = dockerContainerNm;
	}

	public Integer getErrorCount() {
		if(errorCount == null) {
			errorCount = 0;
		}
		return errorCount;
	}

	public void setErrorCount(Integer errorCount) {
		this.errorCount = errorCount;
	}

	public boolean getActiveCd() {
		if(activeCd == null) {
			return false;
		}
		return activeCd;
	}

	public void setActiveCd(Boolean activeCd) {
		this.activeCd = activeCd;
	}

}
