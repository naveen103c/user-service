package com.akila.health.controller;

import java.util.Properties;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class MailServices {
	private static Logger log = LogManager.getLogger(MailServices.class);
	@Value("${mail_username}")
	private String username;

	@Value("${mail_password}")
	private String password;

	@Value("${mail.smtp.auth}")
	private String mailSmtpAuth;

	@Value("${mail.smtp.starttls.enable}")
	private String mailSmtpStarttlsEnable;
	
	@Value("${mail.smtp.starttls.required}")
	private String mailSmtpStarttlsRequired;

	@Value("${mail.smtp.host}")
	private String mailSmtpHost;

	@Value("${mail.smtp.port}")
	private String mailSmtpPort;
		
	@Value("${notification.emails}")
	private String notificationEmails;
	
	String subject = "Akila Services Health Status";
	
	public void sendMail(String mailBody) throws Exception {
		try {
			Properties props = new Properties();
			//props.put("mail.smtp.auth", mailSmtpAuth);
			//props.put("mail.smtp.starttls.required", mailSmtpStarttlsRequired);
			//props.put("mail.smtp.starttls.enable", mailSmtpStarttlsEnable);
			//props.put("mail.smtp.host", mailSmtpHost);
			//props.put("mail.smtp.port", mailSmtpPort);
			//props.put("mail.user", organizerCn);
			
			 Properties properties = new Properties();
	        properties.put("mail.smtp.starttls.enable", "true");
	        properties.put("mail.smtp.auth", "true");
	        properties.put("mail.smtp.host", "smtp.gmail.com");
	        properties.put("mail.smtp.port", "587");
			   
			log.info("Mail User : "+username);
			log.info("Mail Pass : "+password);
			log.info("Mail mailSmtpHost : "+mailSmtpHost);
			 Session session = Session.getInstance(properties,
		                new javax.mail.Authenticator() {
		                    protected PasswordAuthentication getPasswordAuthentication() {
		                        return new PasswordAuthentication(username, password);
		                    }
		                });
			
			String [] emails = notificationEmails.split(",");
			InternetAddress[] recipientAddress = new InternetAddress[emails.length];
			int counter = 0;
			for (String recipient : emails) {
				try {
					recipientAddress[counter] = new InternetAddress(recipient.trim());
				} catch (AddressException e) {
					e.printStackTrace();
				}
				counter++;
			}
	
		
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(username));
			message.setRecipients(Message.RecipientType.TO, recipientAddress);
			message.setSubject(subject);
			message.setText(mailBody);
			log.info("Sending mail.................. : ");	      
			Transport.send(message);
			log.info("Sent mail.................. : ");	 
		} catch (AddressException e) {
			throw new Exception(e);
		} catch (MessagingException e) {
			throw new Exception(e);
		}
		
		
	}
}
