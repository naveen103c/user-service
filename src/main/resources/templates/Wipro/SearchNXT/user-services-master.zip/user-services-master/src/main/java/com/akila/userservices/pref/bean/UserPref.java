package com.akila.userservices.pref.bean;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class UserPref {
	
	@NotNull(message = "{USER.PREF.JSON.MANDATORY}")
	@NotEmpty(message = "{USER.PREF.JSON.MANDATORY}")
	private String personalPreferenceJson;

	@NotNull(message = "{USER.PREF.PREFCODE.MANDATORY}")
	private Integer prefTypeCd;

	public Integer getPrefTypeCd() {
		return prefTypeCd;
	}

	public void setPrefTypeCd(Integer prefTypeCd) {
		this.prefTypeCd = prefTypeCd;
	}

	public void setPersonalPreferenceJson(String personalPreferenceJson) {
		this.personalPreferenceJson = personalPreferenceJson;
	}

	public String getPersonalPreferenceJson() {
		return personalPreferenceJson;
	}
	
}
