package com.akila.userservices.pref.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseRefCodeType implements Serializable {
	private static final long serialVersionUID = 1L;

	private String refCodeTypeId;

	private Boolean isCrudEnabled;

	private Boolean isDisplayEditable;

	private String refCodeType;

	protected String crtBy;

	protected Timestamp crtTs;

	protected String modBy;

	protected Timestamp modTs;
	
	private List<OrgRefCode> orgRefCodes;

	public BaseRefCodeType() {
	}

	public String getRefCodeTypeId() {
		return this.refCodeTypeId;
	}

	public void setRefCodeTypeId(String refCodeTypeId) {
		this.refCodeTypeId = refCodeTypeId;
	}

	public Boolean getIsCrudEnabled() {
		return this.isCrudEnabled;
	}

	public void setIsCrudEnabled(Boolean isCrudEnabled) {
		this.isCrudEnabled = isCrudEnabled;
	}

	public Boolean getIsDisplayEditable() {
		return this.isDisplayEditable;
	}

	public void setIsDisplayEditable(Boolean isDisplayEditable) {
		this.isDisplayEditable = isDisplayEditable;
	}

	public String getRefCodeType() {
		return this.refCodeType;
	}

	public void setRefCodeType(String refCodeType) {
		this.refCodeType = refCodeType;
	}

	public List<OrgRefCode> getOrgRefCodes() {
		return this.orgRefCodes;
	}

	public void setOrgRefCodes(List<OrgRefCode> orgRefCodes) {
		this.orgRefCodes = orgRefCodes;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Timestamp getModTs() {
		return modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "BaseRefCodeType [refCodeTypeId=" + refCodeTypeId + ", isCrudEnabled=" + isCrudEnabled
				+ ", isDisplayEditable=" + isDisplayEditable + ", refCodeType=" + refCodeType + ", crtBy=" + crtBy
				+ ", crtTs=" + crtTs + ", modBy=" + modBy + ", modTs=" + modTs + ", orgRefCodes=" + orgRefCodes
				+ ", getRefCodeTypeId()=" + getRefCodeTypeId() + ", getIsCrudEnabled()=" + getIsCrudEnabled()
				+ ", getIsDisplayEditable()=" + getIsDisplayEditable() + ", getRefCodeType()=" + getRefCodeType()
				+ ", getOrgRefCodes()=" + getOrgRefCodes() + ", getCrtBy()=" + getCrtBy() + ", getCrtTs()=" + getCrtTs()
				+ ", getModBy()=" + getModBy() + ", getModTs()=" + getModTs() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

}