package com.akila.userservices.favlist.bean;

import com.akila.userservices.entity.OrgUserFavlist;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface FavlistMapper {
  FavlistMapper INSTANCE = Mappers.getMapper(FavlistMapper.class);
  ;

  @Mappings({})
  FavlistResponse orgUserFavlistToFavlistResponse(OrgUserFavlist orgUserFavlist);

  @Mappings({})
  List<FavlistResponse> orgUserFavlistToFavlistResponseList(List<OrgUserFavlist> orgUserFavlist);

  @Mappings({})
  OrgUserFavlist favlistRequestToOrgUserFavlist(FavlistRequest favlistRequest);
}
