package com.akila.userservices.favlist.bean;

import java.sql.Timestamp;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.akila.AkilaRequest;
import com.akila.userservices.entity.OrgUserFavlistPK;

public class FavlistRequest extends AkilaRequest {
	
  private Timestamp crtTs;

  @NotNull(message = "{USER.FAVLIST.DESC.MANDATORY}")
  @NotEmpty(message = "{USER.FAVLIST.DESC.MANDATORY}")
  @Size(min = 2 ,max =100,message = "{USER.FAVLIST.DESC.LENGTH}")
  private String description;

  @NotNull(message = "{USER.FAVLIST.NAME.MANDATORY}")
  @NotEmpty(message = "{USER.FAVLIST.NAME.MANDATORY}")
  @Size(min = 2 ,max =50,message = "{USER.FAVLIST.NAME.LENGTH}")
  private String favlistNm;

  @NotNull(message = "{USER.FAVLIST.ISDEFAULT.MANDATORY}")
  private Boolean isDefault;

  @NotNull(message = "{USER.FAVLIST.ISSHARED.MANDATORY}")
  private Boolean isShared;

  private Timestamp modTs;

  private OrgUserFavlistPK id;

  public OrgUserFavlistPK getId() {
	return id;
  }

  public void setId(OrgUserFavlistPK id) {
	this.id = id;
  }
  
  public void setCrtTs(Timestamp crtTs) {
    this.crtTs = crtTs;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setFavlistNm(String favlistNm) {
    this.favlistNm = favlistNm;
  }

  public void setIsDefault(Boolean isDefault) {
    this.isDefault = isDefault;
  }

  public void setIsShared(Boolean isShared) {
    this.isShared = isShared;
  }

  public void setModTs(Timestamp modTs) {
    this.modTs = modTs;
  }

  public Timestamp getCrtTs() {
    return crtTs;
  }

  public String getDescription() {
    return description;
  }

  public String getFavlistNm() {
    return favlistNm;
  }

  public Boolean getIsDefault() {
    return isDefault;
  }

  public Boolean getIsShared() {
    return isShared;
  }

  public Timestamp getModTs() {
    return modTs;
  }
}
