package com.akila.userservices.pref.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OrgRefCode implements Serializable {
	private static final long serialVersionUID = 1L;

	private String refCodeId;

	private String refCodeDescription;

	private String refCodeDisplayVal;

	private Integer refCodeStoreVal;

	private String crtBy;

	public OrgRefCode() {
	}

	public String getRefCodeId() {
		return this.refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public String getRefCodeDescription() {
		return this.refCodeDescription;
	}

	public void setRefCodeDescription(String refCodeDescription) {
		this.refCodeDescription = refCodeDescription;
	}

	public String getRefCodeDisplayVal() {
		return this.refCodeDisplayVal;
	}

	public void setRefCodeDisplayVal(String refCodeDisplayVal) {
		this.refCodeDisplayVal = refCodeDisplayVal;
	}

	public Integer getRefCodeStoreVal() {
		return this.refCodeStoreVal;
	}

	public void setRefCodeStoreVal(Integer refCodeStoreVal) {
		this.refCodeStoreVal = refCodeStoreVal;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	@Override
	public String toString() {
		return "OrgRefCode [refCodeId=" + refCodeId + ", refCodeDescription=" + refCodeDescription
				+ ", refCodeDisplayVal=" + refCodeDisplayVal + ", refCodeStoreVal=" + refCodeStoreVal + ", crtBy="
				+ crtBy + "]";
	}

}