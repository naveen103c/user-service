package com.akila.userservices.entity;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import com.akila.AkilaEntity;

/**
 * The persistent class for the org_user_to_roles_link database table.
 * 
 */
@Entity
@Table(name = "org_user_to_roles_link")
@NamedQuery(name = "OrgUserToRolesLink.findAll", query = "SELECT o FROM OrgUserToRolesLink o")
public class OrgUserToRolesLink extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgUserToRolesLinkPK id;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "role_id", insertable = false, updatable = false)
	private BaseRole baseRole;

	@Column(name = "user_id", insertable = false, updatable = false)
	private String userId;

	public OrgUserToRolesLink() {
	}

	public OrgUserToRolesLinkPK getId() {
		return this.id;
	}

	public void setId(OrgUserToRolesLinkPK id) {
		this.id = id;
	}

	public BaseRole getBaseRole() {
		return baseRole;
	}

	public void setBaseRole(BaseRole baseRole) {
		this.baseRole = baseRole;
	}

}