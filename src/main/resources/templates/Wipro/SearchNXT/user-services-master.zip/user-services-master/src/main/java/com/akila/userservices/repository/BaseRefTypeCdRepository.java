package com.akila.userservices.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BaseRefTypeCdRepository  {
	
	@Autowired
	private OrgUserPrefChildRepository orgUserPrefRepository;
	
	public List<String> getTagsForPreferences(List<String> options) {
		List<String> result = orgUserPrefRepository.findByRefCodeDisplayValue(options);
		return result;
	}
}
