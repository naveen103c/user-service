package com.akila.userservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.userservices.entity.BaseUserPref;

@Repository
public interface BaseUserPrefRepository extends JpaRepository<BaseUserPref, String> {
	
	List<BaseUserPref> findByprefTypeCdAndActive(Integer prefTypeId,Boolean action);
	
	List<BaseUserPref> findAlllByParentPrefIdNotNull();
}
