package com.akila.userservices.favlink.bean;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.akila.AkilaRequest;

public class FavLinkRequest extends AkilaRequest {

	private String favlistId;

	@NotNull(message = "{USER.FAVLINK.CONTENTID.MANDATORY}")
	@NotEmpty(message = "{USER.FAVLINK.CONTENTID.MANDATORY}")
	private String contentId;
	
	@NotNull(message = "{USER.FAVLINK.TITLE.MANDATORY}")
	@NotEmpty(message = "{USER.FAVLINK.TITLE.MANDATORY}")
	@Size(min = 2,max = 100, message = "{USER.FAVLINK.TITLE.LENGTH}")
	private String title;

	@NotNull(message = "{USER.FAVLINK.URL.MANDATORY}")
	@NotEmpty(message = "{USER.FAVLINK.URL.MANDATORY}")
	@Size(min = 2, max = 1024, message = "{USER.FAVLINK.URL.LENGTH}")
	private String url;

	public String getFavlistId() {
		return favlistId;
	}

	public void setFavlistId(String favlistId) {
		this.favlistId = favlistId;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

  }
