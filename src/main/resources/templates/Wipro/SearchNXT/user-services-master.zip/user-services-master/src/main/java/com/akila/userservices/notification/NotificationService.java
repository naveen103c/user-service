package com.akila.userservices.notification;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.userservices.entity.OrgNotification;
import com.akila.userservices.entity.OrgNotificationHistory;
import com.akila.userservices.notification.bean.NotificationMapper;
import com.akila.userservices.notification.bean.NotificationResponse;
import com.akila.userservices.repository.OrgNotificationHistoryRepository;
import com.akila.userservices.repository.OrgNotificationRepository;

@Service
public class NotificationService extends AkilaService {

	private static Logger logger = LogManager.getLogger(NotificationService.class);
	
	@Autowired
	private OrgNotificationRepository orgNotificationRepository;

	@Autowired
	private OrgNotificationHistoryRepository orgNotificationHistoryRepository;

	@Autowired
	private NotificationMapper notificationMapper;

	public Map<String, Object> getAllNotifications(Integer offSet, Integer pageSize) {
		logger.info("NotificationService:getAllNotifications starting getting all the user's notification");
		Map<String, Object> notificationResponse = new HashMap<String, Object>();
		Pageable pageable = PageRequest.of(offSet, pageSize, Sort.by("crtTs").descending());
		List<OrgNotification> orgNotifications = orgNotificationRepository.findByUserId(getUserId(), pageable);
		long totalCount = orgNotificationRepository.countByUserId(getUserId());
		List<NotificationResponse> notificationResponses = notificationMapper
				.orgNotificationToNotificationResponseList(orgNotifications);
		Timestamp modTs = new Timestamp(new Date().getTime());
		orgNotifications.forEach(notification -> {
			notification.setIsRead(true);
			notification.setModTs(modTs);
		});
		orgNotificationRepository.saveAll(orgNotifications);
		notificationResponse.put("notifications", notificationResponses);
		notificationResponse.put("totalPages", totalCount);
		logger.info("NotificationService:getAllNotifications Got all the user's notification and updated the notification status");
		return notificationResponse;
	}

	public long getUnreadNotificationsCount() {
		long unreadCount = orgNotificationRepository.countByIsReadAndUserId(false, getUserId());
		return unreadCount;
	}

	public boolean deleteNotification(String id) {
		OrgNotification orgNotification = orgNotificationRepository.findById(id).orElse(null);
		if (orgNotification != null) {
			orgNotificationRepository.deleteById(id);
			OrgNotificationHistory orgNotificationHistory = notificationMapper
					.orgNotificationToOrgNotificationHistory(orgNotification);
			orgNotificationHistoryRepository.save(orgNotificationHistory);
			return true;

		} else {
			return false;
		}

	}

}
