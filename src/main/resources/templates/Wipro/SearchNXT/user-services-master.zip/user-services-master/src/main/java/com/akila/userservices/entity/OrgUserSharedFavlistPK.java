package com.akila.userservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * The primary key class for the org_user_shared_favlist database table.
 * 
 */
@Embeddable
public class OrgUserSharedFavlistPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="shared_favlist_id", insertable=false, updatable=false)
	private String sharedFavlistId;

	@Column(name="favlist_id")
	private String favlistId;

	public OrgUserSharedFavlistPK() {
	}
	public String getSharedFavlistId() {
		return sharedFavlistId;
	}
	public void setSharedFavlistId(String sharedFavlistId) {
		this.sharedFavlistId = sharedFavlistId;
	}
	public String getFavlistId() {
		return this.favlistId;
	}
	public void setFavlistId(String favlistId) {
		this.favlistId = favlistId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof OrgUserSharedFavlistPK)) {
			return false;
		}
		OrgUserSharedFavlistPK castOther = (OrgUserSharedFavlistPK)other;
		return 
			this.sharedFavlistId.equals(castOther.sharedFavlistId)
			&& this.favlistId.equals(castOther.favlistId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.sharedFavlistId.hashCode();
		hash = hash * prime + this.favlistId.hashCode();
		
		return hash;
	}
}