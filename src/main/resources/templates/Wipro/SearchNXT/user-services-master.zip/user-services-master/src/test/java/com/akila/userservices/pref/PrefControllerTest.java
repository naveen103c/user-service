package com.akila.userservices.pref;

import java.sql.Timestamp;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.userservices.UserServicesApplication;
import com.akila.userservices.entity.OrgUserPrefPK;
import com.akila.userservices.favlist.bean.FavlistResponse;
import com.akila.userservices.pref.bean.PrefRequest;
import com.akila.userservices.pref.bean.PrefResponse;

@SpringBootTest(classes = UserServicesApplication.class)

public class PrefControllerTest {

	/*
	 * @Autowired private PrefController prefController;
	 */

//	@Test
//	public void getPreferenceTest() {
//		PrefResponse prefResponse = prefController.getPreference(999);
//		System.out.println("prefResponse.getId().getPrefTypeCd() = " + prefResponse.getId().getPrefTypeCd());
//	}
//
//	@Test
//	public void updatePreferenceTest() {
//		PrefRequest prefRequest = new PrefRequest();
//		OrgUserPrefPK id=new OrgUserPrefPK();
//		id.setPrefTypeCd(999);
//		prefRequest.setId(id);
//		prefRequest.setModTs(new Timestamp(System.currentTimeMillis()));
//		prefRequest.setCrtTs(new Timestamp(System.currentTimeMillis()));
//
//		System.out.println("udated the record with id = " + prefController.updatePreference(prefRequest).getId());
//	}

}