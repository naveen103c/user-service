package com.akila.userservices.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the org_community_user_groups database table.
 * 
 */
@Embeddable
public class OrgCommunityUserGroupPK implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Column(name="community_id", insertable=false, updatable=false)
	private String communityId;

	@Column(name="user_group_id", insertable=false, updatable=false)
	private String userGroupId;

	public OrgCommunityUserGroupPK() {
	}
	public String getCommunityId() {
		return this.communityId;
	}
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}
	public String getUserGroupId() {
		return userGroupId;
	}
	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}
	
}