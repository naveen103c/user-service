package com.akila.userservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;

/**
 * The persistent class for the org_notifications_history database table.
 * 
 */
@Entity
@Table(name = "org_notifications_history")
@NamedQuery(name = "OrgNotificationHistory.findAll", query = "SELECT o FROM OrgNotificationHistory o")
public class OrgNotificationHistory extends AkilaEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "notification_id")
	private String notificationId;

	@Column(name = "userid")
	private String userId;

	@Column(name = "notification_title")
	private String notificationTitle;

	@Column(name = "notification_msg")
	private String notificationMsg;

	@Column(name = "notification_type_cd")
	private int notificationTypeCd;

	@Column(name = "is_read")
	private Boolean isRead;
	
	@Column(name = "redirect_url")
	private String redirectUrl;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getNotificationTitle() {
		return notificationTitle;
	}

	public void setNotificationTitle(String notificationTitle) {
		this.notificationTitle = notificationTitle;
	}

	public String getNotificationMsg() {
		return notificationMsg;
	}

	public void setNotificationMsg(String notificationMsg) {
		this.notificationMsg = notificationMsg;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public int getNotificationTypeCd() {
		return notificationTypeCd;
	}

	public void setNotificationTypeCd(int notificationTypeCd) {
		this.notificationTypeCd = notificationTypeCd;
	}

	public Boolean getIsRead() {
		return isRead;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	public String getRedirectUrl() {
		return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

}
