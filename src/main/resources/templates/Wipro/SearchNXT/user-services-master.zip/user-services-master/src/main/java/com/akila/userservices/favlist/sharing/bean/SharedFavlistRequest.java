package com.akila.userservices.favlist.sharing.bean;

import java.sql.Timestamp;
import java.util.List;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.akila.AkilaRequest;

public class SharedFavlistRequest extends AkilaRequest {

	@NotEmpty(message = "{USER.FAVLIST.SHARED.USERID.MANDATORY}")
	@NotNull(message = "{USER.FAVLIST.SHARED.USERID.MANDATORY}")
	private List<@NotBlank(message = "{USER.FAVLIST.SHARED.USERID.MANDATORY}") String> userId;

	@NotNull(message = "{USER.FAVLIST.SHARED.FAVLISTID.MANDATORY}")
	@NotEmpty(message = "{USER.FAVLIST.SHARED.FAVLISTID.MANDATORY}")
	private String favlistId;

	@NotNull(message = "{USER.FAVLIST.SHARED.USERGROUPID.MANDATORY}")
	@NotEmpty(message = "{USER.FAVLIST.SHARED.USERGROUPID.MANDATORY}")
	private String userGroupId;

	@Future(message = "{USER.FAVLIST.SHARED.EXPIREDATE.FUTURE}")
	private Timestamp expiryDate;

	public List<String> getUserId() {
		return userId;
	}

	public void setUserId(List<String> userId) {
		this.userId = userId;
	}

	public String getFavlistId() {
		return favlistId;
	}

	public void setFavlistId(String favlistId) {
		this.favlistId = favlistId;
	}

	public String getUserGroupId() {
		return userGroupId;
	}

	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}

	public Timestamp getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}

}
