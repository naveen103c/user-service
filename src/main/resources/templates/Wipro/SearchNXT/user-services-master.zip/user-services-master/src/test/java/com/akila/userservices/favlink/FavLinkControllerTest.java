package com.akila.userservices.favlink;

import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.userservices.UserServicesApplication;
import com.akila.userservices.favlink.bean.FavLinkRequest;
import com.akila.userservices.favlink.bean.FavLinkResponse;

@SpringBootTest(classes = UserServicesApplication.class)

public class FavLinkControllerTest {

	/*
	 * @Autowired private FavLinkController favLinkController;
	 */

	int count = 1;

	@Test
	public void getFavoriteListTest() {
		/*
		 * List<FavLinkResponse> favLinkResponseList = favLinkController
		 * .getAllFavoriteLink("4fadab2f-83c1-4ef2-9c3f-706cb0f7ca38");
		 * System.out.println("favLinkResponseList.size() = " +
		 * favLinkResponseList.size()); count += favLinkResponseList.size();
		 * FavLinkResponse favLinkResponse = new FavLinkResponse();
		 * Iterator<FavLinkResponse> itr = favLinkResponseList.iterator(); while
		 * (itr.hasNext()) { favLinkResponse = itr.next();
		 * System.out.println("favLinkResponse.getTitle() = " +
		 * favLinkResponse.getTitle()); }
		 */}

	@Test
	public void addLinkToFavouriteListTest() {
		FavLinkRequest favLinkRequest = new FavLinkRequest();
		favLinkRequest.setTitle("fav video" + count++);
		favLinkRequest.setUrl("https://www.youtube.com/");

//		System.out.println("added link to favlistId = "
//				+ favLinkController.addLinkToFavoriteList("d4c1ad6a-6a4c-443e-aec3-01f0dabeea28", favLinkRequest));
	}

	@Test
	public void removeFromFavoriteList() {
		/*
		 * System.out.println("Link removed with content Id = " +
		 * favLinkController.removeFromFavoriteList(
		 * "d4c1ad6a-6a4c-443e-aec3-01f0dabeea28",
		 * "308e5baf-09fc-43ad-8190-9591ade52aff"));
		 */

	}

}