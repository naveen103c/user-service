package com.akila.userservices.entity;

import com.akila.AkilaEntity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the org_user_shared_favlist database table.
 * 
 */
@Entity
@Table(name="org_user_shared_favlist")
@NamedQuery(name="OrgUserSharedFavlist.findAll", query="SELECT o FROM OrgUserSharedFavlist o")
public class OrgUserSharedFavlist extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgUserSharedFavlistPK id;

	@Column(name="expiry_date")
	private Timestamp expiryDate;

	@Column(name="user_id")
	private String userId;
	
	@Column(name="user_group_id")
	private String userGroupId;

	@Column(name="owner_user_id")
	private String ownerUserId;

	public OrgUserSharedFavlist() {
	}

	public OrgUserSharedFavlistPK getId() {
		return id;
	}

	public void setId(OrgUserSharedFavlistPK id) {
		this.id = id;
	}

	public Timestamp getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Timestamp expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getUserGroupId() {
		return userGroupId;
	}

	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}

	public String getOwnerUserId() {
		return ownerUserId;
	}

	public void setOwnerUserId(String ownerUserId) {
		this.ownerUserId = ownerUserId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "OrgUserSharedFavlist [id=" + id + ", expiryDate=" + expiryDate + ", userId=" + userId + ", userGroupId="
				+ userGroupId + ", ownerUserId=" + ownerUserId + "]";
	}

}