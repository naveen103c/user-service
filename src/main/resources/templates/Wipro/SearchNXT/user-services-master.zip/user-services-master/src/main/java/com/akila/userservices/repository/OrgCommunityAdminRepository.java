package com.akila.userservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.userservices.entity.OrgCommunityAdmin;
import com.akila.userservices.entity.OrgCommunityAdminPK;

@Repository
public interface OrgCommunityAdminRepository extends JpaRepository<OrgCommunityAdmin, OrgCommunityAdminPK> {

	List<OrgCommunityAdmin> findByUserId(String userId);

}
