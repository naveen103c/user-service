package com.akila.userservices.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;

/**
 * The persistent class for the org_user_shared_favlist_history database table.
 */

@Entity
@Table(name = "org_user_shared_favlist_history")
@NamedQuery(name = "org_user_shared_favlist_history.findAll", query = "SELECT o FROM OrgUserSharedFavlistHistory o")
public class OrgUserSharedFavlistHistory extends AkilaEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "shared_favlist_history_id")
	private String sharedFavlistHistoryId;

	@Column(name = "favlist_id")
	private String favlistId;
	
	@Column(name = "user_id")
	private String userId;
	
	@Column(name = "user_group_id")
	private String userGroupId;
	
	@Column(name = "owner_user_id")
	private String ownerUserId;
	
	@Column(name = "expiry_ts")
	private Timestamp expiryTs;
	
	public OrgUserSharedFavlistHistory() {

	}

	public String getSharedFavlistHistoryId() {
		return sharedFavlistHistoryId;
	}

	public void setSharedFavlistHistoryId(String sharedFavlistHistoryId) {
		this.sharedFavlistHistoryId = sharedFavlistHistoryId;
	}

	public String getFavlistId() {
		return favlistId;
	}

	public void setFavlistId(String favlistId) {
		this.favlistId = favlistId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserGroupId() {
		return userGroupId;
	}

	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}

	public String getOwnerUserId() {
		return ownerUserId;
	}

	public void setOwnerUserId(String ownerUserId) {
		this.ownerUserId = ownerUserId;
	}

	public Timestamp getExpiryTs() {
		return expiryTs;
	}

	public void setExpiryTs(Timestamp expiryTs) {
		this.expiryTs = expiryTs;
	}
	
	
}
