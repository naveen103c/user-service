package com.akila.userservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.userservices.entity.OrgUserPref;
import com.akila.userservices.entity.OrgUserPrefPK;

@Repository
public interface OrgUserPrefRepository extends JpaRepository<OrgUserPref, OrgUserPrefPK> {
	
	@Query(value="select b.ref_code_display_val from org_tags ot inner join "
			+ "(select * from org_ref_codes orc  where ref_code_type_id in ( select ref_code_type_id from base_ref_code_types brct where ref_code_type = 'TAG_TYPE_CD')) b "
			+ "on ot.tag_type_cd  = b.ref_code_store_val and  b.ref_code_display_val in (:tagTypes) group by b.ref_code_display_val", nativeQuery = true)
	List<String> findByRefCodeDisplayValue(List<String> tagTypes);
	
}
