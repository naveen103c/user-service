package com.akila.userservices.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the org_user_prefs database table.
 * 
 */
@Embeddable
public class OrgUserPrefPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

//	@Column(name="org_id", insertable=false, updatable=false)
//	private String orgId;

	@Column(name="user_id", insertable=false, updatable=false)
	private String userId;

	@Column(name="pref_type_cd")
	private Integer prefTypeCd;

	public OrgUserPrefPK() {
	}
//	public String getOrgId() {
//		return this.orgId;
//	}
//	public void setOrgId(String orgId) {
//		this.orgId = orgId;
//	}
	public String getUserId() {
		return this.userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Integer getPrefTypeCd() {
		return this.prefTypeCd;
	}
	public void setPrefTypeCd(Integer prefTypeCd) {
		this.prefTypeCd = prefTypeCd;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof OrgUserPrefPK)) {
			return false;
		}
		OrgUserPrefPK castOther = (OrgUserPrefPK)other;
		return 
			//this.orgId.equals(castOther.orgId)
			 this.userId.equals(castOther.userId)
			&& this.prefTypeCd.equals(castOther.prefTypeCd);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		//hash = hash * prime + this.orgId.hashCode();
		hash = hash * prime + this.userId.hashCode();
		hash = hash * prime + this.prefTypeCd.hashCode();
		
		return hash;
	}
}