package com.akila.userservices.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface OrgUserFavLinkChildRepository extends OrgUserFavLinkRepository {
}
