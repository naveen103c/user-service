package com.akila.userservices.favlink.bean;

import com.akila.userservices.entity.OrgUserFavLink;
import com.akila.userservices.entity.OrgUserFavlist;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface FavLinkMapper {
  FavLinkMapper INSTANCE = Mappers.getMapper(FavLinkMapper.class);
  ;

  @Mappings({})
  FavLinkResponse orgUserFavLinkToFavLinkResponse(OrgUserFavLink OrgUserFavLink);

  @Mappings({})
  List<FavLinkResponse> orgUserFavLinkToFavLinkResponseList(List<OrgUserFavLink> orgUserFavLink);

  @Mappings({})
  OrgUserFavLink favLinkRequestToOrgUserFavLink(FavLinkRequest favLinkRequest);
}
