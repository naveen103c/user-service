package com.akila.userservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.userservices.entity.OrgUserSharedFavlistHistory;

@Repository
public interface OrgUserSharedFavlistHistoryRepository extends JpaRepository<OrgUserSharedFavlistHistory, String> {
	
}
