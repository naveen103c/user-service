package com.akila.userservices.user;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.akila.AkilaController;
import com.akila.userservices.user.bean.OrgBatchJobConfResponse;
import com.akila.userservices.user.bean.OrgUserToCommunityResponse;
import com.akila.userservices.user.bean.OrgUserToRolesLinkResponse;

@RestController
public class UserController extends AkilaController {

	@Autowired
	private UserService userService;

	@GetMapping(path = "/user/roles")
	public ResponseEntity<List<OrgUserToRolesLinkResponse>> getUserLinkedRole() {
	return ResponseEntity.ok(userService.getUserLinkedRoles());
	}
	
	@GetMapping(path = "/user/communities")
	public ResponseEntity<List<OrgUserToCommunityResponse>> getUserLinkedCommunities() {
	return ResponseEntity.ok(userService.getUserRelatedCommunities());
	}

	@GetMapping(path = "/user/confs")
	public ResponseEntity<List<OrgBatchJobConfResponse>> getUserDataConfigurations() {
	return ResponseEntity.ok(userService.getUserDataConfigurations());
	}

}
