package com.akila.userservices.pref.bean;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

public class UserPrefResponseMapper {

	private String key;

	private String title;

	private String type;

	private List<String> answer = new ArrayList<String>();
	
	private List<String> values = new ArrayList<String>();
	
	private List<UserPrefResponseMapper> children;
	
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String visibility;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String sequence;

	public UserPrefResponseMapper() {
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getAnswer() {
		return answer;
	}

	public void setAnswer(List<String> answer) {
		this.answer = answer;
	}

	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	public List<UserPrefResponseMapper> getChildren() {
		return children;
	}

	public void setChildren(List<UserPrefResponseMapper> children) {
		this.children = children;
	}

	@Override
	public String toString() {
		return "UserPrefResponseMapper [key=" + key + ", title=" + title + ", type=" + type + ", answer=" + answer
				+ ", values=" + values + ", children=" + children + ", visibility=" + visibility + ", sequence="
				+ sequence + "]";
	}

}
