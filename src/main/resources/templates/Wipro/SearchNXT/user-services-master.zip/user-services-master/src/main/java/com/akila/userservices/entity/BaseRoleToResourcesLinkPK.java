package com.akila.userservices.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the base_role_to_resources_link database table.
 * 
 */
@Embeddable
public class BaseRoleToResourcesLinkPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="role_id", insertable=false, updatable=false)
	private String roleId;

	@Column(name="resource_id", insertable=false, updatable=false)
	private String resourceId;

	public BaseRoleToResourcesLinkPK() {
	}
	public String getRoleId() {
		return this.roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getResourceId() {
		return this.resourceId;
	}
	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof BaseRoleToResourcesLinkPK)) {
			return false;
		}
		BaseRoleToResourcesLinkPK castOther = (BaseRoleToResourcesLinkPK)other;
		return 
			this.roleId.equals(castOther.roleId)
			&& this.resourceId.equals(castOther.resourceId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.roleId.hashCode();
		hash = hash * prime + this.resourceId.hashCode();
		
		return hash;
	}
}