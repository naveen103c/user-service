package com.akila.userservices.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;


/**
 * The persistent class for the base_role_to_resources_link database table.
 * 
 */
@Entity
@Table(name="base_role_to_resources_link",schema="base")
@NamedQuery(name="BaseRoleToResourcesLink.findAll", query="SELECT b FROM BaseRoleToResourcesLink b")
public class BaseRoleToResourcesLink extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BaseRoleToResourcesLinkPK id;

	
	public BaseRoleToResourcesLink() {
	}

	public BaseRoleToResourcesLinkPK getId() {
		return this.id;
	}

	public void setId(BaseRoleToResourcesLinkPK id) {
		this.id = id;
	}

}