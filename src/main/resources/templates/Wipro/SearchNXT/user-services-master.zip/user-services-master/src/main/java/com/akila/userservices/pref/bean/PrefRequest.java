package com.akila.userservices.pref.bean;

import java.util.List;

import com.akila.AkilaRequest;

public class PrefRequest extends AkilaRequest {

	private List<UserPref> userPrefs;

	public List<UserPref> getUserPrefs() {
		return userPrefs;
	}

	public void setUserPrefs(List<UserPref> userPrefs) {
		this.userPrefs = userPrefs;
	}

}
