package com.akila.userservices.pref.bean;

import java.util.List;

public class UserPrefMapper {

	private String prefId;
	
	private String ans;
	
	private String visibility;
	
	private String sequence;
	
	private Integer prefTypeCd;

	List<UserPrefMapper> children;
	
	public UserPrefMapper() {
	}

	public String getPrefId() {
		return prefId;
	}

	public void setPrefId(String prefId) {
		this.prefId = prefId;
	}

	public String getAns() {
		return ans;
	}

	public void setAns(String ans) {
		this.ans = ans;
	}

	public String getVisibility() {
		return visibility;
	}

	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}

	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	public Integer getPrefTypeCd() {
		return prefTypeCd;
	}

	public void setPrefTypeCd(Integer prefTypeCd) {
		this.prefTypeCd = prefTypeCd;
	}

	public List<UserPrefMapper> getChildren() {
		return children;
	}

	public void setChildren(List<UserPrefMapper> children) {
		this.children = children;
	}

	@Override
	public String toString() {
		return "UserPrefMapper [prefId=" + prefId + ", ans=" + ans + ", visibility=" + visibility + ", sequence="
				+ sequence + ", prefTypeCd=" + prefTypeCd + ", children=" + children + "]";
	}
	
}
