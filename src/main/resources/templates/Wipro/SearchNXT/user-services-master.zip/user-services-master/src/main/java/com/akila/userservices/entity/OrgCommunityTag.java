package com.akila.userservices.entity;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the org_community_tags database table.
 * 
 */
@Entity
@Table(name="org_community_tags")
@NamedQuery(name="OrgCommunityTag.findAll", query="SELECT o FROM OrgCommunityTag o")
public class OrgCommunityTag extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgCommunityTagPK id;

	//bi-directional many-to-one association to OrgCommunity
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="community_id",  insertable=false, updatable=false)
	private OrgCommunity orgCommunity;

	public OrgCommunityTag() {
	}

	public OrgCommunityTagPK getId() {
		return this.id;
	}

	public void setId(OrgCommunityTagPK id) {
		this.id = id;
	}

	public OrgCommunity getOrgCommunity() {
		return this.orgCommunity;
	}

	public void setOrgCommunity(OrgCommunity orgCommunity) {
		this.orgCommunity = orgCommunity;
	}

}