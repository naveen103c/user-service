package com.akila.userservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.akila.userservices.entity.OrgCommunitySme;
import com.akila.userservices.entity.OrgCommunitySmePK;
@Repository
public interface OrgCommunitySmeRepository extends JpaRepository<OrgCommunitySme, OrgCommunitySmePK>{
	List<OrgCommunitySme> findByUserId(String userId);
}
