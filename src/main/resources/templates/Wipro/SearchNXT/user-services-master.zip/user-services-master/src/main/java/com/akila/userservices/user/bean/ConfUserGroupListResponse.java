package com.akila.userservices.user.bean;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ConfUserGroupListResponse {
	private static final Logger logger = LogManager.getLogger(ConfUserGroupListResponse.class);
	
	private String confId;
	private List<String> sourceAllowedUserGroupList;	
	ObjectMapper objectMapper = new ObjectMapper();
	
	public ConfUserGroupListResponse(String confId, String sourceAllowedUserGroupList) {
		super();
		this.confId = confId;
		try {
			this.sourceAllowedUserGroupList = objectMapper.readValue(sourceAllowedUserGroupList, List.class);
		} catch (JsonProcessingException e) {
			logger.error(e.getMessage(), e);
		}
	}
	public String getConfId() {
		return confId;
	}
	public void setConfId(String confId) {
		this.confId = confId;
	}
	public List<String> getSourceAllowedUserGroupList() {
		return sourceAllowedUserGroupList;
	}
	public void setSourceAllowedUserGroupList(List<String> sourceAllowedUserGroupList) {
		this.sourceAllowedUserGroupList = sourceAllowedUserGroupList;
	}
}
