package com.akila.userservices.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@DynamicUpdate
@Table(name = "org_batch_job_runtime")
public class OrgBatchJobRuntime {

	@Id
	@Column(name = "job_id")
	String jobId;

	@Column(name = "conf_id")
	String confId;

	@Column(name = "current_running_module")
	String currentRunningModule;

	@Column(name = "last_job_updated_ts")
	Date lastJobUpdatedTs;

	@Column(name = "job_status_cd")
	int jobStatusCd;

	@Column(name = "exec_env_json")
	String execEnvJson;

	@Column(name = "job_control_data_json")
	String jobControlDataJson;

	@Column(name = "job_start_ts")
	Date jobStartTs;

	@Column(name = "job_summary_json")
	String jobSummaryJson;

	@Column(name = "job_priority")
	int jobPriority;

	@Column(name = "crt_by")
	String crtBy;

	@Column(name = "crt_ts")
	Date crtTs;

	@Column(name = "mod_by")
	String modBy;

	@Column(name = "mod_ts")
	Date modTs;

	@ManyToOne
	@JoinColumn(name = "conf_id", insertable = false, updatable = false)
	OrgBatchJobConf orgBatchJobConfs;

	public String getJobId() {
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public String getConfId() {
		return confId;
	}

	public void setConfId(String confId) {
		this.confId = confId;
	}

	public String getCurrentRunningModule() {
		return currentRunningModule;
	}

	public void setCurrentRunningModule(String currentRunningModule) {
		this.currentRunningModule = currentRunningModule;
	}

	public Date getLastJobUpdatedTs() {
		return lastJobUpdatedTs;
	}

	public void setLastJobUpdatedTs(Date lastJobUpdatedTs) {
		this.lastJobUpdatedTs = lastJobUpdatedTs;
	}

	public int getJobStatusCd() {
		return jobStatusCd;
	}

	public void setJobStatusCd(int jobStatusCd) {
		this.jobStatusCd = jobStatusCd;
	}

	public String getExecEnvJson() {
		return execEnvJson;
	}

	public void setExecEnvJson(String execEnvJson) {
		this.execEnvJson = execEnvJson;
	}

	public String getJobControlDataJson() {
		return jobControlDataJson;
	}

	public void setJobControlDataJson(String jobControlDataJson) {
		this.jobControlDataJson = jobControlDataJson;
	}

	public Date getJobStartTs() {
		return jobStartTs;
	}

	public void setJobStartTs(Date jobStartTs) {
		this.jobStartTs = jobStartTs;
	}

	public String getJobSummaryJson() {
		return jobSummaryJson;
	}

	public void setJobSummaryJson(String jobSummaryJson) {
		this.jobSummaryJson = jobSummaryJson;
	}

	public int getJobPriority() {
		return jobPriority;
	}

	public void setJobPriority(int jobPriority) {
		this.jobPriority = jobPriority;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Date getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Date crtTs) {
		this.crtTs = crtTs;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Date getModTs() {
		return modTs;
	}

	public void setModTs(Date modTs) {
		this.modTs = modTs;
	}

}
