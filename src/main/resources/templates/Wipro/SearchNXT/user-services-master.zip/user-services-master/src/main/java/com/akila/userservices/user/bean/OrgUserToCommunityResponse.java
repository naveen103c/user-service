package com.akila.userservices.user.bean;

import java.util.List;

public class OrgUserToCommunityResponse {

	private String communityId;
	private String communityNm;
	private String parentCommunityNm;
	private String communityOwnerNm;
	private List<String> roles;

	public OrgUserToCommunityResponse() {
		super();
	}

	public OrgUserToCommunityResponse(String communityNm, String parentCommunityNm,
			String communityOwnerNm, List<String> roles) {
		super();
		this.communityNm = communityNm;
		this.parentCommunityNm = parentCommunityNm;
		this.communityOwnerNm = communityOwnerNm;
		this.roles = roles;
	}
	
	public OrgUserToCommunityResponse(String communityId, String communityNm, String parentCommunityNm,
			String communityOwnerNm, List<String> roles) {
		super();
		this.communityId = communityId;
		this.communityNm = communityNm;
		this.parentCommunityNm = parentCommunityNm;
		this.communityOwnerNm = communityOwnerNm;
		this.roles = roles;
	}


	public String getCommunityId() {
		return communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}	

	public String getCommunityNm() {
		return communityNm;
	}

	public void setCommunityNm(String communityNm) {
		this.communityNm = communityNm;
	}

	public String getParentCommunityNm() {
		return parentCommunityNm;
	}

	public void setParentCommunityNm(String parentCommunityNm) {
		this.parentCommunityNm = parentCommunityNm;
	}

	public String getcommunityOwnerNm() {
		return communityOwnerNm;
	}

	public void setcommunityOwnerNm(String communityOwnerNm) {
		this.communityOwnerNm = communityOwnerNm;
	}

	public List<String> getroles() {
		return roles;
	}

	public void setroles(List<String> roles) {
		this.roles = roles;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((communityId == null) ? 0 : communityId.hashCode());
		result = prime * result + ((communityOwnerNm == null) ? 0 : communityOwnerNm.hashCode());
		result = prime * result + ((parentCommunityNm == null) ? 0 : parentCommunityNm.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrgUserToCommunityResponse other = (OrgUserToCommunityResponse) obj;
		if (communityId == null) {
			if (other.communityId != null)
				return false;
		} else if (!communityId.equals(other.communityId))
			return false;
		if (communityOwnerNm == null) {
			if (other.communityOwnerNm != null)
				return false;
		} else if (!communityOwnerNm.equals(other.communityOwnerNm))
			return false;
		if (parentCommunityNm == null) {
			if (other.parentCommunityNm != null)
				return false;
		} else if (!parentCommunityNm.equals(other.parentCommunityNm))
			return false;
		return true;
	}

}
