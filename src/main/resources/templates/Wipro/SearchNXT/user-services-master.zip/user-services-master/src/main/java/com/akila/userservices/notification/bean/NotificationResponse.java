package com.akila.userservices.notification.bean;

import java.sql.Timestamp;

import javax.persistence.Column;

import com.akila.AkilaResponse;

public class NotificationResponse extends AkilaResponse {

	private String notificationId;

	private String userId;

	private String notificationTitle;

	private String notificationMsg;

	private int notificationTypeCd;

	private String crtBy;

	private Timestamp crtTs;

	private String modBy;

	private Timestamp modTs;

	private Boolean isRead;
	
	private String redirectUrl;

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setNotificationTitle(String notificationTitle) {
		this.notificationTitle = notificationTitle;
	}

	public void setNotificationMsg(String notificationMsg) {
		this.notificationMsg = notificationMsg;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public String getUserId() {
		return userId;
	}

	public String getNotificationTitle() {
		return notificationTitle;
	}

	public String getNotificationMsg() {
		return notificationMsg;
	}

	public int getNotificationTypeCd() {
		return notificationTypeCd;
	}

	public void setNotificationTypeCd(int notificationTypeCd) {
		this.notificationTypeCd = notificationTypeCd;
	}

	public Boolean getIsRead() {
		return isRead;
	}

	public String getCrtBy() {
		return crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getModBy() {
		return modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Timestamp getModTs() {
		return modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public String getRedirectUrl() {
		return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}

}
