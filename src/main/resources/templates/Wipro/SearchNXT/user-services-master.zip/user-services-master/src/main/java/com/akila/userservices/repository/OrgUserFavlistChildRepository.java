package com.akila.userservices.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface OrgUserFavlistChildRepository extends OrgUserFavlistRepository {
}
