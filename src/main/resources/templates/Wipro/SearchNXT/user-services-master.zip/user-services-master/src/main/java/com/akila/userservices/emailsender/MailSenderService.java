package com.akila.userservices.emailsender;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.commons.email.sender.MailSenderHelper;
import com.akila.userservices.entity.BaseEmailTemplate;
import com.akila.userservices.entity.OrgEmailTemplate;
import com.akila.userservices.repository.BaseEmailTemplateRepository;
import com.akila.userservices.repository.OrgEmailTemplateRepository;

import javassist.NotFoundException;

@Service
public class MailSenderService extends MailSenderHelper {

	@Autowired
	private OrgEmailTemplateRepository orgMailTemplateRepository;

	@Autowired
	private BaseEmailTemplateRepository baseMailTemplateRepository;

	public Map<String, String> getMailDetails(String templateId) throws NotFoundException {
		Map<String, String> responseMap = new HashMap<String, String>();

		if (orgMailTemplateRepository.existsById(templateId)) {
			OrgEmailTemplate orgMailTemplate = new OrgEmailTemplate();
			orgMailTemplate = orgMailTemplateRepository.getOne(templateId);
			responseMap.put("body", orgMailTemplate.getTemplate());
			responseMap.put("subject", orgMailTemplate.getSubject());
			responseMap.put("defaultCC", orgMailTemplate.getDefaultCC());
			responseMap.put("defaultTO", orgMailTemplate.getDefaultTO());
		} else if (baseMailTemplateRepository.existsById(templateId)) {
			BaseEmailTemplate baseMailTemplate = new BaseEmailTemplate();
			baseMailTemplate = baseMailTemplateRepository.getOne(templateId);
			responseMap.put("body", baseMailTemplate.getTemplate());
			responseMap.put("subject", baseMailTemplate.getSubject());
			responseMap.put("defaultCC", baseMailTemplate.getDefaultCC());
			responseMap.put("defaultTO", baseMailTemplate.getDefaultTO());
		} else {
			throw new NotFoundException("specified template ID does not exists");
		}

		return responseMap;
	}

public void initiateEmail(List<String> toEmail, String templateId, String attachmentUrl) throws NotFoundException {
		
		Map<String, String> responseMap = getMailDetails(templateId);
		
		List<String> CC = new ArrayList<String>();
		if (responseMap.get("defaultCC") != null) {
			CC.addAll(Arrays.asList(responseMap.get("defaultCC").split(",")));
		}
		
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		executorService.execute(new Runnable() {
			@Override
			public void run() {
				try {
					sendEmail(toEmail, CC, responseMap, null, attachmentUrl);
				} catch (MessagingException | IOException e) {
					e.printStackTrace();
				}
			}
		});
	}

	  
}
