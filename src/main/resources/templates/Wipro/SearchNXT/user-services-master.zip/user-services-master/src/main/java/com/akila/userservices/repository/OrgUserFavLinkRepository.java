package com.akila.userservices.repository;

import com.akila.userservices.entity.OrgUserFavLink;
import com.akila.userservices.entity.OrgUserFavLinkPK;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface OrgUserFavLinkRepository extends JpaRepository<OrgUserFavLink, OrgUserFavLinkPK> {
	
	@Query("select fl from OrgUserFavLink fl where fl.id.favlistId = :favlistId")
	public List<OrgUserFavLink> findAllOrgUserFavLinkbyFavLinkId(String favlistId);
}
