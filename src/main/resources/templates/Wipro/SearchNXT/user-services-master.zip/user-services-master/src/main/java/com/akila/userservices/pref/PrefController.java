package com.akila.userservices.pref;

import com.akila.AkilaController;
import com.akila.response.ResponseId;
import com.akila.userservices.pref.bean.PrefRequest;
import com.akila.userservices.pref.bean.PrefResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PrefController extends AkilaController {
	
  private static Logger log = LogManager.getLogger(PrefController.class);
	
  @Autowired
  private PrefService prefService;

  @GetMapping(
      path = "/prefs"
  )
  public PrefResponse getPreference(@RequestParam Integer prefTypeCd) throws Exception {
		try {
			return prefService.getPreference(prefTypeCd);
		} catch (JsonMappingException e) {
			log.error("getPreference Mapping  : " + e.getMessage(), e);
			throw new Exception(e);
		} catch (JsonProcessingException e1) {
			log.error("getPreference Mapping  : " + e1.getMessage(), e1);
			throw new Exception(e1);
		} catch (Exception e2) {
			log.error("getPreference Mapping  : " + e2.getMessage(), e2);
			throw new Exception(e2);
		}
  }

  @PutMapping(
      path = "/prefs"
  )
  public void updatePreference(@Valid @RequestBody PrefRequest prefRequest) {
     prefService.updatePreference(prefRequest);
  }
  
  @GetMapping(
	      path = "/user/prefs"
	  )
	  public PrefResponse getUserPreference(@RequestParam(required=false) String prefTypeCd) throws Exception {
			try {
				return prefService.getPreference(prefTypeCd);
			} catch (JsonMappingException e) {
				log.error("getPreference Mapping  : " + e.getMessage(), e);
				throw new Exception(e);
			} catch (JsonProcessingException e1) {
				log.error("getPreference Mapping  : " + e1.getMessage(), e1);
				throw new Exception(e1);
			} catch (Exception e2) {
				log.error("getPreference Mapping  : " + e2.getMessage(), e2);
				throw new Exception(e2);
			}
	  }
  
}
