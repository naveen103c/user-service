package com.akila.userservices.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.userservices.entity.OrgNotification;

@Repository
public interface OrgNotificationRepository extends JpaRepository<OrgNotification, String> {

	public List<OrgNotification> findByUserId(String userId, Pageable pageable);

	long countByIsReadAndUserId(Boolean isRead, String userId);

	long countByUserId(String userId);
}
