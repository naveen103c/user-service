package com.akila.userservices.user.bean;

public class OrgUserToRolesLinkResponse {

	private String roleId;
	private String roleNm;
	private String roleDescription;

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRoleNm() {
		return roleNm;
	}

	public void setRoleNm(String roleNm) {
		this.roleNm = roleNm;
	}

	public String getRoleDescription() {
		return roleDescription;
	}

	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}

	public OrgUserToRolesLinkResponse() {
		super();
	}

	public OrgUserToRolesLinkResponse(String roleId, String roleNm, String roleDescription) {
		super();
		this.roleId = roleId;
		this.roleNm = roleNm;
		this.roleDescription = roleDescription;
	}

}
