package com.akila.userservices.pref.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class UserPrefResponse implements Serializable {


	private static final long serialVersionUID = 1L;

	private String title;
    
	private Integer prefTypeCd;
	
	private List<UserPrefResponseMapper> values = new ArrayList<UserPrefResponseMapper>();

	public UserPrefResponse() {
		
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<UserPrefResponseMapper> getValues() {
		return values;
	}

	public void setValues(List<UserPrefResponseMapper> values) {
		this.values = values;
	}
	
	public Integer getPrefTypeCd() {
		return prefTypeCd;
	}

	public void setPrefTypeCd(Integer prefTypeCd) {
		this.prefTypeCd = prefTypeCd;
	}

	@Override
	public String toString() {
		return "UserPrefResponse [title=" + title + ", prefTypeCd=" + prefTypeCd + ", values=" + values + "]";
	}

}
