package com.akila.userservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.userservices.entity.OrgUserFavlist;
import com.akila.userservices.entity.OrgUserFavlistPK;

@Repository
public interface OrgUserFavlistRepository extends JpaRepository<OrgUserFavlist, OrgUserFavlistPK> {
	
	@Query("select fl from OrgUserFavlist fl where fl.id.userId = :userId")
	public List<OrgUserFavlist> findByUserId(String userId);
	
	@Query("select fl from OrgUserFavlist fl where fl.id.userId = :userId and fl.isDefault = :status")
	public List<OrgUserFavlist> findByUserIdAndDefaultStatus(String userId,Boolean status);
	
	public OrgUserFavlist findByIdAndIsShared(OrgUserFavlistPK id,Boolean status);
	
}
