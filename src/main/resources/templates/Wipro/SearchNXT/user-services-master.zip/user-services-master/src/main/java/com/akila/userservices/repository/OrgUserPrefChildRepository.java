package com.akila.userservices.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface OrgUserPrefChildRepository extends OrgUserPrefRepository {
}
