package com.akila.userservices.pref.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SettingResponse implements Serializable {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private List<UserPrefResponse> settings = new ArrayList<UserPrefResponse>();

	public SettingResponse() {
		
	}

	public List<UserPrefResponse> getSettings() {
		return settings;
	}

	public void setSettings(List<UserPrefResponse> settings) {
		this.settings = settings;
	}

}
