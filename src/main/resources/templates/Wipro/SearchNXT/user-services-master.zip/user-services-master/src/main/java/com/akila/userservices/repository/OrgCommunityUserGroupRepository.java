package com.akila.userservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.akila.userservices.entity.OrgCommunityUserGroup;
import com.akila.userservices.entity.OrgCommunityUserGroupPK;

@Repository
public interface OrgCommunityUserGroupRepository extends JpaRepository<OrgCommunityUserGroup, OrgCommunityUserGroupPK>{
}
