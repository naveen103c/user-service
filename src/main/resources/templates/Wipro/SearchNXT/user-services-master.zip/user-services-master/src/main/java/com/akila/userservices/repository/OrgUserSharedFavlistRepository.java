package com.akila.userservices.repository;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.userservices.entity.OrgUserSharedFavlist;
import com.akila.userservices.entity.OrgUserSharedFavlistPK;

@Repository
public interface OrgUserSharedFavlistRepository extends JpaRepository<OrgUserSharedFavlist, OrgUserSharedFavlistPK> {
	
	public List<OrgUserSharedFavlist> findByUserId(String userId);
	
	public List<OrgUserSharedFavlist> findByUserIdAndExpiryDateGreaterThanEqual(String userId, Timestamp currentTimeStamp);
	
	public List<OrgUserSharedFavlist> findByIdFavlistId(String favListId);
	
	public void deleteByIdFavlistId(String favListId);
	
	public void deleteByIdFavlistIdAndUserId(String favListId, String userId);
	
	public boolean existsByIdFavlistIdAndUserId(String favListId, String userId);
}
