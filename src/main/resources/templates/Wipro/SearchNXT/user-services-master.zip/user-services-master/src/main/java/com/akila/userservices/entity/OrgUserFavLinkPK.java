package com.akila.userservices.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the org_user_fav_link database table.
 * 
 */
@Embeddable
public class OrgUserFavLinkPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="user_id", insertable=false, updatable=false)
	private String userId;

	@Column(name="favlist_id", insertable=false, updatable=false)
	private String favlistId;

	@Column(name="content_id")
	private String contentId;

	public OrgUserFavLinkPK() {
	}
	public String getUserId() {
		return this.userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getFavlistId() {
		return this.favlistId;
	}
	public void setFavlistId(String favlistId) {
		this.favlistId = favlistId;
	}
	public String getContentId() {
		return this.contentId;
	}
	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof OrgUserFavLinkPK)) {
			return false;
		}
		OrgUserFavLinkPK castOther = (OrgUserFavLinkPK)other;
		return 
			this.userId.equals(castOther.userId)
			&& this.favlistId.equals(castOther.favlistId)
			&& this.contentId.equals(castOther.contentId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.userId.hashCode();
		hash = hash * prime + this.favlistId.hashCode();
		hash = hash * prime + this.contentId.hashCode();
		
		return hash;
	}
}