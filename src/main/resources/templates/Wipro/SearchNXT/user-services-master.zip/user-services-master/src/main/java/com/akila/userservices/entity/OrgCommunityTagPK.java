package com.akila.userservices.entity;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the org_community_tags database table.
 * 
 */
@Embeddable
public class OrgCommunityTagPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	@Column(name="community_id", insertable=false, updatable=false)
	private String communityId;

	@Column(name="tag_id", insertable=false, updatable=false)
	private String tagId;

	public OrgCommunityTagPK() {
	}
	public String getCommunityId() {
		return this.communityId;
	}
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}
	public String getTagId() {
		return this.tagId;
	}
	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public boolean equals(Object other) {
		if (this == other) {
			return true;
		}
		if (!(other instanceof OrgCommunityTagPK)) {
			return false;
		}
		OrgCommunityTagPK castOther = (OrgCommunityTagPK)other;
		return 
			this.communityId.equals(castOther.communityId)
			&& this.tagId.equals(castOther.tagId);
	}

	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + this.communityId.hashCode();
		hash = hash * prime + this.tagId.hashCode();
		
		return hash;
	}
}