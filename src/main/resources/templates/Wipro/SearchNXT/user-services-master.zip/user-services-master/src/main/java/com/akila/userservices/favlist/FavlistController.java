package com.akila.userservices.favlist;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.response.ResponseId;
import com.akila.userservices.favlist.bean.FavlistRequest;
import com.akila.userservices.favlist.bean.FavlistResponse;

@RestController
public class FavlistController extends AkilaController {
	@Autowired
	private FavlistService favlistService;

	@PostMapping(path = "/fav-list")
	public ResponseId createFavoriteList(@Valid @RequestBody FavlistRequest favlistRequest) {
		return favlistService.createFavoriteList(favlistRequest);
	}

	@GetMapping(path = "/fav-list")
	public List<FavlistResponse> getAllFavoriteList() {
		return favlistService.getAllFavoriteList();
	}

	@GetMapping(path = "/fav-list/{id}")
	public FavlistResponse getFavoriteList(@PathVariable String id) {
		return favlistService.getFavoriteListById(id);
	}
	
	@DeleteMapping(path = "/fav-list/{id}")
	public ResponseEntity<?> deleteListById(@PathVariable String id) {
		String deletedFavListId = favlistService.deleteListById(id);
		if(deletedFavListId != null)
			return ResponseEntity.status(HttpStatus.OK).body(deletedFavListId);
		else
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("At least one favorite list is required");
	}

	@PutMapping(path = "/fav-list/{id}")
	public ResponseId updateFavoriteList(@PathVariable String id,@Valid @RequestBody FavlistRequest favlistRequest) {
		return favlistService.updateFavoriteList(id, favlistRequest);
	}

}
