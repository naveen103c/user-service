package com.akila.userservices.notification;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;

@RestController
public class NotificationController extends AkilaController {
	@Autowired
	private NotificationService notificationService;

	@GetMapping(path = "/notifications")
	public ResponseEntity<Map<String, Object>> getAllNotifications(@RequestParam(defaultValue = "0") Integer offSet,
			@RequestParam(defaultValue = "10", required=false) Integer pageSize) {
		Map<String, Object> notificationsMap = notificationService.getAllNotifications(offSet, pageSize);
		return new ResponseEntity<Map<String, Object>>(notificationsMap, HttpStatus.OK);
	}

	@GetMapping(path = "/notifications/unread-count")
	public ResponseEntity<Map<String, Object>> getUnreadNotificationsCount() {
		Map<String, Object> unreadNotificationsCountMap = new HashMap<String, Object>();
		unreadNotificationsCountMap.put("unreadNotifications", notificationService.getUnreadNotificationsCount());
		return new ResponseEntity<Map<String, Object>>(unreadNotificationsCountMap, HttpStatus.OK);
	}

	@DeleteMapping(path = "/notifications/{id}")
	public ResponseEntity<String> deleteNotification(@PathVariable String id) {
		boolean isDeleted = notificationService.deleteNotification(id);
		if (!isDeleted) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(id, HttpStatus.OK);
	}

}
