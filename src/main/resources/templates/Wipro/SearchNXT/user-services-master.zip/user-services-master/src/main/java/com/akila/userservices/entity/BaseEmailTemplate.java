package com.akila.userservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;

/**
 * The persistent class for the base_email_template database table.
 * 
 */

@Entity
@Table(name = "base_email_template", schema = "base")
@NamedQuery(name = "BaseEmailTemplate.findAll", query = "SELECT o FROM BaseEmailTemplate o")
public class BaseEmailTemplate extends AkilaEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "template_id")
	private String templateId;

	@Column(name = "subject")
	private String subject;
	
	@Column(name = "template")
	private String template;
	
	@Column(name = "defaultTO")
	private String defaultTO;
	
	@Column(name = "defaultCC")
	private String defaultCC;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "description")
	private String description;

	@Column(name = "status")
	private Integer status;

	public BaseEmailTemplate() {

	}

	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}

	public String getDefaultTO() {
		return defaultTO;
	}

	public void setDefaultTO(String defaultTO) {
		this.defaultTO = defaultTO;
	}

	public String getDefaultCC() {
		return defaultCC;
	}

	public void setDefaultCC(String defaultCC) {
		this.defaultCC = defaultCC;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}
