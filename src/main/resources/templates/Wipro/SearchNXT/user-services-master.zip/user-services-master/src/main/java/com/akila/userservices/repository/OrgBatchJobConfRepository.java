package com.akila.userservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.userservices.entity.OrgBatchJobConf;

@Repository
public interface OrgBatchJobConfRepository extends JpaRepository<OrgBatchJobConf, String> {

	List<OrgBatchJobConf> findByCrtBy(String userId);
	
}
