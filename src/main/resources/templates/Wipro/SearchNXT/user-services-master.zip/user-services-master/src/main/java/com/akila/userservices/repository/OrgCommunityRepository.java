package com.akila.userservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.akila.userservices.entity.OrgCommunity;

@Repository
public interface OrgCommunityRepository extends JpaRepository<OrgCommunity, String> {

	List<OrgCommunity> findByCommunityOwner(String userId);
}
