package com.akila.userservices.notification.bean;

import com.akila.userservices.entity.OrgNotification;
import com.akila.userservices.entity.OrgNotificationHistory;

import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface NotificationMapper {
	NotificationMapper INSTANCE = Mappers.getMapper(NotificationMapper.class);;

	@Mappings({})
	NotificationResponse orgNotificationToNotificationResponse(OrgNotification orgNotification);

	@Mappings({})
	List<NotificationResponse> orgNotificationToNotificationResponseList(List<OrgNotification> orgNotification);

	@Mappings({})
	OrgNotification notificationRequestToOrgNotification(NotificationRequest notificationRequest);

	@Mappings({})
	OrgNotificationHistory orgNotificationToOrgNotificationHistory(OrgNotification orgNotification);
}
