package com.akila.userservices.favlist.sharing.bean;

import java.sql.Timestamp;
import java.util.List;

import com.akila.AkilaResponse;

public class SharedListResponse extends AkilaResponse {
	
	private String favlistId;
	
	private String description;

	private String favlistNm;
	
	private List<String> userIds;
	
	private String userGroupId;
	
	private Timestamp sharedTs;

	private String ownerUserId;
	
	private Timestamp expiryTs;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFavlistNm() {
		return favlistNm;
	}

	public void setFavlistNm(String favlistNm) {
		this.favlistNm = favlistNm;
	}

	public String getFavlistId() {
		return favlistId;
	}

	public void setFavlistId(String favlistId) {
		this.favlistId = favlistId;
	}

	public List<String> getUserIds() {
		return userIds;
	}

	public void setUserIds(List<String> userIds) {
		this.userIds = userIds;
	}

	public String getUserGroupId() {
		return userGroupId;
	}

	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}

	public Timestamp getSharedTs() {
		return sharedTs;
	}

	public void setSharedTs(Timestamp sharedTs) {
		this.sharedTs = sharedTs;
	}

	public String getOwnerUserId() {
		return ownerUserId;
	}

	public void setOwnerUserId(String ownerUserId) {
		this.ownerUserId = ownerUserId;
	}

	public Timestamp getExpiryTs() {
		return expiryTs;
	}

	public void setExpiryTs(Timestamp expiryTs) {
		this.expiryTs = expiryTs;
	}
	
}
