package com.akila.userservices.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.akila.AkilaEntity;


/**
 * The persistent class for the org_user_groups database table.
 * 
 */
@Entity
@Table(name="org_user_groups")
@NamedQuery(name="OrgUserGroup.findAll", query="SELECT o FROM OrgUserGroup o")
public class OrgUserGroup extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="user_group_id")
	private String userGroupId;

	@Column(name="user_group_desc")
	private String userGroupDesc;

	@Column(name="user_group_nm")
	private String userGroupNm;
	
	@Column(name="is_default")
	private Boolean isDefault;

	@OneToMany(mappedBy="orgUserGroup", cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	private List<OrgUserGroupToUsersLink> users;
	
	public OrgUserGroup() {
	}

	public String getUserGroupId() {
		return this.userGroupId;
	}

	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}

	public String getUserGroupDesc() {
		return this.userGroupDesc;
	}

	public void setUserGroupDesc(String userGroupDesc) {
		this.userGroupDesc = userGroupDesc;
	}

	public String getUserGroupNm() {
		return this.userGroupNm;
	}

	public void setUserGroupNm(String userGroupNm) {
		this.userGroupNm = userGroupNm;
	}

	public List<OrgUserGroupToUsersLink> getUsers() {
		return users;
	}

	public void setUsers(List<OrgUserGroupToUsersLink> users) {
		this.users = users;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Boolean getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(Boolean isDefault) {
		this.isDefault = isDefault;
	}
	
}