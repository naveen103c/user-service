package com.akila.userservices.notification.bean;

import com.akila.AkilaRequest;

public class NotificationRequest extends AkilaRequest {

	private String notificationId;

	private String userId;

	private String notificationTitle;

	private String notificationMsg;

	private String notificationTypeCd;

	private Boolean isRead;

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public void setNotificationTitle(String notificationTitle) {
		this.notificationTitle = notificationTitle;
	}

	public void setNotificationMsg(String notificationMsg) {
		this.notificationMsg = notificationMsg;
	}

	public void setNotificationTypeCd(String notificationTypeCd) {
		this.notificationTypeCd = notificationTypeCd;
	}

	public void setIsRead(Boolean isRead) {
		this.isRead = isRead;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public String getUserId() {
		return userId;
	}

	public String getNotificationTitle() {
		return notificationTitle;
	}

	public String getNotificationMsg() {
		return notificationMsg;
	}

	public String getNotificationTypeCd() {
		return notificationTypeCd;
	}

	public Boolean getIsRead() {
		return isRead;
	}

}
