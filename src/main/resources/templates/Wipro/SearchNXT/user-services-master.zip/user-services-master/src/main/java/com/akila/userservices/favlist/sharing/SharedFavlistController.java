package com.akila.userservices.favlist.sharing;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.response.ResponseId;
import com.akila.userservices.favlist.sharing.bean.SharedFavlistRequest;
import com.akila.userservices.favlist.sharing.bean.SharedFavlistResponse;
import com.akila.userservices.favlist.sharing.bean.SharedListResponse;

@RestController
public class SharedFavlistController extends AkilaController {
	@Autowired
	private SharedFavlistService favlistService;

	@PostMapping(path = "/fav-list/shared")
	public ResponseId shareFavList(@Valid @RequestBody SharedFavlistRequest favSharedlistRequest) {
		return favlistService.shareFavList(favSharedlistRequest);
	}

	@GetMapping(path = "/fav-list/shared/{id}")
	public SharedListResponse getSharedFavoriteListByFavlistId(@PathVariable String id) {
		return favlistService.getSharedFavoriteListByFavlistId(id);
	}

	@GetMapping(path = "/fav-list/shared")
	public List<SharedFavlistResponse> getAllSharedFavoriteListByUserId() {
		return favlistService.getAllSharedFavoriteListByUserId();
	}
	
	@PutMapping(path = "/fav-list/shared")
	public ResponseId updateSharedFavoriteList(@Valid @RequestBody SharedFavlistRequest favSharedlistRequest) {
		return favlistService.updateFavList(favSharedlistRequest);
	}

	@DeleteMapping(path = "/fav-list/shared/{id}")
	public void deleteSharedFavoriteListByFavlistId(@PathVariable String id) {
		favlistService.deleteSharedFavoriteListByFavlistId(id);
	}
}
