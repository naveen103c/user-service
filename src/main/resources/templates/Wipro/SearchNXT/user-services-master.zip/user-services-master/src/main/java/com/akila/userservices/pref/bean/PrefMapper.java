package com.akila.userservices.pref.bean;

import com.akila.userservices.entity.OrgUserPref;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface PrefMapper {
  PrefMapper INSTANCE = Mappers.getMapper(PrefMapper.class);
  ;

  @Mappings({})
  PrefResponse orgUserPrefToPrefResponse(OrgUserPref orgUserPref);

  @Mappings({})
  List<PrefResponse> orgUserPrefToPrefResponseList(List<OrgUserPref> orgUserPref);

  @Mappings({})
  OrgUserPref prefRequestToOrgUserPref(PrefRequest prefRequest);
}
