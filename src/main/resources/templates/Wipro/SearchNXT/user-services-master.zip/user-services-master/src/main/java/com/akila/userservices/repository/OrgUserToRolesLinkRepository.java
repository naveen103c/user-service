package com.akila.userservices.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.akila.userservices.entity.OrgUserToRolesLink;
import com.akila.userservices.entity.OrgUserToRolesLinkPK;

@Repository
public interface OrgUserToRolesLinkRepository extends JpaRepository<OrgUserToRolesLink, OrgUserToRolesLinkPK> {
	List<OrgUserToRolesLink> findByUserId(String userId);
}
