package com.akila.userservices.pref;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.userservices.entity.BaseUserPref;
import com.akila.userservices.entity.OrgUserPref;
import com.akila.userservices.entity.OrgUserPrefPK;
import com.akila.userservices.pref.bean.BaseRefCodeType;
import com.akila.userservices.pref.bean.OrgRefCode;
import com.akila.userservices.pref.bean.PrefRequest;
import com.akila.userservices.pref.bean.PrefResponse;
import com.akila.userservices.pref.bean.SettingResponse;
import com.akila.userservices.pref.bean.UserPrefMapper;
import com.akila.userservices.pref.bean.UserPrefResponse;
import com.akila.userservices.pref.bean.UserPrefResponseMapper;
import com.akila.userservices.repository.BaseRefTypeCdRepository;
import com.akila.userservices.repository.BaseUserPrefRepository;
import com.akila.userservices.repository.OrgUserPrefChildRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class PrefService extends AkilaService {

	private static Logger log = LogManager.getLogger(PrefService.class);

	@Autowired
	private OrgUserPrefChildRepository orgUserPrefRepository;

	@Autowired
	private BaseUserPrefRepository baseUserPrefRepository;

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate loadBalancedRestTemplate;

	@Value("${org.service.url}")
	private String orgServiceURL;

	@Autowired
	AkilaRestTemplate akilaRestTemplate;

	@Value("${user.pref.type.code}")
	private List<Integer> userPrefTypeCds;
	
	@Value("${user.filter.pref.type.code}")
	private Integer userFilterPrefTypeCd;
	
	@Value("${user.pref.control.type.code}")
	private Integer userPrefControlTypeCd;
	
	@Autowired
	private BaseRefTypeCdRepository baseRefTypeCdRepository;
	
	public PrefResponse getPreference(Integer prefTypeCd) throws JsonMappingException, JsonProcessingException {

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		log.info("getPreference Entry Time -- " + dateFormat.format(System.currentTimeMillis()));
		PrefResponse prefResponse = new PrefResponse();
		ObjectMapper objectMapper = new ObjectMapper();
		SettingResponse settingResponse = new SettingResponse();
		log.info("getPreference Before getRefCodes -- " + dateFormat.format(System.currentTimeMillis()));
		// Get Reference Codes from org-services /ref-codes API
		BaseRefCodeType baseRefCodeTypeModel = this.getRefCodes(prefTypeCd);
		log.info("getPreference  After getRefCodes -- " + dateFormat.format(System.currentTimeMillis()));
		// Get User Answers which are already saved in DB
		Map<String, String> userAns = this.getUserAnswers(prefTypeCd, prefResponse);
		log.info("getPreference  After getUserAnswers -- " + dateFormat.format(System.currentTimeMillis()));
		for (OrgRefCode orgRefCode : baseRefCodeTypeModel.getOrgRefCodes()) {

			List<BaseUserPref> baseUserPrefList = baseUserPrefRepository
					.findByprefTypeCdAndActive(orgRefCode.getRefCodeStoreVal(), Boolean.TRUE);
			List<UserPrefResponseMapper> userPrefResponseMapperList = new ArrayList<UserPrefResponseMapper>();
			for (BaseUserPref baseUserPref : baseUserPrefList) {
				UserPrefResponseMapper userPrefResponseMapper = new UserPrefResponseMapper();
				userPrefResponseMapper.setKey(baseUserPref.getId());
				userPrefResponseMapper.setTitle(baseUserPref.getPrefNm());
				userPrefResponseMapper.setType(baseUserPref.getPrefControlTypeCd() + "");
				userPrefResponseMapper.setValues(Arrays.asList(baseUserPref.getPrefOptions().split(",")));
				if (userAns.containsKey(baseUserPref.getId()) && baseUserPref.getPrefControlTypeCd() != userPrefControlTypeCd) {
					String[] answers = userAns.get(baseUserPref.getId()).split(",");
					List<String> options = Arrays.asList(baseUserPref.getPrefOptions().split(","));
					List<String> filterAns = new ArrayList<String>();
					for (String ans : answers) {
						if (options.contains(ans)) {
							filterAns.add(ans);
						}
					}
					if (filterAns.size() == 0)
						userPrefResponseMapper.setAnswer(Arrays.asList(baseUserPref.getPrefDefault().split(",")));
					else
						userPrefResponseMapper.setAnswer(filterAns);
				} else if (userAns.containsKey(baseUserPref.getId()) && baseUserPref.getPrefControlTypeCd() == userPrefControlTypeCd) {
					userPrefResponseMapper.setAnswer(Arrays.asList(userAns.get(baseUserPref.getId()).split(",")));
				} else {
					userPrefResponseMapper.setAnswer(Arrays.asList(baseUserPref.getPrefDefault().split(",")));
				}

				userPrefResponseMapperList.add(userPrefResponseMapper);
			}
			// if (userPrefResponseMapperList.size() > 0) {
			UserPrefResponse userPrefResponse = new UserPrefResponse();
			userPrefResponse.setTitle(orgRefCode.getRefCodeDisplayVal());
			userPrefResponse.setValues(userPrefResponseMapperList);
			settingResponse.getSettings().add(userPrefResponse);
			// }
		}
		log.info("getPreference  Before setPersonalPreferenceJson -- " + dateFormat.format(System.currentTimeMillis()));
		prefResponse.setPersonalPreferenceJson(objectMapper.writeValueAsString(settingResponse));

		log.info("getPreference Before Return Time -- " + dateFormat.format(System.currentTimeMillis()));
		return prefResponse;
	}

	public Map<String, String> getUserAnswers(Integer prefTypeCd, PrefResponse prefResponse)
			throws JsonMappingException, JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, String> userAns = new HashMap<String, String>();
		OrgUserPrefPK id = getOrgUserPrefPK(prefTypeCd);
		if (orgUserPrefRepository.existsById(id)) {
			OrgUserPref orgUserPref = orgUserPrefRepository.findById(getOrgUserPrefPK(prefTypeCd)).orElse(null);
			OrgUserPrefPK orgUserPrefPKId = new OrgUserPrefPK();
			orgUserPrefPKId.setPrefTypeCd(1);
			orgUserPrefPKId.setUserId(super.getUserId());
			prefResponse.setCrtBy(orgUserPref.getCrtBy());
			prefResponse.setCrtTs(orgUserPref.getCrtTs());
			prefResponse.setModBy(orgUserPref.getModBy());
			prefResponse.setModTs(orgUserPref.getModTs());
			UserPrefMapper[] userPrefMapperList = null;
			userPrefMapperList = objectMapper.readValue(orgUserPref.getPersonalPreferenceJson(),
					UserPrefMapper[].class);

			for (UserPrefMapper userPrefMapper : userPrefMapperList) {
				userAns.put(userPrefMapper.getPrefId(), userPrefMapper.getAns());
			}
		}
		return userAns;
	}

	public BaseRefCodeType getRefCodes(Integer prefTypeCd) throws JsonMappingException, JsonProcessingException {

		BaseRefCodeType baseRefCodeTypeModel = null;
		ObjectMapper objectMapper = new ObjectMapper();

		HttpEntity<String> entity = new HttpEntity<String>("Reference-codes", getRequestHeader());
		ResponseEntity<String> response = akilaRestTemplate.exchange(loadBalancedRestTemplate,
				orgServiceURL + "/ref-codes/type/PREF_TYPE_CD", HttpMethod.GET, entity, String.class);
		baseRefCodeTypeModel = objectMapper.readValue(response.getBody(), BaseRefCodeType.class);

		if (prefTypeCd != null && prefTypeCd != 0) {

			List<OrgRefCode> orgRefCodeList = new ArrayList<OrgRefCode>();
			for (OrgRefCode orgRefCode : baseRefCodeTypeModel.getOrgRefCodes()) {
				if (orgRefCode.getRefCodeStoreVal().equals(prefTypeCd)) {
					orgRefCodeList.add(orgRefCode);
					break;
				}
			}
			baseRefCodeTypeModel.setOrgRefCodes(orgRefCodeList);
		}
		return baseRefCodeTypeModel;
	}

	public void updatePreference(PrefRequest prefRequest) {
		prefRequest.getUserPrefs().forEach(userPref -> {
				OrgUserPrefPK id = getOrgUserPrefPK(userPref.getPrefTypeCd());
				if (orgUserPrefRepository.existsById(id)) {
					OrgUserPref orgUserPref = orgUserPrefRepository.findById(id).orElse(null);
					orgUserPref.setId(id);
					orgUserPref.setModBy(super.getUserId());
					orgUserPref.setModTs(new Timestamp(System.currentTimeMillis()));
					orgUserPref.setPersonalPreferenceJson(userPref.getPersonalPreferenceJson());
					orgUserPref = orgUserPrefRepository.save(orgUserPref);
				} else {
					OrgUserPref orgUserPref = new OrgUserPref();
					orgUserPref.setId(id);
					orgUserPref.setModBy(super.getUserId());
					orgUserPref.setCrtBy(super.getUserId());
					orgUserPref.setCrtTs(new Timestamp(System.currentTimeMillis()));
					orgUserPref.setModTs(new Timestamp(System.currentTimeMillis()));
					orgUserPref.setPersonalPreferenceJson(userPref.getPersonalPreferenceJson());
					orgUserPref = orgUserPrefRepository.save(orgUserPref);
				}
		});
	}

	public OrgUserPrefPK getOrgUserPrefPK(Integer prefTypeCd) {
		OrgUserPrefPK orgUserPrefPK = new OrgUserPrefPK();
		orgUserPrefPK.setUserId(super.getUserId());
		orgUserPrefPK.setPrefTypeCd(prefTypeCd);
		return orgUserPrefPK;
	}

	public PrefResponse getPreference(String prefTypeCd) throws JsonMappingException, JsonProcessingException {

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		log.info("getPreference Entry Time -- " + dateFormat.format(System.currentTimeMillis()));
		PrefResponse prefResponse = new PrefResponse();
		ObjectMapper objectMapper = new ObjectMapper();
		SettingResponse settingResponse = new SettingResponse();
		log.info("getPreference Before getRefCodes -- " + dateFormat.format(System.currentTimeMillis()));
		// Get Reference Codes from org-services /ref-codes API
		BaseRefCodeType baseRefCodeTypeModel = this.getRefCodes(prefTypeCd);
		log.info("getPreference  After getRefCodes -- " + dateFormat.format(System.currentTimeMillis()));
		// Get User Answers which are already saved in DB
		List<Integer> refCodes = new ArrayList<Integer>();
		baseRefCodeTypeModel.getOrgRefCodes().forEach(refCode -> {
			refCodes.add(refCode.getRefCodeStoreVal());
		});
		baseRefCodeTypeModel.getOrgRefCodes().sort(Comparator.comparing(OrgRefCode::getRefCodeStoreVal));
		Map<String, Map<String, String>> userAns = this.getUserAnswers(prefResponse, refCodes);
		log.info("getPreference  After getUserAnswers -- " + dateFormat.format(System.currentTimeMillis()));
		int sequenceCount = 0;
		for (OrgRefCode orgRefCode : baseRefCodeTypeModel.getOrgRefCodes()) {
			List<BaseUserPref> baseUserPrefList = baseUserPrefRepository
					.findByprefTypeCdAndActive(orgRefCode.getRefCodeStoreVal(), Boolean.TRUE);
			List<UserPrefResponseMapper> userPrefResponseMapperList = new ArrayList<UserPrefResponseMapper>();
			List<BaseUserPref> baseUserPrefChildNode = baseUserPrefRepository.findAlllByParentPrefIdNotNull();
			for (BaseUserPref baseUserPref : baseUserPrefList) {
				if (baseUserPref.getParentPrefId() != null) {
					continue;
				}
				UserPrefResponseMapper userPrefResponseMapper = new UserPrefResponseMapper();
				userPrefResponseMapper.setKey(baseUserPref.getId());
				userPrefResponseMapper.setTitle(baseUserPref.getPrefNm());
				userPrefResponseMapper.setType(baseUserPref.getPrefControlTypeCd() + "");
				List<String> options = Arrays.asList(baseUserPref.getPrefOptions().split(","));
				if(baseUserPref.getPrefNm().equalsIgnoreCase("Tags")) {
					options = tagOptions(baseUserPref, userPrefResponseMapper, options);
				}
				else {
					userPrefResponseMapper.setValues(options);
				}
				List<UserPrefResponseMapper> children = new ArrayList<>();
				baseUserPrefChildNode.forEach(userPref -> {
					if (userPref.getParentPrefId().equalsIgnoreCase(baseUserPref.getId())) {
						UserPrefResponseMapper childUserPrefResponseMapper = new UserPrefResponseMapper();
						childUserPrefResponseMapper.setKey(userPref.getId());
						childUserPrefResponseMapper.setTitle(userPref.getPrefNm());
						childUserPrefResponseMapper.setType(userPref.getPrefControlTypeCd() + "");
						childUserPrefResponseMapper.setValues(Arrays.asList(userPref.getPrefOptions().split(",")));
						childUserPrefResponseMapper.setChildren(new ArrayList<>());
						if (userAns.containsKey(userPref.getId())) {
							String[] answers = userAns.get(userPref.getId()).get(userPref.getId()).split(",");
							List<String> prefOptions = Arrays.asList(userPref.getPrefOptions().split(","));
							List<String> optionsList = new ArrayList<>();
							prefOptions.forEach(option -> {
								optionsList.add(option.trim());
							});
							List<String> filterAns = new ArrayList<String>();
							for (String ans : answers) {
								if (optionsList.contains(ans.trim())) {
									filterAns.add(ans);
								}
							}
							childUserPrefResponseMapper.setAnswer(filterAns);
						}
						else {
							childUserPrefResponseMapper.setAnswer(Arrays.asList(userPref.getPrefDefault().split(",")));
						}
						children.add(childUserPrefResponseMapper);

					}
				});
				userPrefResponseMapper.setChildren(children);
				if (userAns.containsKey(baseUserPref.getId()) && baseUserPref.getPrefControlTypeCd() != userPrefControlTypeCd) {
					String[] answers = userAns.get(baseUserPref.getId()).get("Answer").split(",");
					List<String> filterAns = new ArrayList<String>();
					for (String ans : answers) {
						if (options.contains(ans)) {
							filterAns.add(ans);
						}
					}
					if (filterAns.size() == 0) {
						if (baseUserPref.getPrefTypeCd() == userFilterPrefTypeCd) {
							userPrefResponseMapper.setVisibility("true");
							userPrefResponseMapper.setSequence(String.valueOf(++sequenceCount));
						}
						userPrefResponseMapper.setAnswer(Arrays.asList(baseUserPref.getPrefDefault().split(",")));
					} else {
						if (baseUserPref.getPrefTypeCd() == userFilterPrefTypeCd &&userAns.get(baseUserPref.getId()).get("Sequence") == null) {
							userPrefResponseMapper.setVisibility("true");
							userPrefResponseMapper.setSequence(String.valueOf(++sequenceCount));
							userPrefResponseMapper.setAnswer(filterAns);
						} else {
							userPrefResponseMapper.setVisibility(userAns.get(baseUserPref.getId()).get("Visibility"));
							userPrefResponseMapper.setSequence(userAns.get(baseUserPref.getId()).get("Sequence"));
							userPrefResponseMapper.setAnswer(filterAns);
						}
					}
				} else if (userAns.containsKey(baseUserPref.getId()) && baseUserPref.getPrefControlTypeCd() == userPrefControlTypeCd) {
					userPrefResponseMapper.setAnswer(Arrays.asList(userAns.get(baseUserPref.getId()).get("Answer")));
				} else {
					if (baseUserPref.getPrefTypeCd() == userFilterPrefTypeCd) {
						userPrefResponseMapper.setVisibility("true");
						userPrefResponseMapper.setSequence(String.valueOf(++sequenceCount));
					}
					userPrefResponseMapper.setAnswer(Arrays.asList(baseUserPref.getPrefDefault().split(",")));
				}

				userPrefResponseMapperList.add(userPrefResponseMapper);
			}
			UserPrefResponse userPrefResponse = new UserPrefResponse();
			userPrefResponse.setTitle(orgRefCode.getRefCodeDisplayVal());
			userPrefResponse.setValues(userPrefResponseMapperList);
			userPrefResponse.setPrefTypeCd(orgRefCode.getRefCodeStoreVal());
			settingResponse.getSettings().add(userPrefResponse);
		}
		log.info("getPreference  Before setPersonalPreferenceJson -- " + dateFormat.format(System.currentTimeMillis()));
		prefResponse.setPersonalPreferenceJson(objectMapper.writeValueAsString(settingResponse));

		log.info("getPreference Before Return Time -- " + dateFormat.format(System.currentTimeMillis()));
		return prefResponse;
	}

	private List<String> tagOptions(BaseUserPref baseUserPref, UserPrefResponseMapper userPrefResponseMapper,
			List<String> options) {
		List<String> tagTypes = baseRefTypeCdRepository.getTagsForPreferences(options);
		List<String> tempOptions = new ArrayList<String>();
		tempOptions.add(baseUserPref.getPrefDefault());
		for(String tagType : tagTypes) {
			tempOptions.add(tagType);
		}
		 options = tempOptions;
		 userPrefResponseMapper.setValues(options);
		return options;
	}
    
	public BaseRefCodeType getRefCodes(String prefTypeCd) throws JsonMappingException, JsonProcessingException {

		BaseRefCodeType baseRefCodeTypeModel = null;
		ObjectMapper objectMapper = new ObjectMapper();

		HttpEntity<String> entity = new HttpEntity<String>("Reference-codes", getRequestHeader());
		ResponseEntity<String> response = akilaRestTemplate.exchange(loadBalancedRestTemplate,
				orgServiceURL + "/ref-codes/type/PREF_TYPE_CD", HttpMethod.GET, entity, String.class);
		baseRefCodeTypeModel = objectMapper.readValue(response.getBody(), BaseRefCodeType.class);

		List<OrgRefCode> orgRefCodeList = new ArrayList<OrgRefCode>();
		if (prefTypeCd != null && !prefTypeCd.isEmpty()){
			for (OrgRefCode orgRefCode : baseRefCodeTypeModel.getOrgRefCodes()) {
				if (orgRefCode.getRefCodeStoreVal().equals(Integer.valueOf(prefTypeCd))) {
					orgRefCodeList.add(orgRefCode);
					break;
				}
			}
			baseRefCodeTypeModel.setOrgRefCodes(orgRefCodeList);
		}
		else {
			for (OrgRefCode orgRefCode : baseRefCodeTypeModel.getOrgRefCodes()) {
				userPrefTypeCds.forEach(id -> {
					if (orgRefCode.getRefCodeStoreVal().equals(id)) {
						orgRefCodeList.add(orgRefCode);
					}
				});
				baseRefCodeTypeModel.setOrgRefCodes(orgRefCodeList);
			}
		}
		return baseRefCodeTypeModel;
	}

	public Map<String, Map<String, String>> getUserAnswers(PrefResponse prefResponse, List<Integer> refCodes)
			throws JsonMappingException, JsonProcessingException {

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Map<String, String>> userAns = new HashMap<String, Map<String, String>>();
		refCodes.forEach(refCode -> {
			OrgUserPrefPK id = getOrgUserPrefPK(refCode);
			if (orgUserPrefRepository.existsById(id)) {
				OrgUserPref orgUserPref = orgUserPrefRepository.findById(getOrgUserPrefPK(refCode)).orElse(null);
				OrgUserPrefPK orgUserPrefPKId = new OrgUserPrefPK();
				orgUserPrefPKId.setPrefTypeCd(1);
				orgUserPrefPKId.setUserId(super.getUserId());
				prefResponse.setCrtBy(orgUserPref.getCrtBy());
				prefResponse.setCrtTs(orgUserPref.getCrtTs());
				prefResponse.setModBy(orgUserPref.getModBy());
				prefResponse.setModTs(orgUserPref.getModTs());

				UserPrefMapper[] userPrefMapperList = null;
				try {
					userPrefMapperList = objectMapper.readValue(orgUserPref.getPersonalPreferenceJson(),
							UserPrefMapper[].class);
				} catch (JsonMappingException e) {
					log.error("PrefService:getUserAnswers JsonMappingException : " + e.getMessage());
				} catch (JsonProcessingException e) {
					log.error("PrefService:getUserAnswers JsonProcessingException : " + e.getMessage());
				}

				for (UserPrefMapper userPrefMapper : userPrefMapperList) {
					Map<String, String> answers = new HashMap<>();
					answers.put("Answer", userPrefMapper.getAns());
					answers.put("Sequence", userPrefMapper.getSequence());
					answers.put("Visibility", userPrefMapper.getVisibility());
					if (userPrefMapper.getChildren() != null && userPrefMapper.getChildren().size() > 0) {
						userPrefMapper.getChildren().forEach(child -> {
							Map<String, String> answer = new HashMap<>();
							answer.put(child.getPrefId(), child.getAns());
							userAns.put(child.getPrefId(), answer);
						});
					}
					userAns.put(userPrefMapper.getPrefId(), answers);
				}
			}
		});
		return userAns;
	}
}
