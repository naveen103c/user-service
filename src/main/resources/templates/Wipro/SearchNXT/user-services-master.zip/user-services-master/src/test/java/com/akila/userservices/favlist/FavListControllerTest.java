package com.akila.userservices.favlist;

import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.userservices.UserServicesApplication;
import com.akila.userservices.favlist.bean.FavlistRequest;
import com.akila.userservices.favlist.bean.FavlistResponse;

@SpringBootTest(classes = UserServicesApplication.class)

public class FavListControllerTest {

	/*
	 * @Autowired private FavlistController favListController;
	 */

	int count = 1;

	String favListId = null;

	@Test
	public void createFavouriteListTest() {
		FavlistRequest favlistRequest = new FavlistRequest();
		favlistRequest.setFavlistNm("Govind Favs");
		favlistRequest.setIsDefault(false);
		favlistRequest.setIsShared(false);
		favlistRequest.setDescription("favourite list");

		//favListId = favListController.createFavoriteList(favlistRequest).getId();
		//System.out.println("created favouritelist with id = " + favListId);
	}

//	@Test
//	public void getFavoriteListTest() {
//		FavlistResponse favlistResponse = favListController.getFavoriteList("7290d427-f44b-42b0-9694-86426e9b10fa");
//		System.out.println("favlistResponse.getFavlistNm() = " + favlistResponse.getFavlistNm());
//	}

	@Test
	public void getAllFavoriteListTest() {
		/*
		 * List<FavlistResponse> favlistResponseList =
		 * favListController.getAllFavoriteList();
		 * System.out.println("favlistResponseList.size() = " +
		 * favlistResponseList.size()); count += favlistResponseList.size();
		 * FavlistResponse favlistResponse = new FavlistResponse();
		 * Iterator<FavlistResponse> itr = favlistResponseList.iterator(); while
		 * (itr.hasNext()) { favlistResponse = itr.next();
		 * System.out.println("favlistResponse.getFavlistNm() = " +
		 * favlistResponse.getFavlistNm()); }
		 */
	}

//	@Test
//	public void updateFavouriteListTest() {
//		FavlistRequest favlistRequest = new FavlistRequest();
//		favlistRequest.setFavlistNm("konish fav"+ count++);
//		favlistRequest.setIsDefault(true);
//		favlistRequest.setIsShared(false);
//		favlistRequest.setDescription("update method");
//
//		System.out.println("created favouritelist with id = " + favListController.updateFavoriteList("7290d427-f44b-42b0-9694-86426e9b10fa", favlistRequest).getId());
//	}

}
