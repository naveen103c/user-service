package com.akila.userservices.user.bean;

import java.util.List;

public class OrgBatchJobConfResponse {

	private String confId;
	
	private String confNm;
	
	private Integer sourceTypeCd;
	
	private String sourceTypeNm;
	
	private String resourceUrl;
	
	private List<String> userGroups;
	
	private String lastJobStartedTs;

	
	public OrgBatchJobConfResponse() {
		super();
	}

	public OrgBatchJobConfResponse(String confId, String confNm, Integer sourceTypeCd, String sourceTypeNm,
			String resourceUrl, List<String> userGroups, String lastJobStartedTs) {
		super();
		this.confId = confId;
		this.confNm = confNm;
		this.sourceTypeCd = sourceTypeCd;
		this.sourceTypeNm = sourceTypeNm;
		this.resourceUrl = resourceUrl;
		this.userGroups = userGroups;
		this.lastJobStartedTs = lastJobStartedTs;
	}

	/**
	 * @return the confId
	 */
	public String getConfId() {
		return confId;
	}

	/**
	 * @param confId the confId to set
	 */
	public void setConfId(String confId) {
		this.confId = confId;
	}

	/**
	 * @return the confNm
	 */
	public String getConfNm() {
		return confNm;
	}

	/**
	 * @param confNm the confNm to set
	 */
	public void setConfNm(String confNm) {
		this.confNm = confNm;
	}

	public String getSourceTypeNm() {
		return sourceTypeNm;
	}

	public void setSourceTypeNm(String sourceTypeNm) {
		this.sourceTypeNm = sourceTypeNm;
	}

	/**
	 * @return the sourceTypeCd
	 */
	public Integer getSourceTypeCd() {
		return sourceTypeCd;
	}

	/**
	 * @param sourceTypeCd the sourceTypeCd to set
	 */
	public void setSourceTypeCd(Integer sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}

	/**
	 * @return the resourceUrl
	 */
	public String getResourceUrl() {
		return resourceUrl;
	}

	/**
	 * @param resourceUrl the resourceUrl to set
	 */
	public void setResourceUrl(String resourceUrl) {
		this.resourceUrl = resourceUrl;
	}

	/**
	 * @return the userGroups
	 */
	public List<String> getUserGroups() {
		return userGroups;
	}

	/**
	 * @param userGroups the userGroups to set
	 */
	public void setUserGroups(List<String> userGroups) {
		this.userGroups = userGroups;
	}

	/**
	 * @return the lastJobStartedTs
	 */
	public String getLastJobStartedTs() {
		return lastJobStartedTs;
	}

	/**
	 * @param lastJobStartedTs the lastJobStartedTs to set
	 */
	public void setLastJobStartedTs(String lastJobStartedTs) {
		this.lastJobStartedTs = lastJobStartedTs;
	}
	
	
}
