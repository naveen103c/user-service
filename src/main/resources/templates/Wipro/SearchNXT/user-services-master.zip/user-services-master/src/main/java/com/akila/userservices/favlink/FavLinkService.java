package com.akila.userservices.favlink;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.sql.Timestamp;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.http.HttpEntity;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.response.ResponseId;
import com.akila.userservices.entity.OrgContentMetadata;
import com.akila.userservices.entity.OrgUserContentMetadata;
import com.akila.userservices.entity.OrgUserContentMetadataPK;
import com.akila.userservices.entity.OrgUserFavLink;
import com.akila.userservices.entity.OrgUserFavLinkPK;
import com.akila.userservices.favlink.bean.FavLinkMapper;
import com.akila.userservices.favlink.bean.FavLinkRequest;
import com.akila.userservices.favlink.bean.FavLinkResponse;
import com.akila.userservices.repository.OrgContentMetadataRepository;
import com.akila.userservices.repository.OrgUserContentMetadataRepository;
import com.akila.userservices.repository.OrgUserFavLinkRepository;

@Service
public class FavLinkService extends AkilaService {
  private static Logger log = LogManager.getLogger(FavLinkService.class);
  @Autowired
  private OrgUserFavLinkRepository orgUserFavLinkRepository;
  
  @Autowired
  private FavLinkMapper favLinkMapper;
  
  @Autowired
  private OrgContentMetadataRepository orgContentRepository;

  @Autowired
  private OrgUserContentMetadataRepository orgUserContentRepository;
  
  @Autowired
  @Qualifier("loadBalanced")
  private RestTemplate restTemplateloadBalanced;
  
  @Value("${metric.service.url}")
  private String metricServiceURL;

  @Autowired
  AkilaRestTemplate akilaRestTemplate;
  
  public ResponseId addLinkToFavoriteList(String favLinkId, FavLinkRequest favLinkRequest) {
	  OrgUserFavLinkPK id=getOrgUserFavLinkPK(favLinkId, favLinkRequest.getContentId());
	  OrgUserFavLink orgUserFavLink=favLinkMapper.favLinkRequestToOrgUserFavLink(favLinkRequest);
	  orgUserFavLink.setId(id);
	  OrgContentMetadata orgContent = orgContentRepository.findById(favLinkRequest.getContentId()).orElse(null);
	  orgUserFavLink.setMediaCd(orgContent.getMediaCd());
	  orgUserFavLink.setContentTypeCd(orgContent.getContentTypeCd());
	  orgUserFavLink.setCrtTs(new Timestamp(System.currentTimeMillis()));
	  orgUserFavLink= orgUserFavLinkRepository.save(orgUserFavLink);
	  
	  OrgUserContentMetadataPK orgUserContentMetadataPK = getOrgUserContentMetadataPK(favLinkRequest.getContentId());
	  OrgUserContentMetadata orgUserContentMetadata= new OrgUserContentMetadata();
	  if(orgUserContentRepository.existsById(orgUserContentMetadataPK)) {
		  orgUserContentMetadata = orgUserContentRepository.getOne(orgUserContentMetadataPK);
		  orgUserContentMetadata.setIsFavorite(true);
		  orgUserContentMetadata.setModTs(new Timestamp(System.currentTimeMillis()));
		  orgUserContentRepository.save(orgUserContentMetadata);
	  }
	  else{
	  orgUserContentMetadata.setId(orgUserContentMetadataPK);
	  orgUserContentMetadata.setIsFavorite(true);
	  orgUserContentMetadata.setModTs(new Timestamp(System.currentTimeMillis()));
	  orgUserContentRepository.save(orgUserContentMetadata);
	  }
	  HttpEntity<String> entity = new HttpEntity<String>("Metric-Fav",getRequestHeader());
		
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		executorService.execute(new Runnable() {
		    @Override
		    public void run() {
		    	try {
		    		akilaRestTemplate.postForEntity(restTemplateloadBalanced, metricServiceURL + "/metric/fav/"+favLinkRequest.getContentId(), entity, Void.class);
				} catch (Exception e) {
					 log.error("FavLinkService.addLinkToFavoriteList : Error while updating metrics",e);
				}
		    }
		});
	  return new ResponseId(orgUserFavLink.getId().getContentId().toString());
  }

  public List<FavLinkResponse> getAllFavoriteLink(String favlistId) {
	  List<OrgUserFavLink> orgUserFavLinkList=orgUserFavLinkRepository.findAllOrgUserFavLinkbyFavLinkId(favlistId);
	  return favLinkMapper.orgUserFavLinkToFavLinkResponseList(orgUserFavLinkList);
  }
  
  public ResponseId removeFromFavoriteList(String favId, String id) {
	  OrgUserFavLinkPK favLinkIdPK=getOrgUserFavLinkPK(favId, id);
	  orgUserFavLinkRepository.deleteById(favLinkIdPK);
	  OrgUserContentMetadataPK orgUserContentMetadataPK = getOrgUserContentMetadataPK(id);
	  orgUserContentRepository.deleteById(orgUserContentMetadataPK);
	  HttpEntity<String> entity = new HttpEntity<String>("Metric-Fav",getRequestHeader());
		
		ExecutorService executorService = Executors.newSingleThreadExecutor();
		executorService.execute(new Runnable() {
		    @Override
		    public void run() {
		    	try {
		    		akilaRestTemplate.postForEntity(restTemplateloadBalanced, metricServiceURL + "/metric/fav/"+id+"/remove", entity, Void.class);
				} catch (Exception e) {
					 log.error("FavLinkService.removeFromFavoriteList : Error while updating metrics",e);
				}
		    }
		});
		
	  return new ResponseId(favLinkIdPK.getContentId());
  }

  public OrgUserContentMetadataPK getOrgUserContentMetadataPK(String contentId) {
	  OrgUserContentMetadataPK orgUserContentMetadataPK = new OrgUserContentMetadataPK();
	  orgUserContentMetadataPK.setContentId(contentId);
	  orgUserContentMetadataPK.setUserId(getUserId());
	        return orgUserContentMetadataPK;
	  }

  public OrgUserFavLinkPK getOrgUserFavLinkPK(String favlistId, String contentId) {
    OrgUserFavLinkPK orgUserFavLinkPK = new OrgUserFavLinkPK();
        orgUserFavLinkPK.setUserId(super.getUserId());
        orgUserFavLinkPK.setFavlistId(favlistId);
        orgUserFavLinkPK.setContentId(contentId);
        return orgUserFavLinkPK;
  }
}
