package com.akila.userservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.akila.userservices.entity.OrgUserGroupToUsersLink;
import com.akila.userservices.entity.OrgUserGroupToUsersLinkPK;

public interface OrgUserGroupToUsersLinkRepository extends JpaRepository<OrgUserGroupToUsersLink, OrgUserGroupToUsersLinkPK>{

	List<OrgUserGroupToUsersLink> findByUserId(String userId);

}
