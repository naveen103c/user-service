package com.akila.userservices.favlist.sharing.bean;

import java.sql.Timestamp;

import com.akila.AkilaResponse;

public class SharedFavlistResponse extends AkilaResponse {
	
	private String description;

	private String favlistNm;

	private String favlistId;
	
	private Timestamp sharedTs;

	private String ownerUserId;

	public Timestamp getSharedTs() {
		return sharedTs;
	}

	public void setSharedTs(Timestamp sharedTs) {
		this.sharedTs = sharedTs;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFavlistNm() {
		return favlistNm;
	}

	public void setFavlistNm(String favlistNm) {
		this.favlistNm = favlistNm;
	}

	public String getFavlistId() {
		return favlistId;
	}

	public void setFavlistId(String favlistId) {
		this.favlistId = favlistId;
	}

	public String getOwnerUserId() {
		return ownerUserId;
	}

	public void setOwnerUserId(String ownerUserId) {
		this.ownerUserId = ownerUserId;
	}
	
}
