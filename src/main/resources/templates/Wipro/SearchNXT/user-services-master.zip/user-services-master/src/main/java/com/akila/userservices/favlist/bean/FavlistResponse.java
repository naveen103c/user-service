package com.akila.userservices.favlist.bean;

import com.akila.AkilaResponse;
import com.akila.userservices.entity.OrgUserFavlistPK;

import java.lang.Boolean;
import java.lang.String;
import java.sql.Timestamp;

public class FavlistResponse extends AkilaResponse {
  private Timestamp crtTs;

  private String description;

  private String favlistNm;

  private Boolean isDefault;

  private Boolean isShared;

  private Timestamp modTs;
  
  private OrgUserFavlistPK id;

  public OrgUserFavlistPK getId() {
	return id;
  }

  public void setId(OrgUserFavlistPK id) {
	this.id = id;
  }

  public void setCrtTs(Timestamp crtTs) {
    this.crtTs = crtTs;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public void setFavlistNm(String favlistNm) {
    this.favlistNm = favlistNm;
  }

  public void setIsDefault(Boolean isDefault) {
    this.isDefault = isDefault;
  }

  public void setIsShared(Boolean isShared) {
    this.isShared = isShared;
  }

  public void setModTs(Timestamp modTs) {
    this.modTs = modTs;
  }

  public Timestamp getCrtTs() {
    return crtTs;
  }

  public String getDescription() {
    return description;
  }

  public String getFavlistNm() {
    return favlistNm;
  }

  public Boolean getIsDefault() {
    return isDefault;
  }

  public Boolean getIsShared() {
    return isShared;
  }

  public Timestamp getModTs() {
    return modTs;
  }
}
