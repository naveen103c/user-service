package com.akila.userservices.favlink;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.response.ResponseId;
import com.akila.userservices.favlink.bean.FavLinkRequest;
import com.akila.userservices.favlink.bean.FavLinkResponse;

@RestController
public class FavLinkController extends AkilaController {

	@Autowired
	private FavLinkService favLinkService;

	@PostMapping(path = "/fav-list/{id}/links")
	public ResponseId addLinkToFavoriteList(@PathVariable String id,@Valid @RequestBody FavLinkRequest favLinkRequest) {
		return favLinkService.addLinkToFavoriteList(id, favLinkRequest);
	}

	@GetMapping(path = "/fav-list/{id}/links")
	public List<FavLinkResponse> getAllFavoriteLink(@PathVariable String id) {
		return favLinkService.getAllFavoriteLink(id);
	}

	@PutMapping(path = "/fav-list/{favId}/links/{id}")
	public ResponseId removeFromFavoriteList(@PathVariable String favId, @PathVariable String id) {
		return favLinkService.removeFromFavoriteList(favId, id);
	}
}
