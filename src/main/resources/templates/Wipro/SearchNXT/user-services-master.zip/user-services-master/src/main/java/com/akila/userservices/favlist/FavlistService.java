package com.akila.userservices.favlist;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.response.ResponseId;
import com.akila.userservices.entity.OrgUserFavLink;
import com.akila.userservices.entity.OrgUserFavlist;
import com.akila.userservices.entity.OrgUserFavlistPK;
import com.akila.userservices.favlist.bean.FavlistMapper;
import com.akila.userservices.favlist.bean.FavlistRequest;
import com.akila.userservices.favlist.bean.FavlistResponse;
import com.akila.userservices.pref.PrefService;
import com.akila.userservices.repository.OrgUserFavLinkRepository;
import com.akila.userservices.repository.OrgUserFavlistRepository;

@Service
public class FavlistService extends AkilaService {
	
  private static Logger log = LogManager.getLogger(FavlistService.class);
 
  @Autowired
  private OrgUserFavlistRepository orgUserFavlistRepository;

  @Autowired
  private FavlistMapper favlistMapper;
  
  @Autowired
  private OrgUserFavLinkRepository orgUserFavLinkRepository;
  
  public ResponseId createFavoriteList(FavlistRequest favlistRequest) {
    OrgUserFavlist orgUserFavlist=favlistMapper.favlistRequestToOrgUserFavlist(favlistRequest);
    orgUserFavlist.setId(getOrgUserFavlistPK(UUID.randomUUID().toString()));
    orgUserFavlist.setCrtTs(new Timestamp(System.currentTimeMillis()));
    orgUserFavlist.setModTs(new Timestamp(System.currentTimeMillis()));
    orgUserFavlist.setCrtBy(getUserId());
    orgUserFavlist.setModBy(getUserId());
    
    List<OrgUserFavlist> orgUserFavList=orgUserFavlistRepository.findByUserIdAndDefaultStatus(getUserId(),Boolean.TRUE);
    if(!orgUserFavlist.getIsDefault() && orgUserFavList.size() == 0 ) {
    	orgUserFavlist.setIsDefault(Boolean.TRUE);
    }
    else if(orgUserFavlist.getIsDefault() && orgUserFavList.size() != 0 ) {
    	for (OrgUserFavlist list : orgUserFavList) {
    		list.setIsDefault(Boolean.FALSE);
    		orgUserFavlistRepository.save(list);
		}
    }
    
    orgUserFavlist =  orgUserFavlistRepository.save(orgUserFavlist);
    return new ResponseId(orgUserFavlist.getId().getFavlistId());
  }

  public List<FavlistResponse> getAllFavoriteList() {
	  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	  log.info("getAllFavoriteList Entry Time -- "+dateFormat.format(System.currentTimeMillis()));
	  List<OrgUserFavlist> orgUserFavList=orgUserFavlistRepository.findByUserId(getUserId());
	  log.info("getAllFavoriteList Before Return Time -- "+dateFormat.format(System.currentTimeMillis()));
	  return favlistMapper.orgUserFavlistToFavlistResponseList(orgUserFavList);
  }
  
  public FavlistResponse getFavoriteListById(String favlistId) {
	  OrgUserFavlist orgUserFavlist=orgUserFavlistRepository.getOne(getOrgUserFavlistPK(favlistId));
	  return favlistMapper.orgUserFavlistToFavlistResponse(orgUserFavlist);
  }
  
	public String deleteListById(String favlistId) {
		String responseId = null;
		List<OrgUserFavlist> orgUserFavList = orgUserFavlistRepository.findByUserId(getUserId());
		if (orgUserFavList.size() > 1) {
			OrgUserFavlist orgUserFavlist = orgUserFavlistRepository.findById(getOrgUserFavlistPK(favlistId))
					.orElse(null);
			if (orgUserFavlist != null) {

				if (orgUserFavlist.getIsDefault()) {

					if (orgUserFavList.size() > 1) {
						for (OrgUserFavlist list : orgUserFavList) {
							if (!list.getId().getFavlistId().equals(favlistId)) {
								list.setIsDefault(Boolean.TRUE);
								orgUserFavlistRepository.save(list);
								break;
							}
						}
					}
				}

				List<OrgUserFavLink> orgUserFavLinkList = orgUserFavLinkRepository
						.findAllOrgUserFavLinkbyFavLinkId(favlistId);
				for (OrgUserFavLink orgUserFavLink : orgUserFavLinkList) {
					orgUserFavLinkRepository.deleteById(orgUserFavLink.getId());
				}

				OrgUserFavlistPK orgUserFavlistPK = getOrgUserFavlistPK(favlistId);
				orgUserFavlistRepository.deleteById(orgUserFavlistPK);
				responseId = favlistId;
			}
		}
		return responseId;
	}

  public ResponseId updateFavoriteList(String id, FavlistRequest favlistRequest) {
    OrgUserFavlistPK orgUserFavlistPK=getOrgUserFavlistPK(id);
    if(orgUserFavlistRepository.existsById(orgUserFavlistPK)) {
    	
		if (favlistRequest.getIsDefault()) {
			List<OrgUserFavlist> orgUserFavList = orgUserFavlistRepository.findByUserIdAndDefaultStatus(getUserId(),
					Boolean.TRUE);
			for (OrgUserFavlist list : orgUserFavList) {
				list.setIsDefault(Boolean.FALSE);
				list.setModTs(new Timestamp(System.currentTimeMillis()));
				orgUserFavlistRepository.save(list);
			}
		}
    	
    	OrgUserFavlist orgUserFavlist=favlistMapper.favlistRequestToOrgUserFavlist(favlistRequest);
	    orgUserFavlist.setId(orgUserFavlistPK);
	    orgUserFavlist.setCrtTs(new Timestamp(System.currentTimeMillis()));
	    orgUserFavlist.setModTs(new Timestamp(System.currentTimeMillis()));
	    orgUserFavlist =  orgUserFavlistRepository.save(orgUserFavlist);
	    return new ResponseId(orgUserFavlist.getId().getFavlistId());
    }
    else {
		return null;
	}
  }
  
  public OrgUserFavlistPK getOrgUserFavlistPK(String favlistId) {
    OrgUserFavlistPK orgUserFavlistPK = new OrgUserFavlistPK();
        orgUserFavlistPK.setUserId(super.getUserId());
        orgUserFavlistPK.setFavlistId(favlistId);
        return orgUserFavlistPK;
  }

}
