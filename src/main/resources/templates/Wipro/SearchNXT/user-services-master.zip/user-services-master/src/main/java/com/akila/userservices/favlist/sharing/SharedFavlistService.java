package com.akila.userservices.favlist.sharing;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.akila.AkilaService;
import com.akila.response.ResponseId;
import com.akila.userservices.entity.OrgUserFavlist;
import com.akila.userservices.entity.OrgUserFavlistPK;
import com.akila.userservices.entity.OrgUserSharedFavlist;
import com.akila.userservices.entity.OrgUserSharedFavlistHistory;
import com.akila.userservices.entity.OrgUserSharedFavlistPK;
import com.akila.userservices.favlist.sharing.bean.SharedFavlistRequest;
import com.akila.userservices.favlist.sharing.bean.SharedFavlistResponse;
import com.akila.userservices.favlist.sharing.bean.SharedListResponse;
import com.akila.userservices.repository.OrgUserFavlistRepository;
import com.akila.userservices.repository.OrgUserSharedFavlistHistoryRepository;
import com.akila.userservices.repository.OrgUserSharedFavlistRepository;

@Service
public class SharedFavlistService extends AkilaService {
	private static Logger log = LogManager.getLogger(SharedFavlistService.class);
	
	@Value("${bookmark.expiry.days}")
	private int bookmarkExpiryDays;
	
	@Autowired
	private OrgUserSharedFavlistRepository orgUserSharedFavlistRepository;

	@Autowired
	private OrgUserFavlistRepository orgUserFavlistRepository;
	
	@Autowired
	private OrgUserSharedFavlistHistoryRepository orgUserSharedFavlistHistoryRepository;

	public ResponseId shareFavList(SharedFavlistRequest favSharedlistRequest) {
		log.info("inside shareFavList method of SharedFavlistService");
		List<OrgUserSharedFavlist> sharedFavlist = new ArrayList<OrgUserSharedFavlist>();
		log.info("favSharedlistRequest.getUserId() = "+favSharedlistRequest.getUserId());
		for (String userId : favSharedlistRequest.getUserId()) {
			if(!orgUserSharedFavlistRepository.existsByIdFavlistIdAndUserId(favSharedlistRequest.getFavlistId(), userId)) {
			OrgUserSharedFavlist orgUserSharedFavlist = new OrgUserSharedFavlist();
			orgUserSharedFavlist.setId(
					getOrgUserSharedFavlistPK(UUID.randomUUID().toString(), favSharedlistRequest.getFavlistId()));
			orgUserSharedFavlist.setExpiryDate(getBookmarkExpiryTimestamp());
			orgUserSharedFavlist.setOwnerUserId(super.getUserId());
			orgUserSharedFavlist.setUserId(userId);
			orgUserSharedFavlist.setUserGroupId(favSharedlistRequest.getUserGroupId());
			orgUserSharedFavlist.setCrtTs(new Timestamp(System.currentTimeMillis()));
			orgUserSharedFavlist.setModTs(new Timestamp(System.currentTimeMillis()));
			orgUserSharedFavlist.setCrtBy(getUserId());
			orgUserSharedFavlist.setModBy(getUserId());
			sharedFavlist.add(orgUserSharedFavlist);
			}
		}
		log.info("sharedFavlist = "+sharedFavlist);
		if (!sharedFavlist.isEmpty()) {
			orgUserSharedFavlistRepository.saveAll(sharedFavlist);			
			OrgUserFavlist orgUserFavlist = orgUserFavlistRepository.getOne(getOrgUserFavlistPK(favSharedlistRequest.getFavlistId(), super.getUserId()));
			orgUserFavlist.setIsShared(true);
			orgUserFavlist.setModTs(new Timestamp(System.currentTimeMillis()));
			orgUserFavlist = orgUserFavlistRepository.save(orgUserFavlist);

			log.info("Before returning from shareFavList method of SharedFavlistService");
			return new ResponseId(orgUserFavlist.getId().getFavlistId());
		}
		else {
			log.info("Requested favlist is already shared with the given user");
			log.info("Before returning from shareFavList method of SharedFavlistService");
			return new ResponseId(favSharedlistRequest.getFavlistId());
		}
	}
	
	private Timestamp getBookmarkExpiryTimestamp() {
		// getting Current Time
		Timestamp currentTimestamp = new Timestamp(new Date().getTime());
		// getting 30 Days from today timestamp
		Timestamp bookmarkExpiryTimestamp = Timestamp.valueOf(currentTimestamp.toLocalDateTime().plusDays(bookmarkExpiryDays));
		return bookmarkExpiryTimestamp;
	}

	@Transactional
	public ResponseId updateFavList(SharedFavlistRequest favSharedlistRequest) {

		log.info("inside updateFavList method of SharedFavlistService");
		List<OrgUserSharedFavlist> sharedFavlist = new ArrayList<OrgUserSharedFavlist>();
		SharedListResponse response = getSharedFavoriteListByFavlistId(favSharedlistRequest.getFavlistId());
		List<String> oldUserIds = response.getUserIds();
		log.info("Old userIds = "+oldUserIds);
		log.info("new userIds = "+favSharedlistRequest.getUserId());
		for (String userId : favSharedlistRequest.getUserId()) {
			if (!oldUserIds.contains(userId)) {
				OrgUserSharedFavlist orgUserSharedFavlist = new OrgUserSharedFavlist();
				orgUserSharedFavlist.setId(
						getOrgUserSharedFavlistPK(UUID.randomUUID().toString(), favSharedlistRequest.getFavlistId()));
				orgUserSharedFavlist.setExpiryDate(favSharedlistRequest.getExpiryDate());
				orgUserSharedFavlist.setOwnerUserId(super.getUserId());
				orgUserSharedFavlist.setUserId(userId);
				orgUserSharedFavlist.setUserGroupId(favSharedlistRequest.getUserGroupId());
				orgUserSharedFavlist.setCrtTs(new Timestamp(System.currentTimeMillis()));
				orgUserSharedFavlist.setModTs(new Timestamp(System.currentTimeMillis()));
				orgUserSharedFavlist.setCrtBy(getUserId());
				orgUserSharedFavlist.setModBy(getUserId());
				sharedFavlist.add(orgUserSharedFavlist);
			}else {
				oldUserIds.remove(userId);
			}
		}
		
		orgUserSharedFavlistRepository.saveAll(sharedFavlist);
		response.setUserIds(oldUserIds);
		List<OrgUserSharedFavlistHistory> historyList = new ArrayList<OrgUserSharedFavlistHistory>();
		log.info("Remaining user Ids from the old Ids= "+ oldUserIds);
		for(String userId : oldUserIds) {
			OrgUserSharedFavlistHistory orgUserSharedFavlistHistory = new OrgUserSharedFavlistHistory();
			orgUserSharedFavlistHistory.setSharedFavlistHistoryId(UUID.randomUUID().toString());
			orgUserSharedFavlistHistory.setFavlistId(response.getFavlistId());
			orgUserSharedFavlistHistory.setExpiryTs(response.getExpiryTs());
			orgUserSharedFavlistHistory.setUserGroupId(response.getUserGroupId());
			orgUserSharedFavlistHistory.setUserId(userId);
			orgUserSharedFavlistHistory.setOwnerUserId(response.getOwnerUserId());
			historyList.add(orgUserSharedFavlistHistory);
			orgUserSharedFavlistRepository.deleteByIdFavlistIdAndUserId(favSharedlistRequest.getFavlistId(), userId);
		}
		orgUserSharedFavlistHistoryRepository.saveAll(historyList);
		
		log.info("Before returning from updateFavList method of SharedFavlistService");
		return new ResponseId(response.getFavlistId());
	}

	public SharedListResponse getSharedFavoriteListByFavlistId(String favListId) {
		
		log.info("inside getSharedFavoriteListByFavlistId method of SharedFavlistService");
		SharedListResponse response = new SharedListResponse();
		List<String> userIds = new ArrayList<String>();
		List<OrgUserSharedFavlist> sharedFavlist = orgUserSharedFavlistRepository.findByIdFavlistId(favListId);
		for (OrgUserSharedFavlist orgUserSharedFavlist : sharedFavlist) {
			userIds.add(orgUserSharedFavlist.getUserId());
		}
		OrgUserFavlist orgUserFavlist = orgUserFavlistRepository.findByIdAndIsShared(getOrgUserFavlistPK(favListId, sharedFavlist.get(0).getOwnerUserId()), true);
		response.setExpiryTs(sharedFavlist.get(0).getExpiryDate());
		response.setFavlistId(favListId);
		response.setDescription(orgUserFavlist.getDescription());
		response.setFavlistNm(orgUserFavlist.getFavlistNm());
		response.setSharedTs(sharedFavlist.get(0).getCrtTs());
		response.setUserGroupId(sharedFavlist.get(0).getUserGroupId());
		response.setUserIds(userIds);
		response.setOwnerUserId(sharedFavlist.get(0).getOwnerUserId());
		log.info("userIds in the list = "+response.getUserIds());
		log.info("Before returning from getSharedFavoriteListByFavlistId method of SharedFavlistService");
		return response;
	}

	public List<SharedFavlistResponse> getAllSharedFavoriteListByUserId() {
		log.info("inside getAllSharedFavoriteListByUserId method of SharedFavlistService");
		List<SharedFavlistResponse> responseList = new ArrayList<SharedFavlistResponse>();
		List<OrgUserSharedFavlist> listOfOrgUserSharedFavlist = orgUserSharedFavlistRepository
				.findByUserIdAndExpiryDateGreaterThanEqual(super.getUserId(), new Timestamp(new Date().getTime()));
		for (OrgUserSharedFavlist orgUserSharedFavlist : listOfOrgUserSharedFavlist) {
			OrgUserFavlist orgUserFavlist = orgUserFavlistRepository.findByIdAndIsShared(getOrgUserFavlistPK(
			orgUserSharedFavlist.getId().getFavlistId(), orgUserSharedFavlist.getOwnerUserId()), true);
			SharedFavlistResponse sharedFavlistResponse = new SharedFavlistResponse();
			sharedFavlistResponse.setFavlistId(orgUserFavlist.getId().getFavlistId());
			sharedFavlistResponse.setDescription(orgUserFavlist.getDescription());
			sharedFavlistResponse.setOwnerUserId(orgUserSharedFavlist.getOwnerUserId());
			sharedFavlistResponse.setFavlistNm(orgUserFavlist.getFavlistNm());
			log.info("favListId = "+orgUserFavlist.getId().getFavlistId()+"------FavList Name = "+orgUserFavlist.getFavlistNm());
			sharedFavlistResponse.setSharedTs(orgUserFavlist.getCrtTs());
			responseList.add(sharedFavlistResponse);
		}
		log.info("Before returning from getAllSharedFavoriteListByUserId method of SharedFavlistService");
		return responseList;
	}

	@Transactional
	public void deleteSharedFavoriteListByFavlistId(String favlistId) {
		log.info("inside deleteSharedFavoriteListByFavlistId method of SharedFavlistService");
		log.info("favlist id to be deleted ="+favlistId);
		SharedListResponse response = getSharedFavoriteListByFavlistId(favlistId);
		List<OrgUserSharedFavlistHistory> historyList = new ArrayList<OrgUserSharedFavlistHistory>();
		for(String userId : response.getUserIds()) {
			OrgUserSharedFavlistHistory orgUserSharedFavlistHistory = new OrgUserSharedFavlistHistory();
			orgUserSharedFavlistHistory.setSharedFavlistHistoryId(UUID.randomUUID().toString());
			orgUserSharedFavlistHistory.setFavlistId(response.getFavlistId());
			orgUserSharedFavlistHistory.setExpiryTs(response.getExpiryTs());
			orgUserSharedFavlistHistory.setUserGroupId(response.getUserGroupId());
			orgUserSharedFavlistHistory.setUserId(userId);
			orgUserSharedFavlistHistory.setOwnerUserId(response.getOwnerUserId());
			historyList.add(orgUserSharedFavlistHistory);
		}
		orgUserSharedFavlistHistoryRepository.saveAll(historyList);
		
		orgUserSharedFavlistRepository.deleteByIdFavlistId(favlistId);
		OrgUserFavlist orgUserFavlist = orgUserFavlistRepository.getOne(
				getOrgUserFavlistPK(favlistId, super.getUserId()));
		log.info("orgUserFavlist ="+orgUserFavlist);
		orgUserFavlist.setIsShared(false);
		orgUserFavlist.setModTs(new Timestamp(System.currentTimeMillis()));
		orgUserFavlistRepository.save(orgUserFavlist);
		log.info("Exiting deleteSharedFavoriteListByFavlistId method of SharedFavlistService");
	}

	public OrgUserSharedFavlistPK getOrgUserSharedFavlistPK(String sharedFavlistId, String favlistId) {
		OrgUserSharedFavlistPK orgUserSharedFavlistPK = new OrgUserSharedFavlistPK();
		orgUserSharedFavlistPK.setSharedFavlistId(sharedFavlistId);
		orgUserSharedFavlistPK.setFavlistId(favlistId);
		return orgUserSharedFavlistPK;
	}

	public OrgUserFavlistPK getOrgUserFavlistPK(String favlistId, String userId) {
		OrgUserFavlistPK orgUserFavlistPK = new OrgUserFavlistPK();
		orgUserFavlistPK.setUserId(userId);
		orgUserFavlistPK.setFavlistId(favlistId);
		return orgUserFavlistPK;
	}

}
