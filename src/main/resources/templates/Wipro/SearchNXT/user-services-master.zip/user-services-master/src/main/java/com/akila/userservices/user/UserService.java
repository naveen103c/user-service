package com.akila.userservices.user;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.akila.AkilaService;
import com.akila.userservices.user.bean.ConfUserGroupListResponse;
import com.akila.userservices.entity.OrgBatchJobConf;
import com.akila.userservices.entity.OrgBatchJobRuntime;
import com.akila.userservices.entity.OrgCommunity;
import com.akila.userservices.entity.OrgCommunityAdmin;
import com.akila.userservices.entity.OrgCommunitySme;
import com.akila.userservices.entity.OrgCommunityUserGroup;
import com.akila.userservices.entity.OrgUser;
import com.akila.userservices.entity.OrgUserGroup;
import com.akila.userservices.repository.OrgBatchJobConfRepository;
import com.akila.userservices.repository.OrgCommunityAdminRepository;
import com.akila.userservices.repository.OrgCommunityRepository;
import com.akila.userservices.repository.OrgCommunitySmeRepository;
import com.akila.userservices.repository.OrgCommunityUserGroupRepository;
import com.akila.userservices.repository.OrgUserGroupRepository;
import com.akila.userservices.repository.OrgUserGroupToUsersLinkRepository;
import com.akila.userservices.repository.OrgUserToRolesLinkRepository;
import com.akila.userservices.user.bean.OrgBatchJobConfResponse;
import com.akila.userservices.user.bean.OrgUserToCommunityResponse;
import com.akila.userservices.user.bean.OrgUserToRolesLinkResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class UserService extends AkilaService {
	private static final Logger logger = LogManager.getLogger(UserService.class);

	@Autowired
	private OrgUserToRolesLinkRepository orgUserToRolesLinkRepository;
	@Autowired
	private OrgCommunityAdminRepository orgCommunityAdminRepository;
	@Autowired
	private OrgCommunitySmeRepository orgCommunitySmeRepository;
	@Autowired
	private OrgCommunityRepository orgCommunityRepository;
	@Autowired
	private OrgBatchJobConfRepository orgBatchJobConfRepository;
	@Autowired
	private OrgUserGroupRepository orgUserGroupRepository;
	@Autowired
	private OrgUserGroupToUsersLinkRepository orgUserGroupToUsersLinkRepository;
	@Autowired
	private OrgCommunityUserGroupRepository orgCommunityUserGroupRepository;

	public List<OrgUserToRolesLinkResponse> getUserLinkedRoles() {
		String userId = getUserId();
		logger.info("UserServices:  UserService -> getting user linked roles");
		List<OrgUserToRolesLinkResponse> userRoles = (orgUserToRolesLinkRepository.findByUserId(userId))
				.stream().map(p -> new OrgUserToRolesLinkResponse(p.getBaseRole().getRoleId(),
						p.getBaseRole().getRoleNm(), p.getBaseRole().getRoleDescription()))
				.collect(Collectors.toList());
		return userRoles;
	}

	public List<OrgUserToCommunityResponse> getUserRelatedCommunities() {
		List<String> adminList = Stream.of("Admin").collect(Collectors.toList());
		List<String> smeList = Stream.of("SME").collect(Collectors.toList());
		List<String> ownerList = Stream.of("Owner").collect(Collectors.toList());
		List<String> memberList = Stream.of("Member").collect(Collectors.toList());
		String userId = getUserId();
		logger.info("UserServices:  UserService -> getting user linked Communities");

		List<OrgCommunityAdmin> userAdminRelatedCommunities = orgCommunityAdminRepository.findByUserId(userId);
		List<OrgUserToCommunityResponse> userAdminCommunities = userAdminRelatedCommunities.stream()
				.map(p -> new OrgUserToCommunityResponse(p.getOrgCommunity().getCommunityId(),
						p.getOrgCommunity().getCommunityNm(),
						getOrgParentCommunityName(p.getOrgCommunity().getParentCommunityNm()),
						getOrgCommunityOwnerName(p.getOrgCommunity().getOrgUser()), adminList))
				.collect(Collectors.toList());

		List<OrgCommunitySme> userSmeRelatedCommunities = orgCommunitySmeRepository.findByUserId(userId);
		List<OrgUserToCommunityResponse> userSmeCommunities = userSmeRelatedCommunities.stream()
				.map(p -> new OrgUserToCommunityResponse(p.getOrgCommunity().getCommunityId(),
						p.getOrgCommunity().getCommunityNm(),
						getOrgParentCommunityName(p.getOrgCommunity().getParentCommunityNm()),
						getOrgCommunityOwnerName(p.getOrgCommunity().getOrgUser()), smeList))
				.collect(Collectors.toList());

		List<OrgCommunity> userOwnerRelatedCommunities = orgCommunityRepository.findByCommunityOwner(userId);
		List<OrgUserToCommunityResponse> userOwnerCommunities = userOwnerRelatedCommunities.stream()
				.map(p -> new OrgUserToCommunityResponse(p.getCommunityId(), p.getCommunityNm(),
						getOrgParentCommunityName(p.getParentCommunityNm()), getOrgCommunityOwnerName(p.getOrgUser()),
						ownerList))
				.collect(Collectors.toList());

		List<String> userGroupId = orgUserGroupToUsersLinkRepository.findByUserId(userId).stream()
				.map(p -> p.getId().getUserGroupId()).collect(Collectors.toList());
		List<OrgCommunityUserGroup> orgCommunityUserGroup = orgCommunityUserGroupRepository.findAll().stream()
				.filter(p -> userGroupId.contains(p.getUserGroupId())).collect(Collectors.toList());
		List<OrgUserToCommunityResponse> userMemberCommunities = orgCommunityUserGroup.stream()
				.map(p -> new OrgUserToCommunityResponse(p.getOrgCommunity().getCommunityId(),
						p.getOrgCommunity().getCommunityNm(),
						getOrgParentCommunityName(p.getOrgCommunity().getParentCommunityNm()),
						getOrgCommunityOwnerName(p.getOrgCommunity().getOrgUser()), memberList))
				.collect(Collectors.toList());

		for (OrgUserToCommunityResponse sme : userSmeCommunities) {
			boolean flag = true;
			for (OrgUserToCommunityResponse admin : userAdminCommunities) {
				if (admin.getCommunityId().equals(sme.getCommunityId())) {
					List<String> roles = new ArrayList<>();
					roles.addAll(admin.getroles());
					roles.addAll(sme.getroles());
					admin.setroles(roles);
					flag = false;
					break;
				}
			}
			if (flag)
				userAdminCommunities.add(sme);
		}
		for (OrgUserToCommunityResponse owner : userOwnerCommunities) {
			boolean flag = true;
			for (OrgUserToCommunityResponse admin : userAdminCommunities) {
				if (admin.getCommunityId().equals(owner.getCommunityId())) {
					List<String> roles = new ArrayList<>();
					roles.addAll(admin.getroles());
					roles.addAll(owner.getroles());
					admin.setroles(roles);
					flag = false;
					break;
				}
			}
			if (flag)
				userAdminCommunities.add(owner);
		}
		for (OrgUserToCommunityResponse member : userMemberCommunities) {
			boolean flag = true;
			for (OrgUserToCommunityResponse admin : userAdminCommunities) {
				if (admin.getCommunityId().equals(member.getCommunityId())) {
					List<String> roles = new ArrayList<>();
					roles.addAll(admin.getroles());
					roles.addAll(member.getroles());
					admin.setroles(roles);
					flag = false;
					break;
				}
			}
			if (flag)
				userAdminCommunities.add(member);
		}
		return userAdminCommunities;
	}

	private String getOrgParentCommunityName(String parentCommunityNm) {
		if (!parentCommunityNm.isEmpty()) {
			Optional<OrgCommunity> orgCommunity = orgCommunityRepository.findById(parentCommunityNm);
			if (orgCommunity.isPresent()) {
				return orgCommunity.get().getCommunityNm();
			}
		}
		return "";
	}

	private String getOrgCommunityOwnerName(OrgUser orgUser) {
		if (orgUser != null) {
			if (orgUser.getUserLastNm().isEmpty())
				return orgUser.getUserFirstNm();
			return orgUser.getUserFirstNm() + " " + orgUser.getUserLastNm();
		}
		return "";
	}

	public List<OrgBatchJobConfResponse> getUserDataConfigurations() {
		List<OrgBatchJobConf> userDataConfs = null;
		List<OrgBatchJobConfResponse> userDataConfsResponse = null;
		String userId = getUserId();
		logger.info("UserServices:  UserService -> getting user linked confs");

		List<String> userGroupId = orgUserGroupToUsersLinkRepository.findByUserId(userId).stream()
				.map(p -> p.getId().getUserGroupId()).collect(Collectors.toList());
		List<ConfUserGroupListResponse> confUserGroupListResponse = orgBatchJobConfRepository.findAll().stream()
				.map(p -> new ConfUserGroupListResponse(p.getConfId(), p.getSourceAllowedUserGroupList()))
				.collect(Collectors.toList());
		Set<String> confIds = new HashSet<>();
		for (String tempUserGroupId : userGroupId) {
			for (ConfUserGroupListResponse ConfUserGroupList : confUserGroupListResponse) {
				for (String UserGpId : ConfUserGroupList.getSourceAllowedUserGroupList()) {
					if (UserGpId.equals(tempUserGroupId)) {
						confIds.add(ConfUserGroupList.getConfId());
					}
				}
			}
		}
		userDataConfs = orgBatchJobConfRepository.findAll().stream()
				.filter(p -> (p.getCrtBy().equals(userId) || confIds.contains(p.getConfId())))
				.collect(Collectors.toList());
		userDataConfsResponse = userDataConfs.stream()
				.map(p -> new OrgBatchJobConfResponse(p.getConfId(), p.getConfName(), p.getSourceTypeCd(),
						p.getBaseSourceType().getSourceTypeName(), p.getSourceUrl() == null ? "" : p.getSourceUrl(),
						getSourceAllowedUserGroupName(p.getSourceAllowedUserGroupList()),
						getJobStartTs(p.getOrgBatchJobRuntime(), p.getLastJobId())))
				.collect(Collectors.toList());
		return userDataConfsResponse;
	}

	private String getJobStartTs(List<OrgBatchJobRuntime> orgBatchJobRuntime, String lastJobId) {
		for (OrgBatchJobRuntime o : orgBatchJobRuntime) {
			if (o.getJobId().equals(lastJobId)) {
				return o.getJobStartTs().toString();
			}
		}
		return "";
	}

	private List<String> getSourceAllowedUserGroupName(String userGrouplist) {
		List<String> userGroup = new ArrayList<>();
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			userGroup = objectMapper.readValue(userGrouplist, List.class);
		} catch (JsonProcessingException e) {
			logger.error(e.getMessage(), e);
		}

		List<OrgUserGroup> orgUserGroup = orgUserGroupRepository.findAll();
		List<OrgUserGroup> orgUserGrouptemp = new ArrayList<>();

		List<String> userGroupName = new ArrayList<>();

		for (String groupId : userGroup) {
			for (OrgUserGroup usrGroup : orgUserGroup) {
				if (usrGroup.getUserGroupId().equals(groupId)) {
					userGroupName.add(usrGroup.getUserGroupNm());
				}
			}
		}

		userGroupName.addAll(orgUserGrouptemp.stream().map(p -> p.getUserGroupNm()).collect(Collectors.toList()));
		return userGroupName;
	}

}
