package com.akila.userservices.favlink.bean;

import java.sql.Timestamp;

import com.akila.AkilaResponse;
import com.akila.userservices.entity.OrgUserFavLinkPK;

public class FavLinkResponse extends AkilaResponse {
private OrgUserFavLinkPK id;
	
	private Integer contentTypeCd;

	private Timestamp crtTs;

	private Integer mediaCd;

	private String title;

	private String url;

	public OrgUserFavLinkPK getId() {
		return id;
	}

	public void setId(OrgUserFavLinkPK id) {
		this.id = id;
	}

	public Integer getContentTypeCd() {
		return contentTypeCd;
	}

	public void setContentTypeCd(Integer contentTypeCd) {
		this.contentTypeCd = contentTypeCd;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public Integer getMediaCd() {
		return mediaCd;
	}

	public void setMediaCd(Integer mediaCd) {
		this.mediaCd = mediaCd;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
}
