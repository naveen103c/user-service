package com.akila.userservices.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import com.akila.AkilaEntity;


/**
 * The persistent class for the org_community_user_groups database table.
 * 
 */
@Entity
@Table(name="org_community_user_groups")
@NamedQuery(name="OrgCommunityUserGroup.findAll", query="SELECT o FROM OrgCommunityUserGroup o")
public class OrgCommunityUserGroup extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgCommunityUserGroupPK id;
	
	@Column(name="user_group_id", insertable=false, updatable=false)
	private String userGroupId;
	
	@Column(name="community_id", insertable=false, updatable=false)
	private String communityId;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="community_id",  insertable=false, updatable=false)
	private OrgCommunity orgCommunity;

	public OrgCommunityUserGroup() {
	}

	public OrgCommunityUserGroupPK getId() {
		return this.id;
	}

	public void setId(OrgCommunityUserGroupPK id) {
		this.id = id;
	}

	public OrgCommunity getOrgCommunity() {
		return this.orgCommunity;
	}

	public void setOrgCommunity(OrgCommunity orgCommunity) {
		this.orgCommunity = orgCommunity;
	}

	public String getUserGroupId() {
		return userGroupId;
	}

	public void setUserGroupId(String userGroupId) {
		this.userGroupId = userGroupId;
	}

	public String getCommunityId() {
		return communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}
}