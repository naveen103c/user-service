package com.akila.contentservices.contentitem;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.akila.AkilaController;
import com.akila.contentservices.contentitem.bean.ContentItemProcessor;
import com.akila.contentservices.contentitem.bean.ContentItemRequest;
import com.akila.contentservices.contentitem.bean.ContentItemResponse;
import com.akila.contentservices.contentitem.bean.ContentMetaDataResponse;
import com.akila.response.ResponseId;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

@RestController
public class ContentItemController extends AkilaController 
{
	@Autowired
	private ContentItemService contentitemService;

	@PostMapping(path = "/content/store")
	public ResponseId createStrippedContentVersion(@RequestBody ContentItemRequest contentitemRequest) throws JsonMappingException, JsonProcessingException, Exception  {
		return contentitemService.createStrippedContentVersion(new ContentItemProcessor(contentitemRequest));
	}

	@PostMapping(path = "/content/cache")
	public ResponseId createOriginalContentCopy(@RequestBody ContentItemRequest contentitemRequest) throws JsonMappingException, JsonProcessingException, Exception  {
		return contentitemService.createOriginalContentCopy(new ContentItemProcessor(contentitemRequest));
	}

	@PostMapping(path = "/content/index")
	public ResponseId createContentIndex(@RequestBody ContentItemRequest contentitemRequest) {
		return contentitemService.createContentIndex(new ContentItemProcessor(contentitemRequest));
	}

	@PostMapping(path = "/content/meta")
	public ResponseId createContentMetaData(@RequestBody ContentItemRequest contentitemRequest) {
		return contentitemService.createContentMetaData(new ContentItemProcessor(contentitemRequest));
	}

	@PutMapping(path = "/content/{id}")
	public void updateContent(@PathVariable String id, @RequestBody ContentItemRequest contentitemRequest,@RequestHeader("contentType") String contentType) throws JsonMappingException, JsonProcessingException, Exception  
	{
		ContentItemProcessor processor = new ContentItemProcessor(contentitemRequest);
		processor.setContentType(contentType);
		contentitemService.updateContent(id, processor);
	}

	@DeleteMapping(path = "/content/{id}")
	public ResponseId deleteContent(@PathVariable String id, @RequestHeader("contentType") String contentType) throws JsonMappingException, JsonProcessingException, Exception  {
		return contentitemService.deleteContent(id, contentType);
	}

	@GetMapping(path = "/content/{id}")
	public ContentItemResponse getContent(@PathVariable String id, @RequestHeader("contentType") String contentType) throws Exception  {
		try {
			return contentitemService.getContent(id, contentType);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	@PutMapping(path = "/content/{id}/transcribe")
	public ResponseId transcribe(@PathVariable String id, @RequestBody ContentItemRequest contentitemRequest) {
		return contentitemService.transcribe(id, contentitemRequest);
	}

	@PostMapping(path = "/content/classify")
	public ResponseId createClassificationRequest(@RequestBody ContentItemRequest contentitemRequest) {
		return contentitemService.createClassificationRequest(contentitemRequest);
	}

	@PostMapping(path = "/content")
	public ResponseId createContent(@RequestBody ContentItemRequest contentitemRequest,@RequestHeader("contentType") String contentType) throws JsonMappingException, JsonProcessingException, Exception 
	{
		ContentItemProcessor processor = new ContentItemProcessor(contentitemRequest);
		processor.setContentType(contentType);
		
		return contentitemService.createContent(processor);
	}
	
	@GetMapping(path = "/content")
	public List<ContentItemResponse> getAllQueryContent(@RequestHeader("contentTypeCd") String contentTypeCd, @RequestHeader("actionStatusCd") String actionStatusCd) throws Exception  {
		try {
			return contentitemService.getAllQueryContent(contentTypeCd, actionStatusCd);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	@GetMapping(path = "/content/wiki")
	public List<ContentItemResponse> getAllWikis(@RequestHeader("contentTypeCd") String contentTypeCd, @RequestHeader("contentStatusCd") String contentStatusCd) throws Exception  {
		try {
			return contentitemService.getAllWikis(contentTypeCd, contentStatusCd);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}
	
	@GetMapping(path = "/content/{configId}/{sourceFileKey}")
	public ContentMetaDataResponse getContentByConfigIdAndSourceFileKey(@PathVariable String configId, @PathVariable String sourceFileKey)
			throws Exception {
		return contentitemService.getContentByConfigIdAndSourceFileKey(configId, sourceFileKey);
	}
	
}
