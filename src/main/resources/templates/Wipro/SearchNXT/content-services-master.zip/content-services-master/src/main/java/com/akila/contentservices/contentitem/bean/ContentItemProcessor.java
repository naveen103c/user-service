package com.akila.contentservices.contentitem.bean;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.akila.contentservices.entity.OrgContentMetadata;

public class ContentItemProcessor 
{
	public ContentItemProcessor()
	{
		
	}
	
	public ContentItemProcessor(ContentItemRequest request)
	{
		title = request.getTitle();
		content = request.getContent();
		tagList = request.getTags() == null ? "" : String.join(",", request.getTags());
		tagListArray = request.getTags();
		isPrivate = request.isPrivateContent();
		mediaCd = request.getMediaCd();
		parentContentId = request.getParentContentId();
		rootContentId = request.getRootContentId();
		versionNum = request.getVersionNum();
		contentStatusCd = request.getContentStatusCd();
		publishedTs = new Timestamp(new Date().getTime());
		feedbackTs = new Timestamp(new Date().getTime());
		keyValList = request.getKeyValList();
		contentTypeCd = request.getContentTypeCd();
		communityId = request.getCommunityId();
	    fileList = request.getFileList();
	    taggedUserIds = request.getTaggedUserIds();
	}
	
	public ContentItemProcessor(OrgContentMetadata request)
	{
		title = request.getTitle();
		content = "";
		tagList = request.getTagList() == null ? "" : request.getTagList() ;
		isPrivate = request.getIsPrivate() == null ? false : request.getIsPrivate();
		mediaCd = request.getMediaCd();
		parentContentId = null;
		rootContentId = null;
		versionNum = request.getVersionNum();
		contentStatusCd = request.getContentStatusCd();
		publishedTs = new Timestamp(new Date().getTime());
		feedbackTs = new Timestamp(new Date().getTime());
		keyValList = request.getKeyValList();
		contentTypeCd = request.getContentTypeCd();
		contentId = request.getContentId();
		communityId = request.getCommunityId();
	}
	
	public ContentItemProcessor(ContentItemRequest request, String contentId)
	{
		
	}
	
	private String title;
	private String content;
	private String strippedContent;
	private String tagList;
	private boolean isPrivate;
	private String contentId;
	private String versionId;
	private String strippedVersionId;
	private String formatType;
	private String contentType;
	private int contentStatusCd;
	private int contentTypeCd;
	private String createdByUserId;
	private String fileHash;
	private String parentContentId;
	private String rootContentId;
	private int mediaCd;
	private String mediaType;
	private int versionNum;
	private String author;
	private Timestamp publishedTs;
	private String userId;
	private Timestamp feedbackTs;
	private String[] tagListArray;
	private String keyValList;
	private String communityId;
	private Integer actionStatusCd;
	private List<String> fileList;
	private String confId;
	private Timestamp crtTs;
	private Timestamp modTs;
	private List<String> taggedUserIds;
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getStrippedContent() {
		return strippedContent;
	}

	public void setStrippedContent(String strippedContent) {
		this.strippedContent = strippedContent;
	}

	public String getTagList() {
		return tagList;
	}

	public void setTagList(String tagList) {
		this.tagList = tagList;
	}

	public boolean getIsPrivate() {
		return isPrivate;
	}

	public void setIsPrivate(boolean isPrivate) {
		this.isPrivate = isPrivate;
	}

	public int getContentTypeCd() {
		return contentTypeCd;
	}

	public void setContentTypeCd(int contentTypeCd) {
		this.contentTypeCd = contentTypeCd;
	}

	public String getCreatedByUserId() {
		return createdByUserId;
	}

	public void setCreatedByUserId(String createdByUserId) {
		this.createdByUserId = createdByUserId;
		this.userId = createdByUserId;
	}

	public String getFileHash() {
		return fileHash;
	}

	public void setFileHash(String fileHash) {
		this.fileHash = fileHash;
	}

	public String getVersionId() {
		return versionId;
	}

	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}

	public String getFormatType() {
		return formatType;
	}

	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getStrippedVersionId() {
		return strippedVersionId;
	}

	public void setStrippedVersionId(String strippedVersionId) {
		this.strippedVersionId = strippedVersionId;
	}

	public int getContentStatusCd() {
		return contentStatusCd;
	}

	public void setContentStatusCd(int contentStatusCd) {
		this.contentStatusCd = contentStatusCd;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getParentContentId() {
		return parentContentId;
	}

	public void setParentContentId(String parentContentId) {
		this.parentContentId = parentContentId;
	}

	public String getRootContentId() {
		return rootContentId;
	}

	public void setRootContentId(String rootContentId) {
		this.rootContentId = rootContentId;
	}

	public int getMediaCd() {
		return mediaCd;
	}

	public void setMediaCd(int mediaCd) {
		this.mediaCd = mediaCd;
		if(mediaCd == 103)
		{
			mediaType = "html";
		}
		else if(mediaCd == 104)
		{
			mediaType = "text";
		}
		else if(mediaCd == 105)
		{
			mediaType = "pdf";
		}
	}

	public String getMediaType() {
		return mediaType;
	}

	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}

	public int getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public Timestamp getPublishedTs() {
		return publishedTs;
	}

	public void setPublishedTs(Timestamp publishedTs) {
		this.publishedTs = publishedTs;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Timestamp getFeedbackTs() {
		return feedbackTs;
	}

	public void setFeedbackTs(Timestamp feedbackTs) {
		this.feedbackTs = feedbackTs;
	}

	public String[] getTagListArray() 
	{
		List<String> list = new ArrayList<String>(Arrays.asList(tagListArray));
		list.removeAll(Collections.singleton(null));
		list.removeAll(Collections.singleton(""));
		return list.toArray(new String[list.size()]);
	}

	public void setTagListArray(String[] tagListArray) {
		this.tagListArray = tagListArray;
	}

	public String getKeyValList() {
		return keyValList;
	}

	public void setKeyValList(String keyValList) {
		this.keyValList = keyValList;
	}

	public String getCommunityId() {
		return communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public Integer getActionStatusCd() {
		return actionStatusCd;
	}

	public void setActionStatusCd(Integer actionStatusCd) {
		this.actionStatusCd = actionStatusCd;
	}

	public List<String> getFileList() {
		return fileList;
	}

	public void setFileList(List<String> fileList) {
		this.fileList = fileList;
	}

	public String getConfId() {
		return confId;
	}

	public void setConfId(String confId) {
		this.confId = confId;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public Timestamp getModTs() {
		return modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public List<String> getTaggedUserIds() {
		if(taggedUserIds == null) {
			taggedUserIds = new ArrayList<>();
		}
		return taggedUserIds;
	}

	public void setTaggedUserIds(List<String> taggedUserIds) {
		this.taggedUserIds = taggedUserIds;
	}

}
