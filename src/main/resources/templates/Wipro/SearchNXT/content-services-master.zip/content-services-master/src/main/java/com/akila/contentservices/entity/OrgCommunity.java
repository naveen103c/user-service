package com.akila.contentservices.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.akila.AkilaEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * The persistent class for the org_communities database table.
 * 
 */
@Entity
@Table(name="org_communities")
@NamedQuery(name="OrgCommunity.findAll", query="SELECT o FROM OrgCommunity o")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class OrgCommunity extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="community_id")
	private String communityId;

	@Column(name="community_nm")
	private String communityNm;

	@Column(name="community_owner")
	private String communityOwner;

	@Column(name="parent_community_nm")
	private String parentCommunityNm;
	
	@Column(name="config_id")
	private String configId;

	//bi-directional many-to-one association to OrgCommunitySme
	@OneToMany(fetch=FetchType.EAGER)
	@JoinColumn(name = "community_id", insertable = false, updatable = false)
	private List<OrgCommunitySme> orgCommunitySmes;

	public OrgCommunity() {
	}

	public String getCommunityId() {
		return this.communityId;
	}

	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}

	public String getCommunityNm() {
		return this.communityNm;
	}

	public void setCommunityNm(String communityNm) {
		this.communityNm = communityNm;
	}

	public String getCommunityOwner() {
		return this.communityOwner;
	}

	public void setCommunityOwner(String communityOwner) {
		this.communityOwner = communityOwner;
	}

	public String getParentCommunityNm() {
		return this.parentCommunityNm;
	}

	public void setParentCommunityNm(String parentCommunityNm) {
		this.parentCommunityNm = parentCommunityNm;
	}

	public List<OrgCommunitySme> getOrgCommunitySmes() {
		return this.orgCommunitySmes;
	}

	public void setOrgCommunitySmes(List<OrgCommunitySme> orgCommunitySmes) {
		this.orgCommunitySmes = orgCommunitySmes;
	}

	public String getConfigId() {
		return configId;
	}

	public void setConfigId(String configId) {
		this.configId = configId;
	}
	
}