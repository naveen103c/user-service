package com.akila.contentservices.contentitem.bean;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ContentIndexRequest 
{
	@JsonProperty("author")
	private String author;

	@JsonProperty("content_status_cd")
	@JsonIgnore
	private Integer contentStatusCd;

	@JsonProperty("content_type")
	private String contentType;

	@JsonIgnore
	@JsonProperty("created_by_user_id")
	private String createdByUserId;

	@JsonProperty("created_date")
	private Timestamp crtTs;

	@JsonIgnore
	@JsonProperty("file_hash")
	private String fileHash;

	@JsonProperty("file_name")
	private String fileNm;

	@JsonProperty("is_private")
	private Boolean isPrivate;

	@JsonProperty("job_id")
	private String jobId;

	@JsonIgnore
	@JsonProperty("key_val_list")
	private String keyValList;

	
	@JsonProperty("media_type")
	private String mediaType;

	@JsonProperty("modification_date")
	private Timestamp modTs;

	@JsonProperty("published_date")
	private Timestamp publishedTs;

//	@JsonProperty("tag_list")
	private Map<String, List<String>> tagsMap = new HashMap<>();

	private String title;

	@JsonProperty("version")
	private Integer versionNum;

	@JsonProperty("org_id")
	private String orgId;

	@JsonProperty("content_id")
	private String contentId;
	
	@JsonIgnore
	@JsonProperty("sys_version_num")
	private String sysVersionNum;
	
	private String content;
	
	@JsonProperty("page_link")
	private String pageLink;
	
	@JsonProperty("parent_content_id")
	private String parentContentId;
	
	@JsonProperty("conf_id")
	private String confId;
	
	@JsonProperty("source_type")
	private String sourceType;
	
	@JsonProperty("media_start_time")
	private String mediaStartTime;
	

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@JsonIgnore
	public Integer getContentStatusCd() {
		return contentStatusCd;
	}

	public void setContentStatusCd(Integer contentStatusCd) {
		this.contentStatusCd = contentStatusCd;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	@JsonIgnore
	public String getCreatedByUserId() {
		return createdByUserId;
	}

	public void setCreatedByUserId(String createdByUserId) {
		this.createdByUserId = createdByUserId;
	}

	public String getCrtTs() {
		if(crtTs == null)
		{
			crtTs = new Timestamp(new Date().getTime());
		}
		SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
		return df.format(crtTs);
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	@JsonIgnore
	public String getFileHash() {
		if(fileHash == null)
		{
			fileHash = "";
		}
		return fileHash;
	}

	public void setFileHash(String fileHash) {
		this.fileHash = fileHash;
	}

	public String getFileNm() 
	{
		if(fileNm == null)
		{
			fileNm = "";
		}
		return fileNm;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public Boolean getIsPrivate() 
	{
		return isPrivate;
	}

	public void setIsPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}

	public String getJobId() {
		if(jobId == null)
		{
			jobId = "";
		}
		return jobId;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	@JsonIgnore
	public String getKeyValList() 
	{
		if(keyValList == null)
		{
			keyValList = "";
		}
		return keyValList;
	}

	public void setKeyValList(String keyValList) {
		this.keyValList = keyValList;
	}

	public String getMediaType() 
	{
		if(mediaType == null)
		{
			mediaType = "";
		}
		return mediaType;
	}

	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}

	public String getModTs() {
		if(modTs == null)
		{
			modTs = new Timestamp(new Date().getTime());
		}
		SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
		return df.format(modTs);
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public String getPublishedTs() {
		if(publishedTs == null)
		{
			publishedTs = new Timestamp(new Date().getTime());
		}
		SimpleDateFormat df = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
		return df.format(publishedTs);
	}

	public void setPublishedTs(Timestamp publishedTs) {
		this.publishedTs = publishedTs;
	}
	
	@JsonAnyGetter
	public Map<String, List<String>> getTagsMap() {
		if(tagsMap == null)
		{
			return new HashMap<String, List<String>>();
		}
		return tagsMap;
	}
	
	@JsonAnySetter
	public void setTagsMap(Map<String, List<String>> tagsMap) {
		this.tagsMap = tagsMap;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getVersionNum() {
		return versionNum;
	}

	public void setVersionNum(Integer versionNum) {
		this.versionNum = versionNum;
	}

	public String getOrgId() 
	{
		if(orgId == null)
		{
			orgId = "123";
		}
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	@JsonIgnore
	public String getSysVersionNum() 
	{
		if(sysVersionNum == null)
		{
			return "";
		}
		return sysVersionNum;
	}

	public void setSysVersionNum(String sysVersionNum) {
		this.sysVersionNum = sysVersionNum;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPageLink() {
		return pageLink == null ? "" : pageLink;
	}

	public void setPageLink(String pageLink) {
		this.pageLink = pageLink;
	}

	public String getParentContentId() {
		return parentContentId == null? "" : parentContentId;
	}

	public void setParentContentId(String parentContentId) {
		this.parentContentId = parentContentId;
	}

	public String getConfId() {
		return confId == null ? "" : confId;
	}

	public void setConfId(String confId) {
		this.confId = confId;
	}

	public String getSourceType() {
		return sourceType == null ? "" : sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getMediaStartTime() {
		return mediaStartTime == null ? "" : mediaStartTime;
	}

	public void setMediaStartTime(String mediaStartTime) {
		this.mediaStartTime = mediaStartTime;
	}
	
}
