package com.akila.contentservices.utility;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.akila.commons.email.sender.EmailGraphClient;
import com.akila.contentservices.entity.OrgCommunity;
import com.akila.contentservices.entity.OrgCommunitySme;
import com.akila.contentservices.entity.OrgContentMetadata;
import com.akila.contentservices.entity.OrgContentRelationship;
import com.akila.contentservices.entity.OrgEmailTemplate;
import com.akila.contentservices.entity.OrgUser;
import com.akila.contentservices.repository.OrgCommunityRepository;
import com.akila.contentservices.repository.OrgCommunitySmeRepository;
import com.akila.contentservices.repository.OrgContentMetadataRepository;
import com.akila.contentservices.repository.OrgContentRelationshipRepository;
import com.akila.contentservices.repository.OrgEmailTemplateRepository;
import com.akila.contentservices.repository.OrgUserRepository;
import com.akilacommons.tenant.DataSourceProperties;

@Configuration
@EnableScheduling
public class MailUtility extends EmailGraphClient {

	private static final Logger logger = LogManager.getLogger(MailUtility.class);

	@Autowired
	private EmailGraphClient emailGraphClient;

	@Autowired
	private OrgContentMetadataRepository orgContentMetadataRepository;

	@Autowired
	OrgEmailTemplateRepository orgEmailTemplateRepository;

	@Value("${contentType.query}")
	private String contentTypeCd;

	@Value("${contentType.followup}")
	private int contentTypeFollowup;

	@Value("${contentType.response}")
	private int contentTypeResponse;

	@Value("${contentType.response.pending}")
	private int contentTypeResponsePending;

	@Value("${user.content.url}")
	private String userContentUrl;

	@Value("${ask.page.url}")
	private String askPageUrl;
	
	@Value("${mail.notification.enable}")
	private Boolean isNotificationEnable;
	
	@Value("${mail.notification.schedular.enable}")
	private Boolean isMailSchedularEnable;
	
	@Value("${microsoft.ad.emailId}")
	private String microsoftAdEmailId;

	@Autowired
	private OrgCommunitySmeRepository orgCommunitySmeRepository;

	@Autowired
	private OrgUserRepository orgUserRepository;

	@Autowired
	OrgCommunityRepository orgCommunityRepository;
	
	@Autowired
	DataSourceProperties dataSourceProperties;
	
	@Autowired
	OrgContentRelationshipRepository orgContentRelationshipRepository;
	
	@Autowired
	UserPrefUtility userPrefUtility;

	@Value("${tagged.user.type.code}")
	int taggedUserTypeCd;

	public void sendSMEEmail(String communityName, List<String> smeEmail) {

		SimpleMailMessage msg = new SimpleMailMessage();
		List<String> toEmailList = new ArrayList<String>();
		List<String> ccEmailList = new ArrayList<String>();
		toEmailList.add(microsoftAdEmailId);
		getTemplate(null, msg, Integer.valueOf(contentTypeResponsePending), communityName, null);
//		toEmailList.add(smeEmail);
//		if (smeSecEmail != null && smeSecEmail.isEmpty()) {
//			toEmailList.add(smeSecEmail);
//		}
		sendMail(msg,toEmailList, ccEmailList, smeEmail);
	}

	public void sendEmail(String contentId, int contentTypeCd, String currentUserId, List<String> taggedUserIds) {

		if (isNotificationEnable) {
			logger.info("MailUtility -> sendEmail(contentId,contentTypeCd) - contentId->" + contentId+" , contentTypeCd->" + contentTypeCd);
			OrgContentMetadata orgContentMetadata = orgContentMetadataRepository.findByContentId(contentId);
			OrgContentMetadata rootOrgContentMetadata = null;
			SimpleMailMessage msg = new SimpleMailMessage();
			List<String> toEmailList = new ArrayList<String>();
			List<String> ccEmailList = new ArrayList<String>();
            OrgUser orgUser = orgUserRepository.findByUserId(orgContentMetadata.getAuthor());
			
			if (orgContentMetadata != null) {

				String communityId = orgContentMetadata.getCommunityId();
				if (contentTypeCd == Integer.valueOf(contentTypeResponse)
						|| contentTypeCd == Integer.valueOf(contentTypeFollowup)) {

					rootOrgContentMetadata = getRootContent(orgContentMetadata);
					communityId = rootOrgContentMetadata.getCommunityId();
				}

				OrgCommunity orgCommunity = orgCommunityRepository.findByCommunityId(communityId);

				// For REsponse and FollowUp
				if (contentTypeCd == Integer.valueOf(contentTypeResponse)
						|| contentTypeCd == Integer.valueOf(contentTypeFollowup)) {

					getTemplate(rootOrgContentMetadata, msg, contentTypeCd, orgCommunity.getCommunityNm(), null);
					toEmailList = getMailTOList(rootOrgContentMetadata, currentUserId, contentTypeCd, taggedUserIds);
					ccEmailList = getMailCCList(orgContentMetadata, taggedUserIds);
				}
				// For Query
				else if (contentTypeCd == Integer.valueOf(contentTypeCd)) {

					getTemplate(orgContentMetadata, msg, contentTypeCd, orgCommunity.getCommunityNm(), null);
					toEmailList = getMailTOList(orgContentMetadata,currentUserId, contentTypeCd, taggedUserIds);
					ccEmailList = getMailCCList(orgContentMetadata, taggedUserIds);
				}
				if(toEmailList.size() > 0) {
				sendMail(msg, toEmailList, ccEmailList,null);
				}
				if(taggedUserIds != null && taggedUserIds.size() > 0) {
					List<String> notificationEnabledUserList = userPrefUtility.getMailFilterUserList(taggedUserIds, taggedUserTypeCd);
					List<OrgUser> orgUsers = orgUserRepository.findByUserIdIn(notificationEnabledUserList);
					List<String> taggedUserMailIds = new ArrayList<String>();
					if(orgUsers != null && orgUsers.size() > 0) {
					orgUsers.forEach(user -> {
						taggedUserMailIds.add(user.getUsrEmail());	
					});
					if (contentTypeCd == Integer.valueOf(contentTypeResponse)
							|| contentTypeCd == Integer.valueOf(contentTypeFollowup)) {
						taggedUserIds.remove(rootOrgContentMetadata.getAuthor());
						getTemplate(rootOrgContentMetadata, msg, contentTypeCd, orgCommunity.getCommunityNm(), orgUser.getUserFirstNm());
					}
					else if (contentTypeCd == Integer.valueOf(contentTypeCd)) {
						getTemplate(orgContentMetadata, msg, contentTypeCd, orgCommunity.getCommunityNm(), orgUser.getUserFirstNm());
					}
					sendMail(msg, taggedUserMailIds, new ArrayList<String>() ,null);
					logger.info("email sent to the tagged users");
				  }
					
				}
			}
		}
	}
	
	private void sendMail(SimpleMailMessage msg, List<String> toEmailList, List<String> ccEmailList, List<String> bccEmailList) {
		try {
			logger.info("Trying to send Email to : " + toEmailList + "  and EmailCc to : " + ccEmailList);
			emailGraphClient.sendEmail(msg.getText(), msg.getSubject(), toEmailList, ccEmailList, bccEmailList, null);
		} catch (Exception e) {
			logger.error("MailUtility sendEmail-" + e);
		}
	}

	private OrgContentMetadata getRootContent(OrgContentMetadata orgContentMetadata) {

		OrgContentRelationship orgContentRelationship = orgContentRelationshipRepository
				.findBycontentId(orgContentMetadata.getContentId());
		if (orgContentRelationship != null) {
			return orgContentMetadataRepository.findByContentId(orgContentRelationship.getRootContentId());
		}
		return orgContentMetadata;
	}

	private List<String> getMailTOList(OrgContentMetadata orgContentMetadata, String currentUserId, int contentTypeCd, List<String> taggedUserIds) {
		logger.info("MailUtility -> getMailTOList() - Fetching smeList for Comm Id - "
				+ orgContentMetadata.getCommunityId());
		List<OrgCommunitySme> smeList = orgCommunitySmeRepository
				.findByIdCommunityId(orgContentMetadata.getCommunityId());		
		logger.info("MailUtility -> getMailTOList() - Fetched smeList - " + smeList);

		//If SME is deactivated then remove the SME from smeList
		smeList.removeIf(sme -> sme.getUser().getIsActive() == false);
		
		List<String> toEmailList = new ArrayList<String>();
		List<String> filterUser = new ArrayList<String>();
		for (OrgCommunitySme sme : smeList) {
			if ((sme.getUser().getUserId()).equals(currentUserId)) {
				filterUser.add(orgContentMetadata.getAuthor());
			} else
				filterUser.add(sme.getUser().getUserId());
		}
        filterUser.removeAll(taggedUserIds);
		logger.info("MailUtility -> getMailTOList() - Before Filteration - " + filterUser);
		filterUser = userPrefUtility.getMailFilterUserList(filterUser, contentTypeCd);
		logger.info("MailUtility -> getMailTOList() - After Filteration - " + filterUser);
		
		if (filterUser.contains(orgContentMetadata.getAuthor())) {
			OrgUser orgUser = orgUserRepository.findByUserId(orgContentMetadata.getAuthor());
			toEmailList.add(orgUser.getUsrEmail());
			if (orgUser.getUsrSecEmail() != null && !orgUser.getUsrSecEmail().isEmpty()) {
				toEmailList.add(orgUser.getUsrSecEmail());
			}
		}
		for (OrgCommunitySme sme : smeList) {
			if (filterUser.contains(sme.getUser().getUserId())) {
				toEmailList.add(sme.getUser().getUsrEmail());
				if (sme.getUser().getUsrSecEmail() != null && !sme.getUser().getUsrSecEmail().isEmpty()) {
					toEmailList.add(sme.getUser().getUsrSecEmail());
				}
			}
		}
		return toEmailList;
	}

	private List<String> getMailCCList(OrgContentMetadata orgContentMetadata, List<String> taggedUserIds ) {

		List<String> ccEmailList = new ArrayList<String>();
		List<String> filterUser = new ArrayList<String>();
		filterUser.add(orgContentMetadata.getAuthor());
		
		logger.info("MailUtility -> getMailCCList() - Before Filteration - " + filterUser);
		filterUser = userPrefUtility.getMailFilterUserList(filterUser, orgContentMetadata.getContentTypeCd());
		logger.info("MailUtility -> getMailCCList() - After Filteration - " + filterUser);
		
		if (filterUser.contains(orgContentMetadata.getAuthor())) {
			OrgUser orgUser = orgUserRepository.findByUserId(orgContentMetadata.getAuthor());
			ccEmailList.add(orgUser.getUsrEmail());
			if (orgUser.getUsrSecEmail() != null && !orgUser.getUsrSecEmail().isEmpty()) {
				ccEmailList.add(orgUser.getUsrSecEmail());
			}
		}
		return ccEmailList;
	}

	private void getTemplate(OrgContentMetadata orgContentMetadata, SimpleMailMessage msg, int contentType,
			String communityName, String taggedBy) {

		String templateName = null;

		if (contentType == Integer.valueOf(contentTypeCd) && taggedBy == null) {
			templateName = "CREATE_QUERY";
		}else if (contentType == Integer.valueOf(contentTypeFollowup) && taggedBy == null) {
			templateName = "CREATE_FOLLOW_UP";
		} else if (contentType == Integer.valueOf(contentTypeResponse) && taggedBy == null) {
			templateName = "CREATE_RESPONSE";
		} else if(contentType == Integer.valueOf(contentTypeCd) && taggedBy != null) {
			templateName = "TAGGED_USER_QUERY";
		}else if(contentType == Integer.valueOf(contentTypeFollowup) && taggedBy != null) {
			templateName = "TAGGED_USER_FOLLOW_UP";
		}else if(contentType == Integer.valueOf(contentTypeResponse) && taggedBy != null) {
			templateName = "TAGGED_USER_RESPONSE";
		}

		OrgEmailTemplate orgEmailTemplate = orgEmailTemplateRepository.findByName(templateName);

		if (orgEmailTemplate != null) {
			String taggedByUser = taggedBy != null && !taggedBy.isEmpty() ? taggedBy : null;
			createEmailMessageData(orgContentMetadata, msg, communityName, orgEmailTemplate, taggedByUser);
		} 
	}

	private void createEmailMessageData(OrgContentMetadata orgContentMetadata, SimpleMailMessage msg,
			String communityName, OrgEmailTemplate orgEmailTemplate, String taggedByUser) {
		msg.setSubject(orgEmailTemplate.getSubject().replaceAll("&TITLE&", orgContentMetadata.getTitle()));
		msg.setSubject(msg.getSubject().replaceAll("&COMMUNITY_NAME&", communityName));
		msg.setText(orgEmailTemplate.getTemplate().replaceAll("&LINK&",
				askPageUrl + orgContentMetadata.getContentId()));
		if(taggedByUser != null && !taggedByUser.isEmpty()) {
		    msg.setText(msg.getText().replaceAll("&USER&", taggedByUser));
		}
		
	}

}
