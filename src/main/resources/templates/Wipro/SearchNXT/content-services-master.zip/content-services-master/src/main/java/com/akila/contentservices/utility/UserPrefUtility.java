package com.akila.contentservices.utility;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.contentservices.entity.BaseUserPref;
import com.akila.contentservices.entity.OrgUserPref;
import com.akila.contentservices.repository.BaseUserPrefRepository;
import com.akila.contentservices.repository.OrgUserPrefRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class UserPrefUtility extends AkilaService {
	private static final Logger logger = LogManager.getLogger(UserPrefUtility.class);

	@Autowired
	private OrgUserPrefRepository orgUserPrefRepository;
	@Autowired
	private BaseUserPrefRepository baseUserPrefRepository;
	@Value("${user.mail.notification.ans}")
	private String userMailNotificationAns;

	public List<String> getMailFilterUserList(List<String> userList, int contentTypeCd) {
		logger.info("UserPrefUtility -> getMailFilterUserList() for contentTypeCd-" + contentTypeCd
				+ " and for UserList- " + userList);
		List<BaseUserPref> baseUserPrefList = baseUserPrefRepository
				.findByPrefTypeCd(Constants.MAIL_NOTIFICATION_PREF_CD);
		
		List<String> validUserList = new ArrayList<String>();
		
		if (baseUserPrefList != null) {
			BaseUserPref parentPref = null;
			BaseUserPref childPref = null;

			Boolean parentAns = false;
			String childAns = "";

			for (BaseUserPref baseUserPref : baseUserPrefList) {
				if (baseUserPref.getParentPrefId() == null) {
					parentPref = baseUserPref;
				} else {
					childPref = baseUserPref;
				}
			}

			for (String userId : userList) {
				Boolean isValidUser = Boolean.valueOf(parentPref.getPrefDefault());				
				OrgUserPref orgUserPref = orgUserPrefRepository.findByUserIdAndIdPrefTypeCd(userId,
						Constants.MAIL_NOTIFICATION_PREF_CD);

				if (orgUserPref != null) {
					List<PersonalPreferenceJson> personalPrefList = getPrefObject(
							orgUserPref.getPersonalPreferenceJson());
					for (PersonalPreferenceJson personalPref : personalPrefList) {
						if (personalPref.getPrefId().equals(parentPref.getId())) {
							parentAns = Boolean.valueOf(personalPref.getAns());
							if (parentAns) {
								for (PersonalPreferenceJsonChild personalPreferenceJsonChild : personalPref
										.getChildren()) {
									if (personalPreferenceJsonChild.getPrefId().equals(childPref.getId())) {
										childAns = personalPreferenceJsonChild.getAns();
									}
								}
							}
							break;
						}
					}
					if (parentAns && !childAns.isEmpty()) {
						isValidUser = getUserChildAns(contentTypeCd, childAns);
					} else {
						isValidUser = false;
					}
				} 
				if(isValidUser) {
					validUserList.add(userId);
				}
			}
		}

		return validUserList;
	}

	// Convert user Answer JSON into List<PersonalPreferenceJson>
	private List<PersonalPreferenceJson> getPrefObject(String personalPref) {
		ObjectMapper objectMapper = new ObjectMapper();
		List<PersonalPreferenceJson> readValue = null;
		try {
			readValue = objectMapper.readValue(personalPref,
					objectMapper.getTypeFactory().constructCollectionType(List.class, PersonalPreferenceJson.class));
		} catch (JsonProcessingException e) {
			logger.error(e.getMessage(), e);
		}
		return readValue;
	}

	// Return Boolean on the basis of user Answer and contentTypeCd
	private Boolean getUserChildAns(int contentTypeCd, String userAns) {

		String childList[] = userMailNotificationAns.split(",");
		for (String child : childList) {
			if (Integer.valueOf(child.split("-")[0]) == contentTypeCd) {
				String userAnsList[] = userAns.split(",");
				for (String ans : userAnsList) {
					if (ans.equalsIgnoreCase(child.split("-")[1])) {
						return true;
					}
				}
				break;
			}
		}
		return false;
	}

}
