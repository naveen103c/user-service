package com.akila.contentservices.entity;

import com.akila.AkilaEntity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the org_user_fav_link database table.
 * 
 */
@Entity
@Table(name="org_user_fav_link")
@NamedQuery(name="OrgUserFavLink.findAll", query="SELECT o FROM OrgUserFavLink o")
public class OrgUserFavLink implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgUserFavLinkPK id;

	@Column(name="content_type_cd")
	private Integer contentTypeCd;

	@Column(name="crt_ts")
	private Timestamp crtTs;

	@Column(name="media_cd")
	private Integer mediaCd;

	private String title;

	private String url;

	public OrgUserFavLink() {
	}

	public OrgUserFavLinkPK getId() {
		return this.id;
	}

	public void setId(OrgUserFavLinkPK id) {
		this.id = id;
	}

	public Integer getContentTypeCd() {
		return this.contentTypeCd;
	}

	public void setContentTypeCd(Integer contentTypeCd) {
		this.contentTypeCd = contentTypeCd;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public Integer getMediaCd() {
		return this.mediaCd;
	}

	public void setMediaCd(Integer mediaCd) {
		this.mediaCd = mediaCd;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

}