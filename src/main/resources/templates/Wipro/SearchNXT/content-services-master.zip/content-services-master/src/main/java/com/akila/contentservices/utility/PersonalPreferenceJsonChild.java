package com.akila.contentservices.utility;

import java.io.Serializable;

public class PersonalPreferenceJsonChild implements Serializable {
	private static final long serialVersionUID = 1L;

	private String prefId;
	private String ans;

	public PersonalPreferenceJsonChild(String prefId, String ans) {
		super();
		this.prefId = prefId;
		this.ans = ans;
	}

	public PersonalPreferenceJsonChild() {
	}

	public String getPrefId() {
		return prefId;
	}

	public void setPrefId(String prefId) {
		this.prefId = prefId;
	}

	public String getAns() {
		return ans;
	}

	public void setAns(String ans) {
		this.ans = ans;
	}

}