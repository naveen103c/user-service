package com.akila.contentservices.contentitem.bean;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.akila.contentservices.entity.OrgContentMetadata;

@Mapper(
    componentModel = "spring"
)
public interface ContentMetaDataMapper {
  ContentItemMapper INSTANCE = Mappers.getMapper(ContentItemMapper.class);
  ;

  @Mappings({
	  @Mapping(source = "contentId", target = "id")
  })
  ContentMetaDataResponse orgContentMetadataToContentitemResponse(
      OrgContentMetadata orgContentMetadata);

}
