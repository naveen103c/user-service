package com.akila.contentservices.utility;

import java.io.Serializable;
import java.util.List;

public class PersonalPreferenceJson  implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String prefId;
	private String ans;
	private List<PersonalPreferenceJsonChild> children;
	public String getPrefId() {
		return prefId;
	}
	public void setPrefId(String prefId) {
		this.prefId = prefId;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	public PersonalPreferenceJson() {
		super();
	}
	public PersonalPreferenceJson(String prefId, String ans) {
		super();
		this.prefId = prefId;
		this.ans = ans;
	}
	
	public List<PersonalPreferenceJsonChild> getChildren() {
		return children;
	}
	public void setChildren(List<PersonalPreferenceJsonChild> children) {
		this.children = children;
	}
	public PersonalPreferenceJson(String prefId, String ans, List<PersonalPreferenceJsonChild> children) {
		super();
		this.prefId = prefId;
		this.ans = ans;
		this.children = children;
	}
	
	
}
