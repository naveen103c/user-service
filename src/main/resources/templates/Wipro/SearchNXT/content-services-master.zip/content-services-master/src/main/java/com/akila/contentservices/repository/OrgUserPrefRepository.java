package com.akila.contentservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgUserPref;
import com.akila.contentservices.entity.OrgUserPrefPK;

@Repository
public interface OrgUserPrefRepository extends JpaRepository<OrgUserPref, OrgUserPrefPK> {

	OrgUserPref findByUserIdAndIdPrefTypeCd(String userId,Integer prefTypeCd);
}
