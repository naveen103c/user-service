package com.akila.contentservices.utility;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.akila.AkilaService;
import com.akila.contentservices.entity.OrgCommunity;
import com.akila.contentservices.entity.OrgCommunitySme;
import com.akila.contentservices.entity.OrgContentMetadata;
import com.akila.contentservices.entity.OrgContentRelationship;
import com.akila.contentservices.entity.OrgNotification;
import com.akila.contentservices.entity.OrgUser;
import com.akila.contentservices.repository.OrgCommunityRepository;
import com.akila.contentservices.repository.OrgCommunitySmeRepository;
import com.akila.contentservices.repository.OrgContentMetadataRepository;
import com.akila.contentservices.repository.OrgContentRelationshipRepository;
import com.akila.contentservices.repository.OrgNotificationRepository;
import com.akila.contentservices.repository.OrgNotificationTemplateRepository;
import com.akila.contentservices.repository.OrgUserRepository;
import com.akilacommons.tenant.DataSourceProperties;

@Service
public class NotificationUtility extends AkilaService {

	private static final Logger logger = LogManager.getLogger(NotificationUtility.class);

	@Autowired
	private OrgContentMetadataRepository orgContentMetadataRepository;

	@Autowired
	OrgNotificationTemplateRepository orgNotificationTemplateRepository;

	@Value("${contentType.query}")
	private int contentTypeQuery;

	@Value("${contentType.followup}")
	private int contentTypeFollowup;

	@Value("${contentType.response}")
	private int contentTypeResponse;

	@Value("${contentType.response.pending}")
	private int contentTypeResponsePending;

	@Value("${user.content.url}")
	private String userContentUrl;

	@Value("${notification.ask.page.url}")
	private String notificationAskPageUrl;

	@Value("${mail.notification.enable}")
	private Boolean isNotificationEnable;

	@Value("${notification.type.worklist}")
	private int notificationTypeWorklist;

	@Value("${notification.type.ask}")
	private int notificationTypeAsk;

	@Autowired
	private OrgCommunitySmeRepository orgCommunitySmeRepository;

	@Autowired
	OrgCommunityRepository orgCommunityRepository;

	@Autowired
	DataSourceProperties dataSourceProperties;

	@Autowired
	OrgContentRelationshipRepository orgContentRelationshipRepository;

	@Autowired
	private OrgNotificationRepository orgNotificationRepository;
	
	@Value("${user.query.submit.notification}")
	private String userQuerySubmitNotification;
	
	@Value("${user.query.response.notification}")
	private String userQueryResponseNotification;

	@Value("${user.query.edit.notification}")
	private String userQueryEditNotification;

	@Value("${worklist.query.submit.notification}")
	private String worklistQuerySubmitNotification;
	
	@Value("${worklist.query.response.notification}")
	private String worklistQueryResponseNotification;

	@Value("${worklist.query.edit.notification}")
	private String worklistQueryEditNotification;	
	
	@Value("${user.query.followup.notification}")
	private String userQueryFollowupNotification;
	
	@Value("${worklist.query.followup.notification}")
	private String worklistQueryFollowupNotification;
	
	@Value("${tagged.user.query.submit.notification}")
	private String taggedUserQuerySubmitNotification;
	
	@Value("${tagged.user.query.response.notification}")
	private String taggedUserQueryResponseNotification;
	
	@Value("${tagged.user.query.followup.notification}")
	private String taggedUserQueryFollowupNotification;
	
	@Autowired
	private OrgUserRepository orgUserRepository;

	public void createNotification(String contentId, int contentTypeCd, String opertionType, List<String> taggedUserIds) {
		if (isNotificationEnable) {
			logger.info(
					"NotificationUtility:createNotification - Notification is enabled and we are starting the notifiaction creation process");
			OrgContentMetadata orgContentMetadata = orgContentMetadataRepository.findByContentId(contentId);
			OrgContentMetadata rootOrgContentMetadata = null;
			if (orgContentMetadata != null) {
				 OrgUser orgUser = orgUserRepository.findByUserId(orgContentMetadata.getAuthor());
				String communityId = orgContentMetadata.getCommunityId();
				if (contentTypeCd == Integer.valueOf(contentTypeResponse)
						|| contentTypeCd == Integer.valueOf(contentTypeFollowup)) {
					rootOrgContentMetadata = getRootContent(orgContentMetadata);
					communityId = rootOrgContentMetadata.getCommunityId();
					OrgCommunity orgCommunity = orgCommunityRepository.findByCommunityId(communityId);
					createUserNotification(rootOrgContentMetadata, contentTypeCd, orgCommunity.getCommunityNm(),
							getUserListToCreateNotification(rootOrgContentMetadata, taggedUserIds), opertionType, taggedUserIds, orgUser.getUserFirstNm());
				} else {
					OrgCommunity orgCommunity = orgCommunityRepository.findByCommunityId(communityId);
					createUserNotification(orgContentMetadata, contentTypeCd, orgCommunity.getCommunityNm(),
							getUserListToCreateNotification(orgContentMetadata, taggedUserIds), opertionType, taggedUserIds, orgUser.getUserFirstNm());
				}
			}
		}
	}

	private OrgContentMetadata getRootContent(OrgContentMetadata orgContentMetadata) {

		OrgContentRelationship orgContentRelationship = orgContentRelationshipRepository
				.findBycontentId(orgContentMetadata.getContentId());
		if (orgContentRelationship != null) {
			return orgContentMetadataRepository.findByContentId(orgContentRelationship.getRootContentId());
		}
		return orgContentMetadata;
	}

	private List<String> getUserListToCreateNotification(OrgContentMetadata orgContentMetadata, List<String> taggedUserIds) {
		List<OrgCommunitySme> smeList = orgCommunitySmeRepository
				.findByIdCommunityId(orgContentMetadata.getCommunityId());
		//If SME is deactivated then remove the SME from smeList
		smeList.removeIf(sme -> sme.getUser().getIsActive() == false);
		List<String> userIdList = new ArrayList<String>();
		if(smeList != null && smeList.size() > 0) {
			
			for (OrgCommunitySme sme : smeList) {
				if(orgContentMetadata.getAuthor().equalsIgnoreCase(sme.getUser().getUserId()))
					continue;
				userIdList.add(sme.getUser().getUserId());
			}
		}
		if(taggedUserIds.size() > 0) {
			userIdList.removeAll(taggedUserIds);
		}
		return userIdList;
	}

	private void createUserNotification(OrgContentMetadata orgContentMetadata, int contentType, String communityName,
			List<String> userIds, String opertionType, List<String> taggedUserIds, String taggedByUser) {
		logger.info("NotificationUtility:createUserNotification - Starting creating notification data for content type "
				+ contentType + " and communityName : " + communityName);
			if (contentType == contentTypeQuery) {
				saveUserNotificationData(orgContentMetadata, userIds, contentTypeQuery, opertionType, taggedUserIds, taggedByUser);
			} else if (contentType == contentTypeFollowup) {
				removeAuthorFromTaggedUser(orgContentMetadata, taggedUserIds);
				saveUserNotificationData(orgContentMetadata, userIds, contentTypeFollowup, opertionType, taggedUserIds, taggedByUser);
			} else if (contentType == contentTypeResponse) {
				removeAuthorFromTaggedUser(orgContentMetadata, taggedUserIds);
				saveUserNotificationData(orgContentMetadata, userIds, contentTypeResponse, opertionType, taggedUserIds, taggedByUser);
		}
	}

	private void removeAuthorFromTaggedUser(OrgContentMetadata orgContentMetadata, List<String> taggedUserIds) {
		if(taggedUserIds.size() > 0) {
		taggedUserIds.remove(orgContentMetadata.getAuthor());
		}
	}

	private void saveUserNotificationData(OrgContentMetadata orgContentMetadata, List<String> userIds,
			Integer contentTypeCd, String opertionType, List<String> taggedUserIds, String taggedByUser) {
		logger.info("NotificationUtility:saveUserNotificationData - Starting saving notification data into db");
		userIds.add(orgContentMetadata.getCreatedByUserId());
		if (userIds != null && userIds.size() > 0) {
			List<OrgNotification> orgNotifications = new ArrayList<>();
			userIds.forEach(userId -> {
				OrgNotification orgNotification = new OrgNotification();
				Timestamp notificationTime = new Timestamp(new Date().getTime());
				orgNotification.setNotificationId(UUID.randomUUID().toString());
				orgNotification.setUserId(userId);
				orgNotification.setCrtBy(getUserId());
				orgNotification.setCrtTs(notificationTime);
				orgNotification.setModBy(getUserId());
				orgNotification.setModTs(notificationTime);
				orgNotification.setIsRead(false);
				if (userId.equalsIgnoreCase(orgContentMetadata.getCreatedByUserId())) {
					if (contentTypeCd == contentTypeQuery && opertionType.equalsIgnoreCase("Create")) {
						orgNotification.setNotificationMsg(userQuerySubmitNotification);
					} else if (contentTypeCd == contentTypeQuery && opertionType.equalsIgnoreCase("Update")) {
						orgNotification.setNotificationMsg(userQueryEditNotification);
					} else if (contentTypeCd == contentTypeResponse) {
						orgNotification.setNotificationMsg(userQueryResponseNotification);
					} else if (contentTypeCd == contentTypeFollowup) {
						orgNotification.setNotificationMsg(userQueryFollowupNotification);
					}
					orgNotification.setNotificationTypeCd(notificationTypeAsk);
				} else {
					if (contentTypeCd == contentTypeQuery && opertionType.equalsIgnoreCase("Create")) {
						orgNotification.setNotificationMsg(worklistQuerySubmitNotification);
					} else if (contentTypeCd == contentTypeQuery && opertionType.equalsIgnoreCase("Update")) {
						orgNotification.setNotificationMsg(worklistQueryEditNotification);
					} else if (contentTypeCd == contentTypeResponse) {
						orgNotification.setNotificationMsg(worklistQueryResponseNotification);
					} else if (contentTypeCd == contentTypeFollowup) {
						orgNotification.setNotificationMsg(worklistQueryFollowupNotification);
					}
					orgNotification.setNotificationTypeCd(notificationTypeWorklist);
				}
				orgNotification.setNotificationTitle(orgContentMetadata.getTitle());
				orgNotification.setRedirectUrl(notificationAskPageUrl + orgContentMetadata.getContentId());
				orgNotifications.add(orgNotification);
			});
			orgNotificationRepository.saveAll(orgNotifications);
			logger.info("NotificationUtility:saveUserNotificationData - Notification data successfully stored for SMEs into db");
		}
		//Save tagged users notification 
		if(opertionType.equalsIgnoreCase("Create") && taggedUserIds.size() > 0) {
			List<OrgNotification> orgNotifications = new ArrayList<>();
			taggedUserIds.forEach(userId -> {
				OrgNotification orgNotification = new OrgNotification();
				Timestamp notificationTime = new Timestamp(new Date().getTime());
				orgNotification.setNotificationId(UUID.randomUUID().toString());
				orgNotification.setUserId(userId);
				orgNotification.setCrtBy(getUserId());
				orgNotification.setCrtTs(notificationTime);
				orgNotification.setModBy(getUserId());
				orgNotification.setModTs(notificationTime);
				orgNotification.setIsRead(false);
				if(contentTypeCd == contentTypeQuery) {
				orgNotification.setNotificationMsg(MessageFormat.format(taggedUserQuerySubmitNotification, taggedByUser));
				}else if (contentTypeCd == contentTypeResponse) {
                    orgNotification.setNotificationMsg(MessageFormat.format(taggedUserQueryResponseNotification, taggedByUser));					
				}else if (contentTypeCd == contentTypeFollowup) {
					orgNotification.setNotificationMsg(MessageFormat.format(taggedUserQueryFollowupNotification, taggedByUser));
				}
				orgNotification.setNotificationTitle(orgContentMetadata.getTitle());
				orgNotification.setRedirectUrl(notificationAskPageUrl + orgContentMetadata.getContentId());
				orgNotification.setNotificationTypeCd(notificationTypeAsk);
				orgNotifications.add(orgNotification);
			});
			orgNotificationRepository.saveAll(orgNotifications);
			logger.info("NotificationUtility:saveUserNotificationData - Notification data successfully stored for tagged users into db");
		}
		
	}

}
