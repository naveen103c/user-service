package com.akila.contentservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgUserFavLink;
import com.akila.contentservices.entity.OrgUserFavLinkPK;

@Repository
public interface OrgUserFavLinkRepository extends JpaRepository<OrgUserFavLink, OrgUserFavLinkPK> {
	
	@Query("select fl from OrgUserFavLink fl where fl.id.contentId = :contentId")
	public List<OrgUserFavLink> findByContentId(String contentId);
}
