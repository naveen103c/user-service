package com.akila.contentservices.contentitem.bean;

import com.akila.AkilaResponse;
import java.lang.Boolean;
import java.lang.Integer;
import java.lang.String;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class ContentItemResponse extends AkilaResponse 
{
	private String id;
	private String parentContentId;
	private String author;
	private Integer contentStatusCd;

	private Integer contentTypeCd;

	private String createdByUserId;

	private Timestamp crtTs;

	private String fileHash;

	private String fileNm;

	private Boolean isPrivate;

	private String jobId;

	private String keyValList;

	private Integer mediaCd;

	private Timestamp modTs;

	private Timestamp publishedTs;

	private String tagList;

	private String title;

	private String content;

	private Integer versionNum;
	
	private Integer actionStatusCd;
	
	private List<ContentItemResponse> children;
	
	

	public void setAuthor(String author) {
		this.author = author;
	}

	public void setContentStatusCd(Integer contentStatusCd) {
		this.contentStatusCd = contentStatusCd;
	}

	public void setContentTypeCd(Integer contentTypeCd) {
		this.contentTypeCd = contentTypeCd;
	}

	public void setCreatedByUserId(String createdByUserId) {
		this.createdByUserId = createdByUserId;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public void setFileHash(String fileHash) {
		this.fileHash = fileHash;
	}

	public void setFileNm(String fileNm) {
		this.fileNm = fileNm;
	}

	public void setIsPrivate(Boolean isPrivate) {
		this.isPrivate = isPrivate;
	}

	public void setJobId(String jobId) {
		this.jobId = jobId;
	}

	public void setKeyValList(String keyValList) {
		this.keyValList = keyValList;
	}

	public void setMediaCd(Integer mediaCd) {
		this.mediaCd = mediaCd;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public void setPublishedTs(Timestamp publishedTs) {
		this.publishedTs = publishedTs;
	}

	public void setTagList(String tagList) {
		this.tagList = tagList;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public void setVersionNum(Integer versionNum) {
		this.versionNum = versionNum;
	}

	public String getAuthor() {
		if(author == null)
		{
			return "";
		}
		return author;
	}

	public Integer getContentStatusCd() {
		return contentStatusCd;
	}

	public Integer getContentTypeCd() {
		return contentTypeCd;
	}

	public String getCreatedByUserId() {
		return createdByUserId;
	}

	public Timestamp getCrtTs() {
		return crtTs;
	}

	public String getFileHash() 
	{
		if(fileHash == null)
		{
			return "";
		}
		return fileHash;
	}

	public String getFileNm() {
		if(fileNm == null)
		{
			return "";
		}
		return fileNm;
	}

	public Boolean getIsPrivate() {
		return isPrivate;
	}

	public String getJobId() 
	{
		if(jobId == null)
		{
			return "";
		}
		return jobId;
	}

	public String getKeyValList() 
	{
		if(keyValList == null)
		{
			return "";
		}
		return keyValList;
	}

	public Integer getMediaCd() {
		return mediaCd;
	}

	public Timestamp getModTs() {
		return modTs;
	}

	public Timestamp getPublishedTs() {
		return publishedTs;
	}

	public String getTagList() 
	{
		if(tagList == null)
		{
			return "";
		}
		return tagList;
	}

	public String getTitle() {
		return title;
	}

	public Integer getVersionNum() {
		return versionNum;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public List<ContentItemResponse> getChildren() {
		if(children == null)
		{
			return new ArrayList<>();
		}
		return children;
	}

	public void setChildren(List<ContentItemResponse> children) {
		this.children = children;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getParentContentId() {
		if(parentContentId == null)
		{
			return "";
		}
		return parentContentId;
	}

	public void setParentContentId(String parentContentId) {
		this.parentContentId = parentContentId;
	}

	public Integer getActionStatusCd() {
		return actionStatusCd;
	}

	public void setActionStatusCd(Integer actionStatusCd) {
		this.actionStatusCd = actionStatusCd;
	}

}
