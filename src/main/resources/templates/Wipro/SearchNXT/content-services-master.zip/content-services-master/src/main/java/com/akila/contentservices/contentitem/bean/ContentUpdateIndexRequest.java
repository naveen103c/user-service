package com.akila.contentservices.contentitem.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ContentUpdateIndexRequest 
{

	@JsonProperty("org_id")
	private String orgId;
	
	@JsonProperty("root_content_id")
	private String rootContentId;
	
	@JsonProperty("root_content_type")
	private String contentType;
	
	@JsonProperty("content_type")
	private String childContentType;

	@JsonProperty("content_id")
	private String contentId;
	
	private String content;
	
	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getRootContentId() {
		return rootContentId;
	}

	public void setRootContentId(String rootContentId) {
		this.rootContentId = rootContentId;
	}

	public String getChildContentType() {
		return childContentType;
	}

	public void setChildContentType(String childContentType) {
		this.childContentType = childContentType;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	
}
