package com.akila.contentservices.entity;

import com.akila.AkilaEntity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the org_user_prefs database table.
 * 
 */
@Entity
@Table(name="org_user_prefs")
@NamedQuery(name="OrgUserPref.findAll", query="SELECT o FROM OrgUserPref o")
public class OrgUserPref extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private OrgUserPrefPK id;

	@Column(name="crt_by")
	private String crtBy;

	@Column(name="crt_ts")
	private Timestamp crtTs;

	@Column(name="mod_by")
	private String modBy;

	@Column(name="mod_ts")
	private Timestamp modTs;

	@Column(name="personal_preference_json")
	private String personalPreferenceJson;
	
	@Column(name="user_id", insertable=false, updatable=false)
	private String userId;
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public OrgUserPref() {
	}

	public OrgUserPrefPK getId() {
		return this.id;
	}

	public void setId(OrgUserPrefPK id) {
		this.id = id;
	}

	public String getCrtBy() {
		return this.crtBy;
	}

	public void setCrtBy(String crtBy) {
		this.crtBy = crtBy;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getModBy() {
		return this.modBy;
	}

	public void setModBy(String modBy) {
		this.modBy = modBy;
	}

	public Timestamp getModTs() {
		return this.modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public String getPersonalPreferenceJson() {
		return this.personalPreferenceJson;
	}

	public void setPersonalPreferenceJson(String personalPreferenceJson) {
		this.personalPreferenceJson = personalPreferenceJson;
	}

}