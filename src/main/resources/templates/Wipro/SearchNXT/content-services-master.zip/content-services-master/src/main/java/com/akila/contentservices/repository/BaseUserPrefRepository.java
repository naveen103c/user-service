package com.akila.contentservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.akila.contentservices.entity.BaseUserPref;

public interface BaseUserPrefRepository extends JpaRepository<BaseUserPref, String>{

	List<BaseUserPref> findByPrefTypeCd(int prefTypeCd);

}
