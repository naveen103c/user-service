package com.akila.contentservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgUser;

@Repository
public interface OrgUserRepository extends JpaRepository<OrgUser, String> {
	
	OrgUser findByUserId(String userId);
	
	List<OrgUser> findByUserIdIn(List<String> userIds);
	
}
