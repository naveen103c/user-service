package com.akila.contentservices.contentitem;

import java.util.UUID;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.contentservices.ContentServicesApplication;
import com.akila.contentservices.contentitem.bean.ContentItemProcessor;
import com.akila.contentservices.contentitem.bean.ContentItemRequest;

@SpringBootTest(classes = ContentServicesApplication.class)
public class ContentItemControllerTest 
{
	
	@Test
	public void createContent()
	{
		ContentItemRequest request = new ContentItemRequest();
		request.setTitle("My Content Title");
		request.setContent("My content body");
		request.setPrivateContent(true);
		request.setContentStatusCd(1);
		request.setMediaCd(104);
		request.setTags(new String[] {"fdbfa350-1d5a-4fd8-9b64-0fa51ecf9d89"});
		request.setVersionNum(1);
		request.setKeyValList("communityId=1");
		request.setRootContentId("95168c4a-0344-4249-8ef9-1eda313e8d1a");
		request.setParentContentId("95168c4a-0344-4249-8ef9-1eda313e8d1a");
		request.setContentStatusCd(3);
		
	//	controller.createContent(request, "wiki");
	}
	
	@Test
	public void createContentService()
	{
		ContentItemProcessor request = new ContentItemProcessor();
		request.setTitle("My Content Title");
		request.setContent("My content body");
		request.setIsPrivate(true);
		request.setContentStatusCd(1);
		request.setContentId(UUID.randomUUID().toString());
		request.setContentType("");
		request.setFormatType("");
		request.setStrippedContent("my stripped content");
		request.setStrippedVersionId(UUID.randomUUID().toString());
		request.setTagList("Tag1, Tag2");
		request.setVersionId("VersionId");
		
		
		request.setCreatedByUserId(UUID.randomUUID().toString());
		//service.createContentMetaData(request);
	}
	
	@Test
	@Transactional
	public void getContent()
	{
		
		/*
		 * ContentItemResponse response =
		 * controller.getContent("ebc2924d-d9c4-408b-96b4-0b38c013fc81", "wiki");
		 * ObjectMapper Obj = new ObjectMapper(); try { String jsonStr =
		 * Obj.writeValueAsString(response); System.out.println(jsonStr); } catch
		 * (IOException e) {e.printStackTrace();}
		 */
		
	}

}
