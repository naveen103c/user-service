package com.akila.contentservices.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "base_orgs", schema = "base")
public class BaseOrgs {

	@Id
	@Column(name = "org_id")
	String orgId;
	
	@Column(name = "org_nm")
	String orgNm;
	
	@Column(name = "plan_id")
	String planId;
	
	@Column(name = "org_status_cd")
	int orgStatusCd;
	
	@Column(name = "plan_effective_from_dt")
	Date planEffectiveDromDt;
	
	@Column(name = "plan_effective_to_dt")
	Date planEffectiveToDt;
	
	@Column(name = "storage_folder_nm")
	String storageFolderNm;
	
	@Column(name = "db_schema_nm")
	String dbSchemaNm;
	
	@Column(name = "search_index_nm")
	String searchIndexNm;
	
	@Column(name = "encryption_key")
	String encryptionKey;
	
	@Column(name = "content_version_support")
	Boolean contentVersionSupport;

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getOrgNm() {
		return orgNm;
	}

	public void setOrgNm(String orgNm) {
		this.orgNm = orgNm;
	}

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public int getOrgStatusCd() {
		return orgStatusCd;
	}

	public void setOrgStatusCd(int orgStatusCd) {
		this.orgStatusCd = orgStatusCd;
	}

	public Date getPlanEffectiveDromDt() {
		return planEffectiveDromDt;
	}

	public void setPlanEffectiveDromDt(Date planEffectiveDromDt) {
		this.planEffectiveDromDt = planEffectiveDromDt;
	}

	public Date getPlanEffectiveToDt() {
		return planEffectiveToDt;
	}

	public void setPlanEffectiveToDt(Date planEffectiveToDt) {
		this.planEffectiveToDt = planEffectiveToDt;
	}

	public String getStorageFolderNm() {
		return storageFolderNm;
	}

	public void setStorageFolderNm(String storageFolderNm) {
		this.storageFolderNm = storageFolderNm;
	}

	public String getDbSchemaNm() {
		return dbSchemaNm;
	}

	public void setDbSchemaNm(String dbSchemaNm) {
		this.dbSchemaNm = dbSchemaNm;
	}

	public String getEncryptionKey() {
		return encryptionKey;
	}

	public void setEncryptionKey(String encryptionKey) {
		this.encryptionKey = encryptionKey;
	}

	public Boolean getContentVersionSupport() {
		return contentVersionSupport;
	}

	public void setContentVersionSupport(Boolean contentVersionSupport) {
		this.contentVersionSupport = contentVersionSupport;
	}

	public String getSearchIndexNm() {
		return searchIndexNm;
	}

	public void setSearchIndexNm(String searchIndexNm) {
		this.searchIndexNm = searchIndexNm;
	}
	
}
