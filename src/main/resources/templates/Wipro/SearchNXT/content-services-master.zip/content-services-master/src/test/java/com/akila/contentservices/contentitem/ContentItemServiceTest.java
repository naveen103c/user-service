package com.akila.contentservices.contentitem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.akila.contentservices.ContentServicesApplication;

@SpringBootTest(classes = ContentServicesApplication.class)
public class ContentItemServiceTest 
{
	
	@Test
	public void getTagList()
	{
		String[] str = new String[1];
		str[0] = "fdbfa350-1d5a-4fd8-9b64-0fa51ecf9d89";
//		service.getTagList(str);
		
	}

}
