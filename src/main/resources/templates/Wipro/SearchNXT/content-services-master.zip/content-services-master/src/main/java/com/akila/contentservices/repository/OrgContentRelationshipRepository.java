package com.akila.contentservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgContentRelationship;

@Repository
public interface OrgContentRelationshipRepository extends JpaRepository<OrgContentRelationship, String> 
{
	List<OrgContentRelationship> findAllByRootContentId(String rootContentId);
	
	OrgContentRelationship findBycontentId(String contentId);
	
}
