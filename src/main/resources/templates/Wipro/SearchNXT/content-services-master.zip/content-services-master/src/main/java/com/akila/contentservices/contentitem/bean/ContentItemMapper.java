package com.akila.contentservices.contentitem.bean;

import com.akila.contentservices.entity.OrgContentMetadata;
import com.akila.contentservices.entity.OrgContentRelationship;

import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

@Mapper(
    componentModel = "spring"
)
public interface ContentItemMapper {
  ContentItemMapper INSTANCE = Mappers.getMapper(ContentItemMapper.class);
  ;

  @Mappings({
	  @Mapping(source = "contentId", target = "id")
  })
  ContentItemResponse orgContentMetadataToContentitemResponse(
      OrgContentMetadata orgContentMetadata);

  @Mappings({})
  List<ContentItemResponse> orgContentMetadataToContentitemResponseList(
      List<OrgContentMetadata> orgContentMetadata);

  @Mappings({})
  OrgContentMetadata contentitemRequestToOrgContentMetadata(ContentItemRequest contentitemRequest);
  
  @Mappings({})
  OrgContentMetadata contentitemProcessorToOrgContentMetadata(ContentItemProcessor contentitemRequest);
  
  @Mappings({})
  OrgContentRelationship contentitemProcessorToOrgContentRelationship(ContentItemProcessor contentitemRequest);
  
  @Mappings({
  })
  ContentIndexRequest contentitemProcessorToContentIndexRequest(ContentItemProcessor contentitemRequest);
  
  @Mappings({
  })
  ContentUpdateIndexRequest contentitemProcessorToContentUpdateIndexRequest(ContentItemProcessor contentitemRequest);
  
}
