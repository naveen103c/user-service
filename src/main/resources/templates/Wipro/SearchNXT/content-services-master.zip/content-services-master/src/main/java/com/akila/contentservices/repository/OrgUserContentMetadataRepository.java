package com.akila.contentservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgUserContentMetadata;
import com.akila.contentservices.entity.OrgUserContentMetadataPK;

@Repository
public interface OrgUserContentMetadataRepository extends JpaRepository<OrgUserContentMetadata, OrgUserContentMetadataPK> {
	
	@Query("from OrgUserContentMetadata where id.contentId = :contentId")
	public List<OrgUserContentMetadata> getByContentId(String contentId);
}
