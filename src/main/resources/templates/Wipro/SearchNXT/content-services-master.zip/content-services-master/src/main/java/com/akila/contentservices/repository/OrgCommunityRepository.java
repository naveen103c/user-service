package com.akila.contentservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgCommunity;

@Repository
public interface OrgCommunityRepository extends JpaRepository<OrgCommunity, String> {

	public OrgCommunity findByCommunityId(String communityId);
	
}
