package com.akila.contentservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgCommunitySme;
import com.akila.contentservices.entity.OrgCommunitySmePK;

@Repository
public interface OrgCommunitySmeRepository extends JpaRepository<OrgCommunitySme, OrgCommunitySmePK> {
	
	List<OrgCommunitySme> findByIdCommunityId(String communityId);
}
