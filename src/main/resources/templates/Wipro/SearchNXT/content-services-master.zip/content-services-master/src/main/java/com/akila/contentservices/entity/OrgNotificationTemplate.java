package com.akila.contentservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.akila.AkilaEntity;

@Entity
@Table(name="org_notification_template")
public class OrgNotificationTemplate extends AkilaEntity implements Serializable{

	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="template_id")
	private String templateId;
	
	@Column(name="template_name")
	private String templateName;
	
	@Column(name="template_description")
	private String templateDescription;
	
	@Column(name="template_subject")
	private String templateSubject;
	
	@Column(name="template")
	private String template;

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getTemplateDescription() {
		return templateDescription;
	}

	public void setTemplateDescription(String templateDescription) {
		this.templateDescription = templateDescription;
	}

	public String getTemplateSubject() {
		return templateSubject;
	}

	public void setTemplateSubject(String templateSubject) {
		this.templateSubject = templateSubject;
	}

	public String getTemplate() {
		return template;
	}

	public void setTemplate(String template) {
		this.template = template;
	}
	
}
