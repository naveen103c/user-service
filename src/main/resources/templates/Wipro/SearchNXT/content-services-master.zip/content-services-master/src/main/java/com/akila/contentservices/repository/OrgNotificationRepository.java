package com.akila.contentservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgNotification;

@Repository
public interface OrgNotificationRepository extends JpaRepository<OrgNotification, String> {

}
