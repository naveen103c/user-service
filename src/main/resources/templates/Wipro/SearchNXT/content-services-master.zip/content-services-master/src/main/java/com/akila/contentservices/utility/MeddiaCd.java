package com.akila.contentservices.utility;
   public enum MeddiaCd {
          VIDEO(1), AUDIO(2), WORD(3), PDF(4), EXCEL(5), PPT(6), TXT(7), IMAGE(8),HTML(9), MAIL(10);

          private int value;

          private MeddiaCd(int value) {
                 this.value = value;
          }
          
          public int getValue() {
                 return value;
          }
   }
