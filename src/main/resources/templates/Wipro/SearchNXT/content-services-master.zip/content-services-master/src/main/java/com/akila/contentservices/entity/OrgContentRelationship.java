package com.akila.contentservices.entity;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the org_content_relationships database table.
 * 
 */
@Entity
@Table(name="org_content_relationships")
@NamedQuery(name="OrgContentRelationship.findAll", query="SELECT o FROM OrgContentRelationship o")
public class OrgContentRelationship implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="content_id")
	private String contentId;

	@Column(name="feedback_ts")
	private Timestamp feedbackTs;

	@Column(name="parent_content_id")
	private String parentContentId;

	@Column(name="root_content_id")
	private String rootContentId;

	@Column(name="user_id")
	private String userId;

	public OrgContentRelationship() {
	}

	public String getContentId() {
		return this.contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public Timestamp getFeedbackTs() {
		return this.feedbackTs;
	}

	public void setFeedbackTs(Timestamp feedbackTs) {
		this.feedbackTs = feedbackTs;
	}

	public String getParentContentId() {
		return this.parentContentId;
	}

	public void setParentContentId(String parentContentId) {
		this.parentContentId = parentContentId;
	}

	public String getRootContentId() {
		return this.rootContentId;
	}

	public void setRootContentId(String rootContentId) {
		this.rootContentId = rootContentId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}