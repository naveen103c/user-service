package com.akila.contentservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgContentMetric;


@Repository
public interface OrgContentMetricRepository extends JpaRepository<OrgContentMetric, String> 
{
	@Modifying
	@Query("delete from OrgContentMetric fl where fl.contentId = :contentId")
	public void deleteByContentId(String contentId);
}
