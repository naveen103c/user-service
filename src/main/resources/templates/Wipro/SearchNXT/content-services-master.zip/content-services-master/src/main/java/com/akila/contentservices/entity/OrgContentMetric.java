package com.akila.contentservices.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;


/**
 * The persistent class for the org_content_metric database table.
 * 
 */
@Entity
@Table(name="org_content_metric")
@NamedQuery(name="OrgContentMetric.findAll", query="SELECT o FROM OrgContentMetric o")
public class OrgContentMetric implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="content_id", insertable=false, updatable=false)
	private String contentId;

	@Column(name="metric_period_cd")
	private Integer metricPeriodCd;

	@Temporal(TemporalType.DATE)
	@Column(name="metric_period_dt")
	private java.util.Date metricPeriodDt;

	@Column(name="down_votes")
	private Integer downVotes;

	@Column(name="favorite_count")
	private Integer favoriteCount;

	@Column(name="interaction_count")
	private Integer interactionCount;

	@Column(name="mod_ts")
	private Timestamp modTs;

	@Column(name="up_votes")
	private Integer upVotes;

	public OrgContentMetric() {
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}


	public Integer getMetricPeriodCd() {
		return metricPeriodCd;
	}


	public void setMetricPeriodCd(Integer metricPeriodCd) {
		this.metricPeriodCd = metricPeriodCd;
	}


	public java.util.Date getMetricPeriodDt() {
		return metricPeriodDt;
	}


	public void setMetricPeriodDt(java.util.Date metricPeriodDt) {
		this.metricPeriodDt = metricPeriodDt;
	}


	public Integer getDownVotes() {
		return this.downVotes;
	}

	public void setDownVotes(Integer downVotes) {
		this.downVotes = downVotes;
	}

	public Integer getFavoriteCount() {
		return this.favoriteCount;
	}

	public void setFavoriteCount(Integer favoriteCount) {
		this.favoriteCount = favoriteCount;
	}

	public Integer getInteractionCount() {
		return this.interactionCount;
	}

	public void setInteractionCount(Integer interactionCount) {
		this.interactionCount = interactionCount;
	}

	public Timestamp getModTs() {
		return this.modTs;
	}

	public void setModTs(Timestamp modTs) {
		this.modTs = modTs;
	}

	public Integer getUpVotes() {
		return this.upVotes;
	}

	public void setUpVotes(Integer upVotes) {
		this.upVotes = upVotes;
	}

}