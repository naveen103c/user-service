package com.akila.contentservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;


/**
 * The persistent class for the org_ref_codes database table.
 * 
 */
@Entity
@Table(name="org_ref_codes")
@NamedQuery(name="OrgRefCode.findAll", query="SELECT o FROM OrgRefCode o")
public class OrgRefCode extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ref_code_id")
	private String refCodeId;

	@Column(name="ref_code_description")
	private String refCodeDescription;

	@Column(name="ref_code_display_val")
	private String refCodeDisplayVal;

	@Column(name="ref_code_store_val")
	private Integer refCodeStoreVal;

	@Column(name="ref_code_type_id")
	private String refCodeTypeId;

	public OrgRefCode() {
	}

	public String getRefCodeId() {
		return this.refCodeId;
	}

	public void setRefCodeId(String refCodeId) {
		this.refCodeId = refCodeId;
	}

	public String getRefCodeDescription() {
		return this.refCodeDescription;
	}

	public void setRefCodeDescription(String refCodeDescription) {
		this.refCodeDescription = refCodeDescription;
	}

	public String getRefCodeDisplayVal() {
		return this.refCodeDisplayVal;
	}

	public void setRefCodeDisplayVal(String refCodeDisplayVal) {
		this.refCodeDisplayVal = refCodeDisplayVal;
	}

	public Integer getRefCodeStoreVal() {
		return this.refCodeStoreVal;
	}

	public void setRefCodeStoreVal(Integer refCodeStoreVal) {
		this.refCodeStoreVal = refCodeStoreVal;
	}

	public String getRefCodeTypeId() {
		return this.refCodeTypeId;
	}

	public void setRefCodeTypeId(String refCodeTypeId) {
		this.refCodeTypeId = refCodeTypeId;
	}

}