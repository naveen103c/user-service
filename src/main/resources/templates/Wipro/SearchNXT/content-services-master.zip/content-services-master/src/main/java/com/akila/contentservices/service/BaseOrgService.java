package com.akila.contentservices.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.akila.contentservices.entity.BaseOrgs;
import com.akila.contentservices.repository.BaseOrgsRepository;

@Service
public class BaseOrgService {

	@Autowired
	BaseOrgsRepository BaseOrgsRepository;
	
	public BaseOrgs getBaseOrgs(String orgId) {
		
		return BaseOrgsRepository.findById(orgId).orElse(null);
		
	}
}
