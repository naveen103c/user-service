package com.akila.contentservices.contentitem.bean;

import java.util.List;

import com.akila.AkilaRequest;

public class ContentItemRequest extends AkilaRequest 
{
	
	private String title;
	private String content;
	private String[] tags;
	private boolean privateContent;
	private int contentStatusCd;
	private String rootContentId;
	private String parentContentId;
	private int mediaCd;
	private int versionNum;
	private String keyValList;
	private int contentTypeCd;
	private String communityId;
	private List<String> fileList;
	private List<String> taggedUserIds;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String[] getTags() {
		return tags;
	}
	public void setTags(String[] tags) {
		this.tags = tags;
	}
	public boolean isPrivateContent() {
		return privateContent;
	}
	public void setPrivateContent(boolean privateContent) {
		this.privateContent = privateContent;
	}
	public int getContentStatusCd() {
		return contentStatusCd;
	}
	public void setContentStatusCd(int contentStatusCd) {
		this.contentStatusCd = contentStatusCd;
	}
	public String getRootContentId() {
		return rootContentId;
	}
	public void setRootContentId(String rootContentId) {
		this.rootContentId = rootContentId;
	}
	public String getParentContentId() {
		return parentContentId;
	}
	public void setParentContentId(String parentContentId) {
		this.parentContentId = parentContentId;
	}
	public int getMediaCd() {
		return mediaCd;
	}
	public void setMediaCd(int mediaCd) {
		this.mediaCd = mediaCd;
	}
	public int getVersionNum() {
		return versionNum;
	}
	public void setVersionNum(int versionNum) {
		this.versionNum = versionNum;
	}
	public String getKeyValList() {
		return keyValList;
	}
	public void setKeyValList(String keyValList) {
		this.keyValList = keyValList;
	}
	public int getContentTypeCd() {
		return contentTypeCd;
	}
	public void setContentTypeCd(int contentTypeCd) {
		this.contentTypeCd = contentTypeCd;
	}
	public String getCommunityId() {
		return communityId;
	}
	public void setCommunityId(String communityId) {
		this.communityId = communityId;
	}
	public List<String> getFileList() {
		return fileList;
	}
	public void setFileList(List<String> fileList) {
		this.fileList = fileList;
	}
	public List<String> getTaggedUserIds() {
		return taggedUserIds;
	}
	public void setTaggedUserIds(List<String> taggedUserIds) {
		this.taggedUserIds = taggedUserIds;
	}

}
