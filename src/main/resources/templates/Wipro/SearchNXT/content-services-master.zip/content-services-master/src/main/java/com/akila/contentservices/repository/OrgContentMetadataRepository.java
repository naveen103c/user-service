package com.akila.contentservices.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgContentMetadata;

@Repository
public interface OrgContentMetadataRepository extends JpaRepository<OrgContentMetadata, String> 
{
	@Query("select o from OrgContentMetadata o where o.id.contentId in (select cr.id.contentId from OrgContentRelationship cr where cr.rootContentId = :contentId) "
			+ "order by o.crtTs ASC")
	public List<OrgContentMetadata> findChildren(String contentId);
	
	@Query("select o from OrgContentMetadata o where o.createdByUserId = :userId and o.contentTypeCd = :contentType and o.contentStatusCd != 4 and o.actionStatusCd != 7"
			+ "order by o.crtTs DESC")
	public List<OrgContentMetadata> findAllQueryContentByUserIdAndContentType(String userId, Integer contentType);
	
	@Query("select o from OrgContentMetadata o where o.createdByUserId = :userId and o.contentTypeCd = :contentType and (:actionStatusCd = -1 or  o.actionStatusCd = :actionStatusCd) and o.contentStatusCd != 4 order by o.crtTs DESC")
	public List<OrgContentMetadata> findAllQueryContentByUserIdAndActionStatusCd(String userId, Integer contentType, Integer actionStatusCd);
	
	@Query("select o from OrgContentMetadata o where o.createdByUserId = :userId and o.contentTypeCd = :contentType order by o.crtTs DESC")
	public List<OrgContentMetadata> findAllWikiContentByUserIdAndContentType(String userId, Integer contentType);
	
	@Query("select o from OrgContentMetadata o where o.createdByUserId = :userId and o.contentTypeCd = :contentType and (:contentStatusCd = -1 or  o.contentStatusCd = :contentStatusCd) order by o.crtTs DESC")
	public List<OrgContentMetadata> findAllWikiContentByUserIdAndContentStatusCd(String userId, Integer contentType, Integer contentStatusCd);
	
	OrgContentMetadata findByContentId(String contentId);
	
	@Query("select o from OrgContentMetadata o where o.createdByUserId = :userId and o.contentTypeCd = :contentType and o.contentStatusCd != 4 and o.actionStatusCd != 7"
			+ "order by o.crtTs DESC")
	public List<OrgContentMetadata> findAllQueryContentByUserIdAndContentType();
	
	@Query("select o from OrgContentMetadata o left outer join OrgContentRelationship b on o.contentId = b.rootContentId  and b.feedbackTs BETWEEN :startDate AND NOW() where o.contentTypeCd = 3 and o.contentStatusCd in (3,4,8) and o.actionStatusCd in (3,5,8) and  b.rootContentId is null")
	public List<OrgContentMetadata> findAllAskWithOpenStatusRelationNotExist(Date startDate);
	
	public OrgContentMetadata findByConfIdAndSourceFileKey(String confId, String sourceFileKey);
	
}
