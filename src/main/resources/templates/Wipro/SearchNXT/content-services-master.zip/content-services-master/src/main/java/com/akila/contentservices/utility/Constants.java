package com.akila.contentservices.utility;

public class Constants {
	
	
	public static final Integer MAIL_NOTIFICATION_PREF_CD =  6;

}
