package com.akila.contentservices.contentitem;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jsoup.Jsoup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.akila.AkilaConstants.ContentFormatType;
import com.akila.AkilaConstants.ContentType;
import com.akila.AkilaConstants.StorageStreamType;
import com.akila.AkilaService;
import com.akila.commons.AkilaRestTemplate;
import com.akila.commons.storage.bean.StorageRequest;
import com.akila.commons.storage.bean.StorageResponse;
import com.akila.commons.storage.service.StorageFactory;
import com.akila.contentservices.contentitem.bean.AttachmentContentMetaDataRequest;
import com.akila.contentservices.contentitem.bean.ContentIndexRequest;
import com.akila.contentservices.contentitem.bean.ContentItemMapper;
import com.akila.contentservices.contentitem.bean.ContentItemProcessor;
import com.akila.contentservices.contentitem.bean.ContentItemRequest;
import com.akila.contentservices.contentitem.bean.ContentItemResponse;
import com.akila.contentservices.contentitem.bean.ContentMetaDataMapper;
import com.akila.contentservices.contentitem.bean.ContentMetaDataResponse;
import com.akila.contentservices.contentitem.bean.ContentMetricRequest;
import com.akila.contentservices.contentitem.bean.ContentUpdateIndexRequest;
import com.akila.contentservices.contentitem.bean.FileMetaDataJsonList;
import com.akila.contentservices.contentitem.bean.TagList;
import com.akila.contentservices.entity.BaseOrgs;
import com.akila.contentservices.entity.OrgCommunity;
import com.akila.contentservices.entity.OrgContentMetadata;
import com.akila.contentservices.entity.OrgContentRelationship;
import com.akila.contentservices.entity.OrgUserContentMetadata;
import com.akila.contentservices.entity.OrgUserFavLink;
import com.akila.contentservices.repository.OrgCommunityRepository;
import com.akila.contentservices.repository.OrgContentMetadataHistoryRepository;
import com.akila.contentservices.repository.OrgContentMetadataRepository;
import com.akila.contentservices.repository.OrgContentMetricRepository;
import com.akila.contentservices.repository.OrgContentRelationshipRepository;
import com.akila.contentservices.repository.OrgUserContentMetadataRepository;
import com.akila.contentservices.repository.OrgUserFavLinkRepository;
import com.akila.contentservices.service.BaseOrgService;
import com.akila.contentservices.utility.MailUtility;
import com.akila.contentservices.utility.MeddiaCd;
import com.akila.contentservices.utility.NotificationUtility;
import com.akila.response.ResponseId;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class ContentItemService extends AkilaService {
	@Autowired
	private OrgContentMetadataRepository orgContentMetadataRepository;

	@Autowired
	private OrgContentRelationshipRepository orgContentRelationshipRepository;

	@Autowired
	private ContentItemMapper contentitemMapper;
	
	@Autowired
	private ContentMetaDataMapper contentMetaDataMapper;

	@Autowired
	private StorageFactory s3StorageService;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private OrgContentMetricRepository orgContentMetricRepository;

	@Autowired
	OrgContentMetadataHistoryRepository orgContentMetadataHistoryRepository;

	@Autowired
	OrgUserFavLinkRepository orgUserFavLinkRepository;

	@Autowired
	private OrgUserContentMetadataRepository orgUserContentMetadataRepository;

	@Autowired
	@Qualifier("loadBalanced")
	private RestTemplate loadBalancedRestTemplate;

	private static Logger log = LogManager.getLogger(ContentItemService.class);

	@Value("${content.status.code.published}")
	private int publishedContentStatusCode;

	@Value("${python.dataindex.content.api.url}")
	private String pythonDataIndexContentURL;

	@Value("${python.update.ask.api.url}")
	private String pythonUpdateAskURL;

	@Value("${python.delete.data.api.url}")
	private String pythonDeleteDataURL;

	@Value("${metric.service.url}")
	private String metricServiceURL;

	@Value("${platform.service.url}")
	private String platformServiceURL;

	@Autowired
	private AkilaRestTemplate akilaRestTemplate;

	@Autowired
	MailUtility mailUtility;

	@Value("${contentType.response}")
	private int contentTypeResponse;

	@Value("${contentType.followup}")
	private int contentTypeFollowup;

	@Autowired
	private OrgCommunityRepository orgCommunityRepository;

	@Value("${batchjob.service.url}")
	private String batchJobServiceURL;

	@Autowired
	private BaseOrgService baseOrgService;

	@Value("${upload.folder.name}")
	private String uploadFolder;

	@Value("${contentType.attachment}")
	private String contentTypeAttachment;

	@Value("${ask.content.length}")
	private int askContentLength;

	@Autowired
	private NotificationUtility notificationUtility;

	private Map<Integer, String> contentTypeCodeMap = new HashMap<Integer, String>();

	{
		contentTypeCodeMap.put(1, "File");
		contentTypeCodeMap.put(2, "Wiki");
		contentTypeCodeMap.put(3, "Query");
		contentTypeCodeMap.put(4, "answer");
		contentTypeCodeMap.put(5, "comment");
		contentTypeCodeMap.put(6, "followup");
		contentTypeCodeMap.put(7, "Attachment");
	}

	@Autowired
	private EntityManager entityManager;

	@Value("${contentType.query}")
	private Integer contentTypeQuery;

	public ResponseId createStrippedContentVersion(ContentItemProcessor content)
			throws JsonMappingException, JsonProcessingException, Exception {
		content.setFormatType(ContentFormatType.STRIPPED.getValue());
		StorageRequest request = getStorageRequest(content);
		StorageResponse response = s3StorageService.putObject(request);
		content.setStrippedVersionId(response.getVersionId());
		return new ResponseId(content.getContentId());
	}

	public void deleteStrippedContentVersion(ContentItemProcessor content)
			throws JsonMappingException, JsonProcessingException, Exception {
		content.setFormatType(ContentFormatType.STRIPPED.getValue());
		StorageRequest request = getStorageRequest(content);
		s3StorageService.deleteObject(request);
	}

	public ResponseId createOriginalContentCopy(ContentItemProcessor content)
			throws JsonMappingException, JsonProcessingException, Exception {
		content.setFormatType(ContentFormatType.ORIGINAL.getValue());
		StorageRequest request = getStorageRequest(content);
		StorageResponse response = s3StorageService.putObject(request);
		content.setVersionId(response.getVersionId());
		return new ResponseId(content.getContentId());
	}

	public void deleteOriginalContentCopy(ContentItemProcessor content)
			throws JsonMappingException, JsonProcessingException, Exception {
		content.setFormatType(ContentFormatType.ORIGINAL.getValue());
		StorageRequest request = getStorageRequest(content);
		s3StorageService.deleteObject(request);
	}

	public ResponseId createContentIndex(ContentItemProcessor content) {
		if (isCommentOrResponse(content)) {
			return updateContentIndexForCommentAndResponse(content);
		}

		if (content.getContentStatusCd() != publishedContentStatusCode) {
			return new ResponseId(content.getContentId());
		}

		ContentIndexRequest request = contentitemMapper.contentitemProcessorToContentIndexRequest(content);
		if (content.getTagListArray().length > 0) {
			request.setTagsMap(getTagList(content.getTagListArray()).getTags());
		}
		// updated source type and media type for Wiki and Ask
		if (request.getContentType().equalsIgnoreCase("query") || request.getContentType().equalsIgnoreCase("wiki")) {
			request.setSourceType(request.getContentType().toLowerCase());
			request.setMediaType("html");
		}

		request.setOrgId(getOrgId());
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(request);
			log.info("createContentIndex JSON" + json);
		} catch (JsonProcessingException e) {
			log.error("Error parsing json", e);
		}
		HttpHeaders headers = getRequestHeader();
		HttpEntity<ContentIndexRequest> entity = new HttpEntity<ContentIndexRequest>(request, headers);
		ResponseEntity<String> response = akilaRestTemplate.postForEntity(restTemplate, pythonDataIndexContentURL,
				entity, String.class);
		log.info("createContentIndex JSON Response " + response.getBody());
		return new ResponseId(content.getContentId());
	}

	public ResponseId updateContentIndexForCommentAndResponse(ContentItemProcessor content) {
		if (content.getContentStatusCd() != publishedContentStatusCode) {
			return new ResponseId(content.getContentId());
		}

		ContentUpdateIndexRequest request = contentitemMapper.contentitemProcessorToContentUpdateIndexRequest(content);
		request.setOrgId(getOrgId());
		String childContentType = contentTypeCodeMap.get(content.getContentTypeCd());
		request.setChildContentType(childContentType);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(request);
			log.info("createContentIndex JSON" + json);
		} catch (JsonProcessingException e) {
			log.error("Error parsing json", e);
		}
		HttpHeaders headers = getRequestHeader();
		HttpEntity<ContentUpdateIndexRequest> entity = new HttpEntity<ContentUpdateIndexRequest>(request, headers);
		ResponseEntity<String> response = akilaRestTemplate.postForEntity(restTemplate, pythonUpdateAskURL, entity,
				String.class);
		log.info("createContentIndex JSON Response " + response.getBody());
		return new ResponseId(content.getContentId());
	}

	public ResponseId deleteContentIndex(ContentItemProcessor content, String contentType) {

		ContentIndexRequest request = contentitemMapper.contentitemProcessorToContentIndexRequest(content);
		request.setOrgId(getOrgId());
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(request);
			log.info("createContentIndex JSON" + json);
		} catch (JsonProcessingException e) {
			log.error("Error parsing json", e);
		}
		HttpHeaders headers = getRequestHeader();
		HttpEntity<ContentIndexRequest> entity = new HttpEntity<ContentIndexRequest>(headers);
		akilaRestTemplate.delete(restTemplate,
				pythonDeleteDataURL + "org_id=" + getOrgId() + "&content_id=" + content.getContentId(), entity,
				String.class);

		return new ResponseId(content.getContentId());
	}

	public ResponseId deleteContentIndex(String contentType, String id) {
		HttpHeaders headers = getRequestHeader();
		HttpEntity<ContentIndexRequest> entity = new HttpEntity<ContentIndexRequest>(headers);
		akilaRestTemplate.delete(restTemplate, pythonDeleteDataURL + "org_id=" + getOrgId() + "&content_id=" + id,
				entity, String.class);

		return new ResponseId(id);
	}

	public ResponseId createContentMetaData(ContentItemProcessor content) {
		OrgContentMetadata metaData = contentitemMapper.contentitemProcessorToOrgContentMetadata(content);
		metaData.setContentId(content.getContentId());
		metaData.setAuthor(metaData.getAuthor() !=null && !metaData.getAuthor().isEmpty() ? metaData.getAuthor() : getUserId());
		if (metaData.getCommunityId() != null && metaData.getCommunityId().trim().isEmpty()) {
			metaData.setCommunityId(null);
		}
		log.info("ContentItemProcessor.community id " + content.getCommunityId());
		log.info("OrgContentMetadata.community id " + metaData.getCommunityId());
		if (content.getContentStatusCd() == publishedContentStatusCode
				&& content.getContentType().equalsIgnoreCase("wiki")) {
			metaData.setActionStatusCd(0);
		}
		if (content.getContentStatusCd() == publishedContentStatusCode
				&& content.getContentType().equalsIgnoreCase("query") && metaData.getActionStatusCd() == null) {
			metaData.setActionStatusCd(content.getContentTypeCd() == contentTypeResponse ? 0 : 3);
		}
		if (content.getContentId() == null || content.getContentId().isEmpty()) {
			metaData.setModTs(new Timestamp(new Date().getTime()));
		}

		orgContentMetadataRepository.save(metaData);
		if (content.getParentContentId() != null && !content.getParentContentId().isEmpty()
				&& content.getRootContentId() != null && !content.getRootContentId().isEmpty()) {
			OrgContentRelationship relationShip = contentitemMapper
					.contentitemProcessorToOrgContentRelationship(content);
			relationShip.setContentId(content.getContentId());
			orgContentRelationshipRepository.save(relationShip);
			OrgContentMetadata rootMetaData = orgContentMetadataRepository.findByContentId(content.getRootContentId());
			content.setCommunityId(rootMetaData.getCommunityId());
		}

		// Ask Attachment process
		if (content.getFileList() != null && content.getFileList().size() > 0) {
			log.info("Attachment received for content type : " + content.getContentType());
			AttachmentContentMetaDataRequest attachmentContentMetaDataRequest = createAttachmentContentMetadata(
					content);
			OrgCommunity orgCommunity = orgCommunityRepository.findByCommunityId(content.getCommunityId());
			log.info("OrgCommunity config id : " + orgCommunity.getConfigId());
			HttpHeaders headers = getRequestHeader();
			HttpEntity<AttachmentContentMetaDataRequest> entity = new HttpEntity<AttachmentContentMetaDataRequest>(
					attachmentContentMetaDataRequest, headers);
			ResponseEntity<ResponseId> responseId = akilaRestTemplate.postForEntity(loadBalancedRestTemplate,
					batchJobServiceURL + "/jobs/attachment?confId=" + orgCommunity.getConfigId(), entity,
					ResponseId.class);
			String jobId = responseId.getBody().getId();
			log.info("Job created id : " + jobId);
			uploadAttachedFiles(getOrgId(), jobId, content.getFileList(), getUserId());
			ResponseEntity<ResponseId> responseEntity = akilaRestTemplate.exchange(loadBalancedRestTemplate,
					batchJobServiceURL + "/jobs/run?jobId=" + jobId, HttpMethod.GET, new HttpEntity<Object>(headers),
					ResponseId.class);
			log.info("Job submitted id : " + responseEntity.getBody().getId());
		}
		return new ResponseId(content.getContentId());
	}

	private AttachmentContentMetaDataRequest createAttachmentContentMetadata(ContentItemProcessor content) {
		log.info("Start inserting data of attachment into db");
		AttachmentContentMetaDataRequest attachmentContentMetaDataRequest = new AttachmentContentMetaDataRequest();
		List<FileMetaDataJsonList> fileMetaDataJsonLists = new ArrayList<>();
		for (String file : content.getFileList()) {
			OrgContentMetadata orgContentMetadata = contentitemMapper.contentitemProcessorToOrgContentMetadata(content);
			FileMetaDataJsonList dataJsonList = new FileMetaDataJsonList();
			if (orgContentMetadata.getCommunityId() != null && orgContentMetadata.getCommunityId().trim().isEmpty()) {
				orgContentMetadata.setCommunityId(null);
			}
			orgContentMetadata.setContentId(UUID.randomUUID().toString());
			log.info("ContentId " + orgContentMetadata.getContentId());
			orgContentMetadata.setCrtTs(new Timestamp(new Date().getTime()));
			orgContentMetadata.setFileNm(file);
			orgContentMetadata.setContentTypeCd(Integer.valueOf(contentTypeAttachment));
			orgContentMetadata.setActionStatusCd(0);
			int index = file.lastIndexOf('.');
			String extension = "";
			if (index > 0) {
				extension = file.substring(index + 1);
			}
			orgContentMetadata.setMediaCd(getMediaType(extension));
			orgContentMetadata.setContentStatusCd(0);
			orgContentMetadata.setTitle(file);
			orgContentMetadata.setVersionNum(1);
			orgContentMetadataRepository.save(orgContentMetadata);
			OrgContentRelationship relationShip = contentitemMapper
					.contentitemProcessorToOrgContentRelationship(content);
			if (content.getContentTypeCd() == contentTypeQuery) {
				relationShip.setRootContentId(content.getContentId());
				relationShip.setParentContentId(content.getContentId());
			} else {
				relationShip.setParentContentId(content.getContentId());
			}
			relationShip.setContentId(orgContentMetadata.getContentId());
			orgContentRelationshipRepository.save(relationShip);
			uploadAttachedFilesInStorage(getOrgId(), relationShip.getContentId(), file, relationShip.getUserId());
			dataJsonList.setContentId(orgContentMetadata.getContentId());
			dataJsonList.setFileName(file);
			fileMetaDataJsonLists.add(dataJsonList);
		}
		attachmentContentMetaDataRequest.setFileMetaDataJsonList(fileMetaDataJsonLists);
		if (content.getContentTypeCd() == contentTypeQuery) {
			attachmentContentMetaDataRequest.setRootContentId(content.getContentId());
			attachmentContentMetaDataRequest.setParentContentId(content.getContentId());
		} else {
			attachmentContentMetaDataRequest.setRootContentId(content.getRootContentId());
			attachmentContentMetaDataRequest.setParentContentId(content.getContentId());
		}
		attachmentContentMetaDataRequest.setRootContentType(content.getContentType());
		attachmentContentMetaDataRequest
				.setChildContentType(contentTypeCodeMap.get(Integer.valueOf(contentTypeAttachment)));
		attachmentContentMetaDataRequest.setTags(content.getTagList());
		return attachmentContentMetaDataRequest;
	}

	private void uploadAttachedFiles(String orgId, String jobId, List<String> fileList, String userId) {
		log.info("Start uploading data into s3 storage folder");
		fileList.forEach(file -> {
			StorageRequest request = new StorageRequest();
			request.setOrgId(getStorageFolder());
			request.setContentType("ent-cont");
			request.setFormatType("original/" + jobId);
			request.setContentId(file);
			File f = new File(uploadFolder + "/" + getUserId() + "/" + file);
			try {
				InputStream in = new FileInputStream(f);
				request.setContent(in);
				Map<String, String> userMap = new HashMap<String, String>();
				userMap.put("uploadBy", getUserId());
				s3StorageService.putObject(request, userMap);
				in.close();
				f.delete();
			} catch (FileNotFoundException e) {
				log.error("ContentItemService.uploadAttachedFiles : File Not found " + e.getMessage());
			} catch (HttpStatusCodeException e) {
				log.error("ContentItemService.uploadAttachedFiles : HttpStatusCodeException " + e.getMessage());
			} catch (NullPointerException e) {
				log.error("ContentItemService.uploadAttachedFiles : Error while uploading file to Azure Storage "
						+ e.getMessage());
			} catch (Exception e) {
				log.error("ContentItemService.uploadAttachedFiles : Exception " + e.getMessage());
			}
		});
	}
	
	private void uploadAttachedFilesInStorage(String orgId, String contentid, String file, String userId) {
		log.info("ContentItemService.uploadAttachedFilesInStorage : Start uploading data into s3 storage folder");
			StorageRequest request = new StorageRequest();
			request.setOrgId(getStorageFolder());
			request.setContentType("ent-cont");
			request.setFormatType("original/" + contentid);
			request.setContentId(file);
			File f = new File(uploadFolder + "/" + getUserId() + "/" + file);
			try {
				InputStream in = new FileInputStream(f);
				request.setContent(in);
				Map<String, String> userMap = new HashMap<String, String>();
				userMap.put("uploadBy", getUserId());
				s3StorageService.putObject(request, userMap);
				in.close();
				f.delete();
			} catch (FileNotFoundException e) {
				log.error("ContentItemService.uploadAttachedFilesInStorage : File Not found " + e.getMessage());
			} catch (HttpStatusCodeException e) {
				log.error("ContentItemService.uploadAttachedFilesInStorage : HttpStatusCodeException " + e.getMessage());
			} catch (NullPointerException e) {
				log.error("ContentItemService.uploadAttachedFilesInStorage : Error while uploading file to Azure Storage "
						+ e.getMessage());
			} catch (Exception e) {
				log.error("ContentItemService.uploadAttachedFilesInStorage : Exception " + e.getMessage());
			}
	}

	private String getStorageFolder() {
		BaseOrgs org = baseOrgService.getBaseOrgs(getOrgId());
		if (org != null) {
			if (org.getStorageFolderNm() != null && org.getStorageFolderNm().trim().length() > 0) {
				log.info("getStorageFolder : StorageFolder : " + org.getStorageFolderNm() + ", orgId : " + getOrgId());
				return org.getStorageFolderNm();
			}
		}
		log.info("getStorageFolder : StorageFolder : No strorage folder for org, orgId : " + getOrgId());
		return null;
	}

	public ResponseId deleteContentMetaData(ContentItemProcessor content) {
		orgContentMetadataRepository.deleteById(content.getContentId());
		return new ResponseId(content.getContentId());
	}

	public void updateContent(String id, ContentItemProcessor content)
			throws JsonMappingException, JsonProcessingException, Exception {
		OrgContentMetadata metaData = orgContentMetadataRepository.findById(id).orElse(null);
		if (metaData == null) {
			throw new RuntimeException();
		}
		if (metaData.getContentTypeCd() == contentTypeQuery) {
			content.setActionStatusCd(metaData.getActionStatusCd());
		}
		content.setAuthor(metaData.getAuthor());
		content.setContentId(id);
		content.setCreatedByUserId(metaData.getCreatedByUserId());
		createStrippedContentVersion(content);
		createOriginalContentCopy(content);
		if (content.getContentTypeCd() == contentTypeQuery) {
			OrgCommunity orgCommunity = orgCommunityRepository.findByCommunityId(content.getCommunityId());
			content.setConfId(orgCommunity.getConfigId());
		}
		content.setCrtTs(metaData.getCrtTs());
		content.setModTs(new Timestamp(new Date().getTime()));
		createContentMetaData(content);
		String html = content.getContent();
		html = html.replaceAll("&lt;", "<");
		html = html.replaceAll("&gt;", ">");
		content.setContent(Jsoup.parse(html).body().text());
		createContentIndex(content);
		
		try {
            createNotification(content.getContentId(), content.getContentTypeCd(), "Update", content.getTaggedUserIds());
		} catch (Exception e) {
			log.error("Exception while sending Notification: " + e.getMessage());
		}
		
	}

	@Transactional
	public ResponseId deleteContent(String id, String contentType)
			throws JsonMappingException, JsonProcessingException, Exception {
		OrgContentMetadata metaData = orgContentMetadataRepository.findById(id).orElse(null);

		if (metaData == null) {
			/*
			 * Removed null pointer exception throw clause from here to avoid 500 error and
			 * to delete the data from elastic search if the data is not present in the db
			 * but is there in elastic.
			 */
			deleteContentIndex(contentType, id);
			return new ResponseId(id);
		}

		ContentItemProcessor content = new ContentItemProcessor(metaData);

		List<OrgContentMetadata> relationshipData = orgContentMetadataRepository.findChildren(content.getContentId());
		for (OrgContentMetadata children : relationshipData) {
			ContentItemProcessor childContent = new ContentItemProcessor(children);
			deleteStrippedContentVersion(childContent);
			deleteOriginalContentCopy(childContent);
			deleteContentIndex(childContent, contentType);
			ContentItemResponse child = contentitemMapper.orgContentMetadataToContentitemResponse(children);
			OrgContentRelationship relationShip = orgContentRelationshipRepository.getOne(child.getId());
			orgContentRelationshipRepository.deleteById(relationShip.getContentId());
			deleteRelatedEntiries(children.getContentId());
			orgContentMetadataRepository.deleteById(children.getContentId());
		}

		// set ContentType to resolve bug
		content.setContentType(contentTypeCodeMap.get(content.getContentTypeCd()).toLowerCase());

		deleteContentIndex(content, contentType);
		deleteRelatedEntiries(content.getContentId());
		deleteStrippedContentVersion(content);
		deleteOriginalContentCopy(content);
		deleteContentMetaData(content);

		return new ResponseId(id);
	}

	public void deleteRelatedEntiries(String contentId) {

		// Delete from Matrix Table
		if (orgContentMetricRepository.existsById(contentId)) {
			orgContentMetricRepository.deleteById(contentId);
		}

		/*
		 * // Fetch Content History Data List<OrgContentMetadataHistory>
		 * orgUserContentMetaHistoryData =
		 * orgContentMetadataHistoryRepository.findByContentId(contentId); // Delete
		 * Content History Data for(OrgContentMetadataHistory history :
		 * orgUserContentMetaHistoryData) {
		 * orgContentMetadataHistoryRepository.deleteById(history.getContentId()); }
		 */

		// Fetch Content Favorite Link Data
		List<OrgUserFavLink> orgUserFavLinkData = orgUserFavLinkRepository.findByContentId(contentId);
		// Delete Content Favorite Link Data
		for (OrgUserFavLink favorite : orgUserFavLinkData) {
			orgUserFavLinkRepository.deleteById(favorite.getId());
		}

		orgContentMetricRepository.deleteByContentId(contentId);

		// Fetch Content User MetaData
		List<OrgUserContentMetadata> OrgUserContentMetadataList = orgUserContentMetadataRepository
				.getByContentId(contentId);
		// Delete Content User MetaData
		for (OrgUserContentMetadata orgUserContentMetadata : OrgUserContentMetadataList) {
			orgUserContentMetadataRepository.deleteById(orgUserContentMetadata.getId());
		}

	}

	public ContentItemResponse getContent(String id, String contentType)
			throws IOException, JsonMappingException, JsonProcessingException, Exception {
		String orgId = getS3BucketName();
		String userId = getUserId();
		OrgContentMetadata metaData = orgContentMetadataRepository.getOne(id);
		List<OrgContentMetadata> relationshipData = orgContentMetadataRepository.findChildren(id);
		ContentItemResponse itemResponse = contentitemMapper.orgContentMetadataToContentitemResponse(metaData);
		StorageRequest storageRequest = getStorageRequest(itemResponse, contentType);
		storageRequest.setModTs(itemResponse.getModTs());
		storageRequest.setUserId(userId);
		storageRequest.setOrgId(orgId);
		StorageResponse response = s3StorageService.getContent(storageRequest);
		itemResponse.setContent(new String(response.getContent()));
		List<ContentItemResponse> childrenResponse = new ArrayList<>();
		for (OrgContentMetadata children : relationshipData) {
			ContentItemResponse child = contentitemMapper.orgContentMetadataToContentitemResponse(children);
			if (children.getContentTypeCd() != Integer.valueOf(contentTypeAttachment)) {
				StorageRequest childStorageRequest = getStorageRequest(child, contentType);
				childStorageRequest.setUserId(userId);
				childStorageRequest.setOrgId(orgId);
				childStorageRequest.setModTs(child.getModTs());
				StorageResponse childResponse = s3StorageService.getContent(childStorageRequest);
				child.setContent(new String(childResponse.getContent()));
			} else {
				child.setContent("");
			}
			OrgContentRelationship relationShip = orgContentRelationshipRepository.getOne(child.getId());
			child.setParentContentId(relationShip.getParentContentId());
			childrenResponse.add(child);
		}
		itemResponse.setChildren(childrenResponse);
		return itemResponse;
	}

	public ResponseId transcribe(String id, ContentItemRequest contentitemRequest) {
		return null;
	}

	public ResponseId createClassificationRequest(ContentItemRequest contentitemRequest) {
		return null;
	}

	private ContentItemProcessor stripContent(ContentItemProcessor content) {
		return content;
	}

	private void createContentMetric(ContentItemProcessor content) {
		try {
			ContentMetricRequest request = new ContentMetricRequest();
			request.setDownVotes(0);
			request.setInteractionCount(0);
			request.setUpVotes(0);
			request.setModTs(new Timestamp(new Date().getTime()));
			HttpEntity<ContentMetricRequest> entity = new HttpEntity<ContentMetricRequest>(request, getRequestHeader());
			akilaRestTemplate.postForEntity(loadBalancedRestTemplate,
					metricServiceURL + "/metric/content/" + content.getContentId(), entity, ResponseId.class);
		} catch (RestClientException e) {
			log.error("ContentItemService:createMetric -Error :  " + e.getMessage(), e);
		}
	}

	public ResponseId createContent(ContentItemProcessor content)
			throws JsonMappingException, JsonProcessingException, Exception {
		ResponseId responseId = createContentWithTransactional(content);
		createContentMetric(content);
		try {
			sendEmail(responseId.getId(), content.getContentTypeCd(), content.getTaggedUserIds());
		} catch (Exception e) {
			log.error("Exception while sending email " + e.getMessage());
		}
		try {
            createNotification(responseId.getId(), content.getContentTypeCd(), "Create", content.getTaggedUserIds());
		} catch (Exception e) {
			log.error("Exception while sending Notification: " + e.getMessage());
		}
		return responseId;
	}

	@Transactional
	public ResponseId createContentWithTransactional(ContentItemProcessor content)
			throws JsonMappingException, JsonProcessingException, Exception {
		content.setCreatedByUserId(getUserId());
		content.setAuthor(getUserId());
		content.setContentId(UUID.randomUUID().toString());
		content.setCreatedByUserId(getUserId());
		content = stripContent(content);
		createStrippedContentVersion(content);
		createOriginalContentCopy(content);
		if (content.getContentTypeCd() == contentTypeQuery) {
			OrgCommunity orgCommunity = orgCommunityRepository.findByCommunityId(content.getCommunityId());
			content.setConfId(orgCommunity.getConfigId());
		}
		Timestamp timestamp = new Timestamp(new Date().getTime());
		content.setCrtTs(timestamp);
		content.setModTs(timestamp);
		ResponseId responseId = createContentMetaData(content);
		String html = content.getContent();
		html = html.replaceAll("&lt;", "<");
		html = html.replaceAll("&gt;", ">");
		content.setContent(Jsoup.parse(html).body().text());
		createContentIndex(content);
		return responseId;
	}

	private StorageRequest getStorageRequest(ContentItemProcessor content)
			throws JsonMappingException, JsonProcessingException, Exception {
		StorageRequest request = new StorageRequest();
		request.setOrgId(getS3BucketName());

		request.setContent(content.getContent());
		request.setInputStreamType("String");
		request.setUserId(getUserId());
		request.setFormatType(content.getFormatType());
		request.setContentType(content.getContentType());
		request.setContentId(content.getContentId());
		return request;
	}

	private StorageRequest getStorageRequest(ContentItemResponse content, String contentType)
			throws JsonMappingException, JsonProcessingException, Exception {
		StorageRequest request = new StorageRequest();
		request.setInputStreamType(StorageStreamType.STRING.name());
		request.setFormatType(ContentFormatType.ORIGINAL.getValue());
		request.setContentType(contentType);
		request.setContentId(content.getId());
		return request;
	}

	public TagList getTagList(String[] tagList) {
		String sql = "select  b.ref_code_display_val,ot.tag_mnemonic from org_tags ot  inner join "
				+ "(select * from org_ref_codes orc  where ref_code_type_id in ( select ref_code_type_id from base_ref_code_types brct where ref_code_type = 'TAG_TYPE_CD')) b "
				+ "on ot.tag_type_cd  = b.ref_code_store_val " + "where tag_id in :tagId";
		Query query = entityManager.createNativeQuery(sql);
		query.setParameter("tagId", Arrays.asList(tagList));
		List<Object[]> resultList = query.getResultList();
		TagList tagListObj = new TagList();
		for (Object[] obj : resultList) {
			tagListObj.addValues("tag_" + obj[0].toString().replaceAll(" ", "_").toLowerCase(), (String) obj[1]);
		}

		return tagListObj;
	}

	private boolean isCommentOrResponse(ContentItemProcessor content) {
		return content.getParentContentId() != null && !content.getParentContentId().trim().isEmpty()
				&& (contentTypeCodeMap.get(content.getContentTypeCd()).equalsIgnoreCase("Comment")
						|| contentTypeCodeMap.get(content.getContentTypeCd()).equalsIgnoreCase("answer")
						|| contentTypeCodeMap.get(content.getContentTypeCd()).equalsIgnoreCase("followup"));

	}

	private String getS3BucketName() throws JsonMappingException, JsonProcessingException, Exception {
		HttpEntity<String> entity = new HttpEntity<String>("Org-Details", super.getRequestHeader());
		ResponseEntity<String> response = akilaRestTemplate.exchange(loadBalancedRestTemplate,
				platformServiceURL + "/orgs/" + getOrgId(), HttpMethod.GET, entity, String.class);
		String responseBody = response.getBody();
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode node = objectMapper.readTree(responseBody);
		String ssStorageFolder = node.get("storageFolderNm").asText();
		log.info("ssStorageFolder : " + ssStorageFolder + ". OrgId : " + getOrgId());
		return ssStorageFolder;
	}

	public List<ContentItemResponse> getAllQueryContent(String contentType, String actionStatusCd)
			throws IOException, JsonMappingException, JsonProcessingException, Exception {
		List<OrgContentMetadata> contentMetadatas = new ArrayList<>();
		String orgId = getS3BucketName();
		String userId = getUserId();
		if (actionStatusCd != null && !actionStatusCd.isEmpty() && !actionStatusCd.equalsIgnoreCase("-1")) {
			contentMetadatas = orgContentMetadataRepository.findAllQueryContentByUserIdAndActionStatusCd(getUserId(),
					Integer.valueOf(contentType), Integer.valueOf(actionStatusCd));
		} else {
			contentMetadatas = orgContentMetadataRepository.findAllQueryContentByUserIdAndContentType(getUserId(),
					Integer.valueOf(contentType));
		}
		List<ContentItemResponse> itemResponse = contentitemMapper
				.orgContentMetadataToContentitemResponseList(contentMetadatas);
		itemResponse.forEach(response -> {
			StorageRequest storageRequest = null;
			try {
				storageRequest = getStorageRequest(response, ContentType.QUERY.getValue());
				storageRequest.setUserId(userId);
				storageRequest.setOrgId(orgId);
				storageRequest.setContentMaxLength(askContentLength);
				storageRequest.setModTs(response.getModTs());
				StorageResponse storageResponse = s3StorageService.getContent(storageRequest);
				response.setContent(new String(storageResponse.getContent()));
			} catch (JsonMappingException e) {
				log.error("ContentItemService:getAllQueryContent - JsonMappingException : " + e.getMessage());
			} catch (JsonProcessingException e) {
				log.error("ContentItemService:getAllQueryContent - JsonProcessingException : " + e.getMessage());
			} catch (Exception e) {
				log.error("ContentItemService:getAllQueryContent - Exception :  " + e.getMessage());
			}
		});
		return itemResponse;
	}

	public List<ContentItemResponse> getAllWikis(String contentType, String contentStatusCd)
			throws IOException, JsonMappingException, JsonProcessingException, Exception {
		List<OrgContentMetadata> contentMetadatas = new ArrayList<>();
		if (contentStatusCd != null && !contentStatusCd.isEmpty() && !contentStatusCd.equalsIgnoreCase("-1")) {
			contentMetadatas = orgContentMetadataRepository.findAllWikiContentByUserIdAndContentStatusCd(getUserId(),
					Integer.valueOf(contentType), Integer.valueOf(contentStatusCd));
		} else {
			contentMetadatas = orgContentMetadataRepository.findAllWikiContentByUserIdAndContentType(getUserId(),
					Integer.valueOf(contentType));
		}
		List<ContentItemResponse> itemResponse = contentitemMapper
				.orgContentMetadataToContentitemResponseList(contentMetadatas);
		return itemResponse;
	}

	private void sendEmail(String contentId, int contentType, List<String> taggedUserIds) {
		if (contentType == contentTypeQuery || contentType == contentTypeResponse
				|| contentType == contentTypeFollowup) {
			mailUtility.sendEmail(contentId, contentType, getUserId(), taggedUserIds);
		}
	}

	private void createNotification(String contentId, int contentType, String operationType, List<String> taggedUserIds) {
		if (contentType == contentTypeQuery || contentType == contentTypeResponse
				|| contentType == contentTypeFollowup) {
			notificationUtility.createNotification(contentId, contentType, operationType, taggedUserIds);
		}
	}
	
	public ContentMetaDataResponse getContentByConfigIdAndSourceFileKey(String configId, String sourceFileKey) {
		return contentMetaDataMapper.orgContentMetadataToContentitemResponse(orgContentMetadataRepository.findByConfIdAndSourceFileKey(configId, new String(Base64.getUrlDecoder().decode(sourceFileKey))));
	}

	public static Integer getMediaType(String extn) {
		Integer cd = 0;
		if (extn.equalsIgnoreCase("pdf")) {
			cd = MeddiaCd.PDF.getValue();
		} else if (extn.equalsIgnoreCase("doc") || extn.equalsIgnoreCase("docx")) {
			cd = MeddiaCd.WORD.getValue();
		} else if (extn.equalsIgnoreCase("ppt") || extn.equalsIgnoreCase("pptx")) {
			cd = MeddiaCd.PPT.getValue();
		} else if (extn.equalsIgnoreCase("xls") || extn.equalsIgnoreCase("xlsx") || extn.equalsIgnoreCase("xlsm")) {
			cd = MeddiaCd.EXCEL.getValue();
		} else if (extn.equalsIgnoreCase("txt") || extn.equalsIgnoreCase("csv") || extn.equalsIgnoreCase("json")) {
			cd = MeddiaCd.TXT.getValue();
		} else if (extn.equalsIgnoreCase("html") || extn.equalsIgnoreCase("htm")) {
			cd = MeddiaCd.HTML.getValue();
		} else if (extn.equalsIgnoreCase("tif") || extn.equalsIgnoreCase("tiff") || extn.equalsIgnoreCase("svg")
				|| extn.equalsIgnoreCase("png") || extn.equalsIgnoreCase("jpeg") || extn.equalsIgnoreCase("jpg")
				|| extn.equalsIgnoreCase("gif") || extn.equalsIgnoreCase("bmp")) {
			cd = MeddiaCd.IMAGE.getValue();
		} else if (extn.equalsIgnoreCase("msg") || extn.equalsIgnoreCase("eml") ) {
			cd = MeddiaCd.MAIL.getValue();		
		} else {
			return cd;
		}
		return cd;
	}

}
