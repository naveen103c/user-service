package com.akila.contentservices.contentitem.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TagList 
{
	private Map<String, List<String>> tags = new HashMap<>();

	public Map<String, List<String>> getTags() {
		return tags;
	}

	public void setTags(Map<String, List<String>> tags) {
		this.tags = tags;
	}
	
	public void addValues(String key, String value)
	{
		List<String> list = tags.get(key);
		if(list == null)
		{
			list = new ArrayList<>();
			tags.put(key, list);
		}
		list.add(value);
	}

}
