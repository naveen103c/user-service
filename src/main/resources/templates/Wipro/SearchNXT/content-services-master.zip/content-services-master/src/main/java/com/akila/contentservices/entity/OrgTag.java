package com.akila.contentservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import com.akila.AkilaEntity;


/**
 * The persistent class for the org_tags database table.
 * 
 */
@Entity
@Table(name="org_tags")
@NamedQuery(name="OrgTag.findAll", query="SELECT o FROM OrgTag o")
public class OrgTag extends AkilaEntity implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="tag_id")
	private String tagId;

	private String description;

	@Column(name="keyword_list")
	private String keywordList;

	@Column(name="tag_mnemonic")
	private String tagMnemonic;

	@Column(name="tag_type_cd")
	private Integer tagTypeCd;

	public OrgTag() {
	}

	public String getTagId() {
		return this.tagId;
	}

	public void setTagId(String tagId) {
		this.tagId = tagId;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getKeywordList() {
		return this.keywordList;
	}

	public void setKeywordList(String keywordList) {
		this.keywordList = keywordList;
	}

	public String getTagMnemonic() {
		return this.tagMnemonic;
	}

	public void setTagMnemonic(String tagMnemonic) {
		this.tagMnemonic = tagMnemonic;
	}

	public Integer getTagTypeCd() {
		return this.tagTypeCd;
	}

	public void setTagTypeCd(Integer tagTypeCd) {
		this.tagTypeCd = tagTypeCd;
	}

}