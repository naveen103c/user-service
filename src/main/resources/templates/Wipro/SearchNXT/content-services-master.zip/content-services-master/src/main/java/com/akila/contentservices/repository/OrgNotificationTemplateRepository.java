package com.akila.contentservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgNotificationTemplate;


@Repository
public interface OrgNotificationTemplateRepository extends JpaRepository<OrgNotificationTemplate, String>{

	OrgNotificationTemplate findByTemplateName(String templateName);

}
