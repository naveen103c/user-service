package com.akila.contentservices.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the base_user_prefs database table.
 * 
 */
@Entity
@Table(name = "base_user_pref")
@NamedQuery(name = "BaseUserPref.findAll", query = "SELECT o FROM BaseUserPref o")
public class BaseUserPref implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "pref_id")
	private String id;

	@Column(name = "pref_type_cd")
	private Integer prefTypeCd;

	@Column(name = "pref_nm")
	private String prefNm;

	@Column(name = "pref_control_type_cd")
	private Integer prefControlTypeCd;

	@Column(name = "pref_options")
	private String prefOptions;

	@Column(name = "pref_default")
	private String prefDefault;

	@Column(name = "parent_pref_id")
	private String parentPrefId;
	
	@Column(name = "active")
	private Boolean active;

	public BaseUserPref() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getPrefTypeCd() {
		return prefTypeCd;
	}

	public void setPrefTypeCd(Integer prefTypeCd) {
		this.prefTypeCd = prefTypeCd;
	}

	public String getPrefNm() {
		return prefNm;
	}

	public void setPrefNm(String prefNm) {
		this.prefNm = prefNm;
	}

	public Integer getPrefControlTypeCd() {
		return prefControlTypeCd;
	}

	public void setPrefControlTypeCd(Integer prefControlTypeCd) {
		this.prefControlTypeCd = prefControlTypeCd;
	}

	public String getPrefOptions() {
		return prefOptions;
	}

	public void setPrefOptions(String prefOptions) {
		this.prefOptions = prefOptions;
	}

	public String getPrefDefault() {
		return prefDefault;
	}

	public void setPrefDefault(String prefDefault) {
		this.prefDefault = prefDefault;
	}

	public Boolean getActive() {
		return active;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public String getParentPrefId() {
		return parentPrefId;
	}

	public void setParentPrefId(String parentPrefId) {
		this.parentPrefId = parentPrefId;
	}

	@Override
	public String toString() {
		return "BaseUserPref [id=" + id + ", prefTypeCd=" + prefTypeCd + ", prefNm=" + prefNm + ", prefControlTypeCd="
				+ prefControlTypeCd + ", prefOptions=" + prefOptions + ", prefDefault=" + prefDefault
				+ ", parentPrefId=" + parentPrefId + ", active=" + active + "]";
	}
}