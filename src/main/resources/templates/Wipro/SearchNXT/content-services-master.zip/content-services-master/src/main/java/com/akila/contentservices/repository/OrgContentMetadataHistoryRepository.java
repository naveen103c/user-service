package com.akila.contentservices.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgContentMetadataHistory;

@Repository
public interface OrgContentMetadataHistoryRepository extends JpaRepository<OrgContentMetadataHistory, String> 
{
	@Query("select o from OrgContentMetadataHistory o where contentId = :contentId")
	public List<OrgContentMetadataHistory> findByContentId(String contentId);
}
