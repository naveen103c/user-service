package com.akila.contentservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.akila.contentservices.entity.OrgEmailTemplate;


@Repository
public interface OrgEmailTemplateRepository extends JpaRepository<OrgEmailTemplate, String>{

	OrgEmailTemplate findByName(String templateName);

}
