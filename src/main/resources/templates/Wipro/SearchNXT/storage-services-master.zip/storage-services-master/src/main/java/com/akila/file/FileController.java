package com.akila.file;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


@RestController
public class FileController {
	private static final Logger logger = LogManager.getLogger(FileController.class);
	
	@Value("${content.strorage.path}")
	String contentStroragePath;
	
	@PostMapping(path = "/file")
	public String putFile(
			@RequestParam("file") MultipartFile file, @RequestHeader String bucketName, @RequestHeader String contentType, 
			@RequestHeader String formatType, @RequestHeader String contentId) throws IOException ,Exception  {
		String filePath = contentStroragePath+"/"+bucketName+"/"+contentType+"/"+formatType;
		logger.info("putFile : "+filePath);
		File f = new File(filePath);
		if(!f.exists()) {
			Path path = Paths.get(filePath);
		    Files.createDirectories(path);
		}
		
		OutputStream out  = new FileOutputStream(filePath+"/"+contentId);
		
		//ByteArrayOutputStream bos = new ByteArrayOutputStream();

		FileCopyUtils.copy(file.getInputStream(), out);
		out.close();
		
		return "";
	}
	
	@GetMapping(path = "/file")
	public ResponseEntity<Resource> getFile(@RequestHeader String bucketName, @RequestHeader String contentType, 
			@RequestHeader String formatType, @RequestHeader String contentId, HttpServletRequest request) throws MalformedURLException, Exception  {
		
		String filePath = contentStroragePath+"/"+bucketName+"/"+contentType+"/"+formatType+"/"+contentId;
		logger.info("getFile : "+filePath);
		 Path path = Paths.get(filePath);
		 
         Resource resource = new UrlResource(path.toUri());
         if(resource.exists()) {
        	 return ResponseEntity.ok().contentType(MediaType.parseMediaType("application/octet-stream"))
    				 .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + "resource.getFilename()" + "\"").body(resource);
         } else {
        	 throw new Exception("File not found " + filePath);
         }
		
	}
	
	@DeleteMapping(path = "/file")
	public void deleteFile(@RequestHeader String bucketName, @RequestHeader String contentType, 
			@RequestHeader String formatType, @RequestHeader String contentId, HttpServletRequest request) throws IOException,FileNotFoundException, Exception {
		
		String filePath = contentStroragePath+"/"+bucketName+"/"+contentType+"/"+formatType+"/"+contentId;
		logger.info("deleteFile : "+filePath);
		File file = new File(filePath);
		file.delete();
		
	}
	
	@GetMapping(path = "/file/list")
	public List<String> getFileList(@RequestHeader String bucketName, @RequestHeader String contentType, 
			@RequestHeader String formatType, @RequestHeader String contentId, HttpServletRequest request) throws IOException,FileNotFoundException, Exception {
		
		String filePath = contentStroragePath+"/"+bucketName+"/"+contentType+"/"+formatType;
		logger.info("getFileList : "+filePath);
		File file = new File(filePath);
		List<String> fileList = new ArrayList<String>();
		 if(file.isDirectory()){
			 String [] sts = file.list();
			 for (int i = 0; i < sts.length; i++) {
				 fileList.add(sts[i]);
			}
		 }
		return fileList;
	}
	
	@GetMapping(path = "/file/listwithsize")
	public List<String> getFileListWithSize(@RequestHeader String bucketName, @RequestHeader String contentType, 
			@RequestHeader String formatType, @RequestHeader String contentId, HttpServletRequest request) throws IOException,FileNotFoundException, Exception {
		
		String filePath = contentStroragePath+"/"+bucketName+"/"+contentType+"/"+formatType;
		logger.info("getFileListWithSize : "+filePath);
		File file = new File(filePath);
		List<String> fileList = new ArrayList<String>();
		 if(file.isDirectory()){
			 File [] sts = file.listFiles();
			 for (int i = 0; i < sts.length; i++) {
				 fileList.add(sts[i].getName()+" : "+sts[i].length());
			}
		 }
		return fileList;
	}

}
