package com.akila.mediaTranscriptionservice;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.web.client.RestTemplate;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;


@SpringBootApplication
@EnableEncryptableProperties
@PropertySources({
	@PropertySource("classpath:app.properties"),
	@PropertySource(name="prod", value = "file:${external.config}", ignoreResourceNotFound = true)
})
public class MediaTranscriptionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MediaTranscriptionServiceApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder)
			throws NoSuchAlgorithmException, KeyManagementException {
		return builder.setConnectTimeout(Duration.ofMillis(30000)).setReadTimeout(Duration.ofMillis(30000)).build();
	}
}
