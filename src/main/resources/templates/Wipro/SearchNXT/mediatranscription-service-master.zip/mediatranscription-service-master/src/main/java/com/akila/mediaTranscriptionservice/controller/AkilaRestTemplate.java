package com.akila.mediaTranscriptionservice.controller;

import java.io.File;
import java.io.IOException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

@Service
public class AkilaRestTemplate {

	private static final Logger logger = LogManager.getLogger(AkilaRestTemplate.class);

	@Value("${api.retry.count}")
	private int retryCount;
	
	@Value("${server.ssl.key-store}")
	private String sslCertificate;
	
	@Value("${server.ssl.key-store-password}")
	private String sslPassword;

	public <T> ResponseEntity<T> exchange(RestTemplate restTemplate, String url, HttpMethod method,
			@Nullable HttpEntity<?> requestEntity, Class<T> responseType) {

		restTemplate.setRequestFactory(getRequestFactoryForCertificate());
		int apiRequestCount = 0;
		while (apiRequestCount < retryCount) {
			apiRequestCount++;
			try {
				ResponseEntity<T> response = (ResponseEntity<T>) restTemplate.exchange(url, method, requestEntity,
						responseType);
				return response;
			} catch (ResourceAccessException e) {
				logger.error("AkilaRestTemplate restTemplateExchange : " + e);
				if (apiRequestCount == retryCount) {
					throw e;
				}
			}
		}
		throw new ResourceAccessException("Exception while hitting -" + url);
	}
	

	
	public <T> ResponseEntity<T> getForEntity(RestTemplate restTemplate, String url, Class<T> responseType) {
		int apiRequestCount = 0;
		restTemplate.setRequestFactory(getRequestFactoryForCertificate());
		while (apiRequestCount < retryCount) {
			apiRequestCount++;
			try {
				ResponseEntity<T> response = restTemplate.getForEntity(url, responseType);
				return response;
			} catch (ResourceAccessException e) {
				logger.error("AkilaRestTemplate restTemplateGetForEntity : " + e);
				if (apiRequestCount == retryCount) {
					throw e;
				}
			}

		}
		throw new ResourceAccessException("Exception while hitting -" + url);

	}

	public <T> ResponseEntity<T> postForEntity(RestTemplate restTemplate, String url,
			@Nullable HttpEntity<?> requestEntity, Class<T> responseType) {
		int apiRequestCount = 0;
		restTemplate.setRequestFactory(getRequestFactoryForCertificate());
		while (apiRequestCount < retryCount) {
			apiRequestCount++;
			try {
				ResponseEntity<T> response = restTemplate.postForEntity(url, requestEntity, responseType);
				return response;
			} catch (ResourceAccessException e) {
				logger.error("AkilaRestTemplate restTemplatePostForEntity : " + e);
				if (apiRequestCount == retryCount) {
					throw e;
				}
			}
		}
		throw new ResourceAccessException("Exception while hitting -" + url);

	}

	public <T> void delete(RestTemplate restTemplate, String url, @Nullable HttpEntity<?> requestEntity,
			Class<T> responseType) {
		int apiRequestCount = 0;
		restTemplate.setRequestFactory(getRequestFactoryForCertificate());
		while (apiRequestCount < retryCount) {
			apiRequestCount++;
			try {
				restTemplate.delete(url, requestEntity, responseType);
				break;
			} catch (ResourceAccessException e) {
				logger.error("AkilaRestTemplate delete : " + e);
				if (apiRequestCount == retryCount) {
					throw e;
				}
			}
		}
	}

	private ClientHttpRequestFactory getRequestFactoryForCertificate() {
		ClientHttpRequestFactory requestFactory = null;
		javax.net.ssl.SSLContext  sslContext = null;
		try {
			sslContext = SSLContextBuilder.create().loadTrustMaterial(new File(sslCertificate), sslPassword.toCharArray()).build();
			SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext, new MyHostnameVerifier());
			HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();
			requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
		} catch (NoSuchAlgorithmException | CertificateException | IOException e) {
			logger.error("AkilaRestTemplate getRequestFactoryForCertificate : " + e);
		} catch (KeyStoreException e) {
			logger.error("AkilaRestTemplate getRequestFactoryForCertificate : " + e);
		} catch (Exception e) {
			logger.error("AkilaRestTemplate getRequestFactoryForCertificate : " + e);
		}
		return requestFactory;
	}
	
}

/**
 * Verify that the host name is an acceptable match with
 * the server's authentication scheme.
 *
 * @param hostname the host name
 * @param session SSLSession used on the connection to host
 * @return true if the host name is acceptable
 */
class MyHostnameVerifier implements HostnameVerifier {

	@Override
	public boolean verify(String hostname, SSLSession session) {
		return true;
	}
}
