package com.akila.mediaTranscriptionservice.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class TranscriptionController {

	@Autowired
	private TranscriptionService transcriptionService;

	@PostMapping(path = "/transcript")
	public ResponseEntity<Response> transcriptMedia(@RequestParam(name = "file", required = false) MultipartFile file,@RequestParam( name = "filePath", required = false)  String filePath) throws IOException {

		Response response = transcriptionService.transcriptMedia(file,filePath);

		if (response.getStatus().equals("200")) {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		} else if (response.getStatus().equals("504")) {
			return new ResponseEntity<Response>(response, HttpStatus.GATEWAY_TIMEOUT);
		}else {
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping(path = "/transcript/{requestId}")
	public ResponseEntity<Response> getTranscriptionStatus(@PathVariable String requestId) {
		
		Response response = transcriptionService.getTranscriptionStatus(requestId);
		
		if (response.getStatus().equals("200")) {
			return new ResponseEntity<Response>(response, HttpStatus.OK);
		}else if(response.getStatus().equals("202")) {
			return new ResponseEntity<Response>(response, HttpStatus.ACCEPTED);
		} else if(response.getStatus().equals("404")) {
			return new ResponseEntity<Response>(response, HttpStatus.NOT_FOUND);
		} else if (response.getStatus().equals("504")) {
			return new ResponseEntity<Response>(response, HttpStatus.GATEWAY_TIMEOUT);
		} else {
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
