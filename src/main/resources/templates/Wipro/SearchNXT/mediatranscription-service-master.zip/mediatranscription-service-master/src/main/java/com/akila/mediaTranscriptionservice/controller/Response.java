package com.akila.mediaTranscriptionservice.controller;

import java.util.Map;

public class Response 
{
	private String status;
	private Map<String,String> responseMap;
	
	public Response()
	{
		
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Map<String, String> getResponseMap() {
		return responseMap;
	}

	public void setResponseMap(Map<String, String> responseMap) {
		this.responseMap = responseMap;
	}


}
