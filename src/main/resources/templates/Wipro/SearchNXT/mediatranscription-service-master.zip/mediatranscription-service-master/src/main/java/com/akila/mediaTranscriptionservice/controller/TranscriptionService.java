package com.akila.mediaTranscriptionservice.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

@Service
public class TranscriptionService {

	private static Logger logger = LogManager.getLogger(TranscriptionService.class);

	@Value("${video.transscript.api.url}")
	private String transcriptMediaPythonIp;

	@Value("${video.transscript.status.api.url}")
	private String transcriptStatusPythonIp;

	/**
	 * Python punctuate transcript API URL field
	 */
	@Value("${video.transscript.punctuation.api.url}")
	private String transcriptPunctuationPythonIp;

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private AkilaRestTemplate akilaRestTemplate;

	public Response transcriptMedia(MultipartFile file,String filePath) throws IOException {

		logger.info("Start of API transcriptMedia call---> File name is - " + file != null ? file.getOriginalFilename() : filePath);
		String requestId = UUID.randomUUID().toString();
		Map<String, String> responseMap = new HashMap<String, String>();
		Response resp = new Response();
		ResponseEntity<String> response;
		try {
			
			if(filePath == null)
				response = this.transcriptWithFile(file, requestId);
			else
				response = this.transcriptWithFileName(filePath, requestId);
		} catch (RestClientException e) {
			logger.info("RestClientException occoured transcriptMedia "+e);
			resp.setStatus(String.valueOf(HttpStatus.GATEWAY_TIMEOUT.value()));
			responseMap.put("message", HttpStatus.GATEWAY_TIMEOUT.getReasonPhrase());
			resp.setResponseMap(responseMap);
			return resp;
		} catch (Exception e1) {
			logger.info("Exception occoured inside transcriptMedia "+e1);
			resp.setStatus(String.valueOf(HttpStatus.GATEWAY_TIMEOUT.value()));
			responseMap.put("message", HttpStatus.GATEWAY_TIMEOUT.getReasonPhrase());
			resp.setResponseMap(responseMap);
			return resp;
		}

		HttpStatus status = response.getStatusCode();
		if (status.equals(HttpStatus.OK)) {
			logger.info("End of execution of transcriptMedia API call with requestId = " + requestId
					+ " response is ---->" + response);
			String message = null, responseStatus = null;
			JSONObject json;
			try {
				json = new JSONObject(response.getBody());
				responseStatus = json.getString("status");
				message = json.getString("message");
			} catch (JSONException e) {
				e.printStackTrace();
				logger.info("Exception occured while converting string to JSON");
			}
			if (responseStatus.equalsIgnoreCase("true")) {
				resp.setStatus(String.valueOf(HttpStatus.OK.value()));
				responseMap.put("requestId", requestId);
				responseMap.put("message", message);
				resp.setResponseMap(responseMap);
				return resp;
			} else {
				resp.setStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
				responseMap.put("message", message);
				resp.setResponseMap(responseMap);
				return resp;
			}
		} else {
			logger.info("End of execution of transcriptMedia API call with error for requestId = " + requestId
					+ " response is ---->" + response);
			resp.setStatus(String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()));
			responseMap.put("message", HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase());
			resp.setResponseMap(responseMap);
			return resp;
		}
	}
	
	public ResponseEntity<String> transcriptWithFileName(String filePath,String requestId) throws RestClientException, Exception {

		String pythonurl = transcriptMediaPythonIp + "request_id=" + requestId + "&filePath=" + filePath;
		logger.info("transcriptWithFileName --> transcriptMediaPythonIp : " + pythonurl);
		return akilaRestTemplate.postForEntity(restTemplate, pythonurl, null, String.class);
	}
	
	public ResponseEntity<String> transcriptWithFile(MultipartFile file,String requestId) throws RestClientException, Exception {

		MultiValueMap<String, String> fileMap = new LinkedMultiValueMap<>();

		ContentDisposition contentDisposition = ContentDisposition.builder("form-data").name("file")
				.filename(file.getOriginalFilename()).build();
		HttpHeaders headers1 = new HttpHeaders();
		headers1.setContentType(MediaType.MULTIPART_FORM_DATA);
		fileMap.add(HttpHeaders.CONTENT_DISPOSITION, contentDisposition.toString());
		HttpEntity<byte[]> fileEntity = new HttpEntity<>(file.getBytes(), fileMap);

		MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
		body.add("file", fileEntity);

		HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers1);
		ResponseEntity<String> response;
		String pythonurl = transcriptMediaPythonIp + "request_id=" + requestId;
		logger.info("transcriptWithFile -- > transcriptMediaPythonIp : " + pythonurl);
		response = akilaRestTemplate.postForEntity(restTemplate, pythonurl, requestEntity, String.class);
		return response;
	}

	public Response getTranscriptionStatus(String requestId) {
		logger.info("Start of execution of getTranscriptionStatus API call with requestId = " + requestId);
		Map<String, String> responseMap = new HashMap<String, String>();
		Response resp = new Response();
		ResponseEntity<String> response;
		try {
			String pythonurl = transcriptStatusPythonIp+"request_id="+requestId;
			logger.info("transcriptStatusPythonIp : " + pythonurl);
			response = akilaRestTemplate.getForEntity(restTemplate, pythonurl, String.class);
		} catch (RestClientException e) {
			logger.info("Exception occoured inside getTranscriptionStatus "+e);
			resp.setStatus(String.valueOf(HttpStatus.GATEWAY_TIMEOUT.value()));
			responseMap.put("message", HttpStatus.GATEWAY_TIMEOUT.getReasonPhrase());
			resp.setResponseMap(responseMap);
			return resp;
		} catch (Exception e1) {
			logger.info("Exception occoured inside getTranscriptionStatus "+e1);
			resp.setStatus(String.valueOf(HttpStatus.GATEWAY_TIMEOUT.value()));
			responseMap.put("message", HttpStatus.GATEWAY_TIMEOUT.getReasonPhrase());
			resp.setResponseMap(responseMap);
			return resp;
		}

		logger.info("End of execution of getTranscriptionStatus API call with error for requestId = " + requestId
				+ " response is ---->" + response);
		HttpStatus status = response.getStatusCode();

		if (status.equals(HttpStatus.OK)) {
			String message = null, data = null, responseStatus = null, progress = null, transcript = null;
			JSONObject json, dataJson;
			try {
				json = new JSONObject(response.getBody());
				responseStatus = json.getString("status");
				message = json.getString("message");
				data = json.getString("data");
				dataJson = new JSONObject(data);
				if (responseStatus.equalsIgnoreCase("true")) {
					progress = dataJson.getString("progress");
				}
				if (progress != null && progress.equals("100")) {
					transcript = dataJson.getString("transcript");
				}
			} catch (JSONException e) {
				e.printStackTrace();
				logger.info("Exception occured while converting string to JSON");
			}
			if (responseStatus.equalsIgnoreCase("true")) {
				if (Integer.parseInt(progress) == 100) {
					return getTranscriptionPunctuation(transcript, requestId);
				} else {
					resp.setStatus(String.valueOf(HttpStatus.ACCEPTED.value()));
					responseMap.put("progress", progress);
					responseMap.put("message", message);
					resp.setResponseMap(responseMap);
					return resp;
				}
			} else {
				resp.setStatus(String.valueOf(HttpStatus.NOT_FOUND.value()));
				responseMap.put("statusCode", String.valueOf(HttpStatus.NOT_FOUND.value()));
				responseMap.put("message", message);
				resp.setResponseMap(responseMap);
				return resp;
			}
		} else {
			resp.setStatus(String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()));
			responseMap.put("message", HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase());
			resp.setResponseMap(responseMap);
			return resp;
		}
	}

	
	/**
	 *  This method is used to Punctuate Transcript using Python API
	 * 
	 * @param transcript
	 * @param requestId
	 * @return
	 */
	private Response getTranscriptionPunctuation(final String transcript, final String requestId) {
		logger.info("Start execution of getTranscriptionPunctuation API call with requestId = " + requestId
				+ " and transcript = " + transcript);
		Map<String, String> responseMap = new HashMap<String, String>();
		Response resp = new Response();
		ResponseEntity<String> apiResponse;
		try {
			String pythonurl = transcriptPunctuationPythonIp;
			logger.info("transcriptPunctuationPythonIp : " + pythonurl);
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<String, String>();
			multiValueMap.add("transcript", transcript);
			multiValueMap.add("transcript_id", requestId);
			HttpEntity<MultiValueMap<String, String>> apiRequest = new HttpEntity<MultiValueMap<String, String>>(
					multiValueMap, headers);
			apiResponse = akilaRestTemplate.postForEntity(restTemplate, pythonurl, apiRequest, String.class);
		} catch (RestClientException restClientException) {
			logger.info("Exception occoured inside getTranscriptionPunctuation " + restClientException);
			resp.setStatus(String.valueOf(HttpStatus.GATEWAY_TIMEOUT.value()));
			responseMap.put("message", HttpStatus.GATEWAY_TIMEOUT.getReasonPhrase());
			resp.setResponseMap(responseMap);
			return resp;
		} catch (Exception e) {
			logger.info("Exception occoured inside getTranscriptionPunctuation " + e);
			resp.setStatus(String.valueOf(HttpStatus.GATEWAY_TIMEOUT.value()));
			responseMap.put("message", HttpStatus.GATEWAY_TIMEOUT.getReasonPhrase());
			resp.setResponseMap(responseMap);
			return resp;
		}
		logger.info("End of execution of getTranscriptionPunctuation API call with  requestId = " + requestId
				+ " response is ---->" + apiResponse);
		HttpStatus status = apiResponse.getStatusCode();
		if (status.equals(HttpStatus.OK)) {
			String data = null, responseStatus = null,  punctuation = null;
			JSONObject json, dataJson;
			try {
				json = new JSONObject(apiResponse.getBody());
				responseStatus = json.getString("status");
				data = json.getString("data");
				dataJson = new JSONObject(data);
				if (responseStatus.equalsIgnoreCase("true")) {
						resp.setStatus(String.valueOf(HttpStatus.OK.value()));
						punctuation = dataJson.getString("punctuation");
						responseMap.put("transcript", punctuation);
						resp.setResponseMap(responseMap);
				}
			} catch (JSONException e) {
				e.printStackTrace();
				logger.info("Exception occured while getting JSON with punctuation");
			}
			return resp;
		} else {
			resp.setStatus(String.valueOf(HttpStatus.SERVICE_UNAVAILABLE.value()));
			responseMap.put("message", HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase());
			resp.setResponseMap(responseMap);
			return resp;
		}
	}

}
